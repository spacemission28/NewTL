# TradeLogic Dashboard - Backend Integration Guide

This guide explains how to connect the TradeLogic dashboard frontend to a backend database (SQLite or any other database).

## Table of Contents
1. [Overview](#overview)
2. [Database Schema Recommendations](#database-schema-recommendations)
3. [API Endpoints to Implement](#api-endpoints-to-implement)
4. [Frontend Integration Points](#frontend-integration-points)
5. [Example Backend Implementation (Python/Flask)](#example-backend-implementation-pythonflask)
6. [Security Considerations](#security-considerations)

---

## Overview

The dashboard has been structured with clear separation between the frontend data structures and the backend API calls. The key integration points are:

1. **User Session Management** - Authenticate users and provide session data
2. **Shareholder Information** - Fetch and display shareholder details from the database
3. **Performance Data** - Retrieve investment performance metrics
4. **Document Management** - Serve the Shareholders Agreement PDF

---

## Database Schema Recommendations

### SQLite Schema

```sql
-- Users table for authentication
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    display_name TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    is_active BOOLEAN DEFAULT 1
);

-- Shareholders table
CREATE TABLE shareholders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    full_name TEXT NOT NULL,
    address TEXT,
    contact_number TEXT,
    contact_email TEXT,
    share_class TEXT DEFAULT 'A Class shares',
    shares_held INTEGER DEFAULT 0,
    entry_date DATE,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Performance data table
CREATE TABLE performance_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    shareholder_id INTEGER NOT NULL,
    date DATE NOT NULL,
    nav_value DECIMAL(15, 2),
    monthly_growth_pct DECIMAL(5, 2),
    total_return_pct DECIMAL(5, 2),
    FOREIGN KEY (shareholder_id) REFERENCES shareholders(id)
);

-- System settings table (for last update timestamps)
CREATE TABLE system_settings (
    key TEXT PRIMARY KEY,
    value TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default last update timestamp
INSERT INTO system_settings (key, value) VALUES ('shareholder_info_last_updated', datetime('now'));
```

---

## API Endpoints to Implement

### 1. Authentication Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/auth/login-step-1` | POST | Validate email/password, initiate 2FA |
| `/api/auth/login-step-2` | POST | Verify 2FA code, create session |
| `/api/auth/logout` | POST | Destroy user session |
| `/api/auth/session` | GET | Get current user session info |

### 2. Shareholder Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/shareholder/info` | GET | Get shareholder details |
| `/api/shareholder/update` | PUT | Update shareholder contact info |
| `/api/shareholder/last-updated` | GET | Get last update timestamp |

### 3. Performance Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/performance/personal` | GET | Get personal performance data |
| `/api/performance/fund` | GET | Get fund-wide performance data |

### 4. Document Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/documents/shareholders-agreement` | GET | Download/view shareholders agreement |

---

## Frontend Integration Points

### JavaScript Configuration Object

Located in `dashboard.html`, the `API_CONFIG` object defines all API endpoints:

```javascript
const API_CONFIG = {
    baseUrl: '/api',
    endpoints: {
        getShareholderInfo: '/shareholder/info',
        getShareholderAgreement: '/shareholder/agreement',
        updateShareholderInfo: '/shareholder/update',
        getUserSession: '/auth/session'
    }
};
```

### Data Structure

The `shareholderData` object in `dashboard.html` maps directly to database fields:

```javascript
const shareholderData = {
    name: "Warren Lum",              // From shareholders.full_name
    address: "123 Financial...",     // From shareholders.address
    contactNumber: "+61 412...",     // From shareholders.contact_number
    contactEmail: "warrenlum@...",   // From shareholders.contact_email
    shareClass: "A Class shares",    // From shareholders.share_class
    sharesHeld: 15000,               // From shareholders.shares_held
    userDisplayName: "Warren Lum",   // From users.display_name
    userEmail: "warrenlum@..."       // From users.email
};
```

### Helper Functions (Ready to Use)

The following functions are already implemented and just need to be uncommented when your backend is ready:

1. **`fetchShareholderDataFromDB()`** - Fetches shareholder info from `/api/shareholder/info`
2. **`fetchUserSessionFromDB()`** - Fetches user session from `/api/auth/session`
3. **`getInfoLastUpdatedDate()`** - Gets the last update date (currently uses system date)

---

## Example Backend Implementation (Python/Flask)

Here's a complete example of how to implement the backend using Flask and SQLite:

```python
from flask import Flask, request, jsonify, session, send_file
from flask_cors import CORS
import sqlite3
import hashlib
import secrets
from datetime import datetime
import os

app = Flask(__name__)
app.secret_key = secrets.token_hex(32)  # Change this in production!
CORS(app)

DATABASE = 'tradelogic.db'

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

# ============================================
# AUTHENTICATION ENDPOINTS
# ============================================

@app.route('/api/auth/session', methods=['GET'])
def get_session():
    """Get current user session info"""
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT u.display_name, u.email, s.full_name 
        FROM users u 
        LEFT JOIN shareholders s ON u.id = s.user_id 
        WHERE u.id = ?
    ''', (session['user_id'],))
    user = cursor.fetchone()
    conn.close()
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    return jsonify({
        'displayName': user['display_name'],
        'email': user['email'],
        'fullName': user['full_name']
    })

@app.route('/api/auth/login-step-1', methods=['POST'])
def login_step_1():
    """Validate credentials and initiate 2FA"""
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')
    
    # Hash password (use bcrypt in production!)
    password_hash = hashlib.sha256(password.encode()).hexdigest()
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        'SELECT id FROM users WHERE email = ? AND password_hash = ? AND is_active = 1',
        (email, password_hash)
    )
    user = cursor.fetchone()
    conn.close()
    
    if user:
        # Store user ID temporarily for step 2
        session['pending_user_id'] = user['id']
        # TODO: Send 2FA code via SMS/email
        return jsonify({'success': True, 'message': '2FA code sent'})
    
    return jsonify({'error': 'Invalid credentials'}), 401

@app.route('/api/auth/login-step-2', methods=['POST'])
def login_step_2():
    """Verify 2FA code and create session"""
    data = request.get_json()
    sms_code = data.get('sms_code')
    
    # TODO: Validate 2FA code against stored/expected code
    # For demo purposes, accept any 6-digit code
    if len(sms_code) == 6 and sms_code.isdigit():
        session['user_id'] = session.pop('pending_user_id', None)
        
        # Update last login
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute(
            'UPDATE users SET last_login = ? WHERE id = ?',
            (datetime.now(), session['user_id'])
        )
        conn.commit()
        conn.close()
        
        return jsonify({'success': True})
    
    return jsonify({'error': 'Invalid code'}), 401

@app.route('/api/auth/logout', methods=['POST'])
def logout():
    """Destroy user session"""
    session.clear()
    return jsonify({'success': True})

# ============================================
# SHAREHOLDER ENDPOINTS
# ============================================

@app.route('/api/shareholder/info', methods=['GET'])
def get_shareholder_info():
    """Get shareholder details for logged-in user"""
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT s.*, u.email as user_email, u.display_name 
        FROM shareholders s 
        JOIN users u ON s.user_id = u.id 
        WHERE u.id = ?
    ''', (session['user_id'],))
    shareholder = cursor.fetchone()
    conn.close()
    
    if not shareholder:
        return jsonify({'error': 'Shareholder not found'}), 404
    
    return jsonify({
        'name': shareholder['full_name'],
        'address': shareholder['address'],
        'contactNumber': shareholder['contact_number'],
        'contactEmail': shareholder['contact_email'],
        'shareClass': shareholder['share_class'],
        'sharesHeld': shareholder['shares_held'],
        'userDisplayName': shareholder['display_name'],
        'userEmail': shareholder['user_email']
    })

@app.route('/api/shareholder/update', methods=['PUT'])
def update_shareholder_info():
    """Update shareholder contact information"""
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE shareholders 
        SET address = ?, contact_number = ?, contact_email = ?
        WHERE user_id = ?
    ''', (
        data.get('address'),
        data.get('contactNumber'),
        data.get('contactEmail'),
        session['user_id']
    ))
    conn.commit()
    
    # Update the last updated timestamp
    cursor.execute('''
        UPDATE system_settings 
        SET value = ?, updated_at = ?
        WHERE key = 'shareholder_info_last_updated'
    ''', (datetime.now().isoformat(), datetime.now()))
    conn.commit()
    conn.close()
    
    return jsonify({'success': True})

@app.route('/api/shareholder/last-updated', methods=['GET'])
def get_last_updated():
    """Get the last update timestamp for shareholder info"""
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        'SELECT value FROM system_settings WHERE key = ?',
        ('shareholder_info_last_updated',)
    )
    result = cursor.fetchone()
    conn.close()
    
    if result:
        return jsonify({'lastUpdated': result['value']})
    
    return jsonify({'lastUpdated': datetime.now().isoformat()})

# ============================================
# PERFORMANCE ENDPOINTS
# ============================================

@app.route('/api/performance/personal', methods=['GET'])
def get_personal_performance():
    """Get personal performance data"""
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    conn = get_db()
    cursor = conn.cursor()
    
    # Get shareholder ID
    cursor.execute(
        'SELECT id FROM shareholders WHERE user_id = ?',
        (session['user_id'],)
    )
    shareholder = cursor.fetchone()
    
    if not shareholder:
        conn.close()
        return jsonify({'error': 'Shareholder not found'}), 404
    
    # Get performance data
    cursor.execute('''
        SELECT * FROM performance_data 
        WHERE shareholder_id = ?
        ORDER BY date DESC
        LIMIT 12
    ''', (shareholder['id'],))
    data = cursor.fetchall()
    conn.close()
    
    return jsonify({
        'performance': [dict(row) for row in data]
    })

@app.route('/api/performance/fund', methods=['GET'])
def get_fund_performance():
    """Get fund-wide performance data"""
    # This could be public or require auth depending on your needs
    # For now, return sample data
    return jsonify({
        'currentNAV': 42800000,
        'monthlyGrowthPct': 2.34,
        'totalReturnPct': 32.4,
        'data': [100, 105, 102, 112, 108, 115, 122, 118, 125, 120, 128, 132.4]
    })

# ============================================
# DOCUMENT ENDPOINTS
# ============================================

@app.route('/api/documents/shareholders-agreement', methods=['GET'])
def get_shareholders_agreement():
    """Serve the shareholders agreement PDF"""
    pdf_path = os.path.join(app.root_path, 'static', 'shareholders_agreement.pdf')
    return send_file(pdf_path, as_attachment=False)

@app.route('/api/documents/shareholders-agreement/download', methods=['GET'])
def download_shareholders_agreement():
    """Download the shareholders agreement PDF"""
    pdf_path = os.path.join(app.root_path, 'static', 'shareholders_agreement.pdf')
    return send_file(
        pdf_path,
        as_attachment=True,
        download_name='Tradelogic_Shareholders_Agreement.pdf'
    )

if __name__ == '__main__':
    app.run(debug=True, port=5000)
```

---

## Security Considerations

### 1. Password Hashing
Replace the simple SHA256 hashing with bcrypt:

```python
from flask_bcrypt import Bcrypt

bcrypt = Bcrypt(app)

# Hash password
password_hash = bcrypt.generate_password_hash(password).decode('utf-8')

# Check password
bcrypt.check_password_hash(stored_hash, password)
```

### 2. 2FA Implementation
Use a service like Twilio for SMS 2FA:

```python
from twilio.rest import Client

def send_2fa_code(phone_number, code):
    client = Client(twilio_sid, twilio_token)
    client.messages.create(
        body=f'Your TradeLogic verification code is: {code}',
        from_=twilio_phone,
        to=phone_number
    )
```

### 3. Session Security
Configure Flask session properly:

```python
app.config.update(
    SESSION_COOKIE_SECURE=True,      # HTTPS only
    SESSION_COOKIE_HTTPONLY=True,    # Prevent XSS
    SESSION_COOKIE_SAMESITE='Lax',   # CSRF protection
    PERMANENT_SESSION_LIFETIME=3600  # 1 hour timeout
)
```

### 4. Input Validation
Always validate and sanitize user inputs:

```python
from marshmallow import Schema, fields, validate

class ShareholderUpdateSchema(Schema):
    address = fields.String(required=True, validate=validate.Length(max=500))
    contactNumber = fields.String(validate=validate.Regexp(r'^\+?[\d\s-]+$'))
    contactEmail = fields.Email(required=True)
```

### 5. Rate Limiting
Prevent brute force attacks:

```python
from flask_limiter import Limiter

limiter = Limiter(app, key_func=lambda: request.form.get('email', request.remote_addr))

@app.route('/api/auth/login-step-1', methods=['POST'])
@limiter.limit("5 per minute")
def login_step_1():
    ...
```

---

## Next Steps

1. **Set up your database** using the schema provided above
2. **Implement the API endpoints** using your preferred backend framework
3. **Update the frontend** by uncommenting the database fetch functions in `dashboard.html`
4. **Test thoroughly** before deploying to production
5. **Consider adding** additional features like:
   - Email notifications for performance reports
   - Buy-back request workflow
   - Historical transaction viewing
   - Admin panel for managing shareholders

---

## Files Modified/Created

| File | Description |
|------|-------------|
| `dashboard.html` | Updated with Shareholder Information page, PDF viewer, and database integration helpers |
| `static/shareholders_agreement.pdf` | Placeholder PDF document |
| `BACKEND_INTEGRATION_GUIDE.md` | This guide |

---

For any questions or issues, refer to the code comments in `dashboard.html` which indicate where database integration points are located.
