package com.tradelogic.models;

import java.util.List;

public class PendingOcoGroup {
    private long magicNumber;
    private String symbol;
    private long timestamp;
    private boolean cleanupAttempted;
    private int checkCount;
    private List<String> orderTickets;

    public PendingOcoGroup(long magicNumber, String symbol, List<String> orderTickets) {
        this.magicNumber = magicNumber;
        this.symbol = symbol;
        this.orderTickets = orderTickets;
        this.timestamp = System.currentTimeMillis();
        this.cleanupAttempted = false;
        this.checkCount = 0;
    }

    public long getMagicNumber() {
        return magicNumber;
    }

    public void setMagicNumber(long magicNumber) {
        this.magicNumber = magicNumber;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public boolean isCleanupAttempted() {
        return cleanupAttempted;
    }

    public void setCleanupAttempted(boolean cleanupAttempted) {
        this.cleanupAttempted = cleanupAttempted;
    }

    public int getCheckCount() {
        return checkCount;
    }

    public void incrementCheckCount() {
        this.checkCount++;
    }

    public List<String> getOrderTickets() {
        return orderTickets;
    }

    public void setOrderTickets(List<String> orderTickets) {
        this.orderTickets = orderTickets;
    }

    @Override
    public String toString() {
        return String.format("PendingOcoGroup{magic=%d, symbol='%s', tickets=%d, checks=%d, cleanup=%s}",
            magicNumber, symbol, orderTickets.size(), checkCount, cleanupAttempted);
    }
}
