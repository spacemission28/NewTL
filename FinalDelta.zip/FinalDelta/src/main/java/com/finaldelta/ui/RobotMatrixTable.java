package com.finaldelta.ui;

import com.finaldelta.Logger;
import com.finaldelta.models.RobotConfig;
import com.finaldelta.models.RobotState;
import com.finaldelta.models.SystemConfig;
import com.finaldelta.services.DatabaseClient;
import com.finaldelta.services.DatabaseFactory;
import com.finaldelta.services.FileDataReader;
import com.finaldelta.ui.NumberConverters.DoubleNumberConverter;
import com.finaldelta.ui.NumberConverters.IntegerNumberConverter;
import javafx.application.Platform;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.util.StringConverter;
import javafx.util.converter.DoubleStringConverter;
import javafx.util.converter.IntegerStringConverter;

import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.google.gson.*;
import java.lang.reflect.Type;
import java.time.Instant;

public class RobotMatrixTable extends BorderPane {

    private final TableView<RobotRow> tableView;
    private final ObservableList<RobotRow> robotRows;
    private final UUID userId;
    private DatabaseClient dbClient;
    private SystemConfig systemConfig;
    private ControlPanelPane controlPanel;
    private Map<Integer, RobotConfig> savedConfigs;
    private String lastClickedColumnName;
    private double accountBalance = 0.0;
    private Set<Integer> lockedRows = new HashSet<>();
    private FileDataReader dataReader;
    private ObservableList<String> availableSymbols = FXCollections.observableArrayList();
    private Runnable onConfigurationChangedCallback;

    public static class RobotRow {
        private final IntegerProperty rowNumber;
        private final BooleanProperty active;
        private final StringProperty magicNumber;
        private final StringProperty robotName;
        private final StringProperty symbol;
        private final StringProperty timeframe;
        private final IntegerProperty startHour;
        private final IntegerProperty startMinute;
        private final DoubleProperty minX1Height;
        private final StringProperty x1Type;
        private final DoubleProperty trigPercent;
        private final DoubleProperty stopLossPercent;
        private final DoubleProperty rptPercent;
        private final DoubleProperty rptFixedAmount;
        private final DoubleProperty tp1Percent;
        private final IntegerProperty tp1Volume;
        private final DoubleProperty tp2Percent;
        private final IntegerProperty tp2Volume;
        private final DoubleProperty tp3Percent;
        private final IntegerProperty tp3Volume;
        private final IntegerProperty profitCandleLimit;
        private final BooleanProperty commissionsEnabled;
        private final StringProperty commissionType;
        private final DoubleProperty commissionValue;
        private final BooleanProperty disableLeapfrog;
        private final BooleanProperty smartTsEnabled;
        private final BooleanProperty eodEnabled;
        private final IntegerProperty endHour;
        private final IntegerProperty endMinute;
        private final BooleanProperty x2StrictEnabled;
        private final BooleanProperty x2RelaxedEnabled;
        private final BooleanProperty x3StrictEnabled;
        private final BooleanProperty x3RelaxedEnabled;
        private final BooleanProperty trendCheckEnabled;
        private final BooleanProperty bounceCheckEnabled;
        private final StringProperty status;
        private final StringProperty lastSignal;
        private final StringProperty activeTrade;
        private final DoubleProperty profitLoss;

        private UUID robotConfigId;
        private boolean isPlaceholder;
        private boolean hasBeenManuallyModified;

        public RobotRow(int rowNumber) {
            this.rowNumber = new SimpleIntegerProperty(rowNumber);
            this.active = new SimpleBooleanProperty(false);
            this.magicNumber = new SimpleStringProperty("");
            this.robotName = new SimpleStringProperty("");
            this.symbol = new SimpleStringProperty("");
            this.timeframe = new SimpleStringProperty("");
            this.startHour = new SimpleIntegerProperty(0);
            this.startMinute = new SimpleIntegerProperty(0);
            this.minX1Height = new SimpleDoubleProperty(0.0);
            this.x1Type = new SimpleStringProperty("");
            this.trigPercent = new SimpleDoubleProperty(0.0);
            this.stopLossPercent = new SimpleDoubleProperty(0.0);
            this.rptPercent = new SimpleDoubleProperty(0.0);
            this.rptFixedAmount = new SimpleDoubleProperty(0.0);
            this.tp1Percent = new SimpleDoubleProperty(0.0);
            this.tp1Volume = new SimpleIntegerProperty(0);
            this.tp2Percent = new SimpleDoubleProperty(0.0);
            this.tp2Volume = new SimpleIntegerProperty(0);
            this.tp3Percent = new SimpleDoubleProperty(0.0);
            this.tp3Volume = new SimpleIntegerProperty(0);
            this.profitCandleLimit = new SimpleIntegerProperty(0);
            this.commissionsEnabled = new SimpleBooleanProperty(false);
            this.commissionType = new SimpleStringProperty("No_Commissions");
            this.commissionValue = new SimpleDoubleProperty(0.0);
            this.disableLeapfrog = new SimpleBooleanProperty(false);
            this.smartTsEnabled = new SimpleBooleanProperty(false);
            this.eodEnabled = new SimpleBooleanProperty(false);
            this.endHour = new SimpleIntegerProperty(23);
            this.endMinute = new SimpleIntegerProperty(50);
            this.x2StrictEnabled = new SimpleBooleanProperty(false);
            this.x2RelaxedEnabled = new SimpleBooleanProperty(false);
            this.x3StrictEnabled = new SimpleBooleanProperty(false);
            this.x3RelaxedEnabled = new SimpleBooleanProperty(false);
            this.trendCheckEnabled = new SimpleBooleanProperty(false);
            this.bounceCheckEnabled = new SimpleBooleanProperty(false);
            this.status = new SimpleStringProperty("⚪");
            this.lastSignal = new SimpleStringProperty("--");
            this.activeTrade = new SimpleStringProperty("--");
            this.profitLoss = new SimpleDoubleProperty(0.0);
            this.isPlaceholder = true;
            this.hasBeenManuallyModified = false;
        }

        // Getters for properties
        public IntegerProperty rowNumberProperty() { return rowNumber; }
        public BooleanProperty activeProperty() { return active; }
        public StringProperty magicNumberProperty() { return magicNumber; }
        public StringProperty robotNameProperty() { return robotName; }
        public StringProperty symbolProperty() { return symbol; }
        public StringProperty timeframeProperty() { return timeframe; }
        public IntegerProperty startHourProperty() { return startHour; }
        public IntegerProperty startMinuteProperty() { return startMinute; }
        public DoubleProperty minX1HeightProperty() { return minX1Height; }
        public StringProperty x1TypeProperty() { return x1Type; }
        public DoubleProperty trigPercentProperty() { return trigPercent; }
        public DoubleProperty stopLossPercentProperty() { return stopLossPercent; }
        public DoubleProperty rptPercentProperty() { return rptPercent; }
        public DoubleProperty rptFixedAmountProperty() { return rptFixedAmount; }
        public DoubleProperty tp1PercentProperty() { return tp1Percent; }
        public IntegerProperty tp1VolumeProperty() { return tp1Volume; }
        public DoubleProperty tp2PercentProperty() { return tp2Percent; }
        public IntegerProperty tp2VolumeProperty() { return tp2Volume; }
        public DoubleProperty tp3PercentProperty() { return tp3Percent; }
        public IntegerProperty tp3VolumeProperty() { return tp3Volume; }
        public IntegerProperty profitCandleLimitProperty() { return profitCandleLimit; }
        public BooleanProperty commissionsEnabledProperty() { return commissionsEnabled; }
        public StringProperty commissionTypeProperty() { return commissionType; }
        public DoubleProperty commissionValueProperty() { return commissionValue; }
        public BooleanProperty disableLeapfrogProperty() { return disableLeapfrog; }
        public BooleanProperty smartTsEnabledProperty() { return smartTsEnabled; }
        public BooleanProperty eodEnabledProperty() { return eodEnabled; }
        public IntegerProperty endHourProperty() { return endHour; }
        public IntegerProperty endMinuteProperty() { return endMinute; }
        public BooleanProperty x2StrictEnabledProperty() { return x2StrictEnabled; }
        public BooleanProperty x2RelaxedEnabledProperty() { return x2RelaxedEnabled; }
        public BooleanProperty x3StrictEnabledProperty() { return x3StrictEnabled; }
        public BooleanProperty x3RelaxedEnabledProperty() { return x3RelaxedEnabled; }
        public BooleanProperty trendCheckEnabledProperty() { return trendCheckEnabled; }
        public BooleanProperty bounceCheckEnabledProperty() { return bounceCheckEnabled; }
        public StringProperty statusProperty() { return status; }
        public StringProperty lastSignalProperty() { return lastSignal; }
        public StringProperty activeTradeProperty() { return activeTrade; }
        public DoubleProperty profitLossProperty() { return profitLoss; }

        public UUID getRobotConfigId() { return robotConfigId; }
        public void setRobotConfigId(UUID id) { this.robotConfigId = id; }
        public boolean isPlaceholder() { return isPlaceholder; }
        public void setPlaceholder(boolean placeholder) { isPlaceholder = placeholder; }
        public boolean hasBeenManuallyModified() { return hasBeenManuallyModified; }
        public void setManuallyModified(boolean modified) { hasBeenManuallyModified = modified; }

        // Setters for editable properties
        public void setActive(boolean value) { this.active.set(value); }
        public void setCommissionsEnabled(boolean value) { this.commissionsEnabled.set(value); }
        public void setDisableLeapfrog(boolean value) { this.disableLeapfrog.set(value); }
        public void setSmartTsEnabled(boolean value) { this.smartTsEnabled.set(value); }
        public void setEodEnabled(boolean value) { this.eodEnabled.set(value); }
        public void setX2StrictEnabled(boolean value) { this.x2StrictEnabled.set(value); }
        public void setX2RelaxedEnabled(boolean value) { this.x2RelaxedEnabled.set(value); }
        public void setX3StrictEnabled(boolean value) { this.x3StrictEnabled.set(value); }
        public void setX3RelaxedEnabled(boolean value) { this.x3RelaxedEnabled.set(value); }
        public void setTrendCheckEnabled(boolean value) { this.trendCheckEnabled.set(value); }
        public void setBounceCheckEnabled(boolean value) { this.bounceCheckEnabled.set(value); }

        public boolean isBounceCheckEnabled() { return bounceCheckEnabled.get(); }

        /**
         * Gets the effective magic number to use.
         * Returns null if no valid magic number is available.
         */
        public String getEffectiveMagicNumber() {
            String magic = magicNumber.get();
            return (magic != null && !magic.isEmpty()) ? magic : null;
        }

        public void updateFromConfig(RobotConfig config) {
            this.robotConfigId = config.getId();
            this.active.set(config.isActive());
            this.magicNumber.set(config.getMagicNumber() != null ? config.getMagicNumber() : "");
            this.robotName.set(config.getRobotName());
            this.symbol.set(config.getSymbol());
            this.timeframe.set(config.getTimeframe());
            this.startHour.set(config.getStartHour());
            this.startMinute.set(config.getStartMinute());
            this.minX1Height.set(config.getMinX1Height());
            this.x1Type.set(config.getX1Type());
            this.trigPercent.set(config.getTrigPercent());
            this.stopLossPercent.set(config.getStopLossPercent());
            this.rptPercent.set(config.getRptPercent());
            this.rptFixedAmount.set(config.getRptFixedAmount());
            this.tp1Percent.set(config.getTp1Percent());
            this.tp1Volume.set(config.getTp1Volume());
            this.tp2Percent.set(config.getTp2Percent());
            this.tp2Volume.set(config.getTp2Volume());
            this.tp3Percent.set(config.getTp3Percent());
            this.tp3Volume.set(config.getTp3Volume());
            this.profitCandleLimit.set(config.getProfitCandleLimit());
            this.commissionsEnabled.set(config.isCommissionsEnabled());
            this.commissionType.set(config.getCommissionType() != null ? config.getCommissionType() : "No_Commissions");
            this.commissionValue.set(config.getCommissionValue());
            this.disableLeapfrog.set(config.isDisableLeapfrog());
            this.smartTsEnabled.set(config.isSmartTsEnabled());
            this.eodEnabled.set(config.isEndTimeEnabled());
            this.endHour.set(config.getEndHour());
            this.endMinute.set(config.getEndMinute());
            this.x2StrictEnabled.set(config.isX2StrictEnabled());
            this.x2RelaxedEnabled.set(config.isX2RelaxedEnabled());
            this.x3StrictEnabled.set(config.isX3StrictEnabled());
            this.x3RelaxedEnabled.set(config.isX3RelaxedEnabled());
            this.trendCheckEnabled.set(config.isTrendCheckEnabled());
            this.bounceCheckEnabled.set(config.isBounceCheckEnabled());
            this.eodEnabled.set(config.isEndTimeEnabled());
            this.isPlaceholder = false;
            // When loading from database, mark as manually modified to prevent defaults from applying
            this.hasBeenManuallyModified = true;
        }

        public void updateFromState(RobotState state) {
            if (state == null) return;
            this.status.set(state.getStatusEmoji());
            this.lastSignal.set(state.getLastSignalDate() != null ?
                state.getLastSignalDate().toString() : "--");
            this.activeTrade.set(state.getActivePositionTicket() != null ?
                "#" + state.getActivePositionTicket() : "--");
            this.profitLoss.set(state.getCurrentProfitLoss());
        }
    }

    public RobotMatrixTable(UUID userId) {
        this.userId = userId;
        this.robotRows = FXCollections.observableArrayList();
        this.tableView = new TableView<>();
        this.dbClient = DatabaseFactory.getInstance();
        this.systemConfig = new SystemConfig();
        this.systemConfig.setUserId(userId);
        this.savedConfigs = new HashMap<>();
        this.controlPanel = new ControlPanelPane(userId, systemConfig, this, this::saveLayout, this::loadLayout, this::saveDefaultValues);

        initialize();
        loadRobots();
        startSystemStatsUpdater();
        setupMasterTradingListener();
    }

    /**
     * Starts a background thread to update system-wide stats (active robots, total RPT)
     */
    private void startSystemStatsUpdater() {
        java.util.concurrent.Executors.newScheduledThreadPool(1).scheduleAtFixedRate(() -> {
            try {
                updateSystemStats();
            } catch (Exception e) {
                Logger.error("Error updating system stats: " + e.getMessage());
            }
        }, 1, 2, java.util.concurrent.TimeUnit.SECONDS);
    }

    /**
     * Calculates and updates system-wide statistics
     */
    private void updateSystemStats() {
        int activeCount = 0;
        double totalRptDollars = 0.0;
        // Use the accountBalance field (updated from TickRecorderApplication)

        for (RobotRow row : robotRows) {
            if (row.active.get()) {
                activeCount++;
                // Calculate RPT for this robot in dollar terms
                double rptPercent = row.rptPercent.get();
                double rptFixed = row.rptFixedAmount.get();

                if (rptFixed > 0) {
                    // Use fixed RPT dollar amount
                    totalRptDollars += rptFixed;
                } else if (rptPercent > 0 && accountBalance > 0) {
                    // Convert RPT percentage to dollar amount based on account balance
                    double robotRpt = accountBalance * rptPercent / 100.0;
                    totalRptDollars += robotRpt;
                    Logger.info(String.format("Robot row %d: RPT %.2f%% of balance %.2f = $%.2f",
                        row.rowNumber.get(), rptPercent, accountBalance, robotRpt));
                }
            }
        }

        Logger.info(String.format("Total RPT calculated: $%.2f from %d active robots (Account Balance: $%.2f)",
            totalRptDollars, activeCount, accountBalance));

        systemConfig.setActiveRobotsCount(activeCount);
        systemConfig.setTotalRptAcrossRobots(totalRptDollars);
    }

    private void setupMasterTradingListener() {
        controlPanel.addMasterStateListener((observable, oldValue, newValue) -> {
            tableView.refresh();
        });
    }

    private void setTableEditable(boolean editable) {
        for (TableColumn<RobotRow, ?> column : tableView.getColumns()) {
            setColumnEditable(column, editable);
        }
    }

    private void setColumnEditable(TableColumn<RobotRow, ?> column, boolean editable) {
        String columnText = column.getText();
        if (!"#".equals(columnText) && !"Status".equals(columnText) &&
            !"Last Signal".equals(columnText) && !"Active Trade".equals(columnText) &&
            !"P/L".equals(columnText)) {
            column.setEditable(editable);
        }
        for (TableColumn<RobotRow, ?> nestedCol : column.getColumns()) {
            setColumnEditable(nestedCol, editable);
        }
    }

    private void initialize() {
        tableView.setItems(robotRows);
        tableView.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);
        tableView.setEditable(true);

        // Apply row factory for conditional styling
        tableView.setRowFactory(tv -> {
            TableRow<RobotRow> row = new TableRow<>() {
                @Override
                protected void updateItem(RobotRow item, boolean empty) {
                    super.updateItem(item, empty);

                    if (item == null || empty) {
                        setStyle("");
                        setContextMenu(null);
                    } else {
                        // Listen to active property changes
                        item.activeProperty().addListener((obs, oldVal, newVal) -> {
                            if (newVal) {
                                setStyle("-fx-background-color: #ffcccc;");
                            } else {
                                setStyle("");
                            }
                        });

                        // Set initial style
                        if (item.activeProperty().get()) {
                            setStyle("-fx-background-color: #ffcccc;");
                        } else {
                            setStyle("");
                        }

                        // Add context menu for right-click actions
                        setContextMenu(createRowContextMenu(item, ""));
                    }
                }
            };
            return row;
        });

        // Create columns
        createRowNumberColumn();
        createActiveColumn();
        createMagicNumberColumn();
        createRobotNameColumn();
        createSymbolColumn();
        createTimeframeColumn();
        createStartHourColumn();
        createStartMinuteColumn();
        createEodEnabledColumn();
        createEndHourColumn();
        createEndMinuteColumn();
        createMinX1HeightColumn();
        createX1TypeColumn();
        createTrigPercentColumn();
        createStopLossPercentColumn();
        createRptPercentColumn();
        createRptFixedAmountColumn();
        createTPColumns();
        createCommissionsEnabledColumn();
        createCommissionTypeColumn();
        createCommissionValueColumn();
        createDisableLeapfrogColumn();
        createSmartTsColumn();
        createX2StrictColumn();
        createX2RelaxedColumn();
        createX3StrictColumn();
        createX3RelaxedColumn();
        createTrendCheckColumn();
        createBounceCheckColumn();
        createProfitCandleLimitColumn();
        // Removed placeholder columns that never update:
        // createStatusColumn();
        // createLastSignalColumn();
        // createActiveTradeColumn();

        // Add listener to commit edits when focus changes
        tableView.editingCellProperty().addListener((obs, oldCell, newCell) -> {
            if (oldCell != null && newCell == null) {
                // Edit was canceled, but that's normal when moving between cells
                Logger.info("Table editing stopped");
            }
        });

        // Add listener to commit edit when clicking outside the table
        tableView.focusedProperty().addListener((obs, wasFocused, isNowFocused) -> {
            if (wasFocused && !isNowFocused) {
                // Table lost focus, commit any pending edits
                tableView.getSelectionModel().clearSelection();
                Logger.info("Table lost focus");
            }
        });

        setPadding(new Insets(10));
        setCenter(tableView);
        setRight(controlPanel);

        controlPanel.setOnSaveLayoutCallback(this::saveLayout);
        controlPanel.setOnSetDefaultsCallback(this::showSetDefaultsDialog);

        Logger.info("RobotMatrixTable initialized with 500 rows and control panel");
    }

    private void createRowNumberColumn() {
        TableColumn<RobotRow, Number> col = new TableColumn<>("#");
        col.setCellValueFactory(cellData -> cellData.getValue().rowNumberProperty());
        col.setEditable(false);
        col.setMinWidth(50);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createActiveColumn() {
        TableColumn<RobotRow, Boolean> col = new TableColumn<>("✓");
        col.setCellValueFactory(cellData -> cellData.getValue().activeProperty());
        col.setCellFactory(column -> {
            TableCell<RobotRow, Boolean> cell = new TableCell<RobotRow, Boolean>() {
                private final CheckBox checkBox = new CheckBox();

                {
                    checkBox.setAllowIndeterminate(false);
                    checkBox.selectedProperty().addListener((obs, oldVal, newVal) -> {
                        if (getIndex() >= 0 && getIndex() < getTableView().getItems().size()) {
                            RobotRow row = getTableView().getItems().get(getIndex());
                            row.setActive(newVal);
                        }
                    });
                }

                @Override
                protected void updateItem(Boolean item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setGraphic(null);
                    } else {
                        checkBox.setSelected(item);
                        setGraphic(checkBox);
                    }
                }
            };
            attachContextMenu(cell);
            return cell;
        });
        col.setEditable(true);
        col.setMinWidth(40);
        tableView.getColumns().add(col);
    }

    private void createMagicNumberColumn() {
        TableColumn<RobotRow, String> col = new TableColumn<>("Magic #");
        col.setCellValueFactory(cellData -> cellData.getValue().magicNumberProperty());
        col.setCellFactory(column -> {
            TableCell<RobotRow, String> cell = new TableCell<RobotRow, String>() {
                private TextField textField;
                private RobotRow currentRow = null;

                @Override
                protected void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);

                    if (empty || getTableRow() == null || getTableRow().getItem() == null) {
                        setText(null);
                        setGraphic(null);
                        setStyle("");
                        if (currentRow != null) {
                            currentRow = null;
                        }
                        return;
                    }

                    RobotRow row = (RobotRow) getTableRow().getItem();

                    if (isEditing()) {
                        if (textField == null) {
                            textField = new TextField();
                            textField.setOnAction(e -> commitEdit(textField.getText()));
                            textField.focusedProperty().addListener((obs, wasFocused, isNowFocused) -> {
                                if (!isNowFocused) {
                                    commitEdit(textField.getText());
                                }
                            });
                        }
                        textField.setText(item == null ? "" : item);
                        setText(null);
                        setGraphic(textField);
                        textField.requestFocus();
                        textField.selectAll();
                    } else {
                        setText(item == null ? "" : item);
                        setGraphic(null);
                        setStyle("-fx-alignment: CENTER;");
                        setTooltip(null);
                    }
                }

                @Override
                public void startEdit() {
                    super.startEdit();
                    updateItem(getItem(), isEmpty());
                }

                @Override
                public void commitEdit(String newValue) {
                    super.commitEdit(newValue == null ? "" : newValue.trim());
                }

                @Override
                public void cancelEdit() {
                    super.cancelEdit();
                    updateItem(getItem(), isEmpty());
                }
            };
            attachContextMenu(cell);
            return cell;
        });
        col.setEditable(true);

        // Handle edit commit to mark row as non-placeholder
        col.setOnEditCommit(event -> {
            RobotRow row = event.getRowValue();
            if (row != null && event.getNewValue() != null) {
                row.magicNumber.set(event.getNewValue());
                if (row.isPlaceholder()) {
                    row.setPlaceholder(false);
                }
            }
        });

        col.setMinWidth(80);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createRobotNameColumn() {
        TableColumn<RobotRow, String> col = new TableColumn<>("Robot Name");
        col.setCellValueFactory(cellData -> cellData.getValue().robotNameProperty());
        col.setCellFactory(createEditableTextCell(new javafx.util.converter.DefaultStringConverter()));
        col.setEditable(true);
        col.setMinWidth(150);
        col.setStyle("-fx-alignment: CENTER-LEFT;");
        tableView.getColumns().add(col);
    }

    private void createSymbolColumn() {
        TableColumn<RobotRow, String> col = new TableColumn<>("Symbol");
        col.setCellValueFactory(cellData -> cellData.getValue().symbolProperty());
        col.setCellFactory(createComboBoxCell(availableSymbols));
        col.setEditable(true);
        col.setMinWidth(80);
        col.setStyle("-fx-alignment: CENTER-LEFT;");
        tableView.getColumns().add(col);
    }

    private void createTimeframeColumn() {
        TableColumn<RobotRow, String> col = new TableColumn<>("TF");
        col.setCellValueFactory(cellData -> cellData.getValue().timeframeProperty());

        ObservableList<String> timeframes = FXCollections.observableArrayList(
            "M1", "M2", "M3", "M5", "M10", "M15", "M30", "H1", "H3", "H4", "D1"
        );
        col.setCellFactory(createComboBoxCell(timeframes));
        col.setEditable(true);
        col.setMinWidth(70);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createStartHourColumn() {
        TableColumn<RobotRow, Number> col = new TableColumn<>("Start Hr");
        col.setCellValueFactory(cellData -> cellData.getValue().startHourProperty());
        col.setCellFactory(column -> {
            TableCell<RobotRow, Number> cell = new TableCell<>() {
                private final ComboBox<Integer> comboBox = new ComboBox<>();
                {
                    for (int i = 0; i <= 23; i++) {
                        comboBox.getItems().add(i);
                    }
                    comboBox.setOnAction(event -> {
                        RobotRow row = getTableRow().getItem();
                        if (row != null && comboBox.getValue() != null) {
                            Logger.info("[START HR setOnAction] Row " + row.rowNumber.get() + ": changing startHour from " + row.startHour.get() + " to " + comboBox.getValue());
                            row.startHour.set(comboBox.getValue());
                        }
                    });
                }
                @Override
                protected void updateItem(Number item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        RobotRow row = getTableRow().getItem();
                        if (row != null) {
                            Logger.info("[START HR updateItem] Row " + row.rowNumber.get() + ": item=" + item + ", row.startHour=" + row.startHour.get() + ", about to set comboBox value");
                            int actualValue = row.startHour.get();
                            comboBox.setValue(actualValue);
                        } else {
                            comboBox.setValue(item != null ? item.intValue() : 0);
                        }
                        if (row != null && systemConfig.isMasterTradingEnabled() && lockedRows.contains(row.rowNumber.get())) {
                            comboBox.setDisable(true);
                        } else {
                            comboBox.setDisable(false);
                        }
                        setGraphic(comboBox);
                    }
                }
            };
            attachContextMenu(cell);
            return cell;
        });
        col.setOnEditCommit(event -> {
            RobotRow row = event.getRowValue();
            Logger.info("[START HR setOnEditCommit] Row " + row.rowNumber.get() + ": setting startHour to " + event.getNewValue());
            row.startHour.set(event.getNewValue().intValue());
        });
        col.setEditable(true);
        col.setMinWidth(75);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createStartMinuteColumn() {
        TableColumn<RobotRow, Number> col = new TableColumn<>("Start Min");
        col.setCellValueFactory(cellData -> cellData.getValue().startMinuteProperty());
        col.setCellFactory(column -> {
            TableCell<RobotRow, Number> cell = new TableCell<>() {
                private final ComboBox<Integer> comboBox = new ComboBox<>();
                {
                    for (int i = 0; i <= 59; i++) {
                        comboBox.getItems().add(i);
                    }
                    comboBox.setOnAction(event -> {
                        RobotRow row = getTableRow().getItem();
                        if (row != null && comboBox.getValue() != null) {
                            Logger.info("[START MIN setOnAction] Row " + row.rowNumber.get() + ": changing startMinute from " + row.startMinute.get() + " to " + comboBox.getValue());
                            row.startMinute.set(comboBox.getValue());
                        }
                    });
                }
                @Override
                protected void updateItem(Number item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        RobotRow row = getTableRow().getItem();
                        if (row != null) {
                            Logger.info("[START MIN updateItem] Row " + row.rowNumber.get() + ": item=" + item + ", row.startMinute=" + row.startMinute.get() + ", about to set comboBox value");
                            int actualValue = row.startMinute.get();
                            comboBox.setValue(actualValue);
                        } else {
                            comboBox.setValue(item != null ? item.intValue() : 0);
                        }
                        if (row != null && systemConfig.isMasterTradingEnabled() && lockedRows.contains(row.rowNumber.get())) {
                            comboBox.setDisable(true);
                        } else {
                            comboBox.setDisable(false);
                        }
                        setGraphic(comboBox);
                    }
                }
            };
            attachContextMenu(cell);
            return cell;
        });
        col.setOnEditCommit(event -> {
            RobotRow row = event.getRowValue();
            Logger.info("[START MIN setOnEditCommit] Row " + row.rowNumber.get() + ": setting startMinute to " + event.getNewValue());
            row.startMinute.set(event.getNewValue().intValue());
        });
        col.setEditable(true);
        col.setMinWidth(75);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createMinX1HeightColumn() {
        TableColumn<RobotRow, Number> col = new TableColumn<>("MinX1");
        col.setCellValueFactory(cellData -> cellData.getValue().minX1HeightProperty());
        col.setCellFactory(createEditableTextCell(new DoubleNumberConverter()));
        col.setEditable(true);
        col.setMinWidth(60);
        tableView.getColumns().add(col);
    }

    private void createX1TypeColumn() {
        TableColumn<RobotRow, String> col = new TableColumn<>("X1 Type");
        col.setCellValueFactory(cellData -> cellData.getValue().x1TypeProperty());

        ObservableList<String> x1Types = FXCollections.observableArrayList(
            "Yen Pips", "Non-Yen Pips", "Cents", "Points"
        );
        col.setCellFactory(createComboBoxCell(x1Types));
        col.setEditable(true);
        col.setMinWidth(120);
        tableView.getColumns().add(col);
    }

    private void createTrigPercentColumn() {
        TableColumn<RobotRow, Number> col = new TableColumn<>("Trig%");
        col.setCellValueFactory(cellData -> cellData.getValue().trigPercentProperty());
        col.setCellFactory(createEditableTextCell(new DoubleNumberConverter()));
        col.setEditable(true);
        col.setMinWidth(60);
        tableView.getColumns().add(col);
    }

    private void createStopLossPercentColumn() {
        TableColumn<RobotRow, Number> col = new TableColumn<>("SL%");
        col.setCellValueFactory(cellData -> cellData.getValue().stopLossPercentProperty());
        col.setCellFactory(createEditableTextCell(new DoubleNumberConverter()));
        col.setEditable(true);
        col.setMinWidth(60);
        tableView.getColumns().add(col);
    }

    private void createRptPercentColumn() {
        TableColumn<RobotRow, Number> col = new TableColumn<>("RPT%");
        col.setCellValueFactory(cellData -> cellData.getValue().rptPercentProperty());
        col.setCellFactory(createEditableTextCell(new DoubleNumberConverter()));
        col.setEditable(true);
        col.setMinWidth(60);
        tableView.getColumns().add(col);
    }

    private void createRptFixedAmountColumn() {
        TableColumn<RobotRow, Number> col = new TableColumn<>("RPT$");
        col.setCellValueFactory(cellData -> cellData.getValue().rptFixedAmountProperty());
        col.setCellFactory(createEditableTextCell(new DoubleNumberConverter()));
        col.setEditable(true);
        col.setMinWidth(70);
        tableView.getColumns().add(col);
    }

    private void createTPColumns() {
        for (int i = 1; i <= 3; i++) {
            final int tpNum = i;

            TableColumn<RobotRow, Number> percentCol = new TableColumn<>("TP" + i + "%");
            percentCol.setCellFactory(createEditableTextCell(new DoubleNumberConverter()));
            percentCol.setEditable(true);
            percentCol.setMinWidth(60);

            TableColumn<RobotRow, Number> volumeCol = new TableColumn<>("TP" + i + " Vol");
            volumeCol.setCellFactory(createEditableTextCell(new IntegerNumberConverter()));
            volumeCol.setEditable(true);
            volumeCol.setMinWidth(70);
            volumeCol.setStyle("-fx-alignment: CENTER;");

            switch (tpNum) {
                case 1:
                    percentCol.setCellValueFactory(cellData -> cellData.getValue().tp1PercentProperty());
                    volumeCol.setCellValueFactory(cellData -> cellData.getValue().tp1VolumeProperty());
                    break;
                case 2:
                    percentCol.setCellValueFactory(cellData -> cellData.getValue().tp2PercentProperty());
                    volumeCol.setCellValueFactory(cellData -> cellData.getValue().tp2VolumeProperty());
                    break;
                case 3:
                    percentCol.setCellValueFactory(cellData -> cellData.getValue().tp3PercentProperty());
                    volumeCol.setCellValueFactory(cellData -> cellData.getValue().tp3VolumeProperty());
                    break;
            }

            tableView.getColumns().addAll(percentCol, volumeCol);
        }
    }

    private void createCommissionsEnabledColumn() {
        TableColumn<RobotRow, Boolean> col = new TableColumn<>("Comm Enabled");
        col.setCellValueFactory(cellData -> cellData.getValue().commissionsEnabledProperty());
        col.setCellFactory(column -> {
            TableCell<RobotRow, Boolean> cell = new TableCell<RobotRow, Boolean>() {
                private final CheckBox checkBox = new CheckBox();

                {
                    checkBox.setAllowIndeterminate(false);
                    checkBox.selectedProperty().addListener((obs, oldVal, newVal) -> {
                        if (getIndex() >= 0 && getIndex() < getTableView().getItems().size()) {
                            RobotRow row = getTableView().getItems().get(getIndex());
                            row.setCommissionsEnabled(newVal);
                        }
                    });
                }

                @Override
                protected void updateItem(Boolean item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setGraphic(null);
                    } else {
                        checkBox.setSelected(item);
                        setGraphic(checkBox);
                    }
                }
            };
            attachContextMenu(cell);
            return cell;
        });
        col.setEditable(true);
        col.setMinWidth(100);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createCommissionTypeColumn() {
        TableColumn<RobotRow, String> col = new TableColumn<>("Comm Type");
        col.setCellValueFactory(cellData -> cellData.getValue().commissionTypeProperty());
        col.setCellFactory(column -> {
            ComboBoxTableCell<RobotRow, String> cell = new ComboBoxTableCell<>("No_Commissions", "FX_per_Lot", "ETF_Stock");
            attachContextMenu(cell);
            return cell;
        });
        col.setOnEditCommit(event -> {
            RobotRow row = event.getRowValue();
            row.commissionType.set(event.getNewValue());
            Logger.info("Commission Type updated for row " + row.rowNumber.get() + ": " + event.getNewValue());
        });
        col.setEditable(true);
        col.setMinWidth(130);
        tableView.getColumns().add(col);
    }

    private void createCommissionValueColumn() {
        TableColumn<RobotRow, Number> col = new TableColumn<>("Comm Value");
        col.setCellValueFactory(cellData -> cellData.getValue().commissionValueProperty());
        col.setCellFactory(createEditableTextCell(new DoubleNumberConverter()));
        col.setEditable(true);
        col.setMinWidth(90);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createDisableLeapfrogColumn() {
        TableColumn<RobotRow, Boolean> col = new TableColumn<>("Disable Leapfrog");
        col.setCellValueFactory(cellData -> cellData.getValue().disableLeapfrogProperty());
        col.setCellFactory(column -> {
            TableCell<RobotRow, Boolean> cell = new TableCell<RobotRow, Boolean>() {
                private final CheckBox checkBox = new CheckBox();

                {
                    checkBox.setAllowIndeterminate(false);
                    checkBox.selectedProperty().addListener((obs, oldVal, newVal) -> {
                        if (getIndex() >= 0 && getIndex() < getTableView().getItems().size()) {
                            RobotRow row = getTableView().getItems().get(getIndex());
                            row.setDisableLeapfrog(newVal);
                        }
                    });
                }

                @Override
                protected void updateItem(Boolean item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setGraphic(null);
                    } else {
                        checkBox.setSelected(item);
                        setGraphic(checkBox);
                    }
                }
            };
            attachContextMenu(cell);
            return cell;
        });
        col.setEditable(true);
        col.setMinWidth(120);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createEodEnabledColumn() {
        TableColumn<RobotRow, Boolean> col = new TableColumn<>("EOD Enabled");
        col.setCellValueFactory(cellData -> cellData.getValue().eodEnabledProperty());
        col.setCellFactory(column -> {
            TableCell<RobotRow, Boolean> cell = new TableCell<RobotRow, Boolean>() {
                private final CheckBox checkBox = new CheckBox();

                {
                    checkBox.setAllowIndeterminate(false);
                    checkBox.selectedProperty().addListener((obs, oldVal, newVal) -> {
                        if (getIndex() >= 0 && getIndex() < getTableView().getItems().size()) {
                            RobotRow row = getTableView().getItems().get(getIndex());
                            row.setEodEnabled(newVal);
                        }
                    });
                }

                @Override
                protected void updateItem(Boolean item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setGraphic(null);
                    } else {
                        checkBox.setSelected(item);
                        setGraphic(checkBox);
                    }
                }
            };
            attachContextMenu(cell);
            return cell;
        });
        col.setEditable(true);
        col.setMinWidth(100);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createEndHourColumn() {
        TableColumn<RobotRow, Number> col = new TableColumn<>("End Hr");
        col.setCellValueFactory(cellData -> cellData.getValue().endHourProperty());
        col.setCellFactory(column -> {
            TableCell<RobotRow, Number> cell = new TableCell<>() {
                private final ComboBox<Integer> comboBox = new ComboBox<>();
                {
                    for (int i = 0; i <= 23; i++) {
                        comboBox.getItems().add(i);
                    }
                    comboBox.setOnAction(event -> {
                        RobotRow row = getTableRow().getItem();
                        if (row != null && comboBox.getValue() != null) {
                            Logger.info("[END HR setOnAction] Row " + row.rowNumber.get() + ": changing endHour from " + row.endHour.get() + " to " + comboBox.getValue());
                            row.endHour.set(comboBox.getValue());
                        }
                    });
                }
                @Override
                protected void updateItem(Number item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        RobotRow row = getTableRow().getItem();
                        if (row != null) {
                            comboBox.setValue(row.endHour.get());
                        } else {
                            comboBox.setValue(item != null ? item.intValue() : 23);
                        }
                        if (row != null && systemConfig.isMasterTradingEnabled() && lockedRows.contains(row.rowNumber.get())) {
                            comboBox.setDisable(true);
                        } else {
                            comboBox.setDisable(false);
                        }
                        setGraphic(comboBox);
                    }
                }
            };
            attachContextMenu(cell);
            return cell;
        });
        col.setOnEditCommit(event -> {
            RobotRow row = event.getRowValue();
            row.endHour.set(event.getNewValue().intValue());
        });
        col.setEditable(true);
        col.setMinWidth(75);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createEndMinuteColumn() {
        TableColumn<RobotRow, Number> col = new TableColumn<>("End Min");
        col.setCellValueFactory(cellData -> cellData.getValue().endMinuteProperty());
        col.setCellFactory(column -> {
            TableCell<RobotRow, Number> cell = new TableCell<>() {
                private final ComboBox<Integer> comboBox = new ComboBox<>();
                {
                    for (int i = 0; i <= 59; i++) {
                        comboBox.getItems().add(i);
                    }
                    comboBox.setOnAction(event -> {
                        RobotRow row = getTableRow().getItem();
                        if (row != null && comboBox.getValue() != null) {
                            Logger.info("[END MIN setOnAction] Row " + row.rowNumber.get() + ": changing endMinute from " + row.endMinute.get() + " to " + comboBox.getValue());
                            row.endMinute.set(comboBox.getValue());
                        }
                    });
                }
                @Override
                protected void updateItem(Number item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        RobotRow row = getTableRow().getItem();
                        if (row != null) {
                            comboBox.setValue(row.endMinute.get());
                        } else {
                            comboBox.setValue(item != null ? item.intValue() : 50);
                        }
                        if (row != null && systemConfig.isMasterTradingEnabled() && lockedRows.contains(row.rowNumber.get())) {
                            comboBox.setDisable(true);
                        } else {
                            comboBox.setDisable(false);
                        }
                        setGraphic(comboBox);
                    }
                }
            };
            attachContextMenu(cell);
            return cell;
        });
        col.setOnEditCommit(event -> {
            RobotRow row = event.getRowValue();
            row.endMinute.set(event.getNewValue().intValue());
        });
        col.setEditable(true);
        col.setMinWidth(85);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createSmartTsColumn() {
        TableColumn<RobotRow, Boolean> col = new TableColumn<>("Smart TS");
        col.setCellValueFactory(cellData -> cellData.getValue().smartTsEnabledProperty());
        col.setCellFactory(column -> {
            TableCell<RobotRow, Boolean> cell = new TableCell<RobotRow, Boolean>() {
                private final CheckBox checkBox = new CheckBox();

                {
                    checkBox.setAllowIndeterminate(false);
                    checkBox.selectedProperty().addListener((obs, oldVal, newVal) -> {
                        if (getIndex() >= 0 && getIndex() < getTableView().getItems().size()) {
                            RobotRow row = getTableView().getItems().get(getIndex());
                            row.setSmartTsEnabled(newVal);
                        }
                    });
                }

                @Override
                protected void updateItem(Boolean item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setGraphic(null);
                    } else {
                        checkBox.setSelected(item);
                        setGraphic(checkBox);
                    }
                }
            };
            attachContextMenu(cell);
            return cell;
        });
        col.setEditable(true);
        col.setMinWidth(75);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createX2StrictColumn() {
        TableColumn<RobotRow, Boolean> col = new TableColumn<>("X2 Strict");
        col.setCellValueFactory(cellData -> cellData.getValue().x2StrictEnabledProperty());
        col.setCellFactory(column -> {
            TableCell<RobotRow, Boolean> cell = new TableCell<RobotRow, Boolean>() {
                private final CheckBox checkBox = new CheckBox();

                {
                    checkBox.setAllowIndeterminate(false);
                    checkBox.selectedProperty().addListener((obs, oldVal, newVal) -> {
                        if (getIndex() >= 0 && getIndex() < getTableView().getItems().size()) {
                            RobotRow row = getTableView().getItems().get(getIndex());
                            if (newVal && !validateSingleSetupSelection(row, "X2_STRICT")) {
                                Platform.runLater(() -> checkBox.setSelected(false));
                                return;
                            }
                            row.setX2StrictEnabled(newVal);
                        }
                    });
                }

                @Override
                protected void updateItem(Boolean item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setGraphic(null);
                    } else {
                        checkBox.setSelected(item);
                        setGraphic(checkBox);
                    }
                }
            };
            attachContextMenu(cell);
            return cell;
        });
        col.setEditable(true);
        col.setMinWidth(75);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createX2RelaxedColumn() {
        TableColumn<RobotRow, Boolean> col = new TableColumn<>("X2 Relaxed");
        col.setCellValueFactory(cellData -> cellData.getValue().x2RelaxedEnabledProperty());
        col.setCellFactory(column -> {
            TableCell<RobotRow, Boolean> cell = new TableCell<RobotRow, Boolean>() {
                private final CheckBox checkBox = new CheckBox();

                {
                    checkBox.setAllowIndeterminate(false);
                    checkBox.selectedProperty().addListener((obs, oldVal, newVal) -> {
                        if (getIndex() >= 0 && getIndex() < getTableView().getItems().size()) {
                            RobotRow row = getTableView().getItems().get(getIndex());
                            if (newVal && !validateSingleSetupSelection(row, "X2_RELAXED")) {
                                Platform.runLater(() -> checkBox.setSelected(false));
                                return;
                            }
                            row.setX2RelaxedEnabled(newVal);
                        }
                    });
                }

                @Override
                protected void updateItem(Boolean item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setGraphic(null);
                    } else {
                        checkBox.setSelected(item);
                        setGraphic(checkBox);
                    }
                }
            };
            attachContextMenu(cell);
            return cell;
        });
        col.setEditable(true);
        col.setMinWidth(85);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createX3StrictColumn() {
        TableColumn<RobotRow, Boolean> col = new TableColumn<>("X3 Strict");
        col.setCellValueFactory(cellData -> cellData.getValue().x3StrictEnabledProperty());
        col.setCellFactory(column -> {
            TableCell<RobotRow, Boolean> cell = new TableCell<RobotRow, Boolean>() {
                private final CheckBox checkBox = new CheckBox();

                {
                    checkBox.setAllowIndeterminate(false);
                    checkBox.selectedProperty().addListener((obs, oldVal, newVal) -> {
                        if (getIndex() >= 0 && getIndex() < getTableView().getItems().size()) {
                            RobotRow row = getTableView().getItems().get(getIndex());
                            if (newVal && !validateSingleSetupSelection(row, "X3_STRICT")) {
                                Platform.runLater(() -> checkBox.setSelected(false));
                                return;
                            }
                            row.setX3StrictEnabled(newVal);
                        }
                    });
                }

                @Override
                protected void updateItem(Boolean item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setGraphic(null);
                    } else {
                        checkBox.setSelected(item);
                        setGraphic(checkBox);
                    }
                }
            };
            attachContextMenu(cell);
            return cell;
        });
        col.setEditable(true);
        col.setMinWidth(75);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createX3RelaxedColumn() {
        TableColumn<RobotRow, Boolean> col = new TableColumn<>("X3 Relaxed");
        col.setCellValueFactory(cellData -> cellData.getValue().x3RelaxedEnabledProperty());
        col.setCellFactory(column -> {
            TableCell<RobotRow, Boolean> cell = new TableCell<RobotRow, Boolean>() {
                private final CheckBox checkBox = new CheckBox();

                {
                    checkBox.setAllowIndeterminate(false);
                    checkBox.selectedProperty().addListener((obs, oldVal, newVal) -> {
                        if (getIndex() >= 0 && getIndex() < getTableView().getItems().size()) {
                            RobotRow row = getTableView().getItems().get(getIndex());
                            if (newVal && !validateSingleSetupSelection(row, "X3_RELAXED")) {
                                Platform.runLater(() -> checkBox.setSelected(false));
                                return;
                            }
                            row.setX3RelaxedEnabled(newVal);
                        }
                    });
                }

                @Override
                protected void updateItem(Boolean item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setGraphic(null);
                    } else {
                        checkBox.setSelected(item);
                        setGraphic(checkBox);
                    }
                }
            };
            attachContextMenu(cell);
            return cell;
        });
        col.setEditable(true);
        col.setMinWidth(85);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createTrendCheckColumn() {
        TableColumn<RobotRow, Boolean> col = new TableColumn<>("Trend");
        col.setCellValueFactory(cellData -> cellData.getValue().trendCheckEnabledProperty());
        col.setCellFactory(column -> {
            TableCell<RobotRow, Boolean> cell = new TableCell<RobotRow, Boolean>() {
                private final CheckBox checkBox = new CheckBox();

                {
                    checkBox.setAllowIndeterminate(false);
                    checkBox.selectedProperty().addListener((obs, oldVal, newVal) -> {
                        if (getIndex() >= 0 && getIndex() < getTableView().getItems().size()) {
                            RobotRow row = getTableView().getItems().get(getIndex());
                            row.setTrendCheckEnabled(newVal);
                        }
                    });
                }

                @Override
                protected void updateItem(Boolean item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setGraphic(null);
                    } else {
                        checkBox.setSelected(item);
                        setGraphic(checkBox);
                    }
                }
            };
            attachContextMenu(cell);
            return cell;
        });
        col.setEditable(true);
        col.setMinWidth(60);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createBounceCheckColumn() {
        TableColumn<RobotRow, Boolean> col = new TableColumn<>("Bounce");
        col.setCellValueFactory(cellData -> cellData.getValue().bounceCheckEnabledProperty());
        col.setCellFactory(column -> {
            TableCell<RobotRow, Boolean> cell = new TableCell<RobotRow, Boolean>() {
                private final CheckBox checkBox = new CheckBox();
                private boolean updating = false;

                {
                    checkBox.setAllowIndeterminate(false);
                    checkBox.selectedProperty().addListener((obs, oldVal, newVal) -> {
                        if (updating) {
                            return;
                        }

                        RobotRow row = getTableRow() != null ? getTableRow().getItem() : null;
                        if (row == null) {
                            return;
                        }
                        if (RobotMatrixTable.this.isRowLockedForEditing(row)) {
                            return;
                        }
                        row.setBounceCheckEnabled(newVal);
                        RobotMatrixTable.this.markRowConfiguredByUser(row);
                    });
                }

                @Override
                protected void updateItem(Boolean item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setGraphic(null);
                    } else {
                        RobotRow row = getTableRow() != null ? getTableRow().getItem() : null;
                        updating = true;
                        try {
                            checkBox.setSelected(item);
                            checkBox.setDisable(RobotMatrixTable.this.isRowLockedForEditing(row));
                        } finally {
                            updating = false;
                        }
                        setGraphic(checkBox);
                    }
                }
            };
            attachContextMenu(cell);
            return cell;
        });
        col.setEditable(true);
        col.setMinWidth(70);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createProfitCandleLimitColumn() {
        TableColumn<RobotRow, Number> col = new TableColumn<>("Prof Cndl Lmt");
        col.setCellValueFactory(cellData -> cellData.getValue().profitCandleLimitProperty());
        col.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.IntegerStringConverter()));
        col.setEditable(true);
        col.setMinWidth(100);
        col.setStyle("-fx-alignment: CENTER_RIGHT;");
        tableView.getColumns().add(col);
    }

    private void createStatusColumn() {
        TableColumn<RobotRow, String> col = new TableColumn<>("Status");
        col.setCellValueFactory(cellData -> cellData.getValue().statusProperty());
        col.setEditable(false);
        col.setMinWidth(60);
        col.setStyle("-fx-alignment: CENTER; -fx-font-size: 16px;");
        tableView.getColumns().add(col);
    }

    private void createLastSignalColumn() {
        TableColumn<RobotRow, String> col = new TableColumn<>("Last Signal");
        col.setCellValueFactory(cellData -> cellData.getValue().lastSignalProperty());
        col.setEditable(false);
        col.setMinWidth(100);
        tableView.getColumns().add(col);
    }

    private void createActiveTradeColumn() {
        TableColumn<RobotRow, String> col = new TableColumn<>("Active Trade");
        col.setCellValueFactory(cellData -> cellData.getValue().activeTradeProperty());
        col.setEditable(false);
        col.setMinWidth(100);
        tableView.getColumns().add(col);
    }

    /**
     * Creates a context menu for right-click actions on rows
     */
    private ContextMenu createRowContextMenu(RobotRow row, String columnName) {
        ContextMenu contextMenu = new ContextMenu();
        contextMenu.setStyle("-fx-background-color: white; -fx-text-fill: black;");

        MenuItem fillColumnItem = new MenuItem("Fill Column (entire column with this value)");
        fillColumnItem.setStyle("-fx-text-fill: black;");
        fillColumnItem.setOnAction(e -> fillColumn(row, columnName));

        MenuItem fillDownItem = new MenuItem("Fill Down (from this row to bottom)");
        fillDownItem.setStyle("-fx-text-fill: black;");
        fillDownItem.setOnAction(e -> fillDown(row));

        MenuItem duplicateRowItem = new MenuItem("Duplicate Row Below");
        duplicateRowItem.setStyle("-fx-text-fill: black;");
        duplicateRowItem.setOnAction(e -> duplicateRow(row));

        MenuItem clearRowItem = new MenuItem("Clear This Row");
        clearRowItem.setStyle("-fx-text-fill: black;");
        clearRowItem.setOnAction(e -> clearRow(row));

        MenuItem clearAllRowsItem = new MenuItem("Clear All Rows (from this row to bottom)");
        clearAllRowsItem.setStyle("-fx-text-fill: black;");
        clearAllRowsItem.setOnAction(e -> clearAllRows(row));

        contextMenu.getItems().addAll(fillColumnItem, fillDownItem, duplicateRowItem,
                                       new SeparatorMenuItem(), clearRowItem, clearAllRowsItem);

        return contextMenu;
    }

    private boolean isRowLockedForEditing(RobotRow row) {
        return row != null && systemConfig.isMasterTradingEnabled() && lockedRows.contains(row.rowNumber.get());
    }

    private void markRowConfiguredByUser(RobotRow row) {
        if (row == null) {
            return;
        }

        if (row.isPlaceholder()) {
            row.setPlaceholder(false);
        }
        if (!row.hasBeenManuallyModified()) {
            row.setManuallyModified(true);
        }
        if (row.getRobotConfigId() == null) {
            row.setRobotConfigId(UUID.randomUUID());
        }
    }

    /**
     * Creates a text field cell that commits on focus loss and supports context menu
     * Blocks editing if Matrix is ON and row is active (pink/checked)
     */
    private <T> javafx.util.Callback<TableColumn<RobotRow, T>, TableCell<RobotRow, T>>
            createEditableTextCell(StringConverter<T> converter) {
        return column -> {
            TableCell<RobotRow, T> cell = new TableCell<RobotRow, T>() {
                private javafx.scene.control.TextField textField;

                @Override
                public void startEdit() {
                    RobotRow row = getTableRow().getItem();

                    // Block editing if Matrix is ON and row is locked
                    if (row != null && systemConfig.isMasterTradingEnabled() && lockedRows.contains(row.rowNumber.get())) {
                        return;
                    }

                    super.startEdit();

                    if (textField == null) {
                        textField = new javafx.scene.control.TextField();

                        // Commit on Enter
                        textField.setOnAction(e -> commitFromTextField());

                        // Commit on focus lost
                        textField.focusedProperty().addListener((obs, was, is) -> {
                            if (was && !is) {
                                Platform.runLater(() -> {
                                    if (isEditing()) {
                                        commitFromTextField();
                                    }
                                });
                            }
                        });
                    }

                    T item = getItem();
                    String text = item == null ? "" : converter.toString(item);
                    textField.setText(text);

                    setText(null);
                    setGraphic(textField);

                    Platform.runLater(() -> {
                        textField.requestFocus();
                        textField.selectAll();
                    });
                }

                @Override
                public void cancelEdit() {
                    // Convert cancel into commit if there's a textField with content
                    if (textField != null && isEditing()) {
                        commitFromTextField();
                    } else {
                        super.cancelEdit();
                        setText(getItem() == null ? "" : converter.toString(getItem()));
                        setGraphic(null);
                    }
                }

                @Override
                public void updateItem(T item, boolean empty) {
                    super.updateItem(item, empty);

                    if (empty) {
                        setText(null);
                        setGraphic(null);
                    } else {
                        if (isEditing()) {
                            if (textField != null) {
                                textField.setText(converter.toString(item));
                            }
                            setText(null);
                            setGraphic(textField);
                        } else {
                            String displayText = converter.toString(item);
                            setText(displayText);
                            setGraphic(null);

                            // Ensure text isn't clipped
                            setWrapText(false);
                            setMaxWidth(Double.MAX_VALUE);
                            setMinWidth(USE_PREF_SIZE);
                        }
                    }
                }

                private void commitFromTextField() {
                    if (!isEditing()) return;

                    try {
                        String text = textField.getText();
                        if (text == null) text = "";
                        T newValue = converter.fromString(text);

                        commitEdit(newValue);
                    } catch (Exception e) {
                        cancelEdit();
                    }
                }
            };

            attachContextMenu(cell);
            return cell;
        };
    }

    /**
     * Creates a combo box cell with context menu support
     * Blocks editing if Matrix is ON and row is active (pink/checked)
     */
    private <T> javafx.util.Callback<TableColumn<RobotRow, T>, TableCell<RobotRow, T>>
            createComboBoxCell(ObservableList<T> items) {
        return column -> {
            ComboBoxTableCell<RobotRow, T> cell = new ComboBoxTableCell<RobotRow, T>(items) {
                @Override
                public void startEdit() {
                    RobotRow row = getTableRow().getItem();

                    // Block editing if Matrix is ON and row is locked
                    if (row != null && systemConfig.isMasterTradingEnabled() && lockedRows.contains(row.rowNumber.get())) {
                        // Don't allow editing - row has live positions/orders
                        return;
                    }

                    super.startEdit();
                }
            };

            attachContextMenu(cell);
            return cell;
        };
    }

    /**
     * Attaches context menu to any table cell
     */
    private void attachContextMenu(TableCell<RobotRow, ?> cell) {
        cell.setOnContextMenuRequested(event -> {
            RobotRow row = cell.getTableRow().getItem();
            if (row != null) {
                TableColumn<RobotRow, ?> col = cell.getTableColumn();
                String colName = col != null ? col.getText() : "";
                ContextMenu menu = createRowContextMenu(row, colName);
                menu.show(cell, event.getScreenX(), event.getScreenY());
                event.consume();
            }
        });
    }

    /**
     * Fills down from the selected row to the bottom of the table
     */
    private void fillDown(RobotRow sourceRow) {
        int startRow = sourceRow.rowNumber.get();

        Logger.info("Fill down from row " + startRow);

        for (int i = startRow; i < robotRows.size(); i++) {
            RobotRow targetRow = robotRows.get(i);
            if (targetRow.rowNumber.get() > startRow) {
                copyRowValues(sourceRow, targetRow);
            }
        }

        tableView.refresh();
        Logger.info("Filled down from row " + startRow + " to row " + robotRows.size());
    }

    /**
     * Fills the entire column with values from the selected row
     */
    private void fillColumn(RobotRow sourceRow, String columnName) {
        Logger.info("Fill column '" + columnName + "' from row " + sourceRow.rowNumber.get());

        for (RobotRow targetRow : robotRows) {
            if (targetRow != sourceRow) {
                copyColumnValue(sourceRow, targetRow, columnName);
            }
        }

        tableView.refresh();
        Logger.info("Filled entire column '" + columnName + "' from row " + sourceRow.rowNumber.get());
    }

    private void copyColumnValue(RobotRow source, RobotRow target, String columnName) {
        switch (columnName) {
            case "Magic #": target.magicNumber.set(source.magicNumber.get()); break;
            case "Robot Name": target.robotName.set(source.robotName.get()); break;
            case "Symbol": target.symbol.set(source.symbol.get()); break;
            case "TF": target.timeframe.set(source.timeframe.get()); break;
            case "Start Hr": target.startHour.set(source.startHour.get()); break;
            case "Start Min": target.startMinute.set(source.startMinute.get()); break;
            case "End Hr": target.endHour.set(source.endHour.get()); break;
            case "End Min": target.endMinute.set(source.endMinute.get()); break;
            case "MinX1": target.minX1Height.set(source.minX1Height.get()); break;
            case "X1 Type": target.x1Type.set(source.x1Type.get()); break;
            case "Trig%": target.trigPercent.set(source.trigPercent.get()); break;
            case "SL%": target.stopLossPercent.set(source.stopLossPercent.get()); break;
            case "RPT%": target.rptPercent.set(source.rptPercent.get()); break;
            case "RPT$": target.rptFixedAmount.set(source.rptFixedAmount.get()); break;
            case "TP1%": target.tp1Percent.set(source.tp1Percent.get()); break;
            case "TP1 Vol": target.tp1Volume.set(source.tp1Volume.get()); break;
            case "TP2%": target.tp2Percent.set(source.tp2Percent.get()); break;
            case "TP2 Vol": target.tp2Volume.set(source.tp2Volume.get()); break;
            case "TP3%": target.tp3Percent.set(source.tp3Percent.get()); break;
            case "TP3 Vol": target.tp3Volume.set(source.tp3Volume.get()); break;
            case "Prof Cndl Lmt": target.profitCandleLimit.set(source.profitCandleLimit.get()); break;
            case "Comm Enabled": target.commissionsEnabled.set(source.commissionsEnabled.get()); break;
            case "Comm Type": target.commissionType.set(source.commissionType.get()); break;
            case "Comm Value": target.commissionValue.set(source.commissionValue.get()); break;
            case "Disable Leapfrog": target.disableLeapfrog.set(source.disableLeapfrog.get()); break;
            case "Smart TS": target.smartTsEnabled.set(source.smartTsEnabled.get()); break;
            case "EOD Enabled": target.eodEnabled.set(source.eodEnabled.get()); break;
            case "X2 Strict": target.x2StrictEnabled.set(source.x2StrictEnabled.get()); break;
            case "X2 Relaxed": target.x2RelaxedEnabled.set(source.x2RelaxedEnabled.get()); break;
            case "X3 Strict": target.x3StrictEnabled.set(source.x3StrictEnabled.get()); break;
            case "X3 Relaxed": target.x3RelaxedEnabled.set(source.x3RelaxedEnabled.get()); break;
            case "Trend": target.trendCheckEnabled.set(source.trendCheckEnabled.get()); break;
            case "Bounce": target.bounceCheckEnabled.set(source.bounceCheckEnabled.get()); break;
            case "E Hour": target.endHour.set(source.endHour.get()); break;
            case "E Minute": target.endMinute.set(source.endMinute.get()); break;
            default:
                Logger.warning("Unknown column name for fill: " + columnName);
                break;
        }
    }

    /**
     * Duplicates a row into the row immediately below it
     */
    private void duplicateRow(RobotRow sourceRow) {
        int sourceRowNum = sourceRow.rowNumber.get();

        if (sourceRowNum >= 500) {
            Logger.warning("Cannot duplicate last row - no row below");
            return;
        }

        int targetRowNum = sourceRowNum + 1;
        RobotRow targetRow = robotRows.get(targetRowNum - 1);

        Logger.info("Duplicating row " + sourceRowNum + " to row " + targetRowNum);

        copyRowValues(sourceRow, targetRow);

        tableView.refresh();
        Logger.info("Row " + sourceRowNum + " duplicated to row " + targetRowNum);
    }

    /**
     * Copies all values from source row to target row (except row number)
     */
    private void copyRowValues(RobotRow source, RobotRow target) {
        // Copy magic number and robot name
        target.magicNumber.set(source.magicNumber.get());
        target.robotName.set(source.robotName.get());

        // Copy all other fields
        target.symbol.set(source.symbol.get());
        target.timeframe.set(source.timeframe.get());
        target.startHour.set(source.startHour.get());
        target.startMinute.set(source.startMinute.get());
        target.minX1Height.set(source.minX1Height.get());
        target.x1Type.set(source.x1Type.get());
        target.trigPercent.set(source.trigPercent.get());
        target.stopLossPercent.set(source.stopLossPercent.get());
        target.rptPercent.set(source.rptPercent.get());
        target.rptFixedAmount.set(source.rptFixedAmount.get());
        target.tp1Percent.set(source.tp1Percent.get());
        target.tp1Volume.set(source.tp1Volume.get());
        target.tp2Percent.set(source.tp2Percent.get());
        target.tp2Volume.set(source.tp2Volume.get());
        target.tp3Percent.set(source.tp3Percent.get());
        target.tp3Volume.set(source.tp3Volume.get());
        target.profitCandleLimit.set(source.profitCandleLimit.get());

        // Copy commission fields
        target.commissionsEnabled.set(source.commissionsEnabled.get());
        target.commissionType.set(source.commissionType.get());
        target.commissionValue.set(source.commissionValue.get());

        // Copy disable leapfrog
        target.disableLeapfrog.set(source.disableLeapfrog.get());

        // Copy EOD enabled flag and end time
        target.eodEnabled.set(source.eodEnabled.get());
        target.endHour.set(source.endHour.get());
        target.endMinute.set(source.endMinute.get());

        // Copy Smart TS flag
        target.smartTsEnabled.set(source.smartTsEnabled.get());

        // Copy pattern enable flags
        target.x2StrictEnabled.set(source.x2StrictEnabled.get());
        target.x2RelaxedEnabled.set(source.x2RelaxedEnabled.get());
        target.x3StrictEnabled.set(source.x3StrictEnabled.get());
        target.x3RelaxedEnabled.set(source.x3RelaxedEnabled.get());
        target.trendCheckEnabled.set(source.trendCheckEnabled.get());
        target.bounceCheckEnabled.set(source.bounceCheckEnabled.get());

        // Mark target as no longer a placeholder if source isn't
        if (!source.isPlaceholder()) {
            target.setPlaceholder(false);
        }
    }

    private void clearRow(RobotRow row) {
        Logger.info("Clearing row " + row.rowNumber.get());

        row.active.set(false);
        row.magicNumber.set("");
        row.robotName.set("");
        row.symbol.set("");
        row.timeframe.set("");
        row.startHour.set(0);
        row.startMinute.set(0);
        row.minX1Height.set(0.0);
        row.x1Type.set("");
        row.trigPercent.set(0.0);
        row.stopLossPercent.set(0.0);
        row.rptPercent.set(0.0);
        row.rptFixedAmount.set(0.0);
        row.tp1Percent.set(0.0);
        row.tp1Volume.set(0);
        row.tp2Percent.set(0.0);
        row.tp2Volume.set(0);
        row.tp3Percent.set(0.0);
        row.tp3Volume.set(0);
        row.profitCandleLimit.set(0);
        row.commissionsEnabled.set(false);
        row.commissionType.set("No_Commissions");
        row.commissionValue.set(0.0);
        row.disableLeapfrog.set(false);
        row.smartTsEnabled.set(false);
        row.eodEnabled.set(false);
        row.endHour.set(23);
        row.endMinute.set(50);
        row.x2StrictEnabled.set(false);
        row.x2RelaxedEnabled.set(false);
        row.x3StrictEnabled.set(false);
        row.x3RelaxedEnabled.set(false);
        row.trendCheckEnabled.set(false);
        row.bounceCheckEnabled.set(false);

        row.setPlaceholder(true);
        row.setManuallyModified(false); // Reset modification flag so defaults can apply again

        tableView.refresh();
        Logger.info("Row " + row.rowNumber.get() + " cleared");
    }

    private void clearAllRows(RobotRow startRow) {
        int startRowNum = startRow.rowNumber.get();
        Logger.info("Clearing all rows from row " + startRowNum + " to bottom");

        for (int i = startRowNum; i <= 500; i++) {
            RobotRow row = robotRows.get(i - 1);
            clearRow(row);
        }

        tableView.refresh();
        Logger.info("Cleared rows from " + startRowNum + " to 500");
    }

    private void loadRobots() {
        // Create 500 placeholder rows
        for (int i = 1; i <= 500; i++) {
            RobotRow row = new RobotRow(i);
            robotRows.add(row);

            // Add listeners to ALL editable fields to mark row as manually modified
            row.symbol.addListener((obs, oldVal, newVal) -> {
                if (!row.hasBeenManuallyModified() && newVal != null && !newVal.isEmpty()) {
                    row.setManuallyModified(true);
                    Logger.info("Row " + row.rowNumber.get() + " marked as manually modified (symbol changed)");
                }
            });
            row.timeframe.addListener((obs, oldVal, newVal) -> {
                if (!row.hasBeenManuallyModified() && newVal != null && !newVal.isEmpty()) {
                    row.setManuallyModified(true);
                    Logger.info("Row " + row.rowNumber.get() + " marked as manually modified (timeframe changed)");
                }
            });
            row.startHour.addListener((obs, oldVal, newVal) -> {
                if (!row.hasBeenManuallyModified() && newVal != null && !oldVal.equals(newVal)) {
                    row.setManuallyModified(true);
                    Logger.info("Row " + row.rowNumber.get() + " marked as manually modified (startHour changed from " + oldVal + " to " + newVal + ")");
                }
            });
            row.startMinute.addListener((obs, oldVal, newVal) -> {
                if (!row.hasBeenManuallyModified() && newVal != null && !oldVal.equals(newVal)) {
                    row.setManuallyModified(true);
                    Logger.info("Row " + row.rowNumber.get() + " marked as manually modified (startMinute changed from " + oldVal + " to " + newVal + ")");
                }
            });
            row.minX1Height.addListener((obs, oldVal, newVal) -> {
                if (!row.hasBeenManuallyModified() && newVal != null && newVal.doubleValue() != 0.0) {
                    row.setManuallyModified(true);
                    Logger.info("Row " + row.rowNumber.get() + " marked as manually modified (minX1Height changed)");
                }
            });
            row.trigPercent.addListener((obs, oldVal, newVal) -> {
                if (!row.hasBeenManuallyModified() && newVal != null && newVal.doubleValue() != 0.0) {
                    row.setManuallyModified(true);
                    Logger.info("Row " + row.rowNumber.get() + " marked as manually modified (trigPercent changed)");
                }
            });
            row.stopLossPercent.addListener((obs, oldVal, newVal) -> {
                if (!row.hasBeenManuallyModified() && newVal != null && newVal.doubleValue() != 0.0) {
                    row.setManuallyModified(true);
                    Logger.info("Row " + row.rowNumber.get() + " marked as manually modified (stopLossPercent changed)");
                }
            });


            // Add listener for active property changes ONLY
            row.activeProperty().addListener((obs, oldValue, newValue) -> {
                // Only trigger if user toggled the checkbox
                if (oldValue != newValue) {
                    Logger.info("Active property changed for row " + row.rowNumber.get() + ": " + oldValue + " -> " + newValue);

                    // Block deactivation if Matrix is ON
                    if (!newValue && systemConfig.isMasterTradingEnabled()) {
                        Logger.warning("Cannot deactivate row " + row.rowNumber.get() + " while Matrix is ON");
                        Platform.runLater(() -> row.active.set(true)); // Revert the change
                        return;
                    }

                    if (newValue && row.isPlaceholder()) {
                        // Activate robot - populate with defaults
                        activateRobot(row);
                    } else if (!newValue && !row.isPlaceholder()) {
                        // Deactivate robot
                        deactivateRobot(row);
                    } else if (newValue && !row.isPlaceholder()) {
                        // Re-activating an already configured row - just set active flag
                        row.active.set(true);
                        Logger.info("Re-activated row " + row.rowNumber.get() + " without resetting values");
                    }
                }
            });
        }

        // Load saved robot configs from database (if available)
        if (dbClient != null) {
            try {
                List<RobotConfig> configs = dbClient.loadRobotConfigs(userId.toString());
                for (RobotConfig config : configs) {
                    int rowNum = config.getRobotNumber();
                    if (rowNum >= 1 && rowNum <= 500) {
                        RobotRow row = robotRows.get(rowNum - 1);
                        row.updateFromConfig(config);
                        savedConfigs.put(rowNum, config);
                    }
                }
                Logger.info("Loaded " + configs.size() + " saved robot configs from database");
            } catch (Exception e) {
                Logger.error("Failed to load robot configs: " + e.getMessage());
            }
        } else {
            Logger.info("Database not available - Trade Logic tab running in file mode");
        }

        Logger.info("Initialized 500 robot rows");
    }

    private void activateRobot(RobotRow row) {
        int rowNum = row.rowNumber.get();
        Logger.info("=== activateRobot() called for row " + rowNum + " ===");
        Logger.info("Current state BEFORE activation: startHour=" + row.startHour.get() + ", startMinute=" + row.startMinute.get() + ", hasBeenManuallyModified=" + row.hasBeenManuallyModified() + ", isPlaceholder=" + row.isPlaceholder());

        try {
            // STRICT RULES FOR SET DEFAULTS APPLICATION:
            // 1. Defaults ONLY apply if row has NEVER been manually modified
            // 2. Once ANY parameter is changed, defaults NEVER apply
            // 3. EXCEPTION: If row is CLEARED via right-click menu, the modification flag
            //    is reset, allowing defaults to apply again on next activation

            if (!row.hasBeenManuallyModified()) {
                // Row has never been touched by user OR was cleared - apply defaults ONLY
                Map<String, Object> defaults = getDefaultValues();

                Logger.info("Row " + rowNum + " has never been modified. Applying Set Defaults: " + defaults);

                // Apply defaults to the row (no database load, only Set Defaults)
                row.symbol.set((String) defaults.getOrDefault("symbol", "XAUUSD"));
                row.timeframe.set((String) defaults.getOrDefault("timeframe", "H1"));
                row.startHour.set(((Number) defaults.getOrDefault("start_hour", 15)).intValue());
                row.startMinute.set(((Number) defaults.getOrDefault("start_minute", 30)).intValue());
                row.minX1Height.set(((Number) defaults.getOrDefault("min_x1_height", 7.0)).doubleValue());
                row.x1Type.set((String) defaults.getOrDefault("x1_type", "Cents"));
                row.trigPercent.set(((Number) defaults.getOrDefault("trig_percent", 13.0)).doubleValue());
                row.stopLossPercent.set(((Number) defaults.getOrDefault("stop_loss_percent", 13.0)).doubleValue());
                row.rptPercent.set(((Number) defaults.getOrDefault("rpt_percent", 0.3)).doubleValue());
                row.rptFixedAmount.set(((Number) defaults.getOrDefault("rpt_fixed_amount", 0.0)).doubleValue());
                row.tp1Percent.set(((Number) defaults.getOrDefault("tp1_percent", 100.0)).doubleValue());
                row.tp1Volume.set(((Number) defaults.getOrDefault("tp1_volume", 14)).intValue());
                row.tp2Percent.set(((Number) defaults.getOrDefault("tp2_percent", 110.0)).doubleValue());
                row.tp2Volume.set(((Number) defaults.getOrDefault("tp2_volume", 14)).intValue());
                row.tp3Percent.set(((Number) defaults.getOrDefault("tp3_percent", 125.0)).doubleValue());
                row.tp3Volume.set(((Number) defaults.getOrDefault("tp3_volume", 14)).intValue());
                row.profitCandleLimit.set(((Number) defaults.getOrDefault("profit_candle_limit", 0)).intValue());
                row.commissionsEnabled.set((Boolean) defaults.getOrDefault("commissions_enabled", false));
                row.commissionType.set((String) defaults.getOrDefault("commission_type", "No_Commissions"));
                row.commissionValue.set(((Number) defaults.getOrDefault("commission_value", 0.0)).doubleValue());
                row.disableLeapfrog.set((Boolean) defaults.getOrDefault("disable_leapfrog", false));
                row.smartTsEnabled.set((Boolean) defaults.getOrDefault("smart_ts_enabled", false));
                row.x2StrictEnabled.set((Boolean) defaults.getOrDefault("x2_strict_enabled", false));
                row.x2RelaxedEnabled.set((Boolean) defaults.getOrDefault("x2_relaxed_enabled", false));
                row.x3StrictEnabled.set((Boolean) defaults.getOrDefault("x3_strict_enabled", false));
                row.x3RelaxedEnabled.set((Boolean) defaults.getOrDefault("x3_relaxed_enabled", false));
                row.trendCheckEnabled.set((Boolean) defaults.getOrDefault("trend_check_enabled", false));
                row.bounceCheckEnabled.set((Boolean) defaults.getOrDefault("bounce_check_enabled", false));
                row.eodEnabled.set((Boolean) defaults.getOrDefault("eod_enabled", false));
                row.endHour.set(((Number) defaults.getOrDefault("end_hour", 23)).intValue());
                row.endMinute.set(((Number) defaults.getOrDefault("end_minute", 50)).intValue());

                Logger.info("Row " + rowNum + " activated with Set Default values");
            } else {
                // Row has been manually modified - NEVER apply defaults, NEVER load from database
                // Just activate with whatever values the user has set
                Logger.info("Row " + rowNum + " has been manually modified. Preserving user values (NO defaults, NO database load)");
            }

            // Mark as no longer placeholder after activation
            row.setPlaceholder(false);
            Logger.info("Row " + rowNum + " state AFTER activation: startHour=" + row.startHour.get() + ", startMinute=" + row.startMinute.get() + ", hasBeenManuallyModified=" + row.hasBeenManuallyModified() + ", isPlaceholder=" + row.isPlaceholder());

            // Force table refresh
            tableView.refresh();

            // Request magic number from MT5
            // TODO: Implement MT5 magic number assignment

        } catch (Exception e) {
            Logger.error("Failed to activate robot at row " + rowNum + ": " + e.getMessage());
            e.printStackTrace();
            row.active.set(false);
        }
    }

    private void deactivateRobot(RobotRow row) {
        int rowNum = row.rowNumber.get();
        Logger.info("Deactivating robot at row " + rowNum);

        row.active.set(false);
        // Keep values visible - don't clear them
        // TODO: Update is_active in database
    }

    public TableView<RobotRow> getTableView() {
        return tableView;
    }

    public ObservableList<RobotRow> getRobotRows() {
        return robotRows;
    }

    /**
     * Snapshots which rows are currently active (checked) when Master ON is pressed
     * Only these rows will be locked for editing while Master is ON
     */
    public void snapshotActiveRows() {
        Logger.info("=== snapshotActiveRows() called (ON button pressed) ===");
        lockedRows.clear();
        for (RobotRow row : robotRows) {
            if (row.active.get()) {
                lockedRows.add(row.rowNumber.get());
                Logger.info("Row " + row.rowNumber.get() + " snapshot: startHour=" + row.startHour.get() + ", startMinute=" + row.startMinute.get() + ", hasBeenManuallyModified=" + row.hasBeenManuallyModified());
            }
        }
        Logger.info("Master ON: Locked " + lockedRows.size() + " active rows for editing. Inactive rows remain editable.");
        Logger.info("=== About to call tableView.refresh() ===");
        tableView.refresh();
        Logger.info("=== tableView.refresh() completed ===");
    }

    /**
     * Clears the locked rows when Master OFF is pressed
     * All rows become editable again
     */
    public void clearLockedRows() {
        lockedRows.clear();
        Logger.info("Master OFF: All rows unlocked");
        tableView.refresh();
    }

    /**
     * Saves all active robot configurations to Supabase
     */
    private void saveLayout() {
        Logger.info("Saving layout...");
        System.out.println("[DEBUG] saveLayout() method called");
        System.out.println("[DEBUG] userId: " + userId);
        System.out.println("[DEBUG] Total rows: " + robotRows.size());

        try {
            int savedCount = 0;
            List<RobotConfig> configsToSave = new ArrayList<>();

            for (RobotRow row : robotRows) {
                System.out.println("[DEBUG] Checking row " + row.rowNumber.get() + ", active: " + row.active.get());
                if (row.active.get()) {
                    System.out.println("[DEBUG] Saving active row " + row.rowNumber.get());
                    RobotConfig config = createConfigFromRow(row);
                    System.out.println("[DEBUG] Created config from row: " + config.getRowNumber());

                    if (dbClient != null) {
                        // Database mode
                        System.out.println("[DEBUG] Calling upsertRobotConfig...");
                        RobotConfig saved = upsertRobotConfig(config);
                        System.out.println("[DEBUG] upsertRobotConfig completed");
                        savedConfigs.put(row.rowNumber.get(), saved);
                        row.setRobotConfigId(saved.getId());
                    } else {
                        // File mode
                        configsToSave.add(config);
                    }

                    savedCount++;
                }
            }

            // Save to file if in file mode
            if (dbClient == null) {
                saveLayoutToFile(configsToSave);
            }

            final int finalSavedCount = savedCount;
            Logger.info("Successfully saved " + finalSavedCount + " robot configurations");

            if (onConfigurationChangedCallback != null) {
                onConfigurationChangedCallback.run();
                Logger.info("Configuration changed callback invoked - clearing pending setups");
            }

            Platform.runLater(() -> {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Layout Saved");
                alert.setHeaderText(null);
                alert.setContentText("Successfully saved " + finalSavedCount + " robot configurations" +
                                   (dbClient == null ? " to file." : " to database."));
                alert.showAndWait();
            });

        } catch (Exception e) {
            Logger.error("Failed to save layout: " + e.getMessage());
            System.err.println("[ERROR] saveLayout failed: " + e.getMessage());
            e.printStackTrace();

            final String errorMessage = e.getMessage();
            Platform.runLater(() -> {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Save Failed");
                alert.setHeaderText("Failed to save layout");
                alert.setContentText(errorMessage);
                alert.showAndWait();
            });
        }
    }

    /**
     * Loads saved layout from database and populates the table
     */
    private void loadLayout() {
        Logger.info("Loading layout...");
        System.out.println("[DEBUG] loadLayout() method called");

        try {
            List<RobotConfig> savedConfigs;
            if (dbClient != null) {
                // Database mode
                savedConfigs = dbClient.loadRobotConfigs(userId.toString());
            } else {
                // File mode
                savedConfigs = loadLayoutFromFile();
            }
            System.out.println("[DEBUG] Loaded " + savedConfigs.size() + " saved configurations");

            if (savedConfigs.isEmpty()) {
                Platform.runLater(() -> {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Load Layout");
                    alert.setHeaderText("No Saved Layout");
                    alert.setContentText("No saved robot configurations found for this user.");
                    alert.showAndWait();
                });
                return;
            }

            // Deactivate all current robots first
            for (RobotRow row : robotRows) {
                if (row.active.get()) {
                    Platform.runLater(() -> row.active.set(false));
                }
            }

            // Load each saved config into the appropriate row
            int loadedCount = 0;
            for (RobotConfig config : savedConfigs) {
                int rowNum = config.getRowNumber();
                if (rowNum < 1 || rowNum > 500) {
                    Logger.warning("Invalid row number in config: " + rowNum);
                    continue;
                }

                RobotRow row = robotRows.get(rowNum - 1);
                Platform.runLater(() -> populateRowFromConfig(row, config));
                loadedCount++;
            }

            final int finalLoadedCount = loadedCount;
            Platform.runLater(() -> {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Load Layout");
                alert.setHeaderText("Layout Loaded Successfully");
                alert.setContentText("Successfully loaded " + finalLoadedCount + " robot configuration(s).");
                alert.showAndWait();
            });

            Logger.info("Successfully loaded " + loadedCount + " robot configurations");

        } catch (Exception e) {
            e.printStackTrace();
            Logger.error("Failed to load layout: " + e.getMessage());

            final String errorMessage = e.getMessage();
            Platform.runLater(() -> {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Load Failed");
                alert.setHeaderText("Failed to load layout");
                alert.setContentText(errorMessage);
                alert.showAndWait();
            });
        }
    }

    /**
     * Populates a table row from a loaded RobotConfig
     */
    private void populateRowFromConfig(RobotRow row, RobotConfig config) {
        row.active.set(true);
        row.robotName.set(config.getRobotName() != null ? config.getRobotName() : "");
        row.magicNumber.set(config.getMagicNumber() != null ? config.getMagicNumber() : "");
        row.symbol.set(config.getSymbol());
        row.timeframe.set(config.getTimeframe());
        row.startHour.set(config.getStartHour());
        row.startMinute.set(config.getStartMinute());
        row.minX1Height.set(config.getMinX1Height());
        row.x1Type.set(config.getX1Type());
        row.trigPercent.set(config.getTrigPercent());
        row.stopLossPercent.set(config.getStopLossPercent());
        row.rptPercent.set(config.getRptPercent());
        row.rptFixedAmount.set(config.getRptFixedAmount());
        row.tp1Percent.set(config.getTp1Percent());
        row.tp1Volume.set(config.getTp1Volume());
        row.tp2Percent.set(config.getTp2Percent());
        row.tp2Volume.set(config.getTp2Volume());
        row.tp3Percent.set(config.getTp3Percent());
        row.tp3Volume.set(config.getTp3Volume());
        row.profitCandleLimit.set(config.getProfitCandleLimit());
        row.commissionsEnabled.set(config.isCommissionsEnabled());
        row.commissionType.set(config.getCommissionType() != null ? config.getCommissionType() : "No_Commissions");
        row.commissionValue.set(config.getCommissionValue());
        row.disableLeapfrog.set(config.isDisableLeapfrog());
        row.smartTsEnabled.set(config.isSmartTsEnabled());
        row.x2StrictEnabled.set(config.isX2StrictEnabled());
        row.x2RelaxedEnabled.set(config.isX2RelaxedEnabled());
        row.x3StrictEnabled.set(config.isX3StrictEnabled());
        row.x3RelaxedEnabled.set(config.isX3RelaxedEnabled());
        row.trendCheckEnabled.set(config.isTrendCheckEnabled());
        row.bounceCheckEnabled.set(config.isBounceCheckEnabled());
        row.eodEnabled.set(config.isEndTimeEnabled());
        row.endHour.set(config.getEndHour());
        row.endMinute.set(config.getEndMinute());

        row.robotConfigId = config.getId();

        Logger.info("Populated row " + row.rowNumber.get() + " with config from database");
    }

    /**
     * Gets default robot values from system config or uses hardcoded defaults
     */
    private Map<String, Object> getDefaultValues() {
        if (dbClient != null) {
            try {
                Map<String, Object> defaults = dbClient.loadDefaultValues(userId.toString());
                if (defaults != null) {
                    return defaults;
                }
            } catch (Exception e) {
                Logger.error("Failed to load default values from database: " + e.getMessage());
            }
        } else {
            // File mode - try to load from file
            try {
                Map<String, Object> defaults = loadDefaultValuesFromFile();
                if (defaults != null && !defaults.isEmpty()) {
                    return defaults;
                }
            } catch (Exception e) {
                Logger.error("Failed to load default values from file: " + e.getMessage());
            }
        }

        // Return hardcoded defaults
        Map<String, Object> defaults = new HashMap<>();
        defaults.put("symbol", "XAUUSD");
        defaults.put("timeframe", "H1");
        defaults.put("start_hour", 0);
        defaults.put("start_minute", 0);
        defaults.put("min_x1_height", 7.0);
        defaults.put("x1_type", "Cents");
        defaults.put("trig_percent", 13.0);
        defaults.put("stop_loss_percent", 13.0);
        defaults.put("rpt_percent", 0.3);
        defaults.put("rpt_fixed_amount", 0.0);
        defaults.put("tp1_percent", 100.0);
        defaults.put("tp1_volume", 14);
        defaults.put("tp2_percent", 110.0);
        defaults.put("tp2_volume", 14);
        defaults.put("tp3_percent", 125.0);
        defaults.put("tp3_volume", 14);
        defaults.put("profit_candle_limit", 0);
        defaults.put("commissions_enabled", false);
        defaults.put("commission_type", "No_Commissions");
        defaults.put("commission_value", 0.0);
        defaults.put("disable_leapfrog", false);
        defaults.put("smart_ts_enabled", false);
        defaults.put("x2_strict_enabled", true);
        defaults.put("x2_relaxed_enabled", false);
        defaults.put("x3_strict_enabled", false);
        defaults.put("x3_relaxed_enabled", false);
        defaults.put("trend_check_enabled", false);
        defaults.put("bounce_check_enabled", false);
        defaults.put("eod_enabled", false);
        defaults.put("end_hour", 23);
        defaults.put("end_minute", 50);

        return defaults;
    }

    /**
     * Upserts (insert or update) a robot config
     */
    private RobotConfig upsertRobotConfig(RobotConfig config) throws Exception {
        if (dbClient == null) {
            Logger.info("Database not available - robot config not persisted (file mode)");
            return config;
        }

        Logger.info("Upserting robot config for robot " + config.getRobotNumber());

        try {
            dbClient.upsertRobotConfig(config.getUserId().toString(), config);
            Logger.info("Successfully saved robot config");
            return config;
        } catch (Exception e) {
            Logger.error("Failed to upsert robot config: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * Creates a RobotConfig from a RobotRow
     */
    private RobotConfig createConfigFromRow(RobotRow row) {
        RobotConfig config = new RobotConfig();

        config.setId(row.getRobotConfigId());
        config.setUserId(userId);
        config.setRobotNumber(row.rowNumber.get());
        config.setActive(row.active.get());
        config.setMagicNumber(row.magicNumber.get());
        config.setRobotName(row.robotName.get());
        config.setSymbol(row.symbol.get());
        config.setTimeframe(row.timeframe.get());
        config.setStartHour(row.startHour.get());
        config.setStartMinute(row.startMinute.get());
        config.setMinX1Height(row.minX1Height.get());
        config.setX1Type(row.x1Type.get());
        config.setTrigPercent(row.trigPercent.get());
        config.setStopLossPercent(row.stopLossPercent.get());
        config.setRptPercent(row.rptPercent.get());
        config.setRptFixedAmount(row.rptFixedAmount.get());
        config.setTp1Percent(row.tp1Percent.get());
        config.setTp1Volume(row.tp1Volume.get());
        config.setTp2Percent(row.tp2Percent.get());
        config.setTp2Volume(row.tp2Volume.get());
        config.setTp3Percent(row.tp3Percent.get());
        config.setTp3Volume(row.tp3Volume.get());
        config.setProfitCandleLimit(row.profitCandleLimit.get());
        config.setCommissionsEnabled(row.commissionsEnabled.get());
        config.setCommissionType(row.commissionType.get());
        config.setCommissionValue(row.commissionValue.get());
        config.setDisableLeapfrog(row.disableLeapfrog.get());
        config.setSmartTsEnabled(row.smartTsEnabled.get());

        config.setEndTimeEnabled(row.eodEnabled.get());
        config.setEndHour(row.endHour.get());
        config.setEndMinute(row.endMinute.get());
        config.setX2StrictEnabled(row.x2StrictEnabled.get());
        config.setX2RelaxedEnabled(row.x2RelaxedEnabled.get());
        config.setX3StrictEnabled(row.x3StrictEnabled.get());
        config.setX3RelaxedEnabled(row.x3RelaxedEnabled.get());
        config.setTrendCheckEnabled(row.trendCheckEnabled.get());
        config.setBounceCheckEnabled(row.bounceCheckEnabled.get());

        System.out.println("[DEBUG] Config from row " + row.rowNumber.get() + ": symbol=" + config.getSymbol() + ", timeframe=" + config.getTimeframe());
        return config;
    }

    /**
     * Shows dialog to set default values for new robots
     */
    private void showSetDefaultsDialog() {
        System.out.println("[DEBUG] showSetDefaultsDialog() called");
        Map<String, Object> currentDefaults = getDefaultValues();
        System.out.println("[DEBUG] Current defaults: " + currentDefaults);

        DefaultValuesDialog dialog = new DefaultValuesDialog(currentDefaults, availableSymbols);
        dialog.showAndWait().ifPresent(newDefaults -> {
            System.out.println("[DEBUG] User confirmed new defaults: " + newDefaults);
            try {
                System.out.println("[DEBUG] Calling saveDefaultValues...");
                saveDefaultValues(newDefaults);
                System.out.println("[DEBUG] saveDefaultValues completed");
                Logger.info("Default values updated successfully");

                Platform.runLater(() -> {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Defaults Updated");
                    alert.setHeaderText(null);
                    alert.setContentText("Default values have been saved. New activated robots will use these values.");
                    alert.showAndWait();
                });

            } catch (Exception e) {
                Logger.error("Failed to save default values: " + e.getMessage());
                System.err.println("[ERROR] Failed to save default values: " + e.getMessage());
                e.printStackTrace();

                final String errorMessage = "Error: " + e.getMessage() + "\n\nCheck the console log for details.";
                Platform.runLater(() -> {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Save Failed");
                    alert.setHeaderText("Failed to save default values");
                    alert.setContentText(errorMessage);
                    alert.showAndWait();
                });
            }
        });
    }

    /**
     * Shows default values dialog (called from control panel)
     */
    private void saveDefaultValues() {
        showSetDefaultsDialog();
    }

    /**
     * Saves default values to system config in database
     */
    private void saveDefaultValues(Map<String, Object> defaults) throws Exception {
        System.out.println("[DEBUG] saveDefaultValues called with userId: " + userId);
        System.out.println("[DEBUG] Raw defaults map: " + defaults);

        Map<String, Object> typedDefaults = new HashMap<>();

        Object symbol = defaults.get("symbol");
        if (symbol == null) throw new Exception("Symbol is required");
        typedDefaults.put("symbol", symbol.toString());

        Object timeframe = defaults.get("timeframe");
        if (timeframe == null) throw new Exception("Timeframe is required");
        typedDefaults.put("timeframe", timeframe.toString());

        Object x1Type = defaults.get("x1_type");
        if (x1Type == null) throw new Exception("X1 Type is required");
        typedDefaults.put("x1_type", x1Type.toString());

        typedDefaults.put("start_hour", parseInt(defaults.get("start_hour"), "start_hour"));
        typedDefaults.put("start_minute", parseInt(defaults.get("start_minute"), "start_minute"));
        typedDefaults.put("min_x1_height", parseDouble(defaults.get("min_x1_height"), "min_x1_height"));
        typedDefaults.put("trig_percent", parseDouble(defaults.get("trig_percent"), "trig_percent"));
        typedDefaults.put("stop_loss_percent", parseDouble(defaults.get("stop_loss_percent"), "stop_loss_percent"));
        typedDefaults.put("rpt_percent", parseDouble(defaults.get("rpt_percent"), "rpt_percent"));
        typedDefaults.put("rpt_fixed_amount", parseDouble(defaults.get("rpt_fixed_amount"), "rpt_fixed_amount"));
        typedDefaults.put("tp1_percent", parseDouble(defaults.get("tp1_percent"), "tp1_percent"));
        typedDefaults.put("tp1_volume", parseInt(defaults.get("tp1_volume"), "tp1_volume"));
        typedDefaults.put("tp2_percent", parseDouble(defaults.get("tp2_percent"), "tp2_percent"));
        typedDefaults.put("tp2_volume", parseInt(defaults.get("tp2_volume"), "tp2_volume"));
        typedDefaults.put("tp3_percent", parseDouble(defaults.get("tp3_percent"), "tp3_percent"));
        typedDefaults.put("tp3_volume", parseInt(defaults.get("tp3_volume"), "tp3_volume"));

        typedDefaults.put("profit_candle_limit", parseInt(defaults.get("profit_candle_limit"), "profit_candle_limit"));

        Object commissionsEnabled = defaults.get("commissions_enabled");
        typedDefaults.put("commissions_enabled", commissionsEnabled != null ? Boolean.parseBoolean(commissionsEnabled.toString()) : false);

        Object commissionType = defaults.get("commission_type");
        typedDefaults.put("commission_type", commissionType != null ? commissionType.toString() : "No_Commissions");

        typedDefaults.put("commission_value", parseDouble(defaults.get("commission_value"), "commission_value"));

        Object disableLeapfrog = defaults.get("disable_leapfrog");
        typedDefaults.put("disable_leapfrog", disableLeapfrog != null ? Boolean.parseBoolean(disableLeapfrog.toString()) : false);

        Object smartTsEnabled = defaults.get("smart_ts_enabled");
        typedDefaults.put("smart_ts_enabled", smartTsEnabled != null ? Boolean.parseBoolean(smartTsEnabled.toString()) : false);

        Object x2StrictEnabled = defaults.get("x2_strict_enabled");
        typedDefaults.put("x2_strict_enabled", x2StrictEnabled != null ? Boolean.parseBoolean(x2StrictEnabled.toString()) : false);

        Object x2RelaxedEnabled = defaults.get("x2_relaxed_enabled");
        typedDefaults.put("x2_relaxed_enabled", x2RelaxedEnabled != null ? Boolean.parseBoolean(x2RelaxedEnabled.toString()) : false);

        Object x3StrictEnabled = defaults.get("x3_strict_enabled");
        typedDefaults.put("x3_strict_enabled", x3StrictEnabled != null ? Boolean.parseBoolean(x3StrictEnabled.toString()) : false);

        Object x3RelaxedEnabled = defaults.get("x3_relaxed_enabled");
        typedDefaults.put("x3_relaxed_enabled", x3RelaxedEnabled != null ? Boolean.parseBoolean(x3RelaxedEnabled.toString()) : false);

        Object trendCheckEnabled = defaults.get("trend_check_enabled");
        typedDefaults.put("trend_check_enabled", trendCheckEnabled != null ? Boolean.parseBoolean(trendCheckEnabled.toString()) : false);

        Object bounceCheckEnabled = defaults.get("bounce_check_enabled");
        typedDefaults.put("bounce_check_enabled", bounceCheckEnabled != null ? Boolean.parseBoolean(bounceCheckEnabled.toString()) : false);

        Object eodEnabled = defaults.get("eod_enabled");
        typedDefaults.put("eod_enabled", eodEnabled != null ? Boolean.parseBoolean(eodEnabled.toString()) : false);

        typedDefaults.put("end_hour", parseInt(defaults.get("end_hour"), "end_hour"));
        typedDefaults.put("end_minute", parseInt(defaults.get("end_minute"), "end_minute"));

        System.out.println("[DEBUG] Typed defaults map: " + typedDefaults);

        if (dbClient == null) {
            // File mode - save to JSON file
            try {
                saveDefaultValuesToFile(typedDefaults);
                Logger.info("Default values saved to file successfully");
            } catch (Exception e) {
                Logger.error("Failed to save default values to file: " + e.getMessage());
                e.printStackTrace();
                throw e;
            }
        } else {
            // Database mode
            try {
                dbClient.saveDefaultValues(userId.toString(), typedDefaults);
                Logger.info("Default values saved to database successfully");
            } catch (Exception e) {
                Logger.error("Failed to save default values: " + e.getMessage());
                e.printStackTrace();
                throw e;
            }
        }
    }

    public ControlPanelPane getControlPanel() {
        return controlPanel;
    }

    /**
     * Updates the account balance used for RPT calculations
     */
    public void setAccountBalance(double balance) {
        double oldBalance = this.accountBalance;
        this.accountBalance = balance;
        Logger.info(String.format("Account balance updated in RobotMatrixTable: %.2f (was: %.2f)", balance, oldBalance));
    }

    public void setDataReader(FileDataReader reader) {
        this.dataReader = reader;
        refreshAvailableSymbols();
    }

    public void setOnConfigurationChangedCallback(Runnable callback) {
        this.onConfigurationChangedCallback = callback;
    }

    private void refreshAvailableSymbols() {
        if (dataReader != null) {
            List<String> symbols = dataReader.getAvailableSymbols();
            Platform.runLater(() -> {
                availableSymbols.clear();
                availableSymbols.addAll(symbols);
            });
        }
    }

    /**
     * Saves layout to JSON file (for file mode)
     */
    private void saveLayoutToFile(List<RobotConfig> configs) throws IOException {
        String userHome = System.getProperty("user.home");
        File appDir = new File(userHome, ".finaldelta");
        File layoutsDir = new File(appDir, "data/layouts");
        if (!layoutsDir.exists()) {
            boolean created = layoutsDir.mkdirs();
            if (!created) {
                throw new IOException("Failed to create layouts directory: " + layoutsDir.getAbsolutePath());
            }
        }

        File layoutFile = new File(layoutsDir, "robot_layout.json");
        Gson gson = new GsonBuilder()
                .setPrettyPrinting()
                .registerTypeAdapter(Instant.class, (JsonSerializer<Instant>) (src, typeOfSrc, context) ->
                    new JsonPrimitive(src.toString()))
                .create();
        String json = gson.toJson(configs);

        Files.write(layoutFile.toPath(), json.getBytes());
        Logger.info("Layout saved to file: " + layoutFile.getAbsolutePath());
    }

    /**
     * Loads layout from JSON file (for file mode)
     */
    private List<RobotConfig> loadLayoutFromFile() throws IOException {
        String userHome = System.getProperty("user.home");
        File appDir = new File(userHome, ".finaldelta");
        File layoutsDir = new File(appDir, "data/layouts");
        File layoutFile = new File(layoutsDir, "robot_layout.json");

        if (!layoutFile.exists()) {
            return new ArrayList<>();
        }

        String json = new String(Files.readAllBytes(layoutFile.toPath()));
        Gson gson = new GsonBuilder()
                .registerTypeAdapter(Instant.class, (JsonDeserializer<Instant>) (jsonElement, type, context) ->
                    Instant.parse(jsonElement.getAsString()))
                .create();
        Type listType = new TypeToken<List<RobotConfig>>(){}.getType();
        List<RobotConfig> configs = gson.fromJson(json, listType);

        Logger.info("Layout loaded from file: " + layoutFile.getAbsolutePath());
        return configs != null ? configs : new ArrayList<>();
    }

    /**
     * Saves default values to JSON file (for file mode)
     */
    private void saveDefaultValuesToFile(Map<String, Object> defaults) throws IOException {
        String userHome = System.getProperty("user.home");
        File appDir = new File(userHome, ".finaldelta");
        File defaultsDir = new File(appDir, "data/defaults");
        if (!defaultsDir.exists()) {
            boolean created = defaultsDir.mkdirs();
            if (!created) {
                throw new IOException("Failed to create defaults directory: " + defaultsDir.getAbsolutePath());
            }
        }

        File defaultsFile = new File(defaultsDir, "robot_defaults.json");
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        String json = gson.toJson(defaults);

        Files.write(defaultsFile.toPath(), json.getBytes());
        Logger.info("Defaults saved to file: " + defaultsFile.getAbsolutePath());
    }

    /**
     * Loads default values from JSON file (for file mode)
     */
    private Map<String, Object> loadDefaultValuesFromFile() throws IOException {
        String userHome = System.getProperty("user.home");
        File appDir = new File(userHome, ".finaldelta");
        File defaultsDir = new File(appDir, "data/defaults");
        File defaultsFile = new File(defaultsDir, "robot_defaults.json");

        if (!defaultsFile.exists()) {
            return null;
        }

        String json = new String(Files.readAllBytes(defaultsFile.toPath()));
        Gson gson = new Gson();
        Type mapType = new TypeToken<Map<String, Object>>(){}.getType();
        Map<String, Object> defaults = gson.fromJson(json, mapType);

        Logger.info("Defaults loaded from file: " + defaultsFile.getAbsolutePath());
        return defaults;
    }

    /**
     * Helper method to parse integer with null check
     */
    private int parseInt(Object value, String fieldName) throws Exception {
        if (value == null) {
            throw new Exception(fieldName + " is required");
        }
        try {
            return Integer.parseInt(value.toString());
        } catch (NumberFormatException e) {
            throw new Exception("Invalid value for " + fieldName + ": " + value);
        }
    }

    /**
     * Helper method to parse double with null check
     */
    private double parseDouble(Object value, String fieldName) throws Exception {
        if (value == null) {
            throw new Exception(fieldName + " is required");
        }
        try {
            return Double.parseDouble(value.toString());
        } catch (NumberFormatException e) {
            throw new Exception("Invalid value for " + fieldName + ": " + value);
        }
    }

    private boolean validateSingleSetupSelection(RobotRow row, String attemptedSetup) {
        int selectedCount = 0;
        if (row.x2StrictEnabled.get() && !"X2_STRICT".equals(attemptedSetup)) selectedCount++;
        if (row.x2RelaxedEnabled.get() && !"X2_RELAXED".equals(attemptedSetup)) selectedCount++;
        if (row.x3StrictEnabled.get() && !"X3_STRICT".equals(attemptedSetup)) selectedCount++;
        if (row.x3RelaxedEnabled.get() && !"X3_RELAXED".equals(attemptedSetup)) selectedCount++;

        if (selectedCount > 0) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Setup Selection Error");
            alert.setHeaderText("You can only select one setup per row");
            alert.setContentText("Please uncheck the other setup before enabling this one.");
            alert.showAndWait();
            return false;
        }
        return true;
    }

}
