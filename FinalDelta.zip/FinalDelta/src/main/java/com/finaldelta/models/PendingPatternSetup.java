package com.finaldelta.models;

import com.finaldelta.services.PatternDetector;

import java.util.List;
import java.util.UUID;

public class PendingPatternSetup {

    private final UUID robotConfigId;
    private final String magicNumber;
    private final String symbol;
    private final String timeframe;
    private final PatternDetector.PatternType patternType;
    private final String direction;
    private final MarketBarData triggerCandle;
    private final List<MarketBarData> patternCandles;
    private final double breachLevel;
    private final long detectedAtTime;
    private final RobotConfig robotConfig;

    public PendingPatternSetup(UUID robotConfigId,
                                String magicNumber,
                                String symbol,
                                String timeframe,
                                PatternDetector.PatternType patternType,
                                String direction,
                                MarketBarData triggerCandle,
                                List<MarketBarData> patternCandles,
                                double breachLevel,
                                RobotConfig robotConfig) {
        this.robotConfigId = robotConfigId;
        this.magicNumber = magicNumber;
        this.symbol = symbol;
        this.timeframe = timeframe;
        this.patternType = patternType;
        this.direction = direction;
        this.triggerCandle = triggerCandle;
        this.patternCandles = patternCandles;
        this.breachLevel = breachLevel;
        this.detectedAtTime = System.currentTimeMillis();
        this.robotConfig = robotConfig;
    }

    public UUID getRobotConfigId() {
        return robotConfigId;
    }

    public String getMagicNumber() {
        return magicNumber;
    }

    public String getSymbol() {
        return symbol;
    }

    public String getTimeframe() {
        return timeframe;
    }

    public PatternDetector.PatternType getPatternType() {
        return patternType;
    }

    public String getDirection() {
        return direction;
    }

    public MarketBarData getTriggerCandle() {
        return triggerCandle;
    }

    public List<MarketBarData> getPatternCandles() {
        return patternCandles;
    }

    public double getBreachLevel() {
        return breachLevel;
    }

    public long getDetectedAtTime() {
        return detectedAtTime;
    }

    public RobotConfig getRobotConfig() {
        return robotConfig;
    }

    public long getAgeMillis() {
        return System.currentTimeMillis() - detectedAtTime;
    }

    public String getKey() {
        return magicNumber + "_" + triggerCandle.getCloseTime();
    }

    @Override
    public String toString() {
        return String.format("PendingSetup{magic=%s, symbol=%s, dir=%s, breach=%.5f, age=%dms}",
            magicNumber, symbol, direction, breachLevel, getAgeMillis());
    }
}
