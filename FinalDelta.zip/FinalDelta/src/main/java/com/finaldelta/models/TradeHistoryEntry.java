package com.finaldelta.models;

public class TradeHistoryEntry {
    private long ticket;
    private long magic;
    private String symbol;
    private long timestamp;
    private String orderType;
    private String state;
    private double volume;
    private double entryPrice;
    private double exitPrice;
    private double profit;
    private double commission;
    private double swap;
    private long openTime;
    private long closeTime;

    public TradeHistoryEntry() {}

    public TradeHistoryEntry(long ticket, long magic, String symbol, long timestamp) {
        this.ticket = ticket;
        this.magic = magic;
        this.symbol = symbol;
        this.timestamp = timestamp;
    }

    public TradeHistoryEntry(long ticket, long magic, String symbol, long timestamp, String orderType, String state) {
        this.ticket = ticket;
        this.magic = magic;
        this.symbol = symbol;
        this.timestamp = timestamp;
        this.orderType = orderType;
        this.state = state;
    }

    public long getTicket() {
        return ticket;
    }

    public void setTicket(long ticket) {
        this.ticket = ticket;
    }

    public long getMagic() {
        return magic;
    }

    public void setMagic(long magic) {
        this.magic = magic;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public double getVolume() {
        return volume;
    }

    public void setVolume(double volume) {
        this.volume = volume;
    }

    public double getEntryPrice() {
        return entryPrice;
    }

    public void setEntryPrice(double entryPrice) {
        this.entryPrice = entryPrice;
    }

    public double getExitPrice() {
        return exitPrice;
    }

    public void setExitPrice(double exitPrice) {
        this.exitPrice = exitPrice;
    }

    public double getProfit() {
        return profit;
    }

    public void setProfit(double profit) {
        this.profit = profit;
    }

    public double getCommission() {
        return commission;
    }

    public void setCommission(double commission) {
        this.commission = commission;
    }

    public double getSwap() {
        return swap;
    }

    public void setSwap(double swap) {
        this.swap = swap;
    }

    public long getOpenTime() {
        return openTime;
    }

    public void setOpenTime(long openTime) {
        this.openTime = openTime;
    }

    public long getCloseTime() {
        return closeTime;
    }

    public void setCloseTime(long closeTime) {
        this.closeTime = closeTime;
    }

    @Override
    public String toString() {
        return String.format("TradeHistoryEntry{ticket=%d, magic=%d, symbol='%s', timestamp=%d, orderType='%s', state='%s', profit=%.2f}",
            ticket, magic, symbol, timestamp, orderType, state, profit);
    }
}
