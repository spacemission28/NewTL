package com.finaldelta.models;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Model class representing a trade command in the RRC (Request-Response-Confirmation) mechanism.
 * Maps to the trade_commands table in Supabase.
 * Commands are queued by Java, polled by MT5 EA, and confirmed via execution feedback.
 */
public class TradeCommand {
    private UUID id;
    private String commandId; // Unique identifier for this command (UUID string)
    private UUID robotConfigId;
    private String magicNumber;

    // Command Details
    private String action; // PLACE_ORDER, MODIFY_ORDER, CLOSE_POSITION, CANCEL_ORDER, EMERGENCY_CLOSE_ALL
    private Map<String, Object> parameters;

    // Status Tracking
    private String status; // QUEUED, SENT, CONFIRMED, FAILED, TIMEOUT
    private Instant queuedAt;
    private Instant sentAt;
    private Instant confirmedAt;

    // Execution Feedback
    private Integer retcode;
    private String feedback; // JSON string
    private String errorMessage;

    // C.E. Support
    private boolean isCeCommand;
    private int ceSequenceNumber;
    private String ceBatchId;

    // Metadata
    private Instant createdAt;

    private static final Gson gson = new GsonBuilder().create();

    // Default constructor
    public TradeCommand() {
        this.commandId = UUID.randomUUID().toString();
        this.parameters = new HashMap<>();
        this.status = "QUEUED";
        this.queuedAt = Instant.now();
        this.createdAt = Instant.now();
        this.isCeCommand = false;
        this.ceSequenceNumber = 0;
        this.ceBatchId = null;
    }

    // Constructor for creating a new command
    public TradeCommand(UUID robotConfigId, String magicNumber, String action, Map<String, Object> parameters) {
        this();
        this.robotConfigId = robotConfigId;
        this.magicNumber = magicNumber;
        this.action = action;
        this.parameters = parameters;
    }

    // Getters and Setters
    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getCommandId() {
        return commandId;
    }

    public void setCommandId(String commandId) {
        this.commandId = commandId;
    }

    public UUID getRobotConfigId() {
        return robotConfigId;
    }

    public void setRobotConfigId(UUID robotConfigId) {
        this.robotConfigId = robotConfigId;
    }

    public String getMagicNumber() {
        return magicNumber;
    }

    public void setMagicNumber(String magicNumber) {
        this.magicNumber = magicNumber;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public Map<String, Object> getParameters() {
        return parameters;
    }

    public void setParameters(Map<String, Object> parameters) {
        this.parameters = parameters;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Instant getQueuedAt() {
        return queuedAt;
    }

    public void setQueuedAt(Instant queuedAt) {
        this.queuedAt = queuedAt;
    }

    public Instant getSentAt() {
        return sentAt;
    }

    public void setSentAt(Instant sentAt) {
        this.sentAt = sentAt;
    }

    public Instant getConfirmedAt() {
        return confirmedAt;
    }

    public void setConfirmedAt(Instant confirmedAt) {
        this.confirmedAt = confirmedAt;
    }

    public Integer getRetcode() {
        return retcode;
    }

    public void setRetcode(Integer retcode) {
        this.retcode = retcode;
    }

    public String getFeedback() {
        return feedback;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    /**
     * Converts the command to JSON format for transmission to MT5 EA
     * Format: {"command_id":"...", "magic":1001, "action":"...", "params":{...}}
     */
    public String toJson() {
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("command_id", commandId);
        jsonMap.put("magic", magicNumber);
        jsonMap.put("action", action);
        jsonMap.put("params", parameters);
        return gson.toJson(jsonMap);
    }

    /**
     * Converts the command to CSV format for transmission to MT5 EA (Legacy Format)
     * Format: ACTION,SYMBOL,TYPE,VOLUME,PRICE,SL,TP,MAGIC,COMMENT,COMMAND_ID
     * Example: OPEN,BTCUSD,4,0.01,113293.04,113163.01,113406.08,2000,TP1_7%,1234
     */
    public String toCsv() {
        // Extract parameters
        String symbol = (String) parameters.getOrDefault("symbol", "");
        Object orderTypeObj = parameters.get("order_type");
        int orderType = 0;

        // Convert order_type string to MT5 integer constant
        if (orderTypeObj instanceof String) {
            String orderTypeStr = (String) orderTypeObj;
            switch (orderTypeStr) {
                case "BUY": orderType = 0; break;
                case "SELL": orderType = 1; break;
                case "BUY_LIMIT": orderType = 2; break;
                case "SELL_LIMIT": orderType = 3; break;
                case "BUY_STOP": orderType = 4; break;
                case "SELL_STOP": orderType = 5; break;
                default: orderType = 0;
            }
        } else if (orderTypeObj instanceof Number) {
            orderType = ((Number) orderTypeObj).intValue();
        }

        double volume = parameters.containsKey("volume") ? ((Number) parameters.get("volume")).doubleValue() : 0.0;
        double price = parameters.containsKey("price") ? ((Number) parameters.get("price")).doubleValue() : 0.0;
        double sl = parameters.containsKey("sl") ? ((Number) parameters.get("sl")).doubleValue() :
                    parameters.containsKey("stop_loss") ? ((Number) parameters.get("stop_loss")).doubleValue() : 0.0;
        double tp = parameters.containsKey("tp") ? ((Number) parameters.get("tp")).doubleValue() :
                    parameters.containsKey("take_profit") ? ((Number) parameters.get("take_profit")).doubleValue() : 0.0;
        String comment = (String) parameters.getOrDefault("comment", "");

        // Convert action to EA format
        String eaAction = action;
        if ("PLACE_ORDER".equals(action)) {
            eaAction = "OPEN";
        } else if ("MODIFY_ORDER".equals(action)) {
            eaAction = "MODIFY";
        } else if ("CLOSE_POSITION".equals(action)) {
            eaAction = "CLOSE";
        } else if ("CANCEL_ORDER".equals(action)) {
            eaAction = "CLOSE";
        } else if ("DELETE_ALL_OPPOSITE".equals(action) || "DELETE_OPPOSITE_SIDE".equals(action)) {
            eaAction = "DELETE_ALL_MAGIC";
        } else if ("DELETE_ALL_MAGIC".equals(action)) {
            eaAction = "DELETE_ALL_MAGIC";
        } else if ("EMERGENCY_CLOSE_ALL".equals(action)) {
            eaAction = "EMERGENCY_CLOSE_ALL";
        }

        // Determine price precision based on symbol
        // Most forex pairs use 5 decimals, JPY pairs use 3, metals/indices vary
        // MT5 will handle normalization, but we should be close to actual digits
        int priceDigits = getPriceDigits(symbol);
        String priceFormat = "%." + priceDigits + "f";

        // Format: ACTION,SYMBOL,TYPE,VOLUME,PRICE,SL,TP,MAGIC,COMMENT,COMMAND_ID
        return String.format("%s,%s,%d,%.2f," + priceFormat + "," + priceFormat + "," + priceFormat + ",%s,%s,%s",
            eaAction,
            symbol,
            orderType,
            volume,    // Volume always 2 decimals (0.01 = 1 micro lot)
            price,
            sl,
            tp,
            magicNumber,
            comment,
            commandId
        );
    }

    /**
     * Determines the appropriate number of decimal places for a symbol's price
     */
    private int getPriceDigits(String symbol) {
        if (symbol == null || symbol.isEmpty()) {
            return 5; // Default
        }

        String upper = symbol.toUpperCase();

        // JPY pairs (3 decimals: 112.345)
        if (upper.contains("JPY")) {
            return 3;
        }

        // Indices (2 decimals: 15234.56)
        if (upper.contains("DAX") || upper.contains("DOW") || upper.contains("SPX") ||
            upper.contains("NAS") || upper.contains("FTSE") || upper.contains("CAC") ||
            upper.matches(".*\\d{2,}.*")) { // Contains 2+ digits (like FRA40, GER30)
            return 2;
        }

        // Metals - Gold/Silver (2 decimals: 1876.45)
        if (upper.contains("XAU") || upper.contains("GOLD") ||
            upper.contains("XAG") || upper.contains("SILVER")) {
            return 2;
        }

        // Crypto (2 decimals: 43521.75)
        if (upper.contains("BTC") || upper.contains("ETH") || upper.contains("XRP") ||
            upper.contains("CRYPTO")) {
            return 2;
        }

        // Standard forex pairs (5 decimals: 1.08234)
        return 5;
    }

    /**
     * Marks the command as sent
     */
    public void markAsSent() {
        this.status = "SENT";
        this.sentAt = Instant.now();
    }

    /**
     * Marks the command as confirmed
     */
    public void markAsConfirmed(int retcode, String feedback) {
        this.status = "CONFIRMED";
        this.confirmedAt = Instant.now();
        this.retcode = retcode;
        this.feedback = feedback;
    }

    /**
     * Marks the command as failed
     */
    public void markAsFailed(int retcode, String errorMessage) {
        this.status = "FAILED";
        this.retcode = retcode;
        this.errorMessage = errorMessage;
    }

    /**
     * Marks the command as timed out
     */
    public void markAsTimeout() {
        this.status = "TIMEOUT";
        this.errorMessage = "Command timed out waiting for execution feedback";
    }

    /**
     * Checks if the command has exceeded timeout threshold (30 seconds)
     */
    public boolean isTimedOut() {
        if (queuedAt == null) {
            return false;
        }
        return Instant.now().getEpochSecond() - queuedAt.getEpochSecond() > 30;
    }

    /**
     * Gets the order type from parameters
     */
    public String getOrderType() {
        Object orderType = parameters.get("order_type");
        return orderType != null ? orderType.toString() : "UNKNOWN";
    }

    /**
     * Gets the lot size from parameters
     */
    public double getLots() {
        Object volume = parameters.get("volume");
        if (volume instanceof Number) {
            return ((Number) volume).doubleValue();
        }
        return 0.0;
    }

    /**
     * Gets the symbol from parameters
     */
    public String getSymbol() {
        Object symbol = parameters.get("symbol");
        return symbol != null ? symbol.toString() : "";
    }

    /**
     * Gets the price from parameters
     */
    public double getPrice() {
        Object price = parameters.get("price");
        if (price instanceof Number) {
            return ((Number) price).doubleValue();
        }
        return 0.0;
    }

    /**
     * Gets the stop loss from parameters
     */
    public double getStopLoss() {
        Object sl = parameters.get("sl");
        if (sl == null) sl = parameters.get("stop_loss");
        if (sl instanceof Number) {
            return ((Number) sl).doubleValue();
        }
        return 0.0;
    }

    /**
     * Gets the take profit from parameters
     */
    public double getTakeProfit() {
        Object tp = parameters.get("tp");
        if (tp == null) tp = parameters.get("take_profit");
        if (tp instanceof Number) {
            return ((Number) tp).doubleValue();
        }
        return 0.0;
    }

    /**
     * Gets the comment from parameters
     */
    public String getComment() {
        Object comment = parameters.get("comment");
        return comment != null ? comment.toString() : "";
    }

    public boolean isCeCommand() {
        return isCeCommand;
    }

    public void setCeCommand(boolean ceCommand) {
        isCeCommand = ceCommand;
    }

    public int getCeSequenceNumber() {
        return ceSequenceNumber;
    }

    public void setCeSequenceNumber(int ceSequenceNumber) {
        this.ceSequenceNumber = ceSequenceNumber;
    }

    public String getCeBatchId() {
        return ceBatchId;
    }

    public void setCeBatchId(String ceBatchId) {
        this.ceBatchId = ceBatchId;
    }
}
