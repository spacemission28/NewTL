package com.finaldelta.services;

import com.finaldelta.Logger;
import com.finaldelta.models.MarketBarData;
import com.finaldelta.models.RobotConfig;

import java.util.List;

public class PatternDetector {

    public enum PatternType {
        OG_BUY,
        OG_SELL,
        X2_STRICT_BUY,
        X2_STRICT_SELL,
        X2_RELAXED_BUY,
        X2_RELAXED_SELL,
        X3_STRICT_BUY,
        X3_STRICT_SELL,
        X3_RELAXED_BUY,
        X3_RELAXED_SELL,
        X4_STRICT_BUY,
        X4_STRICT_SELL,
        X4_RELAXED_BUY,
        X4_RELAXED_SELL,
        NONE
    }

    public static class PatternResult {
        public final PatternType type;
        public final MarketBarData triggerCandle;
        public final List<MarketBarData> patternCandles;
        public final String direction;

        public PatternResult(PatternType type, MarketBarData triggerCandle, List<MarketBarData> patternCandles, String direction) {
            this.type = type;
            this.triggerCandle = triggerCandle;
            this.patternCandles = patternCandles;
            this.direction = direction;
        }

        public boolean isValid() {
            return type != PatternType.NONE;
        }
    }

    public PatternResult detectPattern(RobotConfig robot, List<MarketBarData> candles) {
        if (candles == null || candles.isEmpty()) {
            return new PatternResult(PatternType.NONE, null, null, null);
        }

        int enabledCount = 0;
        if (robot.isX2StrictEnabled()) enabledCount++;
        if (robot.isX2RelaxedEnabled()) enabledCount++;
        if (robot.isX3StrictEnabled()) enabledCount++;
        if (robot.isX3RelaxedEnabled()) enabledCount++;

        if (enabledCount > 1) {
            Logger.warning("  ⚠ ROBOT MISCONFIGURATION: Multiple pattern setups are enabled. Robot can only have one setup enabled at a time. Skipping pattern detection.");
            return new PatternResult(PatternType.NONE, null, null, null);
        }

        if (enabledCount == 0) {
            Logger.warning("  ⚠ ROBOT MISCONFIGURATION: No pattern setup is enabled. Please enable one setup. Skipping pattern detection.");
            return new PatternResult(PatternType.NONE, null, null, null);
        }

        if (robot.isX2StrictEnabled() && candles.size() >= 2) {
            PatternResult result = detectX2Strict(candles);
            if (result.isValid() && validateBbBreach(robot, result)) {
                logPatternDetails("X2 STRICT", result, candles, 2);
                return result;
            }
        }

        if (robot.isX2RelaxedEnabled() && candles.size() >= 2) {
            PatternResult result = detectX2Relaxed(candles);
            if (result.isValid() && validateBbBreach(robot, result)) {
                logPatternDetails("X2 RELAXED", result, candles, 2);
                return result;
            }
        }

        if (robot.isX3StrictEnabled() && candles.size() >= 3) {
            PatternResult result = detectX3Strict(candles);
            if (result.isValid() && validateBbBreach(robot, result)) {
                logPatternDetails("X3 STRICT", result, candles, 3);
                return result;
            }
        }

        if (robot.isX3RelaxedEnabled() && candles.size() >= 3) {
            PatternResult result = detectX3Relaxed(candles);
            if (result.isValid() && validateBbBreach(robot, result)) {
                logPatternDetails("X3 RELAXED", result, candles, 3);
                return result;
            }
        }

        return new PatternResult(PatternType.NONE, null, null, null);
    }

    private void logPatternDetails(String patternName, PatternResult result, List<MarketBarData> candles, int candleCount) {
        Logger.info("★ " + patternName + " DETECTED: " + result.direction);
    }

    private PatternResult detectOG(List<MarketBarData> candles) {
        int size = candles.size();
        MarketBarData x1 = candles.get(size - 1);
        MarketBarData x2 = candles.get(size - 2);

        boolean x2Bullish = isBullish(x2);
        boolean x1Bearish = isBearish(x1);

        if (x2Bullish && x1Bearish) {
            List<MarketBarData> patternCandles = List.of(x2, x1);
            return new PatternResult(PatternType.OG_BUY, x1, patternCandles, "BUY");
        }

        boolean x2Bearish = isBearish(x2);
        boolean x1Bullish = isBullish(x1);

        if (x2Bearish && x1Bullish) {
            List<MarketBarData> patternCandles = List.of(x2, x1);
            return new PatternResult(PatternType.OG_SELL, x1, patternCandles, "SELL");
        }

        return new PatternResult(PatternType.NONE, null, null, null);
    }

    private PatternResult detectX4Strict(List<MarketBarData> candles) {
        int size = candles.size();
        MarketBarData trigger = candles.get(size - 1);
        MarketBarData x1 = candles.get(size - 2);
        MarketBarData trend2 = candles.get(size - 3);
        MarketBarData trend1 = candles.get(size - 4);

        if (isBullish(trend1) && isBullish(trend2) && isBearish(x1)) {
            if (trend2.getLow() > trend1.getLow() && x1.getLow() > trend2.getLow()) {
                List<MarketBarData> patternCandles = List.of(trend1, trend2, x1, trigger);
                return new PatternResult(PatternType.X4_STRICT_BUY, trigger, patternCandles, "BUY");
            }
        }

        if (isBearish(trend1) && isBearish(trend2) && isBullish(x1)) {
            if (trend2.getHigh() < trend1.getHigh() && x1.getHigh() < trend2.getHigh()) {
                List<MarketBarData> patternCandles = List.of(trend1, trend2, x1, trigger);
                return new PatternResult(PatternType.X4_STRICT_SELL, trigger, patternCandles, "SELL");
            }
        }

        return new PatternResult(PatternType.NONE, null, null, null);
    }

    private PatternResult detectX4Relaxed(List<MarketBarData> candles) {
        int size = candles.size();
        MarketBarData trigger = candles.get(size - 1);
        MarketBarData x1 = candles.get(size - 2);
        MarketBarData trend2 = candles.get(size - 3);
        MarketBarData trend1 = candles.get(size - 4);

        if (isBullish(trend1) && isBullish(trend2) && isBearish(x1)) {
            List<MarketBarData> patternCandles = List.of(trend1, trend2, x1, trigger);
            return new PatternResult(PatternType.X4_RELAXED_BUY, trigger, patternCandles, "BUY");
        }

        if (isBearish(trend1) && isBearish(trend2) && isBullish(x1)) {
            List<MarketBarData> patternCandles = List.of(trend1, trend2, x1, trigger);
            return new PatternResult(PatternType.X4_RELAXED_SELL, trigger, patternCandles, "SELL");
        }

        return new PatternResult(PatternType.NONE, null, null, null);
    }

    private PatternResult detectX2Strict(List<MarketBarData> candles) {
        int size = candles.size();
        MarketBarData x1 = candles.get(size - 1);
        MarketBarData candle1 = candles.get(size - 2);

        if (isBullish(candle1) && isBearish(x1)) {
            if (x1.getLow() > candle1.getLow()) {
                List<MarketBarData> patternCandles = List.of(candle1, x1);
                return new PatternResult(PatternType.X2_STRICT_BUY, x1, patternCandles, "BUY");
            }
        }

        if (isBearish(candle1) && isBullish(x1)) {
            if (x1.getHigh() < candle1.getHigh()) {
                List<MarketBarData> patternCandles = List.of(candle1, x1);
                return new PatternResult(PatternType.X2_STRICT_SELL, x1, patternCandles, "SELL");
            }
        }

        return new PatternResult(PatternType.NONE, null, null, null);
    }

    private PatternResult detectX2Relaxed(List<MarketBarData> candles) {
        int size = candles.size();
        MarketBarData x1 = candles.get(size - 1);
        MarketBarData candle1 = candles.get(size - 2);

        if (isBullish(candle1) && isBearish(x1)) {
            List<MarketBarData> patternCandles = List.of(candle1, x1);
            return new PatternResult(PatternType.X2_RELAXED_BUY, x1, patternCandles, "BUY");
        }

        if (isBearish(candle1) && isBullish(x1)) {
            List<MarketBarData> patternCandles = List.of(candle1, x1);
            return new PatternResult(PatternType.X2_RELAXED_SELL, x1, patternCandles, "SELL");
        }

        return new PatternResult(PatternType.NONE, null, null, null);
    }

    private PatternResult detectX3Strict(List<MarketBarData> candles) {
        int size = candles.size();
        MarketBarData x1 = candles.get(size - 1);
        MarketBarData candle2 = candles.get(size - 2);
        MarketBarData candle1 = candles.get(size - 3);

        if (isBullish(candle1) && isBullish(candle2) && isBearish(x1)) {
            if (x1.getLow() > candle2.getLow()) {
                List<MarketBarData> patternCandles = List.of(candle1, candle2, x1);
                return new PatternResult(PatternType.X3_STRICT_BUY, x1, patternCandles, "BUY");
            }
        }

        if (isBearish(candle1) && isBearish(candle2) && isBullish(x1)) {
            if (x1.getHigh() < candle2.getHigh()) {
                List<MarketBarData> patternCandles = List.of(candle1, candle2, x1);
                return new PatternResult(PatternType.X3_STRICT_SELL, x1, patternCandles, "SELL");
            }
        }

        return new PatternResult(PatternType.NONE, null, null, null);
    }

    private PatternResult detectX3Relaxed(List<MarketBarData> candles) {
        int size = candles.size();
        MarketBarData x1 = candles.get(size - 1);
        MarketBarData candle2 = candles.get(size - 2);
        MarketBarData candle1 = candles.get(size - 3);

        if (isBullish(candle1) && isBullish(candle2) && isBearish(x1)) {
            List<MarketBarData> patternCandles = List.of(candle1, candle2, x1);
            return new PatternResult(PatternType.X3_RELAXED_BUY, x1, patternCandles, "BUY");
        }

        if (isBearish(candle1) && isBearish(candle2) && isBullish(x1)) {
            List<MarketBarData> patternCandles = List.of(candle1, candle2, x1);
            return new PatternResult(PatternType.X3_RELAXED_SELL, x1, patternCandles, "SELL");
        }

        return new PatternResult(PatternType.NONE, null, null, null);
    }

    private boolean validateBbBreach(RobotConfig robot, PatternResult result) {
        boolean ogBbEnabled = false;
        boolean ctBbEnabled = false;
        boolean trendCheckEnabled = robot.isTrendCheckEnabled();

        if (!ogBbEnabled && !ctBbEnabled && !trendCheckEnabled) {
            return true;
        }

        if (trendCheckEnabled) {
            Logger.info("  🔍 Trend Check is ENABLED for this robot");
        }

        if (ogBbEnabled) {
            if (!validateOgBbBreach(result)) {
                return false;
            }
        }

        if (ctBbEnabled) {
            if (!validateCtBbTouch(result)) {
                return false;
            }
        }

        if (trendCheckEnabled) {
            if (!validateTrendCheck(result)) {
                return false;
            }
        }

        return true;
    }

    private boolean validateOgBbBreach(PatternResult result) {
        if (result.patternCandles == null || result.patternCandles.size() < 2) {
            Logger.warning("  ⚠ OG-BB Check ENABLED but insufficient pattern candles");
            return false;
        }

        MarketBarData x1 = result.patternCandles.get(result.patternCandles.size() - 2);

        if (x1.getBbUpper() == null || x1.getBbLower() == null) {
            Logger.info("  ⚠ OG-BB Check ENABLED but X1 has no BB data - rejecting pattern");
            return false;
        }

        boolean breached = false;
        String breachType = "";

        if ("BUY".equals(result.direction)) {
            if (x1.getHigh() > x1.getBbUpper()) {
                breached = true;
                breachType = String.format("OG-BB BUY: X1 High %.5f breached BB Upper %.5f", x1.getHigh(), x1.getBbUpper());
            } else {
                Logger.info(String.format("  ✗ OG-BB Check FAILED: BUY pattern but X1 High %.5f did NOT breach BB Upper %.5f",
                    x1.getHigh(), x1.getBbUpper()));
            }
        } else if ("SELL".equals(result.direction)) {
            if (x1.getLow() < x1.getBbLower()) {
                breached = true;
                breachType = String.format("OG-BB SELL: X1 Low %.5f breached BB Lower %.5f", x1.getLow(), x1.getBbLower());
            } else {
                Logger.info(String.format("  ✗ OG-BB Check FAILED: SELL pattern but X1 Low %.5f did NOT breach BB Lower %.5f",
                    x1.getLow(), x1.getBbLower()));
            }
        }

        if (breached) {
            Logger.info("  ✓ OG-BB Check PASSED: " + breachType);
        }

        return breached;
    }

    private boolean validateCtBbTouch(PatternResult result) {
        if (result.patternCandles == null || result.patternCandles.size() < 2) {
            Logger.warning("  ⚠ CT-BB Check ENABLED but insufficient pattern candles");
            return false;
        }

        boolean touched = false;
        String touchDetails = "";

        int lastIndex = result.patternCandles.size() - 1;

        if ("BUY".equals(result.direction)) {
            for (int i = 0; i < lastIndex; i++) {
                MarketBarData candle = result.patternCandles.get(i);
                if (candle.getBbLower() != null && candle.getLow() <= candle.getBbLower()) {
                    touched = true;
                    touchDetails = String.format("CT-BB BUY: Candle Low %.5f touched BB Lower %.5f at %s",
                        candle.getLow(), candle.getBbLower(), candle.getFormattedTimestamp());
                    break;
                }
            }
            if (!touched) {
                Logger.info("  ✗ CT-BB Check FAILED: BUY pattern but NO non-trigger candle touched BB Lower");
            }
        } else if ("SELL".equals(result.direction)) {
            for (int i = 0; i < lastIndex; i++) {
                MarketBarData candle = result.patternCandles.get(i);
                if (candle.getBbUpper() != null && candle.getHigh() >= candle.getBbUpper()) {
                    touched = true;
                    touchDetails = String.format("CT-BB SELL: Candle High %.5f touched BB Upper %.5f at %s",
                        candle.getHigh(), candle.getBbUpper(), candle.getFormattedTimestamp());
                    break;
                }
            }
            if (!touched) {
                Logger.info("  ✗ CT-BB Check FAILED: SELL pattern but NO non-trigger candle touched BB Upper");
            }
        }

        if (touched) {
            Logger.info("  ✓ CT-BB Check PASSED: " + touchDetails);
        }

        return touched;
    }

    private boolean validateTrendCheck(PatternResult result) {
        if (result.triggerCandle == null) {
            Logger.info("  ✗ Trend Check FAILED: No trigger candle");
            return false;
        }

        MarketBarData x1 = result.triggerCandle;

        Logger.info(String.format("  📊 X1 Candle: O=%.5f H=%.5f L=%.5f C=%.5f | BB Upper=%s Lower=%s | Time=%s",
            x1.getOpen(), x1.getHigh(), x1.getLow(), x1.getClose(),
            x1.getBbUpper() != null ? String.format("%.5f", x1.getBbUpper()) : "NULL",
            x1.getBbLower() != null ? String.format("%.5f", x1.getBbLower()) : "NULL",
            x1.getFormattedTimestamp()));

        if (x1.getBbUpper() == null || x1.getBbLower() == null) {
            Logger.info("  ✗ Trend Check FAILED: X1 has no BB data");
            return false;
        }

        if ("BUY".equals(result.direction)) {
            if (x1.getHigh() > x1.getBbUpper()) {
                Logger.info(String.format("  ✓ Trend Check PASSED (BUY): X1 High %.5f > BB Upper %.5f",
                    x1.getHigh(), x1.getBbUpper()));
                return true;
            } else {
                Logger.info(String.format("  ✗ Trend Check FAILED (BUY): X1 High %.5f <= BB Upper %.5f",
                    x1.getHigh(), x1.getBbUpper()));
                return false;
            }
        } else if ("SELL".equals(result.direction)) {
            if (x1.getLow() < x1.getBbLower()) {
                Logger.info(String.format("  ✓ Trend Check PASSED (SELL): X1 Low %.5f < BB Lower %.5f",
                    x1.getLow(), x1.getBbLower()));
                return true;
            } else {
                Logger.info(String.format("  ✗ Trend Check FAILED (SELL): X1 Low %.5f >= BB Lower %.5f",
                    x1.getLow(), x1.getBbLower()));
                return false;
            }
        }

        return false;
    }

    private boolean isBullish(MarketBarData candle) {
        return candle.getClose() > candle.getOpen();
    }

    private boolean isBearish(MarketBarData candle) {
        return candle.getClose() < candle.getOpen();
    }
}
