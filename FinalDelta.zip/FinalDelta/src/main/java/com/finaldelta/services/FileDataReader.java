package com.finaldelta.services;

import com.finaldelta.Logger;
import com.finaldelta.models.MarketBarData;
import com.finaldelta.models.TickData;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class FileDataReader {
    private Path dataDirectory;
    private final Map<String, Long> fileLastModified = new ConcurrentHashMap<>();
    private final Map<String, List<MarketBarData>> barCache = new ConcurrentHashMap<>();
    private final Map<String, TickData> tickCache = new ConcurrentHashMap<>();

    private static final String CANDLES_SUFFIX = "_candles.txt";

    public FileDataReader(String directoryPath) {
        this.dataDirectory = Paths.get(directoryPath);
        if (!Files.exists(dataDirectory)) {
            try {
                Files.createDirectories(dataDirectory);
                Logger.info("Created data directory: " + dataDirectory);
            } catch (IOException e) {
                Logger.error("Failed to create data directory: " + e.getMessage());
            }
        }
    }

    public void setDataDirectory(String directoryPath) {
        this.dataDirectory = Paths.get(directoryPath);
        fileLastModified.clear();
        barCache.clear();
        tickCache.clear();
        Logger.info("Data directory changed to: " + dataDirectory);
    }

    public String getDataDirectory() {
        return dataDirectory.toString();
    }

    public List<MarketBarData> getRecentCompletedBars(String symbol, String timeframe, int count) {
        String fileName = symbol + CANDLES_SUFFIX;
        Path filePath = dataDirectory.resolve(fileName);

        if (!Files.exists(filePath)) {
            return new ArrayList<>();
        }

        try {
            long lastMod = Files.getLastModifiedTime(filePath).toMillis();
            String cacheKey = symbol + "_" + timeframe;

            if (fileLastModified.getOrDefault(cacheKey, 0L) < lastMod) {
                List<MarketBarData> bars = readBarsFromFile(filePath, symbol, timeframe);
                barCache.put(cacheKey, bars);
                fileLastModified.put(cacheKey, lastMod);
            }

            List<MarketBarData> cached = barCache.getOrDefault(cacheKey, new ArrayList<>());
            int size = cached.size();
            if (size <= count) {
                return new ArrayList<>(cached);
            }
            return new ArrayList<>(cached.subList(size - count, size));

        } catch (Exception e) {
            Logger.error("Failed to read bars from file: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    private List<MarketBarData> readBarsFromFile(Path filePath, String symbol, String timeframe) throws IOException {
        List<MarketBarData> bars = new ArrayList<>();
        List<String> lines = Files.readAllLines(filePath);

        for (String line : lines) {
            if (line.trim().isEmpty() || line.startsWith("#")) continue;

            String[] parts = line.split(",");
            if (parts.length < 6) continue;

            try {
                String fileTf = parts[0].trim();

                if (fileTf.equals(timeframe)) {
                    long time = System.currentTimeMillis() / 1000;
                    double open = Double.parseDouble(parts[2].trim());
                    double high = Double.parseDouble(parts[3].trim());
                    double low = Double.parseDouble(parts[4].trim());
                    double close = Double.parseDouble(parts[5].trim());

                    MarketBarData bar = new MarketBarData(symbol, timeframe, time, open, high, low, close);
                    bars.add(bar);
                }
            } catch (Exception e) {
                // Skip malformed lines
            }
        }

        return bars;
    }

    public long getLatestTickTimestamp(String symbol) {
        String fileName = symbol + CANDLES_SUFFIX;
        Path filePath = dataDirectory.resolve(fileName);

        if (!Files.exists(filePath)) {
            return 0;
        }

        try {
            return Files.getLastModifiedTime(filePath).toMillis();
        } catch (IOException e) {
            return 0;
        }
    }

    public long getLatestDataTimestamp() {
        try {
            if (!Files.exists(dataDirectory)) {
                return 0;
            }

            return Files.list(dataDirectory)
                .filter(p -> p.toString().endsWith(CANDLES_SUFFIX))
                .map(p -> {
                    try {
                        return Files.getLastModifiedTime(p).toMillis();
                    } catch (IOException e) {
                        return 0L;
                    }
                })
                .max(Long::compare)
                .orElse(0L);

        } catch (Exception e) {
            Logger.error("Failed to check latest data timestamp: " + e.getMessage());
            return 0;
        }
    }

    public double getLatestBid(String symbol) {
        List<MarketBarData> bars = getRecentCompletedBars(symbol, "M1", 1);
        if (!bars.isEmpty()) {
            return bars.get(bars.size() - 1).getClose();
        }
        return 0.0;
    }

    public double getLatestAsk(String symbol) {
        return getLatestBid(symbol);
    }

    /**
     * Returns list of symbols that have candle data files in the data directory
     */
    public List<String> getAvailableSymbols() {
        try {
            if (!Files.exists(dataDirectory)) {
                return new ArrayList<>();
            }

            return Files.list(dataDirectory)
                    .filter(path -> path.getFileName().toString().endsWith(CANDLES_SUFFIX))
                    .map(path -> {
                        String fileName = path.getFileName().toString();
                        return fileName.substring(0, fileName.length() - CANDLES_SUFFIX.length());
                    })
                    .sorted()
                    .collect(Collectors.toList());

        } catch (Exception e) {
            Logger.error("Failed to get available symbols: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}
