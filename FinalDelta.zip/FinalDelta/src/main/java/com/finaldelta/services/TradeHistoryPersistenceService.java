package com.finaldelta.services;

import com.finaldelta.Logger;
import com.finaldelta.models.TradeHistoryEntry;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

public class TradeHistoryPersistenceService {
    private static TradeHistoryPersistenceService instance;

    private final SupabaseClient supabaseClient;
    private final String localStoragePath;
    private final ExecutorService executor;
    private final boolean useSupabase;
    private final boolean useLocalStorage;

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final ZoneId EET_ZONE = ZoneId.of("Europe/Athens");

    private TradeHistoryPersistenceService(SupabaseClient supabase, String localPath,
                                           boolean useDb, boolean useLocal) {
        this.supabaseClient = supabase;
        this.localStoragePath = localPath;
        this.useSupabase = useDb;
        this.useLocalStorage = useLocal;
        this.executor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "trade-history-persistence");
            t.setDaemon(true);
            return t;
        });

        if (useLocalStorage && localPath != null) {
            initializeLocalStorage();
        }
    }

    public static synchronized TradeHistoryPersistenceService getInstance(
            SupabaseClient supabase, String localPath, boolean useDb, boolean useLocal) {
        if (instance == null) {
            instance = new TradeHistoryPersistenceService(supabase, localPath, useDb, useLocal);
        }
        return instance;
    }

    public static TradeHistoryPersistenceService getInstance() {
        return instance;
    }

    private void initializeLocalStorage() {
        try {
            Path path = Paths.get(localStoragePath);
            if (!Files.exists(path)) {
                Files.createDirectories(path);
                Logger.info("Created local trade history storage at: " + localStoragePath);
            }
        } catch (IOException e) {
            Logger.error("Failed to initialize local storage: " + e.getMessage());
        }
    }

    public void saveTrade(TradeHistoryEntry trade, String userId) {
        executor.submit(() -> {
            if (useSupabase && supabaseClient != null) {
                saveToSupabaseAsync(trade, userId);
            }

            if (useLocalStorage && localStoragePath != null) {
                saveToLocalStorageAsync(trade);
            }
        });
    }

    private void saveToSupabaseAsync(TradeHistoryEntry trade, String userId) {
        try {
            Logger.info("Supabase trade history storage not yet implemented");
        } catch (Exception e) {
            Logger.error("Failed to save trade to Supabase: " + e.getMessage());
        }
    }

    private void saveToLocalStorageAsync(TradeHistoryEntry trade) {
        try {
            String date = LocalDate.now(EET_ZONE).format(DATE_FORMAT);
            String fileName = "trades_" + date + ".csv";
            Path filePath = Paths.get(localStoragePath, fileName);

            boolean fileExists = Files.exists(filePath);

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath.toFile(), true))) {
                if (!fileExists) {
                    writer.write("Timestamp,Ticket,Magic,Symbol,OrderType,State,Volume,EntryPrice,ExitPrice,Profit,Commission,Swap,OpenTime,CloseTime\n");
                }

                writer.write(String.format("%d,%d,%d,%s,%s,%s,%.2f,%.5f,%.5f,%.2f,%.2f,%.2f,%d,%d\n",
                    trade.getTimestamp(),
                    trade.getTicket(),
                    trade.getMagic(),
                    trade.getSymbol(),
                    trade.getOrderType(),
                    trade.getState(),
                    trade.getVolume(),
                    trade.getEntryPrice(),
                    trade.getExitPrice(),
                    trade.getProfit(),
                    trade.getCommission(),
                    trade.getSwap(),
                    trade.getOpenTime(),
                    trade.getCloseTime()
                ));
            }

        } catch (IOException e) {
            Logger.error("Failed to save trade to local storage: " + e.getMessage());
        }
    }

    public List<TradeHistoryEntry> loadTradesFromPeriod(String userId, long fromTimestamp, long toTimestamp) {
        List<TradeHistoryEntry> trades = new ArrayList<>();

        if (useSupabase && supabaseClient != null) {
            trades.addAll(loadFromSupabase(userId, fromTimestamp, toTimestamp));
        } else if (useLocalStorage && localStoragePath != null) {
            trades.addAll(loadFromLocalStorage(fromTimestamp, toTimestamp));
        }

        return trades;
    }

    private List<TradeHistoryEntry> loadFromSupabase(String userId, long fromTimestamp, long toTimestamp) {
        List<TradeHistoryEntry> trades = new ArrayList<>();

        try {
            Logger.info("Supabase trade history loading not yet implemented");
        } catch (Exception e) {
            Logger.error("Failed to load trades from Supabase: " + e.getMessage());
        }

        return trades;
    }

    private List<TradeHistoryEntry> loadFromLocalStorage(long fromTimestamp, long toTimestamp) {
        List<TradeHistoryEntry> trades = new ArrayList<>();

        try {
            Path storagePath = Paths.get(localStoragePath);
            if (!Files.exists(storagePath)) {
                return trades;
            }

            List<Path> csvFiles = Files.list(storagePath)
                .filter(path -> path.getFileName().toString().startsWith("trades_") &&
                               path.getFileName().toString().endsWith(".csv"))
                .collect(Collectors.toList());

            for (Path csvFile : csvFiles) {
                List<String> lines = Files.readAllLines(csvFile);

                for (int i = 1; i < lines.size(); i++) {
                    String line = lines.get(i);
                    String[] parts = line.split(",");

                    if (parts.length >= 14) {
                        long openTime = Long.parseLong(parts[12]);

                        if (openTime >= fromTimestamp && openTime <= toTimestamp) {
                            TradeHistoryEntry trade = new TradeHistoryEntry();
                            trade.setTimestamp(Long.parseLong(parts[0]));
                            trade.setTicket(Long.parseLong(parts[1]));
                            trade.setMagic(Long.parseLong(parts[2]));
                            trade.setSymbol(parts[3]);
                            trade.setOrderType(parts[4]);
                            trade.setState(parts[5]);
                            trade.setVolume(Double.parseDouble(parts[6]));
                            trade.setEntryPrice(Double.parseDouble(parts[7]));
                            trade.setExitPrice(Double.parseDouble(parts[8]));
                            trade.setProfit(Double.parseDouble(parts[9]));
                            trade.setCommission(Double.parseDouble(parts[10]));
                            trade.setSwap(Double.parseDouble(parts[11]));
                            trade.setOpenTime(openTime);
                            trade.setCloseTime(Long.parseLong(parts[13]));
                            trades.add(trade);
                        }
                    }
                }
            }

            trades.sort((t1, t2) -> Long.compare(t2.getOpenTime(), t1.getOpenTime()));
            Logger.info("Loaded " + trades.size() + " trades from local storage");

        } catch (Exception e) {
            Logger.error("Failed to load trades from local storage: " + e.getMessage());
        }

        return trades;
    }

    public void shutdown() {
        executor.shutdown();
        Logger.info("Trade history persistence service shut down");
    }
}
