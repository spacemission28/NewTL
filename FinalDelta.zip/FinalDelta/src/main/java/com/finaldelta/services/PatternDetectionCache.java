package com.finaldelta.services;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Cache for pattern detection to prevent redundant processing.
 *
 * Pattern detection is expensive and only needs to run when a NEW candle closes.
 * This cache tracks the last processed candle timestamp per robot/symbol/timeframe
 * to avoid re-running pattern detection on the same candle multiple times.
 *
 * THREAD-SAFE: Uses ConcurrentHashMap for lock-free concurrent access.
 * COMMAND QUEUE SAFE: This is a READ-ONLY optimization that does NOT affect
 * command generation, queuing, or execution order.
 */
public class PatternDetectionCache {

    /**
     * Key format: "robotId_symbol_timeframe"
     * Value: Last processed candle close time (unix timestamp seconds)
     */
    private final Map<String, Long> lastPatternCheck = new ConcurrentHashMap<>();

    /**
     * Check if pattern detection should run for this candle.
     *
     * @param robotId Unique robot identifier
     * @param symbol Trading symbol (e.g., "EURUSD")
     * @param timeframe Candle timeframe (e.g., "M5", "H1")
     * @param candleCloseTime Unix timestamp (seconds) when candle closed
     * @return true if this is a NEW candle that hasn't been processed yet
     */
    public boolean shouldRunPatternDetection(
        String robotId,
        String symbol,
        String timeframe,
        long candleCloseTime
    ) {
        String cacheKey = buildKey(robotId, symbol, timeframe);
        Long lastCheck = lastPatternCheck.get(cacheKey);

        return lastCheck == null || lastCheck < candleCloseTime;
    }

    /**
     * Mark a candle as processed for pattern detection.
     *
     * @param robotId Unique robot identifier
     * @param symbol Trading symbol
     * @param timeframe Candle timeframe
     * @param candleCloseTime Unix timestamp (seconds) when candle closed
     */
    public void markAsProcessed(
        String robotId,
        String symbol,
        String timeframe,
        long candleCloseTime
    ) {
        String cacheKey = buildKey(robotId, symbol, timeframe);
        lastPatternCheck.put(cacheKey, candleCloseTime);
    }

    /**
     * Clear pattern detection history for a specific robot.
     * Call this when a robot is deactivated or removed.
     *
     * @param robotId Robot to clear
     */
    public void clearRobot(String robotId) {
        lastPatternCheck.keySet().removeIf(key -> key.startsWith(robotId + "_"));
    }

    /**
     * Clear entire cache.
     * Useful for testing or system reset.
     */
    public void clearAll() {
        lastPatternCheck.clear();
    }

    /**
     * Get current cache size (for monitoring/debugging).
     *
     * @return Number of cached entries
     */
    public int size() {
        return lastPatternCheck.size();
    }

    /**
     * Build cache key from robot/symbol/timeframe.
     */
    private String buildKey(String robotId, String symbol, String timeframe) {
        return robotId + "_" + symbol + "_" + timeframe;
    }

    /**
     * Get statistics about pattern detection efficiency.
     *
     * @return Human-readable stats string
     */
    public String getStats() {
        return String.format("Pattern Detection Cache: %d active entries", lastPatternCheck.size());
    }
}
