package com.finaldelta.services;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.finaldelta.Logger;
import com.finaldelta.models.TradeHistoryEntry;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Writes trade history data to local files for file-based mode.
 * Maintains a rolling file of recent trade history entries for OCO imbalance detection.
 */
public class TradeHistoryFileWriter {
    private static TradeHistoryFileWriter instance;
    private final String dataDirectory;
    private final String tradeHistoryFilePath;
    private final Gson gson;
    private final ScheduledExecutorService scheduler;
    private final TradeHistoryCache cache;
    private volatile boolean running = false;

    private static final int WRITE_INTERVAL_SECONDS = 2;

    private TradeHistoryFileWriter(String dataDirectory) {
        this.dataDirectory = dataDirectory;
        File dir = new File(dataDirectory);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        this.tradeHistoryFilePath = dataDirectory + File.separator + "trade_history.json";
        this.gson = new GsonBuilder().setPrettyPrinting().create();
        this.scheduler = Executors.newScheduledThreadPool(1);
        this.cache = TradeHistoryCache.getInstance();
        Logger.info("TradeHistoryFileWriter initialized: " + dataDirectory);
    }

    public static synchronized TradeHistoryFileWriter getInstance(String dataDirectory) {
        if (instance == null) {
            instance = new TradeHistoryFileWriter(dataDirectory);
        }
        return instance;
    }

    public void start() {
        if (running) {
            Logger.warning("TradeHistoryFileWriter already running");
            return;
        }

        scheduler.scheduleAtFixedRate(
            this::writeTradeHistorySnapshot,
            WRITE_INTERVAL_SECONDS,
            WRITE_INTERVAL_SECONDS,
            TimeUnit.SECONDS
        );

        running = true;
        Logger.info("TradeHistoryFileWriter started (writing every " + WRITE_INTERVAL_SECONDS + " seconds)");
    }

    public void stop() {
        if (!running) {
            return;
        }

        if (scheduler != null && !scheduler.isShutdown()) {
            writeTradeHistorySnapshot();
            scheduler.shutdown();
            try {
                if (!scheduler.awaitTermination(5, TimeUnit.SECONDS)) {
                    scheduler.shutdownNow();
                }
            } catch (InterruptedException e) {
                scheduler.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }

        running = false;
        Logger.info("TradeHistoryFileWriter stopped");
    }

    /**
     * Writes a snapshot of recent trades to file.
     * Keeps last 5 minutes of trade history for OCO imbalance detection.
     */
    private void writeTradeHistorySnapshot() {
        try {
            List<TradeHistoryEntry> recentTrades = cache.getTradesInLast(300);

            try (FileWriter writer = new FileWriter(tradeHistoryFilePath)) {
                gson.toJson(recentTrades, writer);
            }

        } catch (IOException e) {
            Logger.error("Failed to write trade history snapshot: " + e.getMessage());
        } catch (Exception e) {
            Logger.error("Unexpected error writing trade history: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public String getTradeHistoryFilePath() {
        return tradeHistoryFilePath;
    }
}
