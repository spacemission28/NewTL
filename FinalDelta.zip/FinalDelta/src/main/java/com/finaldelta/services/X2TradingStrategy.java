package com.finaldelta.services;

import com.finaldelta.Logger;
import com.finaldelta.models.MarketBarData;
import com.finaldelta.models.PendingPatternSetup;
import com.finaldelta.models.RobotConfig;
import com.finaldelta.models.TradeCommand;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;

public class X2TradingStrategy {

    private final LotSizeCalculator lotSizeCalculator;

    public X2TradingStrategy() {
        this.lotSizeCalculator = new LotSizeCalculator();
    }

    public boolean isWithinTradingWindow(RobotConfig robot, long candleCloseTime) {
        LocalDateTime candleTime = LocalDateTime.ofEpochSecond(candleCloseTime, 0, ZoneOffset.UTC);
        int candleHour = candleTime.getHour();
        int candleMinute = candleTime.getMinute();

        int startHour = robot.getStartHour();
        int startMinute = robot.getStartMinute();
        int endHour = robot.getEndHour();
        int endMinute = robot.getEndMinute();

        int candleMinutes = candleHour * 60 + candleMinute;
        int startMinutes = startHour * 60 + startMinute;
        int endMinutes = endHour * 60 + endMinute;

        return candleMinutes >= startMinutes && candleMinutes <= endMinutes;
    }

    public boolean isEndOfDayReached(RobotConfig robot) {
        LocalDateTime now = LocalDateTime.now(ZoneOffset.UTC);
        int currentHour = now.getHour();
        int currentMinute = now.getMinute();

        int endHour = robot.getEndHour();
        int endMinute = robot.getEndMinute();

        int currentMinutes = currentHour * 60 + currentMinute;
        int endMinutes = endHour * 60 + endMinute;

        return currentMinutes >= endMinutes;
    }

    public List<TradeCommand> generateOrdersForBreachedSetup(
            PendingPatternSetup setup,
            double currentBid,
            double accountBalance,
            String accountCurrency,
            Map<String, Double> conversionRates) {

        List<TradeCommand> commands = new ArrayList<>();
        RobotConfig robot = setup.getRobotConfig();

        if (robot.isDisableLeapfrog()) {
            Logger.info("    → Leapfrog protection DISABLED - will place orders");
        } else {
            Logger.info("    → Leapfrog protection ENABLED - checking for existing positions");
        }

        String direction = setup.getDirection();
        String orderType = "BUY".equals(direction) ? "BUY_STOP" : "SELL_STOP";
        MarketBarData triggerCandle = setup.getTriggerCandle();
        double entryPrice = setup.getBreachLevel();

        double slPrice = calculateStopLoss(robot, triggerCandle, setup.getPatternCandles(), direction, entryPrice);
        double[] tpPrices = calculateTpLevels(setup, currentBid, direction);
        double[] tpVolumes = getTpVolumes(robot);
        double[] tpPercentages = {
            robot.getTp1Pct(),
            robot.getTp2Pct(),
            robot.getTp3Pct()
        };
        String patternCode = getPatternCode(setup.getPatternType());

        for (int i = 0; i < 3; i++) {
            if (tpVolumes[i] <= 0) {
                Logger.info(String.format("      ⚠ TP%d: Volume % = 0, skipping", i + 1));
                continue;
            }

            double volumePercent = tpVolumes[i] / 100.0;
            double lotSize = calculateSimpleLotSize(robot, accountBalance, volumePercent);

            if (lotSize <= 0) {
                Logger.info(String.format("      ⚠ TP%d: Lot size = 0, skipping", i + 1));
                continue;
            }

            String comment = String.format("TP%d_%.0f_%s_%s",
                i + 1,
                tpPercentages[i],
                setup.getMagicNumber(),
                patternCode);

            Map<String, Object> params = new HashMap<>();
            params.put("symbol", setup.getSymbol());
            params.put("order_type", orderType);
            params.put("volume", lotSize);
            params.put("price", entryPrice);
            params.put("sl", slPrice);
            params.put("tp", tpPrices[i]);
            params.put("comment", comment);

            TradeCommand cmd = new TradeCommand(
                robot.getId(),
                setup.getMagicNumber(),
                "PLACE_ORDER",
                params
            );

            commands.add(cmd);

            Logger.info(String.format("      ✓ TP%d: Entry=%.5f, SL=%.5f, TP=%.5f, Lot=%.2f, Comment=%s",
                i + 1, entryPrice, slPrice, tpPrices[i], lotSize, comment));
        }

        return commands;
    }

    private double[] calculateTpLevels(PendingPatternSetup setup, double currentBid, String direction) {
        RobotConfig robot = setup.getRobotConfig();
        MarketBarData triggerCandle = setup.getTriggerCandle();
        double barHeight = triggerCandle.getHigh() - triggerCandle.getLow();

        double[] tpPercentages = {
            robot.getTp1Pct(),
            robot.getTp2Pct(),
            robot.getTp3Pct()
        };

        double[] tpPrices = new double[3];
        double entryPrice = setup.getBreachLevel();

        for (int i = 0; i < 3; i++) {
            double distance = barHeight * (tpPercentages[i] / 100.0);

            if ("BUY".equals(direction)) {
                tpPrices[i] = entryPrice + distance;
            } else {
                tpPrices[i] = entryPrice - distance;
            }
        }

        return tpPrices;
    }

    private double[] getTpVolumes(RobotConfig robot) {
        return new double[] {
            robot.getTp1Volume(),
            robot.getTp2Volume(),
            robot.getTp3Volume()
        };
    }

    public TradeCommand generateDeleteAllCommand(String magicNumber, UUID robotConfigId) {
        Map<String, Object> params = new HashMap<>();
        params.put("magic_number", magicNumber);

        return new TradeCommand(
            robotConfigId,
            magicNumber,
            "DELETE_ALL_MAGIC",
            params
        );
    }

    public TradeCommand generateEmergencyCloseAllCommand(String magicNumber, UUID robotConfigId) {
        Map<String, Object> params = new HashMap<>();
        params.put("magic_number", magicNumber);

        return new TradeCommand(
            robotConfigId,
            magicNumber,
            "EMERGENCY_CLOSE_ALL",
            params
        );
    }

    private double calculateSimpleLotSize(RobotConfig robot, double accountBalance, double volumePercent) {
        double riskPercent = robot.getRptPercent();
        double riskAmount = accountBalance * (riskPercent / 100.0);
        double lotSize = (riskAmount * volumePercent) / 1000.0;
        return Math.max(0.01, Math.min(100.0, Math.round(lotSize * 100.0) / 100.0));
    }

    private double calculateStopLoss(RobotConfig robot, MarketBarData triggerCandle, List<MarketBarData> patternCandles, String direction, double entryPrice) {
        double slDistance;

        if (false && patternCandles != null && !patternCandles.isEmpty()) {
            if ("BUY".equals(direction)) {
                double lowestLow = patternCandles.stream()
                    .mapToDouble(MarketBarData::getLow)
                    .min()
                    .orElse(triggerCandle.getLow());
                slDistance = triggerCandle.getHigh() - lowestLow;
            } else {
                double highestHigh = patternCandles.stream()
                    .mapToDouble(MarketBarData::getHigh)
                    .max()
                    .orElse(triggerCandle.getHigh());
                slDistance = highestHigh - triggerCandle.getLow();
            }

            double slPercent = robot.getStopLossPercent();
            slDistance = slDistance * (slPercent / 100.0);

            Logger.info(String.format("  → Sequence SL: Using distance across %d candles = %.5f pips",
                patternCandles.size(), slDistance * 10000));
        } else {
            double barHeight = triggerCandle.getHigh() - triggerCandle.getLow();
            double slPercent = robot.getStopLossPercent();
            slDistance = barHeight * (slPercent / 100.0);

            Logger.info(String.format("  → Standard SL: Using X1 height = %.5f pips",
                slDistance * 10000));
        }

        double slPrice;
        if ("BUY".equals(direction)) {
            slPrice = triggerCandle.getLow() - slDistance;
        } else {
            slPrice = triggerCandle.getHigh() + slDistance;
        }

        return slPrice;
    }

    private String getPatternCode(com.finaldelta.services.PatternDetector.PatternType patternType) {
        switch (patternType) {
            case OG_BUY:
            case OG_SELL:
                return "OG";
            case X2_STRICT_BUY:
            case X2_STRICT_SELL:
                return "X2S";
            case X2_RELAXED_BUY:
            case X2_RELAXED_SELL:
                return "X2R";
            case X4_STRICT_BUY:
            case X4_STRICT_SELL:
                return "X4S";
            case X4_RELAXED_BUY:
            case X4_RELAXED_SELL:
                return "X4R";
            default:
                return "UNKNOWN";
        }
    }

    private int calculateTpDistanceInPips(double entryPrice, double tpPrice, String symbol) {
        double distance = Math.abs(tpPrice - entryPrice);

        if (symbol.contains("JPY")) {
            return (int) Math.round(distance * 100);
        } else {
            return (int) Math.round(distance * 10000);
        }
    }
}
