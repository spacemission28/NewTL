package com.finaldelta.services;

import com.finaldelta.Logger;
import com.finaldelta.models.TradeHistoryEntry;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.stream.Collectors;

public class TradeHistoryCache {
    private static TradeHistoryCache instance;
    private final ConcurrentLinkedDeque<TradeHistoryEntry> recentTrades = new ConcurrentLinkedDeque<>();
    private static final int MAX_CACHE_SIZE = 1000;
    private static final long RETENTION_PERIOD_MS = 300000; // 5 minutes

    private TradeHistoryCache() {}

    public static synchronized TradeHistoryCache getInstance() {
        if (instance == null) {
            instance = new TradeHistoryCache();
        }
        return instance;
    }

    public void addTrade(TradeHistoryEntry entry) {
        recentTrades.addFirst(entry);

        if (recentTrades.size() > MAX_CACHE_SIZE) {
            recentTrades.removeLast();
        }

        cleanupOldTrades();
    }

    public void addTrades(List<TradeHistoryEntry> entries) {
        for (TradeHistoryEntry entry : entries) {
            addTrade(entry);
        }
    }

    public List<TradeHistoryEntry> getAllTrades() {
        return new ArrayList<>(recentTrades);
    }

    public List<TradeHistoryEntry> getTradesInLast(int seconds) {
        long cutoffTime = System.currentTimeMillis() - (seconds * 1000L);

        return recentTrades.stream()
            .filter(trade -> trade.getTimestamp() >= cutoffTime)
            .collect(Collectors.toList());
    }

    public boolean hasFilledOrders(long magicNumber, String symbol, int seconds) {
        long cutoffTime = System.currentTimeMillis() - (seconds * 1000L);

        return recentTrades.stream()
            .anyMatch(trade ->
                trade.getMagic() == magicNumber &&
                trade.getSymbol().equals(symbol) &&
                trade.getTimestamp() >= cutoffTime
            );
    }

    private void cleanupOldTrades() {
        long cutoffTime = System.currentTimeMillis() - RETENTION_PERIOD_MS;
        recentTrades.removeIf(trade -> trade.getTimestamp() < cutoffTime);
    }

    public int size() {
        return recentTrades.size();
    }

    public void clear() {
        recentTrades.clear();
        Logger.info("Trade history cache cleared");
    }
}
