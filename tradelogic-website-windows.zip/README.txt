TradeLogic Website - Local Viewing Instructions
===============================================

FOLDER STRUCTURE:
- index.html          (Main homepage - START HERE)
- log in page.html    (Login page)
- dashboard.html      (Dashboard view)
- static/             (Images and assets)
  - b.jpg            (Logo light mode)
  - c.png            (Logo dark mode)
  - ny1.jpg          (Hero image 1)
  - ny3.jpg          (Hero image 2)
  - ny4.jpg          (Hero image 3)

HOW TO VIEW:
1. Double-click on "index.html" to open in your web browser
2. Navigate using the links on the pages
3. For login page, click "Portal Access" on the homepage

IMPORTANT NOTES:
- This is a static version for viewing only
- Login functionality is disabled (no server running)
- Dashboard is accessible directly by opening dashboard.html
- All images should display correctly

TROUBLESHOOTING:
- If images don't appear: Make sure the "static" folder is in the same folder as the HTML files
- If links don't work: Use the files in this exact folder structure
- For best results: Use Chrome, Firefox, or Edge browsers

Original Python app (app.py) is NOT included in this package as it requires 
a server environment to run. This package is for static viewing only.
