package com.tradelogic.models;

public class BollingerBandsData {
    public String symbol;
    public String timeframe;
    public long timestamp;
    public double bbUpper;
    public double bbMiddle;
    public double bbLower;
    public int period;
    public double deviation;

    public BollingerBandsData() {
    }

    public BollingerBandsData(String symbol, String timeframe, long timestamp,
                               double bbUpper, double bbMiddle, double bbLower,
                               int period, double deviation) {
        this.symbol = symbol;
        this.timeframe = timeframe;
        this.timestamp = timestamp;
        this.bbUpper = bbUpper;
        this.bbMiddle = bbMiddle;
        this.bbLower = bbLower;
        this.period = period;
        this.deviation = deviation;
    }

    @Override
    public String toString() {
        return String.format("BB[%s %s] U:%.5f M:%.5f L:%.5f P:%d D:%.2f",
                symbol, timeframe, bbUpper, bbMiddle, bbLower, period, deviation);
    }
}
