package com.tradelogic.models;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

/**
 * Lightweight POJO for storing tick data without JavaFX properties.
 * Used for efficient storage and processing.
 */
public class TickData {
    private final String symbol;
    private final long timestampSeconds;
    private final double bid;
    private final double ask;
    private final long volume;

    private static final DateTimeFormatter DISPLAY_FORMATTER =
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public TickData(String symbol, long timestampSeconds, double bid, double ask, long volume) {
        this.symbol = symbol;
        this.timestampSeconds = timestampSeconds;
        this.bid = bid;
        this.ask = ask;
        this.volume = volume;
    }

    public String getKey() {
        return symbol;
    }

    public String getSymbol() {
        return symbol;
    }

    public long getTimestampSeconds() {
        return timestampSeconds;
    }

    public String getFormattedTimestamp() {
        return LocalDateTime.ofEpochSecond(
            timestampSeconds,
            0,
            java.time.ZoneOffset.UTC
        ).format(DISPLAY_FORMATTER);
    }

    public double getBid() {
        return bid;
    }

    public double getAsk() {
        return ask;
    }

    public long getVolume() {
        return volume;
    }
}
