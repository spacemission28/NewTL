package com.tradelogic.services;

import com.tradelogic.Logger;
import com.tradelogic.models.ExecutionFeedback;
import com.tradelogic.models.TradeCommand;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * ENHANCED OCO Manager - Manages OCO (One-Cancels-Other) logic for pending orders.
 *
 * NEW BEHAVIOR (v2):
 * - When ANY order fills → IMMEDIATELY HALT all remaining order placement (ALWAYS)
 * - Then check "OCO Wait" flag:
 *   - If FALSE: Immediate delete of opposite orders
 *   - If TRUE: Trigger OcoWaitExecutor for 3-second countdown before deletion
 *
 * When 14 orders are placed (7 BUY STOP + 7 SELL STOP) for a robot:
 * - All 14 orders share the same magic number
 * - When ANY order on one side fills, ALL orders on the opposite side must be deleted
 * - This prevents both sides from executing (which would be a hedge)
 *
 * This class tracks:
 * - Which magic numbers have pending order groups
 * - Which side filled first (BUY or SELL)
 * - Whether "OCO Wait" is enabled for each group
 * - Placement halt signals for active order placement loops
 */
public class OcoManager {

    private static class OrderGroup {
        String magicNumber;
        UUID robotConfigId;
        boolean hasBuyOrders;
        boolean hasSellOrders;
        boolean buyFilled;
        boolean sellFilled;
        boolean oppositeDeleteSent;
        boolean ocoWaitEnabled;
        long placementTime;
        AtomicBoolean haltPlacement;

        OrderGroup(String magicNumber, UUID robotConfigId, boolean ocoWaitEnabled) {
            this.magicNumber = magicNumber;
            this.robotConfigId = robotConfigId;
            this.hasBuyOrders = false;
            this.hasSellOrders = false;
            this.buyFilled = false;
            this.sellFilled = false;
            this.oppositeDeleteSent = false;
            this.ocoWaitEnabled = ocoWaitEnabled;
            this.placementTime = System.currentTimeMillis();
            this.haltPlacement = new AtomicBoolean(false);
        }
    }

    private final Map<String, OrderGroup> activeGroups = new ConcurrentHashMap<>();
    private OcoWaitExecutor ocoWaitExecutor;

    public OcoManager() {
    }

    public void setOcoWaitExecutor(OcoWaitExecutor executor) {
        this.ocoWaitExecutor = executor;
    }

    /**
     * Registers a new OCO order group when orders are being placed (backward compatibility)
     *
     * @param magicNumber Magic number for the order group
     * @param robotConfigId Robot configuration UUID
     * @param hasBuy Whether BUY orders are being placed
     * @param hasSell Whether SELL orders are being placed
     */
    public void registerOrderGroup(String magicNumber, UUID robotConfigId, boolean hasBuy, boolean hasSell) {
        registerOrderGroup(magicNumber, robotConfigId, hasBuy, hasSell, false);
    }

    /**
     * Registers a new OCO order group when orders are being placed
     *
     * @param magicNumber Magic number for the order group
     * @param robotConfigId Robot configuration UUID
     * @param hasBuy Whether BUY orders are being placed
     * @param hasSell Whether SELL orders are being placed
     * @param ocoWaitEnabled Whether "OCO Wait" checkbox is enabled
     */
    public void registerOrderGroup(String magicNumber, UUID robotConfigId, boolean hasBuy, boolean hasSell, boolean ocoWaitEnabled) {
        Logger.info("OCO Manager: Registering order group - Magic: " + magicNumber +
                   ", BUY: " + hasBuy + ", SELL: " + hasSell + ", OCO Wait: " + ocoWaitEnabled);

        OrderGroup group = new OrderGroup(magicNumber, robotConfigId, ocoWaitEnabled);
        group.hasBuyOrders = hasBuy;
        group.hasSellOrders = hasSell;
        activeGroups.put(magicNumber, group);

        Logger.info("OCO Manager: Registered order group for magic " + magicNumber +
                   " (Total active groups: " + activeGroups.size() + ")");
    }

    /**
     * Checks if placement should be halted for a magic number
     * Order placement loops should check this flag frequently
     *
     * @param magicNumber Magic number to check
     * @return true if placement should halt, false otherwise
     */
    public boolean shouldHaltPlacement(String magicNumber) {
        OrderGroup group = activeGroups.get(magicNumber);
        return group != null && group.haltPlacement.get();
    }

    /**
     * Processes execution feedback and determines OCO action
     *
     * @param feedback Execution feedback from MT5
     * @param command Original trade command
     * @return Optional delete command if immediate deletion needed (OCO Wait disabled), empty otherwise
     */
    public Optional<TradeCommand> processFill(ExecutionFeedback feedback, TradeCommand command) {
        if (!feedback.isSuccess()) {
            return Optional.empty();
        }

        String magicNumber = command.getMagicNumber();
        OrderGroup group = activeGroups.get(magicNumber);

        if (group == null) {
            Logger.warning("OCO Manager: Received fill for unknown magic number " + magicNumber);
            return Optional.empty();
        }

        if (group.oppositeDeleteSent) {
            return Optional.empty();
        }

        String action = command.getAction();
        if (!"PLACE_ORDER".equals(action)) {
            return Optional.empty();
        }

        @SuppressWarnings("unchecked")
        Map<String, Object> params = command.getParameters();
        String orderType = (String) params.get("order_type");

        if (orderType == null) {
            return Optional.empty();
        }

        boolean isBuy = orderType.startsWith("BUY");
        boolean isSell = orderType.startsWith("SELL");

        String filledSide = null;
        boolean shouldTriggerOco = false;

        if (isBuy && !group.buyFilled) {
            group.buyFilled = true;
            filledSide = "BUY";
            shouldTriggerOco = group.hasSellOrders;
            Logger.info("★★★ OCO Manager: BUY order filled for magic " + magicNumber + " - FIRST BUY FILL");

        } else if (isSell && !group.sellFilled) {
            group.sellFilled = true;
            filledSide = "SELL";
            shouldTriggerOco = group.hasBuyOrders;
            Logger.info("★★★ OCO Manager: SELL order filled for magic " + magicNumber + " - FIRST SELL FILL");
        }

        if (shouldTriggerOco && filledSide != null) {
            group.haltPlacement.set(true);
            Logger.info("★★★ OCO Manager: HALT SIGNAL SET for magic " + magicNumber + " - No more orders will be placed");

            group.oppositeDeleteSent = true;

            if (group.ocoWaitEnabled) {
                Logger.info("★★★ OCO Manager: OCO Wait ENABLED - Starting 3-second countdown");
                if (ocoWaitExecutor != null) {
                    ocoWaitExecutor.startCountdown(magicNumber, filledSide, group.robotConfigId);
                } else {
                    Logger.error("OCO Manager: OcoWaitExecutor not set! Cannot start countdown");
                }
                return Optional.empty();

            } else {
                Logger.info("★★★ OCO Manager: OCO Wait DISABLED - Immediate deletion");
                return Optional.of(createDeleteCommand(filledSide, magicNumber, group.robotConfigId));
            }
        }

        return Optional.empty();
    }

    /**
     * Creates a delete command for opposite side orders
     */
    private TradeCommand createDeleteCommand(String filledSide, String magicNumber, UUID robotConfigId) {
        String oppositeType = filledSide.equals("BUY") ? "SELL" : "BUY";

        Map<String, Object> params = new HashMap<>();
        params.put("magic_number", magicNumber);
        params.put("order_type", oppositeType + "_STOP");

        TradeCommand command = new TradeCommand(
            robotConfigId,
            magicNumber,
            "DELETE_OPPOSITE_SIDE",
            params
        );

        Logger.info("OCO Manager: Created DELETE command for " + oppositeType + " orders (magic: " + magicNumber + ")");
        return command;
    }

    /**
     * Removes an order group from tracking
     */
    public void removeOrderGroup(String magicNumber) {
        OrderGroup removed = activeGroups.remove(magicNumber);
        if (removed != null) {
            Logger.info("OCO Manager: Removed order group for magic " + magicNumber);
        }
    }

    /**
     * Checks if a magic number has an active OCO group
     */
    public boolean hasActiveGroup(String magicNumber) {
        return activeGroups.containsKey(magicNumber);
    }

    /**
     * Gets all active magic numbers being tracked
     */
    public Set<String> getActiveMagicNumbers() {
        return new HashSet<>(activeGroups.keySet());
    }

    /**
     * Clears all tracked groups
     */
    public void clear() {
        int count = activeGroups.size();
        activeGroups.clear();
        Logger.info("OCO Manager: Cleared " + count + " order groups");
    }

    /**
     * Gets statistics about OCO management
     */
    public Map<String, Object> getStatistics() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("active_groups", activeGroups.size());

        int buyFilled = 0;
        int sellFilled = 0;
        int bothSides = 0;
        int deletesSent = 0;
        int ocoWaitEnabled = 0;

        for (OrderGroup group : activeGroups.values()) {
            if (group.buyFilled) buyFilled++;
            if (group.sellFilled) sellFilled++;
            if (group.hasBuyOrders && group.hasSellOrders) bothSides++;
            if (group.oppositeDeleteSent) deletesSent++;
            if (group.ocoWaitEnabled) ocoWaitEnabled++;
        }

        stats.put("buy_filled", buyFilled);
        stats.put("sell_filled", sellFilled);
        stats.put("both_sides_pending", bothSides);
        stats.put("deletes_sent", deletesSent);
        stats.put("oco_wait_enabled", ocoWaitEnabled);

        return stats;
    }

    /**
     * Marks that a delete command was sent for end-of-day cleanup
     */
    public void markEndOfDayCleanup(String magicNumber) {
        OrderGroup group = activeGroups.get(magicNumber);
        if (group != null) {
            group.oppositeDeleteSent = true;
            Logger.info("OCO Manager: Marked EOD cleanup for magic " + magicNumber);
        }
    }
}
