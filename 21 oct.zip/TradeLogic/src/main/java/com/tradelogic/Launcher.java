package com.tradelogic;

/**
 * This is a non-JavaFX main class used to "trick" the Java launcher
 * and avoid the modular-related "JavaFX runtime components are missing" error
 * when running a shaded (fat) JAR.
 */
public class Launcher {
    public static void main(String[] args) {
        // Call the main method of your original JavaFX application class
        TickRecorderApplication.main(args);
    }
}