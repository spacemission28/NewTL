package com.tradelogic.services;

import com.tradelogic.models.TradeCommand;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedDeque;

public class TradeCommandQueue {
    private final ConcurrentLinkedDeque<TradeCommand> queue = new ConcurrentLinkedDeque<>();

    public void add(TradeCommand command) {
        queue.offerLast(command);
    }

    public void addFirst(TradeCommand command) {
        queue.offerFirst(command);
    }

    public TradeCommand poll() {
        return queue.pollFirst();
    }

    public List<TradeCommand> pollBatch(String magicNumber, int maxBatch) {
        List<TradeCommand> batch = new ArrayList<>();
        List<TradeCommand> remaining = new ArrayList<>();

        TradeCommand cmd;
        while ((cmd = queue.pollFirst()) != null) {
            if (cmd.getMagicNumber().equals(magicNumber) && batch.size() < maxBatch) {
                batch.add(cmd);
            } else {
                remaining.add(cmd);
            }
        }

        for (TradeCommand c : remaining) {
            queue.offerLast(c);
        }

        return batch;
    }

    public List<TradeCommand> pollAll() {
        List<TradeCommand> commands = new ArrayList<>();
        TradeCommand cmd;
        while ((cmd = queue.pollFirst()) != null) {
            commands.add(cmd);
        }
        return commands;
    }

    public int size() {
        return queue.size();
    }

    public boolean isEmpty() {
        return queue.isEmpty();
    }
}
