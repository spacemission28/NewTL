package com.tradelogic.services;

import com.tradelogic.Logger;
import com.tradelogic.models.CERobotConfig;
import com.tradelogic.models.MarketBarData;
import com.tradelogic.models.TradeCommand;
import java.util.*;

public class CEStrategyService {

    private final CEOcoManager ceOcoManager;
    private final TradeHistoryCache tradeHistoryCache;

    public CEStrategyService(CEOcoManager ceOcoManager, TradeHistoryCache tradeHistoryCache) {
        this.ceOcoManager = ceOcoManager;
        this.tradeHistoryCache = tradeHistoryCache;
    }

    public List<TradeCommand> analyzeSignalAndGenerateCECommands(
            CERobotConfig robot,
            MarketBarData barData,
            double currentBid,
            double accountEquity,
            String accountCurrency,
            Map<String, Double> conversionRates) {

        List<TradeCommand> commands = new ArrayList<>();

        if (!robot.isFullyEnabled()) {
            return commands;
        }

        int nextSequence = ceOcoManager.getNextSequenceForRobot(robot.getRobotName());

        if (nextSequence >= robot.getCeMaxSequence()) {
            return commands;
        }

        double barHeight = barData.getHigh() - barData.getLow();
        double minHeight = convertX1Height(robot.getMinX1Height(), robot.getX1Type(), robot.getSymbol());

        if (barHeight < minHeight) {
            return commands;
        }

        double trigPercent = robot.getTrigPercent() / 100.0;
        double stopLossPercent = robot.getStopLossPercent() / 100.0;

        double buyEntry = barData.getHigh() + (barHeight * trigPercent);
        double buyStopLoss = barData.getLow() - (barHeight * stopLossPercent);
        double sellEntry = barData.getLow() - (barHeight * trigPercent);
        double sellStopLoss = barData.getHigh() + (barHeight * stopLossPercent);

        String magicNumber = robot.getMagicNumberForSequence(nextSequence);

        double[] tpPercentages = {
            robot.getTp1Percent(), robot.getTp2Percent(), robot.getTp3Percent(),
            robot.getTp4Percent(), robot.getTp5Percent(), robot.getTp6Percent(),
            robot.getTp7Percent()
        };

        double[] tpVolumes = {
            robot.getTp1Volume(), robot.getTp2Volume(), robot.getTp3Volume(),
            robot.getTp4Volume(), robot.getTp5Volume(), robot.getTp6Volume(),
            robot.getTp7Volume()
        };

        double[] lotSizes = calculateLotSizes(robot, accountEquity, tpVolumes);

        commands.addAll(generateOrdersForSide(robot, "BUY", buyEntry, buyStopLoss, barHeight, tpPercentages, lotSizes, magicNumber));
        commands.addAll(generateOrdersForSide(robot, "SELL", sellEntry, sellStopLoss, barHeight, tpPercentages, lotSizes, magicNumber));

        ceOcoManager.registerOcoGroup(magicNumber, robot.getRobotName(), nextSequence);

        return commands;
    }

    private List<TradeCommand> generateOrdersForSide(
            CERobotConfig robot,
            String side,
            double entryPrice,
            double stopLoss,
            double barHeight,
            double[] tpPercentages,
            double[] lotSizes,
            String magicNumber) {

        List<TradeCommand> orders = new ArrayList<>();

        for (int i = 0; i < 7; i++) {
            if (tpPercentages[i] > 0 && lotSizes[i] > 0) {
                double tpDistance = barHeight * (tpPercentages[i] / 100.0);
                double takeProfit = side.equals("BUY") ? entryPrice + tpDistance : entryPrice - tpDistance;

                String comment = String.format("TP%d_%.0f%%", i + 1, tpPercentages[i]);

                Map<String, Object> params = new HashMap<>();
                params.put("symbol", robot.getSymbol());
                params.put("order_type", side + "_STOP");
                params.put("price", entryPrice);
                params.put("stop_loss", stopLoss);
                params.put("take_profit", takeProfit);
                params.put("volume", lotSizes[i]);
                params.put("comment", comment);

                TradeCommand cmd = new TradeCommand(null, magicNumber, "PLACE_ORDER", params);
                orders.add(cmd);
            }
        }

        return orders;
    }

    private double[] calculateLotSizes(CERobotConfig robot, double accountEquity, double[] tpVolumes) {
        double[] lotSizes = new double[7];
        double totalVolume = 0;
        for (double vol : tpVolumes) {
            totalVolume += vol;
        }

        if (totalVolume == 0 || accountEquity <= 0) {
            return lotSizes;
        }

        // RPT Fixed Amount overrides RPT Percent when > 0
        double rptFixed = robot.getRptFixedAmount() != null ? robot.getRptFixedAmount() : 0.0;
        double rptPercent = robot.getRptPercent() != null ? robot.getRptPercent() : 0.0;
        double riskAmount = (rptFixed > 0) ? rptFixed : accountEquity * (rptPercent / 100.0);

        if (riskAmount <= 0) {
            return lotSizes;
        }

        // Each TP gets a proportion of the total risk based on its volume
        for (int i = 0; i < 7; i++) {
            if (tpVolumes[i] > 0) {
                double proportion = tpVolumes[i] / totalVolume;
                double riskForThisOrder = riskAmount * proportion;

                // Simplified lot calculation: risk / 1000 (this should be replaced with proper calculation)
                // TODO: Implement BTTF method from EA: risk / (sl_distance * contract_size * conversion_rate)
                double minLot = 0.01;
                double calculatedLot = Math.max(minLot, riskForThisOrder / 1000.0);
                lotSizes[i] = Math.min(calculatedLot, 100.0);
            }
        }

        return lotSizes;
    }

    private double convertX1Height(double value, String type, String symbol) {
        if ("PIPS".equalsIgnoreCase(type)) {
            return value * getPointSize(symbol) * 10;
        } else if ("CENTS".equalsIgnoreCase(type)) {
            return value / 100.0;
        }
        return value;
    }

    private double getPointSize(String symbol) {
        if (symbol.contains("JPY")) return 0.001;
        return 0.00001;
    }

    public boolean isValidSignalCandle(MarketBarData barData, CERobotConfig robot) {
        double barHeight = barData.getHigh() - barData.getLow();
        double minHeight = convertX1Height(robot.getMinX1Height(), robot.getX1Type(), robot.getSymbol());
        return barHeight >= minHeight;
    }

    public TradeCommand generateCETradeCommand(CERobotConfig robot, MarketBarData barData, double accountEquity) {
        if (!robot.isFullyEnabled()) {
            return null;
        }

        int nextSequence = ceOcoManager.getNextSequenceForRobot(robot.getRobotName());

        if (nextSequence >= robot.getCeMaxSequence()) {
            return null;
        }

        double barHeight = barData.getHigh() - barData.getLow();
        double minHeight = convertX1Height(robot.getMinX1Height(), robot.getX1Type(), robot.getSymbol());

        if (barHeight < minHeight) {
            return null;
        }

        double trigPercent = robot.getTrigPercent() / 100.0;
        double stopLossPercent = robot.getStopLossPercent() / 100.0;

        double buyEntry = barData.getHigh() + (barHeight * trigPercent);
        double buyStopLoss = barData.getLow() - (barHeight * stopLossPercent);

        String magicNumber = robot.getMagicNumberForSequence(nextSequence);

        // RPT Fixed Amount overrides RPT Percent when > 0
        double rptFixed = robot.getRptFixedAmount() != null ? robot.getRptFixedAmount() : 0.0;
        double rptPercent = robot.getRptPercent() != null ? robot.getRptPercent() : 0.0;
        double riskAmount = (rptFixed > 0) ? rptFixed : accountEquity * (rptPercent / 100.0);

        double minLot = 0.01;
        double calculatedLot = Math.max(minLot, riskAmount / 1000.0);
        double lots = Math.min(calculatedLot, 100.0);

        double tp1Distance = barHeight * (robot.getTp1Percent() / 100.0);
        double takeProfit = buyEntry + tp1Distance;

        Map<String, Object> params = new HashMap<>();
        params.put("symbol", robot.getSymbol());
        params.put("order_type", "BUY_STOP");
        params.put("price", buyEntry);
        params.put("stop_loss", buyStopLoss);
        params.put("take_profit", takeProfit);
        params.put("volume", lots);
        params.put("comment", "CE_Seq" + nextSequence);

        ceOcoManager.registerOcoGroup(magicNumber, robot.getRobotName(), nextSequence);

        return new TradeCommand(null, magicNumber, "PLACE_ORDER", params);
    }
}
