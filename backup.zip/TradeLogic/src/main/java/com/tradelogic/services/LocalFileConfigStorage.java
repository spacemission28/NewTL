package com.tradelogic.services;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonSerializer;
import com.google.gson.TypeAdapter;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import com.tradelogic.Logger;
import com.tradelogic.models.CERobotConfig;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class LocalFileConfigStorage {
    private final String configFilePath;
    private final String defaultsFilePath;
    private final Gson gson;

    public LocalFileConfigStorage(String dataDirectory) {
        File dir = new File(dataDirectory);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        this.configFilePath = dataDirectory + File.separator + "ce_robot_configs.json";
        this.defaultsFilePath = dataDirectory + File.separator + "ce_defaults.json";

        this.gson = new GsonBuilder()
                .setPrettyPrinting()
                .registerTypeAdapter(Instant.class, new TypeAdapter<Instant>() {
                    @Override
                    public void write(JsonWriter out, Instant value) throws IOException {
                        if (value == null) {
                            out.nullValue();
                        } else {
                            out.value(value.toString());
                        }
                    }

                    @Override
                    public Instant read(JsonReader in) throws IOException {
                        String value = in.nextString();
                        return value == null || value.isEmpty() ? null : Instant.parse(value);
                    }
                })
                .create();

        Logger.info("Local file config storage initialized: " + dataDirectory);
    }

    public List<CERobotConfig> loadCERobotConfigs() {
        File file = new File(configFilePath);
        if (!file.exists()) {
            Logger.info("No robot configs file found, starting fresh");
            return new ArrayList<>();
        }

        try (FileReader reader = new FileReader(file)) {
            Type listType = new TypeToken<ArrayList<CERobotConfig>>(){}.getType();
            List<CERobotConfig> configs = gson.fromJson(reader, listType);
            Logger.info("Loaded " + (configs != null ? configs.size() : 0) + " robot configs from file");
            return configs != null ? configs : new ArrayList<>();
        } catch (Exception e) {
            Logger.error("Failed to load robot configs from file: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public void saveCERobotConfig(CERobotConfig config) {
        List<CERobotConfig> configs = loadCERobotConfigs();

        boolean found = false;
        for (int i = 0; i < configs.size(); i++) {
            if (configs.get(i).getCeMagicBase() == config.getCeMagicBase()) {
                configs.set(i, config);
                found = true;
                break;
            }
        }

        if (!found) {
            configs.add(config);
        }

        saveAllConfigs(configs);
    }

    public void deleteCERobotConfig(int ceMagicBase) {
        List<CERobotConfig> configs = loadCERobotConfigs();
        configs.removeIf(c -> c.getCeMagicBase() == ceMagicBase);
        saveAllConfigs(configs);
    }

    private void saveAllConfigs(List<CERobotConfig> configs) {
        try (FileWriter writer = new FileWriter(configFilePath)) {
            gson.toJson(configs, writer);
            Logger.info("Saved " + configs.size() + " robot configs to file");
        } catch (IOException e) {
            Logger.error("Failed to save robot configs to file: " + e.getMessage());
        }
    }

    public CERobotConfig loadCEDefaultValues() {
        File file = new File(defaultsFilePath);
        if (!file.exists()) {
            Logger.info("No defaults file found, returning null");
            return null;
        }

        try (FileReader reader = new FileReader(file)) {
            CERobotConfig defaults = gson.fromJson(reader, CERobotConfig.class);
            Logger.info("Loaded CE default values from file");
            return defaults;
        } catch (Exception e) {
            Logger.error("Failed to load CE defaults from file: " + e.getMessage());
            return null;
        }
    }

    public void saveCEDefaultValues(CERobotConfig defaults) {
        try (FileWriter writer = new FileWriter(defaultsFilePath)) {
            gson.toJson(defaults, writer);
            Logger.info("Saved CE default values to file");
        } catch (IOException e) {
            Logger.error("Failed to save CE defaults to file: " + e.getMessage());
        }
    }
}
