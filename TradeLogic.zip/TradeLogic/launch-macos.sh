#!/bin/bash
# TradeLogic TickRecorder Launcher for macOS/Linux
# Version 2.1.0

echo "Starting TradeLogic TickRecorder..."
echo ""

# Check if Java is installed
if ! command -v java &> /dev/null; then
    echo "ERROR: Java is not installed or not in PATH"
    echo "Please install Java 11 or higher:"
    echo "  macOS: brew install openjdk@11"
    echo "  Linux: sudo apt install openjdk-11-jdk"
    exit 1
fi

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

# Launch the application
java -jar "$SCRIPT_DIR/TickRecorder-2.1.0.jar"

# Check exit code
if [ $? -ne 0 ]; then
    echo ""
    echo "Application exited with errors"
    read -p "Press Enter to continue..."
fi
