//+------------------------------------------------------------------+
//|                  TickRecorderApplication.java                    |
//|                          Copyright 2025, Trade Logic             |
//|                                                                  |
//| Enhanced: Handles both OHLC (11 timeframes) AND Tick data       |
//| for all monitored symbols with separate tabs and storage        |
//| ADDED: Advanced logging system with EET timezone & weekly rotation |
//+------------------------------------------------------------------+
package com.tradelogic;

import com.google.gson.Gson;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import com.tradelogic.io.AsyncFileWriter;
import com.tradelogic.models.BBData;
import com.tradelogic.models.MarketBarData;
import com.tradelogic.models.TickData;
import com.tradelogic.models.TradeCommand;
import com.tradelogic.models.ExecutionFeedback;
import com.tradelogic.models.TradeHistoryEntry;
import com.tradelogic.models.TradeStatistics;
import com.tradelogic.services.*;
import com.tradelogic.services.TradeHistoryPersistenceService;
import com.tradelogic.ui.UIDataManager;
import com.tradelogic.ui.RobotMatrixTable;
import com.tradelogic.ui.DatabaseConfigDialog;
import com.tradelogic.ui.MagicNumberFilterDialog;
import com.tradelogic.ui.DateRangeDialog;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.URL;
import java.text.DecimalFormat;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

public class TickRecorderApplication extends Application {

    private HttpServer server;
    private final ConcurrentHashMap<String, MarketBarData> ohlcData = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, TickData> tickData = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, BBData> bbData = new ConcurrentHashMap<>();
    private final TradeCommandQueue commandQueue = new TradeCommandQueue();
    private final PendingCommandsManager pendingCommandsManager = new PendingCommandsManager();
    private final ConcurrentHashMap<String, Long> processedCandles = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, OrthodoxCCBreachState> orthodoxCCBreachStates = new ConcurrentHashMap<>();

    private TextArea logArea;
    private CircularLogBuffer circularLogBuffer;
    private Button startServerButton;
    private Button downloadLogButton;
    private final Gson gson = new Gson();
    private final DateTimeFormatter logTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

    private String dataFolder = "market_data";  // Default, will be overridden from preferences
    private static final String CANDLES_SUFFIX = "_candles.txt";
    private static final ZoneId EET_ZONE = ZoneId.of("Europe/Athens");
    private static final DecimalFormat PRICE_FORMAT = new DecimalFormat("#,##0.00");

    private ConnectionMonitor connectionMonitor;
    private AsyncFileWriter fileWriter;
    private UIDataManager uiDataManager;
    private RobotMatrixTable robotMatrixTable;
    private com.tradelogic.ui.ConnectionIndicator connectionIndicator;
    private long lastDataReceivedTime = System.currentTimeMillis();
    private ScheduledExecutorService timeoutMonitor;

    private TradingStrategyService tradingStrategy;
    private OcoManager ocoManager;
    private OcoImbalanceDetector ocoImbalanceDetector;
    private BackupOcoMonitor backupOcoMonitor;
    private SimpleOcoPoller simpleOcoPoller;
    private SmartTrailingStopMonitor smartTSMonitor;
    private TradeHistoryCache tradeHistoryCache;
    private com.tradelogic.services.FileDataReader dataReader;
    private double accountBalance = 0.0;
    private String accountCurrency = "USD";
    private long lastAccountBalanceUpdate = 0;
    private Map<String, Double> conversionRates = new ConcurrentHashMap<>();
    private String lastTradingDay = "";
    private ScheduledExecutorService eodCleanupMonitor;
    private final Set<String> eodProcessedMagicNumbers = ConcurrentHashMap.newKeySet();
    private ScheduledExecutorService uiUpdateScheduler;
    private final Map<String, Long> logThrottleMap = new ConcurrentHashMap<>();
    private static final long LOG_THROTTLE_MS = 60000;
    private String dataSourceMode = "supabase";
    private TradeHistoryFileWriter tradeHistoryFileWriter;
    private TradeHistoryPersistenceService tradeHistoryPersistence;

    private ExecutorService robotProcessingPool;
    private final int ROBOT_THREAD_POOL_SIZE = Runtime.getRuntime().availableProcessors() * 2;
    private final Map<String, List<RobotMatrixTable.RobotRow>> robotsBySymbol = new ConcurrentHashMap<>();
    private DataPurgeManager dataPurgeManager;
    private volatile boolean tickDisplayEnabled = true;
    private volatile boolean ohlcDisplayEnabled = true;

    private void updateRobotPartitions() {
        if (robotMatrixTable == null) return;

        robotsBySymbol.clear();
        for (RobotMatrixTable.RobotRow robot : robotMatrixTable.getRobotRows()) {
            if (robot.isPlaceholder()) continue;

            String symbol = robot.symbolProperty().get();
            if (symbol == null || symbol.isEmpty()) continue;

            robotsBySymbol
                .computeIfAbsent(symbol, k -> new CopyOnWriteArrayList<>())
                .add(robot);
        }
    }

    private class ConnectionMonitor {
        private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        private boolean isConnected = true;
        private static final long TIMEOUT_MS = 3000;
        private static final long BLUE_LIGHT_THRESHOLD_MS = 10000;
        private long lastDisconnectTime = 0;
        private long lastReconnectTime = 0;
        private int disconnectionCount = 0;
        private boolean showingBlueLight = false;

        public void start() {
            scheduler.scheduleAtFixedRate(() -> {
                try {
                    checkConnection();
                } catch (Throwable t) {
                    System.err.println("CRITICAL ERROR in ConnectionMonitor: " + t.getClass().getName() + " - " + t.getMessage());
                    t.printStackTrace(System.err);
                }
            }, 1, 1, TimeUnit.SECONDS);
            Logger.connection("Connection monitor started (3s timeout, 10s blue light delay, 1s check interval)");

            // Start UI update scheduler to batch all UI updates every 2000ms
            uiUpdateScheduler = Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "UI-Update-Scheduler");
                t.setDaemon(true);
                return t;
            });

            uiUpdateScheduler.scheduleAtFixedRate(() -> {
                try {
                    if (uiDataManager != null) {
                        uiDataManager.processPendingUpdates();
                    }
                } catch (Throwable t) {
                    System.err.println("CRITICAL ERROR in UI Update Scheduler: " + t.getClass().getName() + " - " + t.getMessage());
                    t.printStackTrace(System.err);
                }
            }, 0, 2000, TimeUnit.MILLISECONDS);

            log("UI update scheduler started (2000ms interval - performance optimized)");
        }

        private void checkConnection() {
            long timeSinceLastData = System.currentTimeMillis() - lastDataReceivedTime;
            long now = System.currentTimeMillis();

            if (timeSinceLastData > TIMEOUT_MS && isConnected) {
                isConnected = false;
                lastDisconnectTime = now;
                disconnectionCount++;

                String msg = String.format("BROKER DISCONNECTED #%d - No data for %.1fs",
                    disconnectionCount, timeSinceLastData/1000.0);
                Logger.connection(msg);
                updateLogArea("[CONNECTION] " + msg);

            } else if (timeSinceLastData <= TIMEOUT_MS && !isConnected) {
                isConnected = true;
                lastReconnectTime = now;
                long disconnectDuration = now - lastDisconnectTime;
                showingBlueLight = false;

                String msg = String.format("BROKER RECONNECTED - Downtime: %.1fs",
                    disconnectDuration/1000.0);
                Logger.connection(msg);
                updateLogArea("[CONNECTION] " + msg);

                if (connectionIndicator != null) {
                    connectionIndicator.updateStatus(
                        com.tradelogic.ui.ConnectionIndicator.Status.GREEN,
                        "Reconnected after " + String.format("%.1fs", disconnectDuration/1000.0)
                    );
                }
            }

            if (!isConnected && !showingBlueLight) {
                long disconnectDuration = now - lastDisconnectTime;
                if (disconnectDuration >= BLUE_LIGHT_THRESHOLD_MS) {
                    showingBlueLight = true;
                    if (connectionIndicator != null) {
                        connectionIndicator.updateStatus(
                            com.tradelogic.ui.ConnectionIndicator.Status.BLUE,
                            String.format("Connection lost for %.1fs", disconnectDuration/1000.0)
                        );
                    }
                    Logger.connection("Connection lost for more than 10 seconds - showing blue indicator");
                }
            } else if (!isConnected && showingBlueLight && connectionIndicator != null) {
                long disconnectDuration = now - lastDisconnectTime;
                connectionIndicator.updateStatus(
                    com.tradelogic.ui.ConnectionIndicator.Status.BLUE,
                    String.format("Connection lost for %.1fs", disconnectDuration/1000.0)
                );
            }
        }

        public void shutdown() {
            scheduler.shutdown();
            Logger.info("Connection monitor stats: " + disconnectionCount + " disconnections detected");
        }

        public boolean isCurrentlyConnected() {
            return isConnected;
        }

        public int getDisconnectionCount() {
            return disconnectionCount;
        }
    }

    private void log(String message) {
        log(message, false);
    }

    private void log(String message, boolean forceLog) {
        if (!forceLog && message.contains("Command queue status")) {
            String throttleKey = "queue_status";
            Long lastLog = logThrottleMap.get(throttleKey);
            long now = System.currentTimeMillis();
            if (lastLog != null && (now - lastLog) < LOG_THROTTLE_MS) {
                return;
            }
            logThrottleMap.put(throttleKey, now);
        }

        String fullMessage = String.format("[%s] [INFO] %s", LocalDateTime.now().format(logTimeFormatter), message);
        updateLogArea(fullMessage);
        Logger.info(message);
    }

    private void updateLogArea(String message) {
        if (circularLogBuffer != null) {
            circularLogBuffer.log(message);
        }
    }

    @Override
    public void start(Stage stage) {
        // Load data folder path from preferences
        java.util.prefs.Preferences prefs = java.util.prefs.Preferences.userNodeForPackage(com.tradelogic.ui.DatabaseConfigDialog.class);
        dataFolder = prefs.get("market_data_path", "./market_data");

        // Initialize singleton Logger with custom path FIRST
        Logger.initialize(dataFolder);

        connectionMonitor = new ConnectionMonitor();
        fileWriter = new AsyncFileWriter(dataFolder, CANDLES_SUFFIX, this::log);
        dataReader = new com.tradelogic.services.FileDataReader(dataFolder);
        uiDataManager = new UIDataManager();
        ocoManager = new OcoManager();
        tradeHistoryCache = TradeHistoryCache.getInstance();
        simpleOcoPoller = SimpleOcoPoller.getInstance();
        simpleOcoPoller.initialize(tradeHistoryCache, commandQueue, pendingCommandsManager);
        simpleOcoPoller.start();
        log("★★★ SimpleOcoPoller initialized and started - polling every 100ms");
        smartTSMonitor = SmartTrailingStopMonitor.getInstance();
        log("★★★ SmartTrailingStopMonitor initialized - tracks TP1 hits and moves SL to breakeven");
        tradingStrategy = new TradingStrategyService(ocoManager, tradeHistoryCache);
        ocoImbalanceDetector = OcoImbalanceDetector.getInstance();

        robotProcessingPool = Executors.newFixedThreadPool(
            ROBOT_THREAD_POOL_SIZE,
            new ThreadFactory() {
                private final AtomicInteger counter = new AtomicInteger(0);
                public Thread newThread(Runnable r) {
                    Thread t = new Thread(r, "robot-processor-" + counter.incrementAndGet());
                    t.setDaemon(true);
                    t.setPriority(Thread.NORM_PRIORITY);
                    return t;
                }
            }
        );
        log("★★★ Robot Processing Pool initialized with " + ROBOT_THREAD_POOL_SIZE + " threads (" + Runtime.getRuntime().availableProcessors() + " cores)");

        dataPurgeManager = new DataPurgeManager(tickData, ohlcData);
        dataPurgeManager.start();
        log("★★★ Data Purge Manager started - auto-cleanup every 15 minutes");

        // Show database configuration dialog
        DatabaseConfigDialog configDialog = new DatabaseConfigDialog();
        var configResult = configDialog.showAndWait();

        if (configResult.isEmpty()) {
            log("Database configuration cancelled. Exiting...");
            Platform.exit();
            return;
        }

        DatabaseConfigDialog.DatabaseConfig dbConfig = configResult.get();
        dataSourceMode = dbConfig.type;

        // Only initialize database if not in file mode
        if (!"file".equals(dbConfig.type)) {
            try {
                switch (dbConfig.type) {
                    case "postgres" -> {
                        PostgresClient.initialize(dbConfig.postgresUrl, dbConfig.postgresUser, dbConfig.postgresPassword);
                        DatabaseFactory.initialize(PostgresClient.getInstance());
                        log("PostgreSQL database initialized successfully");
                    }
                    case "supabase" -> {
                        SupabaseClient.initialize(dbConfig.supabaseUrl, dbConfig.supabaseKey);
                        DatabaseFactory.initialize(new SupabaseDatabaseAdapter(SupabaseClient.getInstance()));
                        ocoImbalanceDetector.setSupabaseClient(SupabaseClient.getInstance());
                        log("Supabase database initialized successfully");
                    }
                    case "bolt" -> {
                        BoltDatabaseAdapter.initialize(dbConfig.boltUrl, "");
                        DatabaseFactory.initialize(BoltDatabaseAdapter.getInstance());
                        log("Bolt database initialized successfully");
                    }
                    default -> {
                        log("ERROR: Unknown database type: " + dbConfig.type);
                        Platform.exit();
                        return;
                    }
                }
            } catch (Exception e) {
                log("ERROR: Failed to initialize database: " + e.getMessage());
                e.printStackTrace();

                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Database Connection Error");
                alert.setHeaderText("Failed to connect to database");
                alert.setContentText(e.getMessage() + "\n\nPlease check your connection settings and try again.");
                alert.showAndWait();

                Platform.exit();
                return;
            }
        } else {
            log("File-based mode initialized - data will be stored locally in " + dataFolder);

            tradeHistoryFileWriter = TradeHistoryFileWriter.getInstance(dataFolder);
            tradeHistoryFileWriter.start();

            String localStoragePath = System.getProperty("user.home") + File.separator + "TradeLogic_TradeHistory";
            boolean useDatabase = false;
            boolean useLocalStorage = true;
            tradeHistoryPersistence = TradeHistoryPersistenceService.getInstance(
                null, localStoragePath, useDatabase, useLocalStorage);
            log("Trade History Persistence initialized - storage path: " + localStoragePath);

            ocoImbalanceDetector.setFileMode(tradeHistoryFileWriter.getTradeHistoryFilePath());
            log("OCO Imbalance Detector enabled in file mode");
            log("All trading features fully operational in file mode");
        }

        // Wire up OcoImbalanceDetector with dependencies
        ocoImbalanceDetector.setCommandQueue(commandQueue);

        initializeDataStorage();
        fileWriter.start();

        connectionIndicator = new com.tradelogic.ui.ConnectionIndicator();

        stage.setTitle("TradeLogic - Enhanced TickRecorder v2.1 (Optimized: Async I/O + Batched UI)");

        logArea = new TextArea();
        logArea.setEditable(false);
        logArea.setStyle("-fx-control-inner-background:#1e1e1e; -fx-text-fill: #cccccc;");

        // Initialize circular log buffer for high-performance logging
        // Logs will be saved to the Market Data Storage folder
        circularLogBuffer = new CircularLogBuffer(logArea, dataFolder);

        ContextMenu logContextMenu = new ContextMenu();
        logContextMenu.setStyle("-fx-background-color: white; -fx-text-fill: black;");

        MenuItem copyItem = new MenuItem("Copy");
        copyItem.setStyle("-fx-text-fill: black;");
        copyItem.setOnAction(e -> {
            String selected = logArea.getSelectedText();
            if (selected != null && !selected.isEmpty()) {
                ClipboardContent content = new ClipboardContent();
                content.putString(selected);
                Clipboard.getSystemClipboard().setContent(content);
            }
        });

        MenuItem selectAllItem = new MenuItem("Select All");
        selectAllItem.setStyle("-fx-text-fill: black;");
        selectAllItem.setOnAction(e -> logArea.selectAll());

        logContextMenu.getItems().addAll(copyItem, selectAllItem);
        logArea.setContextMenu(logContextMenu);

        BorderPane root = new BorderPane();
        root.setPadding(new Insets(10));
        root.setStyle("-fx-background-color: #2e2e2e;");

        Button statReportButton = new Button("Stat Report");
        statReportButton.setStyle(
            "-fx-background-color: #4a90e2; " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 12px; " +
            "-fx-font-weight: bold; " +
            "-fx-padding: 8 15; " +
            "-fx-background-radius: 5; " +
            "-fx-cursor: hand;"
        );
        statReportButton.setOnAction(e -> handleStatReport(stage));

        Button shutdownButton = new Button("Shut Down");
        shutdownButton.setStyle(
            "-fx-background-color: #ff6b6b; " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 12px; " +
            "-fx-font-weight: bold; " +
            "-fx-padding: 8 15; " +
            "-fx-background-radius: 5; " +
            "-fx-cursor: hand;"
        );
        shutdownButton.setOnAction(e -> handleShutdown(stage));

        javafx.scene.layout.Region spacer = new javafx.scene.layout.Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox topBar = new HBox(10);
        topBar.setAlignment(Pos.CENTER_LEFT);
        topBar.setPadding(new Insets(5));
        topBar.getChildren().addAll(spacer, statReportButton, shutdownButton, connectionIndicator);
        root.setTop(topBar);

        TabPane mainTabPane = new TabPane();

        // Set tab height to be compact
        mainTabPane.setStyle("-fx-tab-min-height: 30px; -fx-tab-max-height: 30px; -fx-font-size: 14px;");

        Tab loginTab = new Tab("Login");
        loginTab.setClosable(false);
        loginTab.setContent(buildLoginTabContent(stage, mainTabPane));

        Tab tickRecorderTab = new Tab("Tick Recorder");
        tickRecorderTab.setClosable(false);
        tickRecorderTab.setContent(buildTickRecorderTabContent(stage));

        // Apply darker green background and white text to tab
        Platform.runLater(() -> {
            tickRecorderTab.setStyle("-fx-background-color: #27AE60;");
            javafx.scene.Node tabLabel = tickRecorderTab.getGraphic();
            if (tabLabel == null) {
                Label label = new Label("Tick Recorder");
                label.setStyle("-fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 14px;");
                tickRecorderTab.setGraphic(label);
                tickRecorderTab.setText("");
            }
        });

        Tab robotMatrixTab = new Tab("Trade Logic");
        robotMatrixTab.setClosable(false);

        // Apply lighter orange background (#E67E22 instead of #D35400) and white text to tab
        Platform.runLater(() -> {
            robotMatrixTab.setStyle("-fx-background-color: #E67E22;");
            // Find and style the tab label
            javafx.scene.Node tabLabel = robotMatrixTab.getGraphic();
            if (tabLabel == null) {
                Label label = new Label("Trade Logic");
                label.setStyle("-fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 14px;");
                robotMatrixTab.setGraphic(label);
                robotMatrixTab.setText("");
            }
        });

        mainTabPane.getTabs().addAll(loginTab, tickRecorderTab, robotMatrixTab);

        // Load robot matrix content after UI is set up
        Platform.runLater(() -> {
            try {
                log("Loading Trade Logic tab content...");
                BorderPane content = buildRobotMatrixTabContent();
                robotMatrixTab.setContent(content);
                log("Trade Logic tab content loaded successfully");
            } catch (Exception ex) {
                log("ERROR: Failed to load Trade Logic tab: " + ex.getMessage());
                ex.printStackTrace();
                Label errorLabel = new Label("Failed to load: " + ex.getMessage());
                errorLabel.setStyle("-fx-text-fill: red; -fx-padding: 20px;");
                robotMatrixTab.setContent(errorLabel);
            }
        });
        root.setCenter(mainTabPane);

        Label logLabel = new Label("Application Log:");
        logLabel.setTextFill(Color.WHITE);
        logLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");

        Button copyLogButton = new Button("Copy All");
        copyLogButton.setOnAction(e -> {
            javafx.scene.input.Clipboard clipboard = javafx.scene.input.Clipboard.getSystemClipboard();
            javafx.scene.input.ClipboardContent content = new javafx.scene.input.ClipboardContent();
            content.putString(logArea.getText());
            clipboard.setContent(content);
            log("✓ Log copied to clipboard");
        });
        copyLogButton.getStyleClass().add("action-button");

        Button clearLogButton = new Button("Clear");
        clearLogButton.setOnAction(e -> {
            logArea.clear();
            log("Application log cleared");
        });
        clearLogButton.getStyleClass().add("action-button");

        HBox logControls = new HBox(10, logLabel, copyLogButton, clearLogButton);
        logControls.setAlignment(Pos.CENTER_LEFT);
        logControls.setPadding(new Insets(5, 0, 5, 0));

        VBox logBox = new VBox(5, logControls, logArea);
        VBox.setVgrow(logArea, Priority.ALWAYS);
        logBox.setStyle("-fx-border-color: #444; -fx-border-width: 1px; -fx-padding: 5px; -fx-background-color: #1e1e1e;");
        logBox.setMinHeight(160);
        logBox.setMaxHeight(160);
        root.setBottom(logBox);

        Scene scene = new Scene(root, 1200, 800);
        URL cssResource = getClass().getResource("/css/style.css");
        if (cssResource != null) {
            scene.getStylesheets().add(cssResource.toExternalForm());
        } else {
            log("WARNING: CSS file not found at /css/style.css");
        }

        stage.setScene(scene);
        stage.show();

        // Show configured storage path
        try {
            Path absolutePath = Paths.get(dataFolder).toAbsolutePath();
            log("✓ Data Storage: " + absolutePath);
        } catch (Exception ex) {
            log("✓ Data Storage: " + dataFolder);
        }

        log("Enhanced TickRecorder initialized. Expecting OHLC (55 rows) + Tick data (5 rows).");
    }

    private void downloadCurrentLog(Stage stage) {
        if (circularLogBuffer == null || circularLogBuffer.getCurrentLogFile() == null) {
            log("ERROR: No log file available for download");
            return;
        }

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Current Log File");
        String currentLogPath = circularLogBuffer.getCurrentLogFile();
        File currentLog = new File(currentLogPath);
        fileChooser.setInitialFileName(currentLog.getName());
        fileChooser.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("Log Files", "*.log", "*.txt")
        );

        File saveFile = fileChooser.showSaveDialog(stage);
        if (saveFile != null) {
            try {
                Files.copy(currentLog.toPath(), saveFile.toPath(),
                          java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                log("Log file downloaded successfully: " + saveFile.getName());
                Logger.info("Log file downloaded to: " + saveFile.getAbsolutePath());
            } catch (IOException e) {
                log("ERROR: Failed to download log file: " + e.getMessage());
                Logger.error("Failed to download log file: " + e.getMessage());
            }
        }
    }

    private void initializeDataStorage() {
        try {
            Path dataPath = Paths.get(dataFolder);
            if (!Files.exists(dataPath)) {
                Files.createDirectories(dataPath);
                log("Created data storage folder: " + dataFolder);
            }
        } catch (IOException e) {
            log("ERROR: Failed to create data storage folder: " + e.getMessage());
        }
    }

    private BorderPane buildLoginTabContent(Stage stage, TabPane mainTabPane) {
        BorderPane loginPane = new BorderPane();
        loginPane.setPadding(new Insets(40));
        loginPane.setStyle("-fx-background-color: #2e2e2e;");

        com.tradelogic.ui.LoginDialog loginContent = new com.tradelogic.ui.LoginDialog(stage);
        VBox loginBox = loginContent.getLoginContent(connectionIndicator, (login, password, server) -> {
            Logger.info("=== TRP (Trade Research Platform) Application Started ===");
            Logger.info("Version: 3.0 - TickRecorder with Login");
            Logger.info("User: " + login + " | Server: " + server);
            Logger.info("Log rotation: Weekly on Sunday 22:00 EET");
            Logger.info("Optimizations: 3s disconnect timeout, 5s file flush, batched UI updates, 10s blue light delay");

            stage.setTitle("TradeLogic - TRP v3.0 - " + login + "@" + server);
            log("Logged in as: " + login + " | Server: " + server);

            mainTabPane.getSelectionModel().select(1);
        });

        loginPane.setCenter(loginBox);
        return loginPane;
    }

    private BorderPane buildRobotMatrixTabContent() {
        BorderPane matrixPane = new BorderPane();
        matrixPane.setPadding(new Insets(10));
        matrixPane.setStyle("-fx-text-fill: white;");

        java.util.UUID userId = java.util.UUID.randomUUID();
        robotMatrixTable = new RobotMatrixTable(userId);
        robotMatrixTable.setDataReader(dataReader);
        robotMatrixTable.setAccountBalance(accountBalance);

        // Wire up tick display toggle callback
        robotMatrixTable.getControlPanel().setOnTickDisplayToggleCallback(() -> {
            tickDisplayEnabled = robotMatrixTable.getControlPanel().isTickDisplayEnabled();
            ohlcDisplayEnabled = robotMatrixTable.getControlPanel().isOhlcDisplayEnabled();
            log("Tick display " + (tickDisplayEnabled ? "ENABLED" : "DISABLED"));
            log("OHLC display " + (ohlcDisplayEnabled ? "ENABLED" : "DISABLED (performance boost)"));
        });

        // Wire up configuration changed callback
        robotMatrixTable.setOnConfigurationChangedCallback(() -> {
            updateRobotPartitions();
            log("⚠ Robot configuration changed - refreshed robot partitions");
        });

        updateRobotPartitions();
        log("Robot partitions initialized for parallel processing");

        matrixPane.setCenter(robotMatrixTable);
        return matrixPane;
    }

    private BorderPane buildTickRecorderTabContent(Stage stage) {
        BorderPane tickRecorderPane = new BorderPane();
        tickRecorderPane.setPadding(new Insets(10));

        startServerButton = new Button("Start HTTP Server");
        startServerButton.setOnAction(e -> toggleServer());
        startServerButton.getStyleClass().add("start-button");

        downloadLogButton = new Button("Download Current Log");
        downloadLogButton.setOnAction(e -> downloadCurrentLog(stage));
        downloadLogButton.getStyleClass().add("action-button");

        Label statusLabel = new Label("Server Status: STOPPED");
        statusLabel.setTextFill(Color.web("#ff6b6b"));

        HBox controls = new HBox(10, startServerButton, downloadLogButton, statusLabel);
        controls.setAlignment(Pos.CENTER_LEFT);
        controls.setPadding(new Insets(0, 0, 10, 0));
        tickRecorderPane.setTop(controls);

        TabPane dataTabPane = new TabPane();

        Tab ohlcTab = new Tab("OHLC Data (11 Timeframes)");
        ohlcTab.setClosable(false);
        TableView<UIDataManager.MarketBarUI> ohlcTable = buildOHLCTableView();
        ohlcTable.setItems(uiDataManager.getOhlcObservableList());
        ohlcTab.setContent(ohlcTable);

        Tab tickTab = new Tab("Tick Data (Real-time)");
        tickTab.setClosable(false);
        TableView<UIDataManager.TickUI> tickTable = buildTickTableView();
        tickTable.setItems(uiDataManager.getTickObservableList());
        tickTab.setContent(tickTable);

        dataTabPane.getTabs().addAll(ohlcTab, tickTab);
        tickRecorderPane.setCenter(dataTabPane);

        startServerButton.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal.equals("Stop HTTP Server")) {
                statusLabel.setText("Server Status: RUNNING (Port 8080)");
                statusLabel.setTextFill(Color.web("#4cff4c"));
                startServerButton.getStyleClass().removeAll("start-button", "stop-button");
                startServerButton.getStyleClass().add("stop-button");
            } else {
                statusLabel.setText("Server Status: STOPPED");
                statusLabel.setTextFill(Color.web("#ff6b6b"));
                startServerButton.getStyleClass().removeAll("start-button", "stop-button");
                startServerButton.getStyleClass().add("start-button");
            }
        });

        return tickRecorderPane;
    }


    private String detectJavaFXPath() {
        try {
            String[] requiredModules = {
                "javafx-controls",
                "javafx-graphics",
                "javafx-base",
                "javafx-fxml"
            };

            String mavenRepo = System.getProperty("user.home") + "/.m2/repository/org/openjfx";
            String[] versions = {"21.0.2", "21.0.1", "21.0.0"};

            for (String version : versions) {
                boolean allFound = true;
                StringBuilder modulePath = new StringBuilder();

                for (String module : requiredModules) {
                    String jarPath = mavenRepo + "/" + module + "/" + version + "/" +
                                   module + "-" + version + ".jar";
                    File jarFile = new File(jarPath);

                    if (jarFile.exists()) {
                        if (modulePath.length() > 0) {
                            modulePath.append(File.pathSeparator);
                        }
                        modulePath.append(jarPath);
                    } else {
                        allFound = false;
                        break;
                    }
                }

                if (allFound) {
                    return modulePath.toString();
                }
            }

            String[] possibleSdkPaths = {
                "/usr/local/lib/javafx-sdk-21/lib",
                "/opt/javafx-sdk-21/lib"
            };

            for (String sdkPath : possibleSdkPaths) {
                File dir = new File(sdkPath);
                if (dir.exists() && dir.isDirectory()) {
                    File[] jars = dir.listFiles((d, name) ->
                        name.startsWith("javafx-") && name.endsWith(".jar"));
                    if (jars != null && jars.length >= 4) {
                        return sdkPath;
                    }
                }
            }

        } catch (Exception e) {
            log("⚠ Error detecting JavaFX path: " + e.getMessage());
        }
        return null;
    }

    private void handleStatReport(Stage stage) {
        new Thread(() -> {
            try {
                AtomicReference<DateRangeDialog.DateRange> dateRange = new AtomicReference<>();
                CountDownLatch dateRangeLatch = new CountDownLatch(1);

                Platform.runLater(() -> {
                    DateRangeDialog dialog = new DateRangeDialog(stage);
                    Optional<DateRangeDialog.DateRange> result = dialog.showAndWait();
                    result.ifPresent(dateRange::set);
                    dateRangeLatch.countDown();
                });

                dateRangeLatch.await();

                if (dateRange.get() == null) {
                    return;
                }

                List<TradeHistoryEntry> allTrades = new ArrayList<>();

                if (tradeHistoryPersistence != null) {
                    allTrades = tradeHistoryPersistence.loadTradesFromPeriod(
                        "local_user", dateRange.get().fromTimestamp, dateRange.get().toTimestamp);
                }

                allTrades.addAll(tradeHistoryCache.getAllTrades());

                List<TradeHistoryEntry> uniqueTrades = allTrades.stream()
                    .collect(Collectors.toMap(
                        trade -> trade.getTicket() + "_" + trade.getTimestamp(),
                        trade -> trade,
                        (existing, replacement) -> existing
                    ))
                    .values()
                    .stream()
                    .sorted((t1, t2) -> Long.compare(t2.getOpenTime(), t1.getOpenTime()))
                    .collect(Collectors.toList());

                if (uniqueTrades.isEmpty()) {
                    Platform.runLater(() -> {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("No Trade History");
                        alert.setHeaderText(null);
                        alert.setContentText("No trade history available for the selected date range.");
                        alert.showAndWait();
                    });
                    return;
                }

                Set<Long> magicNumbers = uniqueTrades.stream()
                    .map(TradeHistoryEntry::getMagic)
                    .collect(Collectors.toSet());

                List<Long> selectedMagicNumbers = new ArrayList<>();

                CountDownLatch latch = new CountDownLatch(1);

                Platform.runLater(() -> {
                    MagicNumberFilterDialog dialog = new MagicNumberFilterDialog(magicNumbers);
                    Optional<List<Long>> result = dialog.showAndWait();

                    if (result.isPresent() && !result.get().isEmpty()) {
                        selectedMagicNumbers.addAll(result.get());
                    }

                    latch.countDown();
                });

                latch.await();

                if (selectedMagicNumbers.isEmpty()) {
                    return;
                }

                List<TradeHistoryEntry> filteredTrades = uniqueTrades.stream()
                    .filter(trade -> selectedMagicNumbers.contains(trade.getMagic()))
                    .collect(Collectors.toList());

                String accountName = System.getProperty("user.name", "User");
                String accountNumber = "TradeLogic";
                String company = "Trade Logic";

                TradeStatistics statistics = TradeStatisticsCalculator.calculate(
                    filteredTrades, accountName, accountNumber, company, accountBalance);

                String timestamp = Instant.now().atZone(EET_ZONE)
                    .format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
                String fileName = "TradeReport_" + timestamp + ".xlsx";

                AtomicReference<File> selectedFile = new AtomicReference<>();
                CountDownLatch fileChooserLatch = new CountDownLatch(1);

                Platform.runLater(() -> {
                    FileChooser fileChooser = new FileChooser();
                    fileChooser.setTitle("Save Trade Report");
                    fileChooser.setInitialFileName(fileName);
                    fileChooser.getExtensionFilters().add(
                        new FileChooser.ExtensionFilter("Excel Files (*.xlsx)", "*.xlsx")
                    );
                    fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));

                    File file = fileChooser.showSaveDialog(stage);
                    if (file != null) {
                        selectedFile.set(file);
                    }
                    fileChooserLatch.countDown();
                });

                fileChooserLatch.await();

                if (selectedFile.get() == null) {
                    return;
                }

                String filePath = selectedFile.get().getAbsolutePath();
                if (!filePath.toLowerCase().endsWith(".xlsx")) {
                    filePath += ".xlsx";
                }

                File reportFile = ExcelReportGenerator.generateReport(filteredTrades, statistics, filePath);

                Platform.runLater(() -> {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Report Generated");
                    alert.setHeaderText("Trade statistics report generated successfully!");
                    alert.setContentText("Report saved to:\n" + reportFile.getAbsolutePath() +
                        "\n\nTotal Trades: " + statistics.getTotalTrades() +
                        "\nNet Profit: " + PRICE_FORMAT.format(statistics.getTotalNetProfit()));
                    alert.showAndWait();

                    log("Trade statistics report generated: " + reportFile.getAbsolutePath());
                });

            } catch (Exception e) {
                Logger.error("Failed to generate trade statistics report: " + e.getMessage());
                e.printStackTrace();
                Platform.runLater(() -> {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Failed to generate report");
                    alert.setContentText("Error: " + e.getMessage());
                    alert.showAndWait();
                });
            }
        }, "StatReport-Thread").start();
    }

    private void handleShutdown(Stage stage) {
        Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmAlert.setTitle("Shut Down");
        confirmAlert.setHeaderText("Are you sure you want to shut down?");
        confirmAlert.setContentText("This will stop the server and close the application.");

        Optional<ButtonType> result = confirmAlert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            log("Shutdown initiated by user");
            Logger.info("Application shutdown initiated by user");
            stage.close();
            Platform.exit();
        }
    }

    @Override
    public void stop() {
        try {
            log("Application shutdown initiated...");

            if (server != null) {
                server.stop(0);
                log("Server stopped.");
            }
            if (timeoutMonitor != null && !timeoutMonitor.isShutdown()) {
                timeoutMonitor.shutdown();
                try {
                    if (!timeoutMonitor.awaitTermination(2, TimeUnit.SECONDS)) {
                        timeoutMonitor.shutdownNow();
                    }
                } catch (InterruptedException e) {
                    timeoutMonitor.shutdownNow();
                    Thread.currentThread().interrupt();
                }
                log("Timeout monitor stopped.");
            }
            if (eodCleanupMonitor != null && !eodCleanupMonitor.isShutdown()) {
                eodCleanupMonitor.shutdown();
                try {
                    if (!eodCleanupMonitor.awaitTermination(2, TimeUnit.SECONDS)) {
                        eodCleanupMonitor.shutdownNow();
                    }
                } catch (InterruptedException e) {
                    eodCleanupMonitor.shutdownNow();
                    Thread.currentThread().interrupt();
                }
                log("EOD cleanup monitor stopped.");
            }
            if (backupOcoMonitor != null) {
                backupOcoMonitor.stop();
                log("Backup OCO monitor stopped.");
            }
            if (fileWriter != null) {
                fileWriter.shutdown();
                log("File writer flushed and stopped.");
            }
            if (tradeHistoryFileWriter != null) {
                tradeHistoryFileWriter.stop();
                log("Trade history file writer stopped.");
            }
            if (connectionMonitor != null) {
                connectionMonitor.shutdown();
                log("Connection monitor stopped.");
            }
            if (ocoImbalanceDetector != null) {
                ocoImbalanceDetector.shutdown();
                log("OCO Imbalance Detector shutdown.");
            }
            if (simpleOcoPoller != null) {
                simpleOcoPoller.stop();
                log("SimpleOcoPoller stopped.");
            }
            OcoWaitExecutor ocoWaitExecutor = OcoWaitExecutor.getInstance();
            if (ocoWaitExecutor != null) {
                ocoWaitExecutor.shutdown();
                log("OCO Wait Executor stopped.");
            }
            if (uiUpdateScheduler != null && !uiUpdateScheduler.isShutdown()) {
                uiUpdateScheduler.shutdown();
                try {
                    if (!uiUpdateScheduler.awaitTermination(2, TimeUnit.SECONDS)) {
                        uiUpdateScheduler.shutdownNow();
                    }
                } catch (InterruptedException e) {
                    uiUpdateScheduler.shutdownNow();
                    Thread.currentThread().interrupt();
                }
                log("UI update scheduler stopped");
            }
            if (robotMatrixTable != null) {
                robotMatrixTable.shutdown();
                log("Robot matrix table shutdown");
            }
            if (dataPurgeManager != null) {
                dataPurgeManager.stop();
                log("Data Purge Manager stopped");
            }
            if (robotProcessingPool != null && !robotProcessingPool.isShutdown()) {
                robotProcessingPool.shutdown();
                try {
                    if (!robotProcessingPool.awaitTermination(2, TimeUnit.SECONDS)) {
                        robotProcessingPool.shutdownNow();
                    }
                } catch (InterruptedException e) {
                    robotProcessingPool.shutdownNow();
                    Thread.currentThread().interrupt();
                }
                log("Robot processing pool stopped");
            }
            if (circularLogBuffer != null) {
                circularLogBuffer.shutdown();
                System.out.println("Circular log buffer shutdown complete");
            }

            DatabaseClient dbClient = DatabaseFactory.getClient();
            if (dbClient != null) {
                dbClient.close();
                log("Database connection closed.");
            }

            Logger.info("=== Enhanced TickRecorder Application Shutdown ===");
            Logger.shutdown();

            log("All resources cleaned up. Forcing JVM exit...");
            System.exit(0);
        } catch (Exception e) {
            Logger.error("Error during shutdown: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }

    private void toggleServer() {
        if (server == null) {
            startServer();
        } else {
            stopServer();
        }
    }

    private void startServer() {
        try {
            lastAccountBalanceUpdate = System.currentTimeMillis();

            server = HttpServer.create(new InetSocketAddress(8080), 0);
            server.createContext("/tickrecorder", new OHLCDataHandler());
            server.createContext("/tickdata", new TickDataHandler());
            server.createContext("/bollingerbands", new BollingerBandsHandler());
            server.createContext("/getcommand", new CommandPollHandler());
            server.createContext("/executionfeedback", new ExecutionFeedbackHandler());
            server.createContext("/accountinfo", new AccountInfoHandler());
            server.createContext("/tradehistory", new TradeHistoryHandler());
            server.setExecutor(Executors.newFixedThreadPool(10));
            server.start();

            startServerButton.setText("Stop HTTP Server");
            log("SUCCESS: HTTP Server started on port 8080.");
            log("INFO: Endpoints - /tickrecorder (OHLC), /tickdata (Ticks), /bollingerbands (BB), /getcommand, /executionfeedback, /accountinfo, /tradehistory");
            log("✓ Bollinger Bands: Receiving CLOSED candle BB values with OHLC data (11 timeframes)");
            log("INFO: Java will request account info from MT5 every 5 seconds via /getcommand");
            log("INFO: BackupOcoMonitor will poll for missed fills every 10 seconds");

            Logger.info("HTTP Server started on port 8080");
            Logger.info("Endpoints active: /tickrecorder, /tickdata, /bollingerbands, /getcommand, /executionfeedback");

            connectionMonitor.start();
            startTimeoutMonitor();
            startEndOfDayCleanupMonitor();

            backupOcoMonitor = BackupOcoMonitor.getInstance(ocoManager, tradeHistoryCache);
            backupOcoMonitor.start();
        } catch (IOException e) {
            log("SERVER ERROR: Failed to start HTTP server: " + e.getMessage());
            Logger.error("Failed to start HTTP server: " + e.getMessage());
            server = null;
        }
    }

    private void stopServer() {
        if (server != null) {
            server.stop(0);
            server = null;
            startServerButton.setText("Start HTTP Server");
            log("Server stopped.");
            Logger.info("HTTP Server stopped");

            if (connectionMonitor != null) {
                connectionMonitor.shutdown();
            }

            if (timeoutMonitor != null) {
                timeoutMonitor.shutdown();
                timeoutMonitor = null;
            }

            if (eodCleanupMonitor != null) {
                eodCleanupMonitor.shutdown();
                eodCleanupMonitor = null;
            }

            if (backupOcoMonitor != null) {
                backupOcoMonitor.stop();
            }
        }
    }

    private void startTimeoutMonitor() {
        timeoutMonitor = Executors.newScheduledThreadPool(1);

        timeoutMonitor.scheduleAtFixedRate(() -> {
            try {
                List<TradeCommand> timedOutCommands = pendingCommandsManager.checkTimeouts();

                if (!timedOutCommands.isEmpty()) {
                    for (TradeCommand cmd : timedOutCommands) {
                        log("TIMEOUT: Command " + cmd.getCommandId() + " timed out (Action: " + cmd.getAction() + ", Magic: " + cmd.getMagicNumber() + ")");
                        Logger.warning("Command timeout: " + cmd.getCommandId() + " - " + cmd.getAction());
                    }
                }

                // Cleanup processed candles older than 1 hour
                long oneHourAgo = (System.currentTimeMillis() / 1000) - 3600;
                processedCandles.entrySet().removeIf(entry -> entry.getValue() < oneHourAgo);

            } catch (Throwable t) {
                String errorMsg = "CRITICAL ERROR in TimeoutMonitor: " + t.getClass().getName() + " - " + t.getMessage();
                try {
                    Logger.error(errorMsg);
                } catch (Throwable logError) {
                    System.err.println(errorMsg);
                    t.printStackTrace(System.err);
                }
                t.printStackTrace(System.err);
            }
        }, 5, 5, TimeUnit.SECONDS);

        log("INFO: Command timeout monitor started (checking every 5 seconds)");
        Logger.info("Command timeout monitor started");
    }

    private void startEndOfDayCleanupMonitor() {
        eodCleanupMonitor = Executors.newScheduledThreadPool(1);

        java.time.ZonedDateTime nowEET = java.time.ZonedDateTime.now(java.time.ZoneId.of("Europe/Athens"));
        int currentHour = nowEET.getHour();

        long initialDelaySeconds;
        if (currentHour < 21) {
            int hoursUntil21 = 21 - currentHour;
            int minutesUntil21 = 60 - nowEET.getMinute();
            initialDelaySeconds = (hoursUntil21 * 3600) + (minutesUntil21 * 60);
            log("INFO: EOD cleanup will start at 21:00 EET (in " + hoursUntil21 + "h " + minutesUntil21 + "m)");
        } else {
            initialDelaySeconds = 10;
            log("INFO: EOD cleanup starting now (already past 21:00 EET)");
        }

        eodCleanupMonitor.scheduleAtFixedRate(() -> {
            try {
                if (robotMatrixTable == null) {
                    return;
                }

                java.time.ZonedDateTime currentTimeEET = java.time.ZonedDateTime.now(java.time.ZoneId.of("Europe/Athens"));
                int currentHourNow = currentTimeEET.getHour();

                if (currentHourNow < 6) {
                    eodProcessedMagicNumbers.clear();
                    Logger.info("EOD: Cleared processed magic numbers (new trading day)");
                }

                javafx.collections.ObservableList<RobotMatrixTable.RobotRow> robotRows = robotMatrixTable.getRobotRows();
                if (robotRows == null || robotRows.isEmpty()) {
                    return;
                }

                int triggeredCount = 0;
                for (RobotMatrixTable.RobotRow robot : robotRows) {
                    if (robot.isPlaceholder() || !robot.activeProperty().get()) {
                        continue;
                    }

                    String magicNumber = robot.magicNumberProperty().get();
                    if (magicNumber == null || magicNumber.trim().isEmpty()) continue;

                    if (eodProcessedMagicNumbers.contains(magicNumber)) {
                        continue;
                    }

                    com.tradelogic.models.RobotConfig robotConfig = buildRobotConfigFromRow(robot, magicNumber);

                    if (tradingStrategy.isEndOfDayReached(robotConfig)) {
                        triggeredCount++;

                        String robotName = robot.robotNameProperty().get();
                        log("EOD CLEANUP TRIGGERED: Robot " + robotName + " (Magic: " + magicNumber +
                            ") - End time " + robotConfig.getEndHour() + ":" +
                            String.format("%02d", robotConfig.getEndMinute()) + " reached");

                        TradeCommand closeCmd = tradingStrategy.generateEmergencyCloseAllCommand(
                            magicNumber,
                            robot.getRobotConfigId()
                        );

                        commandQueue.add(closeCmd);
                        pendingCommandsManager.addPending(closeCmd);

                        log("EOD CLEANUP: Queued EMERGENCY_CLOSE_ALL for robot " + robotName +
                            " (Magic: " + magicNumber + ")");
                        Logger.info("EOD: EMERGENCY_CLOSE_ALL queued for magic " + magicNumber);

                        if (ocoManager.hasActiveGroup(magicNumber)) {
                            TradeCommand deleteCmd = tradingStrategy.generateDeleteAllCommand(
                                magicNumber,
                                robot.getRobotConfigId()
                            );

                            commandQueue.add(deleteCmd);
                            pendingCommandsManager.addPending(deleteCmd);
                            ocoManager.markEndOfDayCleanup(magicNumber);

                            log("EOD CLEANUP: Queued DELETE_ALL_PENDING for robot " + robotName +
                                " (Magic: " + magicNumber + ")");
                            Logger.info("EOD: DELETE_ALL_PENDING queued for magic " + magicNumber);
                        }

                        eodProcessedMagicNumbers.add(magicNumber);

                        Logger.info("EOD: Cleanup complete for magic " + magicNumber +
                                    " - Symbol: " + robot.symbolProperty().get() +
                                    ", Timeframe: " + robot.timeframeProperty().get());
                    }
                }

                if (triggeredCount > 0) {
                    log("EOD CLEANUP: Processed " + triggeredCount + " robots this cycle");

                    int breachStatesCleared = orthodoxCCBreachStates.size();
                    if (breachStatesCleared > 0) {
                        orthodoxCCBreachStates.clear();
                        log("EOD CLEANUP: Cleared " + breachStatesCleared + " Orthodox CC breach states");
                    }
                }

            } catch (Throwable t) {
                String errorMsg = "CRITICAL ERROR in EOD Cleanup Monitor: " + t.getClass().getName() + " - " + t.getMessage();
                try {
                    Logger.error(errorMsg);
                } catch (Throwable logError) {
                    System.err.println(errorMsg);
                    t.printStackTrace(System.err);
                }
                t.printStackTrace(System.err);
            }
        }, initialDelaySeconds, 60, TimeUnit.SECONDS);

        Logger.info("End-of-day cleanup monitor started (checks every 60 seconds, EET timezone)");
    }

    private class OHLCDataHandler implements HttpHandler {
        private class BarJson {
            String symbol;
            String tf;
            long time;
            double open;
            double high;
            double low;
            double close;
            Double bb_upper;
            Double bb_middle;
            Double bb_lower;
        }

        @Override
        public void handle(HttpExchange exchange) {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendResponse(exchange, 405, "Method Not Allowed");
                return;
            }

            String jsonBody = "";
            try (InputStream is = exchange.getRequestBody();
                 BufferedReader br = new BufferedReader(new InputStreamReader(is))) {

                jsonBody = br.lines().collect(Collectors.joining(System.lineSeparator()));
                BarJson[] bars = gson.fromJson(jsonBody, BarJson[].class);

                if (bars != null && bars.length > 0) {
                    lastDataReceivedTime = System.currentTimeMillis();

                    for (BarJson b : bars) {
                        MarketBarData bar = new MarketBarData(b.symbol, b.tf, b.time, b.open, b.high, b.low, b.close);
                        ohlcData.put(bar.getKey(), bar);

                        // Only queue UI updates if OHLC display is enabled
                        if (ohlcDisplayEnabled) {
                            uiDataManager.queueOhlcUpdate(bar);
                        }

                        // Process BB data if present (CLOSED candle values only)
                        if (b.bb_upper != null && b.bb_middle != null && b.bb_lower != null) {
                            String displayTimeframe = convertTimeframeFormat(b.tf);
                            BBData bbDataObj = new BBData(b.symbol, displayTimeframe, b.time, b.bb_upper, b.bb_middle, b.bb_lower, 0.0);
                            bbData.put(bbDataObj.getKey(), bbDataObj);
                            uiDataManager.queueBBUpdate(bbDataObj);
                        }

                        fileWriter.queueWrite(bar);
                    }

                    Logger.info("OHLC: Processed " + bars.length + " bars");

                    analyzeForTradeSignals(bars);
                }

                sendResponse(exchange, 200, "OK");
            } catch (Exception e) {
                log("HANDLER ERROR: OHLCDataHandler failed: " + e.getMessage());
                Logger.error("OHLCDataHandler failed: " + e.getMessage());
                // DEBUG: Log the JSON around the error position (column 6246)
                if (jsonBody.length() >= 6246) {
                    int start = Math.max(0, 6220);
                    int end = Math.min(jsonBody.length(), 6280);
                    String snippet = jsonBody.substring(start, end);
                    System.err.println(">>> DEBUG OHLC JSON (6220-6280): [" + snippet + "]");
                    log("DEBUG OHLC JSON (6220-6280): [" + snippet + "]");
                } else if (jsonBody.length() > 0) {
                    System.err.println(">>> DEBUG OHLC LENGTH: " + jsonBody.length());
                    log("DEBUG OHLC JSON LENGTH: " + jsonBody.length());
                }
                sendResponse(exchange, 500, "Internal Server Error");
            }
        }
    }

    private class TickDataHandler implements HttpHandler {
        private class TickJson {
            String symbol;
            long time;
            double bid;
            double ask;
            long volume;
        }

        @Override
        public void handle(HttpExchange exchange) {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendResponse(exchange, 405, "Method Not Allowed");
                return;
            }

            String jsonBody = "";
            try (InputStream is = exchange.getRequestBody();
                 BufferedReader br = new BufferedReader(new InputStreamReader(is))) {

                jsonBody = br.lines().collect(Collectors.joining(System.lineSeparator()));
                TickJson[] ticks = gson.fromJson(jsonBody, TickJson[].class);

                if (ticks != null && ticks.length > 0) {
                    lastDataReceivedTime = System.currentTimeMillis();

                    StringBuilder symbolsReceived = new StringBuilder("Symbols: ");
                    for (TickJson t : ticks) {
                        TickData tick = new TickData(t.symbol, t.time, t.bid, t.ask, t.volume);
                        tickData.put(tick.getKey(), tick);
                        symbolsReceived.append(t.symbol).append(" ");

                        // Only queue UI updates if tick display is enabled
                        if (tickDisplayEnabled) {
                            uiDataManager.queueTickUpdate(tick);
                        }

                        // Auto-populate conversion rates for currency pairs
                        updateConversionRate(t.symbol, t.bid, t.ask);
                    }

                    Logger.info("Processed " + ticks.length + " tick updates - " + symbolsReceived.toString());
                    Logger.info("Tick data received: " + ticks.length + " ticks processed");
                }

                sendResponse(exchange, 200, "OK");
            } catch (Exception e) {
                log("HANDLER ERROR: TickDataHandler failed: " + e.getMessage());
                // DEBUG: Log the JSON around the error position (column 383)
                if (jsonBody.length() >= 383) {
                    int start = Math.max(0, 363);
                    int end = Math.min(jsonBody.length(), 403);
                    String snippet = jsonBody.substring(start, end);
                    System.err.println(">>> DEBUG TICK JSON (363-403): [" + snippet + "]");
                    log("DEBUG TICK JSON (363-403): [" + snippet + "]");
                } else if (jsonBody.length() > 0) {
                    System.err.println(">>> DEBUG TICK LENGTH: " + jsonBody.length());
                    log("DEBUG TICK JSON LENGTH: " + jsonBody.length());
                }
                Logger.error("TickDataHandler failed: " + e.getMessage());
                sendResponse(exchange, 500, "Internal Server Error");
            }
        }
    }

    private class BollingerBandsHandler implements HttpHandler {
        private class BBJson {
            String symbol;
            String timeframe;
            long time;
            double bb_upper;
            double bb_middle;
            double bb_lower;
            double bb_value;
        }

        @Override
        public void handle(HttpExchange exchange) {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendResponse(exchange, 405, "Method Not Allowed");
                return;
            }

            try (InputStream is = exchange.getRequestBody();
                 BufferedReader br = new BufferedReader(new InputStreamReader(is))) {

                String jsonBody = br.lines().collect(Collectors.joining(System.lineSeparator()));
                BBJson[] bbArray = gson.fromJson(jsonBody, BBJson[].class);

                if (bbArray != null && bbArray.length > 0) {
                    lastDataReceivedTime = System.currentTimeMillis();

                    for (BBJson bb : bbArray) {
                        // Convert EA timeframe format (PERIOD_M15) to display format (M15)
                        String displayTimeframe = convertTimeframeFormat(bb.timeframe);
                        BBData bbDataObj = new BBData(bb.symbol, displayTimeframe, bb.time, bb.bb_upper, bb.bb_middle, bb.bb_lower, bb.bb_value);
                        bbData.put(bbDataObj.getKey(), bbDataObj);
                        uiDataManager.queueBBUpdate(bbDataObj);
                    }
                    Logger.info("✓ Received and queued " + bbArray.length + " BB updates");
                } else {
                    Logger.warning("BB data received but array is null or empty");
                }

                sendResponse(exchange, 200, "OK");
            } catch (Exception e) {
                log("HANDLER ERROR: BollingerBandsHandler failed: " + e.getMessage());
                Logger.error("BollingerBandsHandler failed: " + e.getMessage());
                e.printStackTrace();
                sendResponse(exchange, 500, "Internal Server Error");
            }
        }
    }

    private class CommandPollHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) {
            if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendResponse(exchange, 405, "Method Not Allowed");
                return;
            }

            try {
                TradeCommand command = commandQueue.poll();

                if (command != null) {
                    pendingCommandsManager.addPending(command);
                    pendingCommandsManager.markAsSent(command.getCommandId());

                    String csvCommand = command.toCsv();
                    sendResponse(exchange, 200, csvCommand);

                    Map<String, Object> params = command.getParameters();
                    String symbol = (String) params.get("symbol");
                    String orderType = (String) params.get("order_type");
                    double price = params.containsKey("price") ? ((Number) params.get("price")).doubleValue() : 0.0;

                    log("COMMAND POLL: Sent command " + command.getCommandId() + " to MT5 (Action: " + command.getAction() +
                        ", Magic: " + command.getMagicNumber() + ", Symbol: " + symbol + ", Type: " + orderType + ", Price: " + String.format("%.5f", price) + ")");
                    Logger.info("Command sent to MT5: " + command.getCommandId() + " - " + command.getAction() + " " + symbol);
                } else {
                    long currentTime = System.currentTimeMillis();
                    long timeSinceLastUpdate = currentTime - lastAccountBalanceUpdate;

                    if (timeSinceLastUpdate >= 5000) {
                        String accountInfoRequest = "SEND_ACCOUNT_INFO," + UUID.randomUUID().toString();
                        sendResponse(exchange, 200, accountInfoRequest);
                    } else {
                        sendResponse(exchange, 200, "NO_COMMAND");
                    }
                }
            } catch (Exception e) {
                log("COMMAND POLL ERROR: " + e.getMessage());
                Logger.error("CommandPollHandler failed: " + e.getMessage());
                sendResponse(exchange, 500, "Internal Server Error");
            }
        }
    }

    private class ExecutionFeedbackHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendResponse(exchange, 405, "Method Not Allowed");
                return;
            }

            try (InputStream is = exchange.getRequestBody();
                 BufferedReader br = new BufferedReader(new InputStreamReader(is))) {

                String jsonBody = br.lines().collect(Collectors.joining(System.lineSeparator()));
                ExecutionFeedback feedback = ExecutionFeedback.fromJson(jsonBody);

                if (feedback == null || feedback.getCommandId() == null) {
                    log("EXECUTION FEEDBACK ERROR: Invalid feedback received");
                    Logger.warning("Invalid execution feedback received");
                    sendResponse(exchange, 400, "Invalid feedback format");
                    return;
                }

                TradeCommand confirmedCommand = pendingCommandsManager.confirmCommand(feedback);

                if (confirmedCommand != null) {
                    String feedbackMsg = String.format("EXECUTION FEEDBACK: Command %s (%s) finished. Status: %s, RetCode: %d, Magic: %s",
                        feedback.getCommandId(),
                        confirmedCommand.getAction(),
                        feedback.getStatus(),
                        feedback.getRetcode(),
                        confirmedCommand.getMagicNumber());

                    log(feedbackMsg);
                    Logger.info(feedbackMsg);

                    if (feedback.getTicket() != null) {
                        log("EXECUTION FEEDBACK: Ticket: " + feedback.getTicket());
                    }

                    if (feedback.isFailed()) {
                        String errorMsg = feedback.getErrorMessage();
                        if (errorMsg != null && !errorMsg.isEmpty()) {
                            log("EXECUTION FEEDBACK ERROR: " + errorMsg);
                            Logger.error("Command failed: " + feedback.getCommandId() + " - " + errorMsg);
                        }
                    }

                    if (feedback.isSuccess() && "PLACE_ORDER".equals(confirmedCommand.getAction()) && feedback.getRetcode() == 0) {
                        log("OCO FILL FEEDBACK: Order filled, processing OCO logic for magic " + confirmedCommand.getMagicNumber());
                        Optional<TradeCommand> ocoDeleteCmd = ocoManager.processFill(feedback, confirmedCommand);
                        if (ocoDeleteCmd.isPresent()) {
                            TradeCommand deleteCmd = ocoDeleteCmd.get();
                            commandQueue.addFirst(deleteCmd);
                            pendingCommandsManager.addPending(deleteCmd);
                            log("OCO TRIGGER: PRIORITY delete command queued for opposite side (Magic: " + deleteCmd.getMagicNumber() + ")");
                            Logger.info("OCO delete command queued with PRIORITY: " + deleteCmd.getCommandId());
                        }
                    }

                    reconcileRobotState(confirmedCommand, feedback);

                    // Check Smart Trailing Stop - if TP1 is hit, move all SL to breakeven
                    TradeCommand breakevenCommand = smartTSMonitor.checkAndTriggerBreakeven(feedback);
                    if (breakevenCommand != null) {
                        commandQueue.add(breakevenCommand);
                        pendingCommandsManager.addPending(breakevenCommand);
                        log("★★★ SMART TS: Breakeven command queued for magic " + breakevenCommand.getMagicNumber());
                    }
                } else {
                    // Command tracking expired but order may have filled - process OCO anyway
                    if (feedback.isSuccess() && feedback.getRetcode() == 0 && feedback.getTicket() != null && feedback.getMagicNumber() != null) {
                        Object orderTypeObj = feedback.getDetail("order_type");
                        String orderType = (orderTypeObj != null) ? orderTypeObj.toString() : null;

                        if (orderType != null) {
                            log("OCO FILL DETECTED: Processing fill for magic " + feedback.getMagicNumber() + " (Type: " + orderType + ")");
                            Map<String, Object> params = new HashMap<>();
                            params.put("order_type", orderType);
                            TradeCommand syntheticCommand = new TradeCommand(
                                null,
                                feedback.getMagicNumber(),
                                "PLACE_ORDER",
                                params
                            );
                            syntheticCommand.setCommandId(feedback.getCommandId());
                            Optional<TradeCommand> ocoDeleteCmd = ocoManager.processFill(feedback, syntheticCommand);
                            if (ocoDeleteCmd.isPresent()) {
                                TradeCommand deleteCmd = ocoDeleteCmd.get();
                                commandQueue.addFirst(deleteCmd);
                                pendingCommandsManager.addPending(deleteCmd);
                                log("OCO TRIGGER: PRIORITY delete command queued for opposite side (Magic: " + deleteCmd.getMagicNumber() + ")");
                                Logger.info("OCO delete command queued: " + deleteCmd.getCommandId());
                            } else {
                                // OcoManager group not found - create direct delete command
                                log("OCO DIRECT DELETE: Creating delete command for magic " + feedback.getMagicNumber());
                                String filledSide = orderType.startsWith("BUY") ? "BUY" : "SELL";
                                String oppositeType = filledSide.equals("BUY") ? "SELL_STOP" : "BUY_STOP";

                                Map<String, Object> deleteParams = new HashMap<>();
                                deleteParams.put("magic_number", feedback.getMagicNumber());
                                deleteParams.put("order_type", oppositeType);

                                TradeCommand deleteCmd = new TradeCommand(
                                    null,
                                    feedback.getMagicNumber(),
                                    "DELETE_OPPOSITE_SIDE",
                                    deleteParams
                                );

                                commandQueue.addFirst(deleteCmd);
                                pendingCommandsManager.addPending(deleteCmd);
                                log("OCO DELETE: Command queued for " + oppositeType + " orders (Magic: " + feedback.getMagicNumber() + ")");
                                Logger.info("OCO delete command queued: " + deleteCmd.getCommandId());
                            }
                        } else {
                            log("Feedback missing order_type - cannot process OCO");
                        }
                    }
                }

                sendResponse(exchange, 200, "FEEDBACK_RECEIVED");
            } catch (Exception e) {
                log("HANDLER ERROR: ExecutionFeedbackHandler failed: " + e.getMessage());
                Logger.error("ExecutionFeedbackHandler failed: " + e.getMessage());
                sendResponse(exchange, 500, "Internal Server Error");
            }
        }
    }

    private class AccountInfoHandler implements HttpHandler {
        private class AccountInfoJson {
            double balance;
            double equity;
            String currency;
            Map<String, Double> conversion_rates;
        }

        @Override
        public void handle(HttpExchange exchange) {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendResponse(exchange, 405, "Method Not Allowed");
                return;
            }

            try (InputStream is = exchange.getRequestBody();
                 BufferedReader br = new BufferedReader(new InputStreamReader(is))) {

                String jsonBody = br.lines().collect(Collectors.joining(System.lineSeparator()));
                AccountInfoJson accountInfo = gson.fromJson(jsonBody, AccountInfoJson.class);

                if (accountInfo != null) {
                    lastDataReceivedTime = System.currentTimeMillis();

                    double previousBalance = accountBalance;
                    accountBalance = accountInfo.balance;
                    accountCurrency = accountInfo.currency != null ? accountInfo.currency : "USD";
                    lastAccountBalanceUpdate = System.currentTimeMillis();

                    // Update conversion rates from account info (sent by MT5 EA)
                    if (accountInfo.conversion_rates != null && !accountInfo.conversion_rates.isEmpty()) {
                        for (Map.Entry<String, Double> entry : accountInfo.conversion_rates.entrySet()) {
                            String pair = entry.getKey();
                            Double rate = entry.getValue();

                            if (rate != null && rate > 0) {
                                conversionRates.put(pair, rate);

                                // Also store inverse rate for easy lookup
                                if (pair.length() == 6) {
                                    String baseCurrency = pair.substring(0, 3);
                                    String quoteCurrency = pair.substring(3, 6);
                                    String inversePair = quoteCurrency + baseCurrency;
                                    conversionRates.put(inversePair, 1.0 / rate);
                                }
                            }
                        }

                        Logger.info("Updated conversion rates from account info: " + accountInfo.conversion_rates.keySet());
                    }

                    DrawdownMonitor drawdownMonitor = DrawdownMonitor.getInstance();
                    drawdownMonitor.updateAccountEquity(accountInfo.equity);

                    if (robotMatrixTable != null) {
                        robotMatrixTable.setAccountBalance(accountBalance);
                    }

                    String currentDay = LocalDateTime.now().toLocalDate().toString();
                    boolean isNewTradingDay = !currentDay.equals(lastTradingDay);

                    if (previousBalance <= 0 && accountBalance > 0) {
                        log(String.format("★★★ ACCOUNT BALANCE RECEIVED: $%.2f %s - Ready to place orders! ★★★",
                            accountBalance, accountCurrency));
                        drawdownMonitor.setStartOfDayEquity(accountInfo.equity);
                        lastTradingDay = currentDay;
                    } else if (isNewTradingDay) {
                        log(String.format("★★★ NEW TRADING DAY DETECTED (%s) - Resetting start-of-day equity to: $%.2f ★★★",
                            currentDay, accountInfo.equity));
                        drawdownMonitor.setStartOfDayEquity(accountInfo.equity);
                        lastTradingDay = currentDay;
                    }

                    String logKey = "ACCOUNT_INFO";
                    Long lastLogTime = logThrottleMap.get(logKey);
                    long now = System.currentTimeMillis();

                    if (lastLogTime == null || (now - lastLogTime) >= 60000) {
                        log(String.format("ACCOUNT INFO: Balance=%.2f %s, Equity=%.2f",
                            accountInfo.balance, accountCurrency, accountInfo.equity));
                        logThrottleMap.put(logKey, now);
                    }

                    Logger.info(String.format("Account info updated: Balance=%.2f %s",
                        accountBalance, accountCurrency));
                }

                sendResponse(exchange, 200, "OK");
            } catch (Exception e) {
                log("HANDLER ERROR: AccountInfoHandler failed: " + e.getMessage());
                Logger.error("AccountInfoHandler failed: " + e.getMessage());
                sendResponse(exchange, 500, "Internal Server Error");
            }
        }
    }

    private class TradeHistoryHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendResponse(exchange, 405, "Method Not Allowed");
                return;
            }

            try (InputStream is = exchange.getRequestBody();
                 BufferedReader br = new BufferedReader(new InputStreamReader(is))) {

                String jsonBody = br.lines().collect(Collectors.joining(System.lineSeparator()));
                TradeHistoryEntry[] history = gson.fromJson(jsonBody, TradeHistoryEntry[].class);

                if (history != null && history.length > 0) {
                    lastDataReceivedTime = System.currentTimeMillis();

                    for (TradeHistoryEntry entry : history) {
                        tradeHistoryCache.addTrade(entry);

                        if (tradeHistoryPersistence != null) {
                            tradeHistoryPersistence.saveTrade(entry, "local_user");
                        }
                    }

                    String logKey = "TRADE_HISTORY";
                    Long lastLogTime = logThrottleMap.get(logKey);
                    long now = System.currentTimeMillis();

                    if (lastLogTime == null || (now - lastLogTime) >= 60000) {
                        Logger.info(String.format("Trade history received: %d entries", history.length));
                        logThrottleMap.put(logKey, now);
                    }
                }

                sendResponse(exchange, 200, "OK");
            } catch (Exception e) {
                log("HANDLER ERROR: TradeHistoryHandler failed: " + e.getMessage());
                Logger.error("TradeHistoryHandler failed: " + e.getMessage());
                sendResponse(exchange, 500, "Internal Server Error");
            }
        }
    }

    private void reconcileRobotState(TradeCommand command, ExecutionFeedback feedback) {
        try {
            if (feedback.isSuccess()) {
                log("STATE RECONCILIATION: Command " + command.getCommandId() + " succeeded - updating robot state");

                switch (command.getAction()) {
                    case "PLACE_ORDER":
                        log("STATE: New order placed for Magic " + command.getMagicNumber() + ", Ticket: " + feedback.getTicket());
                        break;

                    case "CLOSE_POSITION":
                        log("STATE: Position closed for Magic " + command.getMagicNumber());
                        break;

                    case "MODIFY_ORDER":
                        log("STATE: Order modified for Magic " + command.getMagicNumber());
                        break;

                    case "CANCEL_ORDER":
                        log("STATE: Order canceled for Magic " + command.getMagicNumber());
                        break;

                    case "EMERGENCY_CLOSE_ALL":
                        log("STATE: Emergency close executed for Magic " + command.getMagicNumber());
                        break;

                    default:
                        log("STATE: Unknown action reconciled: " + command.getAction());
                        break;
                }
            } else {
                log("STATE RECONCILIATION: Command " + command.getCommandId() + " failed - no state change");
            }
        } catch (Exception e) {
            Logger.error("State reconciliation failed: " + e.getMessage());
        }
    }

    private void analyzeForTradeSignals(OHLCDataHandler.BarJson[] bars) {
        try {
            if (robotMatrixTable == null) {
                Logger.info("Robot Matrix Table not initialized");
                return;
            }

            javafx.collections.ObservableList<RobotMatrixTable.RobotRow> robotRows = robotMatrixTable.getRobotRows();

            if (robotRows == null || robotRows.isEmpty()) {
                return;
            }

            // CRITICAL FIX: Only process the LATEST bar for each symbol/timeframe combination
            // This prevents processing historical or duplicate bars when All Day mode is enabled
            Map<String, OHLCDataHandler.BarJson> latestBars = new java.util.HashMap<>();
            for (OHLCDataHandler.BarJson bar : bars) {
                String key = bar.symbol + "_" + bar.tf.replace("PERIOD_", "");
                OHLCDataHandler.BarJson existing = latestBars.get(key);
                if (existing == null || bar.time > existing.time) {
                    latestBars.put(key, bar);
                }
            }

            // Throttle bar count logging to once per minute
            String barCountThrottleKey = "bar_count_log";
            Long lastBarCountLog = logThrottleMap.get(barCountThrottleKey);
            long currentTime = System.currentTimeMillis();
            if (lastBarCountLog == null || (currentTime - lastBarCountLog) > 60000) {
                log("INFO: Received " + bars.length + " bars, processing " + latestBars.size() + " latest bars");
                logThrottleMap.put(barCountThrottleKey, currentTime);
            }

            int enabledCount = 0;
            int disabledCount = 0;
            int signalsChecked = 0;

            for (RobotMatrixTable.RobotRow robot : robotRows) {
                if (robot.isPlaceholder()) {
                    continue;
                }

                if (!robot.activeProperty().get()) {
                    disabledCount++;
                    continue;
                }

                // CRITICAL: Check master ON/MUTED button before analyzing ANY robot
                if (robotMatrixTable != null && robotMatrixTable.getControlPanel() != null) {
                    if (!robotMatrixTable.getControlPanel().isMasterEnabled()) {
                        disabledCount++;
                        continue;
                    }
                }

                enabledCount++;

                String baseMagicNumber = robot.magicNumberProperty().get();
                if (baseMagicNumber == null || baseMagicNumber.trim().isEmpty()) {
                    log("  ⚠ Robot " + robot.robotNameProperty().get() + " has no Magic # - skipping");
                    continue;
                }

                String robotSymbol = robot.symbolProperty().get();
                String robotTimeframe = robot.timeframeProperty().get();

                if (pendingCommandsManager.hasCommandsAwaitingConfirmation(baseMagicNumber)) {
                    log("  → Robot " + robot.robotNameProperty().get() + ": ⏳ Awaiting confirmation - BLOCKING");
                    continue;
                }

                boolean foundMatch = false;
                for (OHLCDataHandler.BarJson bar : latestBars.values()) {
                    if (!bar.symbol.equals(robotSymbol)) {
                        continue;
                    }

                    // Normalize timeframe: remove "PERIOD_" prefix if present
                    String normalizedTf = bar.tf.replace("PERIOD_", "");
                    if (!normalizedTf.equals(robotTimeframe)) {
                        continue;
                    }

                    foundMatch = true;
                    signalsChecked++;

                    // Create MarketBarData to use new candle validation
                    MarketBarData barData = new MarketBarData(
                        bar.symbol, bar.tf, bar.time,
                        bar.open, bar.high, bar.low, bar.close
                    );

                    // MT5 timestamps are ALREADY in broker server time (not UTC!)
                    // So we use them directly without timezone conversion
                    long closeTimeSeconds = barData.getCloseTime();

                    // Extract hour and minute from the timestamp using UTC
                    // (because MT5's "local time" is encoded as if it were UTC in the epoch)
                    java.time.LocalDateTime candleTime = java.time.LocalDateTime.ofEpochSecond(
                        closeTimeSeconds, 0, java.time.ZoneOffset.UTC
                    );
                    int candleHour = candleTime.getHour();
                    int candleMinute = candleTime.getMinute();
                    int targetHour = robot.closeHourProperty().get();
                    int targetMinute = robot.closeMinuteProperty().get();

                    String formattedCandleTime = candleTime.format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

                    // Determine pattern type
                    boolean isStrongThrust = robot.strongThrustProperty().get();
                    boolean isOrthodoxCC = robot.orthodoxCCProperty().get();
                    boolean isAllDay = robot.allDayProperty().get();
                    boolean isNormalPattern = !isStrongThrust && !isOrthodoxCC;

                    // Throttle logging: only log every 15 seconds per robot
                    String throttleKey = "robot_check_" + baseMagicNumber;
                    Long lastLog = logThrottleMap.get(throttleKey);
                    long now = System.currentTimeMillis();
                    boolean shouldLog = (lastLog == null || (now - lastLog) > 15000);

                    if (shouldLog) {
                        String patternType = isStrongThrust ? "Strong Thrust" : (isOrthodoxCC ? "Orthodox CC" : "Normal");
                        log("Robot: " + robot.robotNameProperty().get() + " (" + robot.magicNumberProperty().get() + ") [" + patternType + "]");
                        log("  Symbol/TF: " + bar.symbol + " " + bar.tf);
                        log("  Candle Time: " + formattedCandleTime + " [" + candleHour + ":" + String.format("%02d", candleMinute) + "]");
                        log("  Target: " + targetHour + ":" + String.format("%02d", targetMinute) + " | All Day: " + isAllDay);
                        logThrottleMap.put(throttleKey, now);
                    }

                    // For Strong Thrust and Orthodox CC with All Day enabled, skip time check
                    // For Normal pattern, always check time
                    boolean skipTimeCheck = (isStrongThrust || isOrthodoxCC) && isAllDay;

                    if (!skipTimeCheck) {
                        if (candleHour != targetHour || candleMinute != targetMinute) {
                            if (shouldLog) {
                                log("  ⏭ Candle time mismatch - skipping");
                            }
                            continue;
                        }
                    }

                    // ATOMIC duplicate prevention: Use putIfAbsent to prevent race conditions
                    // If multiple threads process the same candle simultaneously, only ONE will succeed
                    String candleKey = baseMagicNumber + "_" + barData.getCloseTime();
                    Long previousValue = processedCandles.putIfAbsent(candleKey, barData.getCloseTime());
                    if (previousValue != null) {
                        // Another thread already processed this candle
                        if (shouldLog) {
                            log("  ⏭ DUPLICATE DETECTED: Candle key '" + candleKey + "' already processed");
                        }
                        continue;
                    }

                    log("  ✓ Candle time matches target!");
                    log("  Candle Key: " + candleKey + " (Magic + CloseTime)");
                    log("  Candle Details:");
                    log("    Open Time:  " + java.time.LocalDateTime.ofEpochSecond(bar.time, 0, java.time.ZoneOffset.UTC).format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
                    log("    Close Time: " + formattedCandleTime);
                    log("    Open:  " + String.format("%.5f", bar.open));
                    log("    High:  " + String.format("%.5f", bar.high));
                    log("    Low:   " + String.format("%.5f", bar.low));
                    log("    Close: " + String.format("%.5f", bar.close));

                    if (!barData.isDurationValid()) {
                        log("  ⚠ WARNING: Candle duration anomaly! Actual: " + barData.getCandleDuration() + "s, Expected: " + barData.getExpectedDuration() + "s");
                    }

                    double barHeight = bar.high - bar.low;
                    boolean signalDetected = false;
                    String signalReason = "";

                    // Calculate minimum height (used by all pattern types)
                    double minHeight = convertX1Height(
                        robot.minX1HeightProperty().get(),
                        robot.x1TypeProperty().get(),
                        bar.symbol
                    );

                    // Get Bollinger Band data for this candle
                    String bbKey = bar.symbol + "_" + convertTimeframeFormat(bar.tf);
                    BBData candleBBData = bbData.get(bbKey);

                    // CRITICAL: Verify BB data timestamp matches candle timestamp
                    if (candleBBData != null && candleBBData.getTimestampSeconds() != bar.time) {
                        log("  ⚠ BB data timestamp mismatch! BB timestamp: " + candleBBData.getTimestampSeconds() + ", Candle timestamp: " + bar.time);
                        log("  → Rejecting stale/mismatched BB data");
                        candleBBData = null;
                    }

                    if (isStrongThrust) {
                        // Strong Thrust pattern detection
                        log("  Bar Height: " + String.format("%.5f", barHeight) + " | Min: " + String.format("%.5f", minHeight));
                        if (candleBBData != null) {
                            signalDetected = detectStrongThrust(bar, candleBBData, minHeight);
                            if (signalDetected) {
                                signalReason = "Strong Thrust: High breached upper BB + min height met";
                                log("  BB Data: Upper=" + String.format("%.5f", candleBBData.getBbUpper()) +
                                    ", Middle=" + String.format("%.5f", candleBBData.getBbMiddle()) +
                                    ", Lower=" + String.format("%.5f", candleBBData.getBbLower()));
                            } else {
                                log("  ⏭ Strong Thrust conditions not met (BB breach + min height required)");
                            }
                        } else {
                            log("  ⚠ No BB data available for Strong Thrust detection");
                        }
                    } else if (isOrthodoxCC) {
                        // Orthodox CC pattern detection (TWO-CANDLE pattern)
                        log("  Bar Height: " + String.format("%.5f", barHeight) + " | Min: " + String.format("%.5f", minHeight));
                        if (candleBBData != null) {
                            String orthodoxStateKey = baseMagicNumber + "_" + bar.symbol + "_" + normalizedTf;
                            signalDetected = detectOrthodoxCC(bar, candleBBData, minHeight, orthodoxStateKey);
                            if (signalDetected) {
                                signalReason = "Orthodox CC: Crossover after BB breach + min height met";
                                log("  BB Data: Upper=" + String.format("%.5f", candleBBData.getBbUpper()) +
                                    ", Middle=" + String.format("%.5f", candleBBData.getBbMiddle()) +
                                    ", Lower=" + String.format("%.5f", candleBBData.getBbLower()));
                            } else {
                                log("  ⏭ Orthodox CC conditions not met (awaiting BB breach + crossover)");
                            }
                        } else {
                            log("  ⚠ No BB data available for Orthodox CC detection");
                        }
                    } else {
                        // Normal pattern: check bar height
                        log("  Bar Height: " + String.format("%.5f", barHeight) + " | Min: " + String.format("%.5f", minHeight));

                        if (barHeight >= minHeight) {
                            signalDetected = true;
                            signalReason = "Normal: Bar height exceeds minimum";
                        } else {
                            log("  ⏭ Bar too small: " + String.format("%.5f", barHeight) + " < " + String.format("%.5f", minHeight));
                        }
                    }

                    if (signalDetected) {
                        log("  ★ SIGNAL DETECTED! " + signalReason);
                        log("  → Preparing trade command...");
                        generateNormalTradeCommand(robot, bar, barData, barHeight, baseMagicNumber);
                    }
                }

                if (!foundMatch) {
                    Logger.info("Robot " + robot.robotNameProperty().get() + " " + baseMagicNumber + ": No match for " + robotSymbol + " " + robotTimeframe);
                }
            }

            Logger.info("Analysis complete: " + enabledCount + " enabled, " + disabledCount + " disabled, " + signalsChecked + " signals checked");

        } catch (Exception e) {
            log("  ✗ ERROR in signal analysis: " + e.getMessage());
            Logger.error("Trade signal analysis failed: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private double convertX1Height(double height, String x1Type, String symbol) {
        String normalized = x1Type.replace(" ", "").replace("-", "");

        switch (normalized) {
            case "NonYenPips":
                return height * 0.0001;
            case "YenPips":
                return height * 0.01;
            case "Cents":
                return height * 0.01;
            case "Points":
                return height;
            default:
                log("    ⚠ Unknown X1 type: " + x1Type + ", using as-is");
                return height;
        }
    }

    /**
     * Checks if a candle touches both Bollinger Bands (disqualification condition)
     */
    private boolean candleTouchesBothBands(OHLCDataHandler.BarJson bar, BBData bbData) {
        if (bbData == null) {
            return false;
        }

        boolean touchesUpper = bar.high >= bbData.getBbUpper();
        boolean touchesLower = bar.low <= bbData.getBbLower();

        return touchesUpper && touchesLower;
    }

    /**
     * Detects Strong Thrust pattern:
     * 1. Candle breaches BB band (high > upper OR low < lower)
     * 2. Candle CLOSES on OPPOSITE side of basis line:
     *    - If breaches upper → close MUST be below basis
     *    - If breaches lower → close MUST be above basis
     * 3. Must NOT touch the opposite band
     */
    private boolean detectStrongThrust(OHLCDataHandler.BarJson bar, BBData bbData, double minHeight) {
        if (bbData == null) {
            return false;
        }

        // Check minimum candle height first
        double barHeight = bar.high - bar.low;
        if (barHeight < minHeight) {
            return false;
        }

        boolean breachesUpper = bar.high > bbData.getBbUpper();
        boolean breachesLower = bar.low < bbData.getBbLower();

        // Must breach at least one band
        if (!breachesUpper && !breachesLower) {
            return false;
        }

        // Disqualify if touches both bands
        if (candleTouchesBothBands(bar, bbData)) {
            log("  ⚠ Strong Thrust disqualified: candle touches both BB bands");
            return false;
        }

        // CRITICAL: Close must be on OPPOSITE side of basis line
        if (breachesUpper) {
            // Breached upper → close MUST be BELOW basis
            if (bar.close >= bbData.getBbMiddle()) {
                log("  ⚠ Strong Thrust disqualified: Breached upper BB but close (" +
                    String.format("%.5f", bar.close) + ") is NOT below basis (" +
                    String.format("%.5f", bbData.getBbMiddle()) + ")");
                return false;
            }
            log("  ✓ Strong Thrust VALID: Breached upper BB + close below basis");
        } else if (breachesLower) {
            // Breached lower → close MUST be ABOVE basis
            if (bar.close <= bbData.getBbMiddle()) {
                log("  ⚠ Strong Thrust disqualified: Breached lower BB but close (" +
                    String.format("%.5f", bar.close) + ") is NOT above basis (" +
                    String.format("%.5f", bbData.getBbMiddle()) + ")");
                return false;
            }
            log("  ✓ Strong Thrust VALID: Breached lower BB + close above basis");
        }

        return true;
    }

    /**
     * Detects Orthodox CC pattern: TWO-CANDLE pattern
     * 1. First candle breaches BB Upper or Lower band
     * 2. IMMEDIATE next candle (N+1) MUST be a crossover candle (open on one side of basis, close on other)
     * 3. If the next candle is NOT a crossover, the breach state is cleared and signal rejected
     * Disqualification:
     *   - If Upper band was breached → crossover candle disqualified only if touches Lower band
     *   - If Lower band was breached → crossover candle disqualified only if touches Upper band
     *   - If crossover happens on candle N+2 or later → REJECTED (must be immediate next candle)
     */
    private boolean detectOrthodoxCC(OHLCDataHandler.BarJson bar, BBData bbData, double minHeight, String stateKey) {
        if (bbData == null) {
            return false;
        }

        double barHeight = bar.high - bar.low;
        if (barHeight < minHeight) {
            return false;
        }

        boolean breachesUpper = bar.high >= bbData.getBbUpper() || bar.low >= bbData.getBbUpper();
        boolean breachesLower = bar.low <= bbData.getBbLower() || bar.high <= bbData.getBbLower();

        OrthodoxCCBreachState existingState = orthodoxCCBreachStates.get(stateKey);

        if (existingState != null && existingState.getCandleTime() != bar.time) {
            long timeframeDuration = getTimeframeDurationSeconds(bar.tf);
            long expectedNextCandleTime = existingState.getCandleTime() + timeframeDuration;

            if (bar.time != expectedNextCandleTime) {
                log("  ⚠ Orthodox CC breach expired: Crossover window missed (expected candle at " +
                    expectedNextCandleTime + ", got " + bar.time + ")");
                orthodoxCCBreachStates.remove(stateKey);

                if (breachesUpper) {
                    log("  → New BB Upper breach detected, tracking for next candle");
                    orthodoxCCBreachStates.put(stateKey, new OrthodoxCCBreachState("UPPER", bar.time));
                } else if (breachesLower) {
                    log("  → New BB Lower breach detected, tracking for next candle");
                    orthodoxCCBreachStates.put(stateKey, new OrthodoxCCBreachState("LOWER", bar.time));
                }

                return false;
            }

            boolean opensAboveMiddle = bar.open > bbData.getBbMiddle();
            boolean closesAboveMiddle = bar.close > bbData.getBbMiddle();
            boolean isCrossover = opensAboveMiddle != closesAboveMiddle;

            if (isCrossover) {
                String breachType = existingState.getBreachType();

                if ("UPPER".equals(breachType)) {
                    boolean touchesLower = bar.low <= bbData.getBbLower();
                    if (touchesLower) {
                        log("  ⚠ Orthodox CC disqualified: Upper breach detected, but crossover candle touches Lower band");
                        orthodoxCCBreachStates.remove(stateKey);
                        return false;
                    }
                } else if ("LOWER".equals(breachType)) {
                    boolean touchesUpper = bar.high >= bbData.getBbUpper();
                    if (touchesUpper) {
                        log("  ⚠ Orthodox CC disqualified: Lower breach detected, but crossover candle touches Upper band");
                        orthodoxCCBreachStates.remove(stateKey);
                        return false;
                    }
                }

                log("  ✓ Orthodox CC VALID: IMMEDIATE crossover candle after " + breachType + " breach");
                orthodoxCCBreachStates.remove(stateKey);
                return true;
            } else {
                log("  ⏭ Orthodox CC expired: Next candle after breach is NOT a crossover - clearing breach state");
                orthodoxCCBreachStates.remove(stateKey);
                return false;
            }
        }

        if (breachesUpper) {
            log("  → BB Upper breach detected, tracking for next candle");
            orthodoxCCBreachStates.put(stateKey, new OrthodoxCCBreachState("UPPER", bar.time));
        } else if (breachesLower) {
            log("  → BB Lower breach detected, tracking for next candle");
            orthodoxCCBreachStates.put(stateKey, new OrthodoxCCBreachState("LOWER", bar.time));
        }

        return false;
    }

    private void generateNormalTradeCommand(RobotMatrixTable.RobotRow robot, OHLCDataHandler.BarJson bar, MarketBarData barData, double barHeight, String baseMagicNumber) {
        try {
            log("      ═══ GENERATING TRADE COMMANDS (14 ORDERS: 7 BUY + 7 SELL) ═══");
            log("        Robot: " + robot.robotNameProperty().get());
            log("        Magic: " + baseMagicNumber);
            log("        Symbol: " + bar.symbol + " " + robot.timeframeProperty().get());
            log("        Bar: H:" + bar.high + " L:" + bar.low + " Height:" + String.format("%.5f", barHeight));
            log("        Candle Open Time: " + barData.getFormattedOpenTime());
            log("        Candle Close Time: " + barData.getFormattedTimestamp());

            double currentBid = getCurrentBid(bar.symbol);
            log("        Current Bid: " + String.format("%.5f", currentBid));

            // Check if account balance is fresh (updated within last 10 seconds)
            long balanceAge = System.currentTimeMillis() - lastAccountBalanceUpdate;
            if (balanceAge > 10000) {
                log(String.format("        ✗ ACCOUNT BALANCE STALE! Last updated %.1f seconds ago. Cannot place orders.", balanceAge / 1000.0));
                log("        ✗ Ensure MT5 EA is running and sending account info every 5 seconds.");
                return;
            }

            if (accountBalance <= 0) {
                log("        ✗ ACCOUNT BALANCE IS ZERO! Cannot place orders. Wait for MT5 to send account info.");
                return;
            }

            log(String.format("        ✓ Account balance is fresh: $%.2f %s (updated %.1f sec ago)",
                accountBalance, accountCurrency, balanceAge / 1000.0));

            com.tradelogic.models.RobotConfig robotConfig = buildRobotConfigFromRow(robot, baseMagicNumber);

            log("        → Calling analyzeSignalAndGenerateCommands...");
            log("        → Robot Config: " + robotConfig.getSymbol() + " | Disable Leapfrog: " + robotConfig.isDisableLeapfrog());
            log("        → Commission Enabled: " + robotConfig.isCommissionsEnabled() + " | Type: " + robotConfig.getCommissionType() + " | Value: " + robotConfig.getCommissionValue());
            log("        → TP1: " + robotConfig.getTp1Percent() + "% Vol:" + robotConfig.getTp1Volume() + "% | TP2: " + robotConfig.getTp2Percent() + "% Vol:" + robotConfig.getTp2Volume() + "%");
            log("        → Account Currency: " + accountCurrency);
            log("        → Available Conversion Rates: " + conversionRates.keySet());

            List<TradeCommand> commands = null;
            try {
                commands = tradingStrategy.analyzeSignalAndGenerateCommands(
                    robotConfig,
                    barData,
                    currentBid,
                    accountBalance,
                    accountCurrency,
                    conversionRates
                );
                log("        → analyzeSignalAndGenerateCommands completed. Commands returned: " + (commands == null ? "NULL" : commands.size()));
            } catch (Exception e) {
                log("        ✗ EXCEPTION in analyzeSignalAndGenerateCommands: " + e.getClass().getName() + " - " + e.getMessage());
                e.printStackTrace();
                return;
            }

            if (commands == null || commands.isEmpty()) {
                log("        ✗ No commands generated (leapfrog protection or validation failed)");
                return;
            }

            log("        ✓ Generated " + commands.size() + " trade commands");

            int buyCount = 0;
            int sellCount = 0;

            for (TradeCommand command : commands) {
                commandQueue.add(command);
                pendingCommandsManager.addPending(command);

                @SuppressWarnings("unchecked")
                Map<String, Object> params = command.getParameters();
                String orderType = (String) params.get("order_type");

                if (orderType.startsWith("BUY")) {
                    buyCount++;
                } else if (orderType.startsWith("SELL")) {
                    sellCount++;
                }
            }

            log("        DEBUG: About to register OCO group for magic " + baseMagicNumber);
            ocoManager.registerOrderGroup(
                baseMagicNumber,
                robot.getRobotConfigId(),
                buyCount > 0,
                sellCount > 0
            );
            // ALSO register with SimpleOcoPoller for bulletproof OCO
            simpleOcoPoller.registerOcoGroup(
                baseMagicNumber,
                robot.symbolProperty().get()
            );
            log("        DEBUG: OCO group registration completed (both OcoManager and SimpleOcoPoller)");

            // Schedule imbalance check 20 seconds after placement
            ocoImbalanceDetector.scheduleImbalanceCheck(
                baseMagicNumber,
                robot.getRobotConfigId()
            );
            log("        DEBUG: Scheduled 20-second imbalance check for magic " + baseMagicNumber);

            // Register Smart TS settings and entry price
            boolean smartTSEnabled = robotConfig.isSmartTS();
            smartTSMonitor.registerSmartTS(baseMagicNumber, smartTSEnabled);

            // Extract entry price from first command
            if (!commands.isEmpty()) {
                @SuppressWarnings("unchecked")
                Map<String, Object> firstParams = commands.get(0).getParameters();
                Double entryPrice = (Double) firstParams.get("price");
                if (entryPrice != null) {
                    smartTSMonitor.registerEntryPrice(baseMagicNumber, entryPrice);
                }
            }
            log("        DEBUG: Smart TS " + (smartTSEnabled ? "ENABLED" : "DISABLED") + " for magic " + baseMagicNumber);

            log("        Summary: " + buyCount + " BUY orders, " + sellCount + " SELL orders");
            log("        Status: QUEUED → awaiting MT5 poll");
            log("      ═══ COMMAND GENERATION COMPLETE ═══");

            Logger.info("Trade commands generated: " + commands.size() + " orders (" +
                       buyCount + " BUY, " + sellCount + " SELL) for robot " +
                       robot.robotNameProperty().get());

        } catch (Exception e) {
            log("      ✗ ERROR generating commands: " + e.getMessage());
            log("      ✗ Exception type: " + e.getClass().getName());
            Logger.error("Failed to generate trade commands: " + e.getMessage());
            e.printStackTrace();

            // Print full stack trace to app log
            for (StackTraceElement element : e.getStackTrace()) {
                log("        at " + element.toString());
            }
        }
    }

    private double getCurrentBid(String symbol) {
        TickData tick = tickData.get(symbol);
        if (tick != null) {
            return tick.getBid();
        }
        log("        ⚠ No tick data for " + symbol + ", using 0.0 for bid");
        return 0.0;
    }

    /**
     * Updates conversion rates map based on incoming tick data
     * Automatically populates rates for forex pairs to enable lot size calculations
     */
    private void updateConversionRate(String symbol, double bid, double ask) {
        String upper = symbol.toUpperCase();

        // For 6-character forex pairs (e.g., EURUSD, USDJPY)
        if (upper.length() == 6) {
            String baseCurrency = upper.substring(0, 3);
            String quoteCurrency = upper.substring(3, 6);

            // Store the rate (use mid-price for accuracy)
            double midPrice = (bid + ask) / 2.0;

            // Store the pair as-is
            conversionRates.put(symbol, midPrice);

            // Also store inverse for easy lookup
            if (midPrice > 0) {
                String inversePair = quoteCurrency + baseCurrency;
                conversionRates.put(inversePair, 1.0 / midPrice);
            }
        }
    }

    private com.tradelogic.models.RobotConfig buildRobotConfigFromRow(RobotMatrixTable.RobotRow robot, String magicNumber) {
        com.tradelogic.models.RobotConfig config = new com.tradelogic.models.RobotConfig();
        config.setId(robot.getRobotConfigId());
        config.setMagicNumber(magicNumber);
        config.setRobotName(robot.robotNameProperty().get());
        config.setSymbol(robot.symbolProperty().get());
        config.setTimeframe(robot.timeframeProperty().get());
        config.setMinX1Height(robot.minX1HeightProperty().get());
        config.setX1Type(robot.x1TypeProperty().get());
        config.setTrigPercent(robot.trigPercentProperty().get());
        config.setStopLossPercent(robot.stopLossPercentProperty().get());
        config.setRptPercent(robot.rptPercentProperty().get());
        config.setRptFixedAmount(robot.rptFixedAmountProperty().get());
        config.setTp1Percent(robot.tp1PercentProperty().get());
        config.setTp1Volume(robot.tp1VolumeProperty().get());
        config.setTp2Percent(robot.tp2PercentProperty().get());
        config.setTp2Volume(robot.tp2VolumeProperty().get());
        config.setTp3Percent(robot.tp3PercentProperty().get());
        config.setTp3Volume(robot.tp3VolumeProperty().get());
        config.setTp4Percent(robot.tp4PercentProperty().get());
        config.setTp4Volume(robot.tp4VolumeProperty().get());
        config.setTp5Percent(robot.tp5PercentProperty().get());
        config.setTp5Volume(robot.tp5VolumeProperty().get());
        config.setTp6Percent(robot.tp6PercentProperty().get());
        config.setTp6Volume(robot.tp6VolumeProperty().get());
        config.setTp7Percent(robot.tp7PercentProperty().get());
        config.setTp7Volume(robot.tp7VolumeProperty().get());
        config.setCommissionsEnabled(robot.commissionsEnabledProperty().get());
        config.setCommissionType(robot.commissionTypeProperty().get());
        config.setCommissionValue(robot.commissionValueProperty().get());
        config.setDisableLeapfrog(robot.disableLeapfrogProperty().get());
        config.setSmartTS(robot.smartTSProperty().get());

        config.setEndTimeEnabled(robot.eodEnabledProperty().get());
        config.setEndHour(robot.endHourProperty().get());
        config.setEndMinute(robot.endMinuteProperty().get());

        config.setStrongThrust(robot.strongThrustProperty().get());
        config.setOrthodoxCC(robot.orthodoxCCProperty().get());
        config.setAllDay(robot.allDayProperty().get());

        return config;
    }

    /**
     * Converts EA timeframe format (PERIOD_M15) to display format (M15)
     */
    private String convertTimeframeFormat(String eaTimeframe) {
        if (eaTimeframe == null) return "M1";

        // Remove "PERIOD_" prefix if present
        String tf = eaTimeframe.replace("PERIOD_", "");

        // Already in correct format
        if (tf.matches("^[MHDW]\\d+$")) return tf;

        // Default to M1 if unknown
        return "M1";
    }

    /**
     * Converts timeframe string to duration in seconds
     * Used for Orthodox CC to validate immediate next candle timing
     */
    private long getTimeframeDurationSeconds(String eaTimeframe) {
        String tf = convertTimeframeFormat(eaTimeframe);

        if (tf.startsWith("M")) {
            int minutes = Integer.parseInt(tf.substring(1));
            return minutes * 60L;
        } else if (tf.startsWith("H")) {
            int hours = Integer.parseInt(tf.substring(1));
            return hours * 3600L;
        } else if (tf.startsWith("D")) {
            int days = Integer.parseInt(tf.substring(1));
            return days * 86400L;
        } else if (tf.startsWith("W")) {
            int weeks = Integer.parseInt(tf.substring(1));
            return weeks * 604800L;
        }

        return 60L;
    }

    private void sendResponse(HttpExchange exchange, int rCode, String response) {
        try {
            exchange.sendResponseHeaders(rCode, response.getBytes().length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(response.getBytes());
            }
        } catch (IOException e) {
            log("SERVER ERROR: Failed to send response: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private TableView<UIDataManager.MarketBarUI> buildOHLCTableView() {
        TableView<UIDataManager.MarketBarUI> tableView = new TableView<>();
        tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<UIDataManager.MarketBarUI, String> symbolCol = new TableColumn<>("Symbol");
        symbolCol.setCellValueFactory(cellData -> cellData.getValue().symbolProperty());
        symbolCol.setMaxWidth(1f * Integer.MAX_VALUE * 10);
        symbolCol.setCellFactory(col -> new TableCell<UIDataManager.MarketBarUI, String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setAlignment(Pos.CENTER_LEFT);
                } else {
                    setText(item);
                    setAlignment(Pos.CENTER);
                }
            }
        });

        TableColumn<UIDataManager.MarketBarUI, String> timeframeCol = new TableColumn<>("TF");
        timeframeCol.setCellValueFactory(cellData -> cellData.getValue().timeframeProperty());
        timeframeCol.setMaxWidth(1f * Integer.MAX_VALUE * 8);
        timeframeCol.setCellFactory(col -> new TableCell<UIDataManager.MarketBarUI, String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setAlignment(Pos.CENTER_LEFT);
                } else {
                    setText(item);
                    setAlignment(Pos.CENTER);
                }
            }
        });

        TableColumn<UIDataManager.MarketBarUI, String> timeCol = new TableColumn<>("Time");
        timeCol.setCellValueFactory(cellData -> cellData.getValue().timestampProperty());
        timeCol.setMaxWidth(1f * Integer.MAX_VALUE * 20);

        DecimalFormat priceFormat = new DecimalFormat("0.#####");

        TableColumn<UIDataManager.MarketBarUI, Number> openCol = new TableColumn<>("Open");
        openCol.setCellValueFactory(cellData -> cellData.getValue().openProperty());
        openCol.setMaxWidth(1f * Integer.MAX_VALUE * 15);
        openCol.setCellFactory(col -> new TableCell<UIDataManager.MarketBarUI, Number>() {
            @Override
            protected void updateItem(Number item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setAlignment(Pos.CENTER_LEFT);
                } else {
                    setText(priceFormat.format(item.doubleValue()));
                    setAlignment(Pos.CENTER);
                }
            }
        });

        TableColumn<UIDataManager.MarketBarUI, Number> highCol = new TableColumn<>("High");
        highCol.setCellValueFactory(cellData -> cellData.getValue().highProperty());
        highCol.setMaxWidth(1f * Integer.MAX_VALUE * 15);
        highCol.setCellFactory(col -> new TableCell<UIDataManager.MarketBarUI, Number>() {
            @Override
            protected void updateItem(Number item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setAlignment(Pos.CENTER_LEFT);
                } else {
                    setText(priceFormat.format(item.doubleValue()));
                    setAlignment(Pos.CENTER);
                }
            }
        });

        TableColumn<UIDataManager.MarketBarUI, Number> lowCol = new TableColumn<>("Low");
        lowCol.setCellValueFactory(cellData -> cellData.getValue().lowProperty());
        lowCol.setMaxWidth(1f * Integer.MAX_VALUE * 15);
        lowCol.setCellFactory(col -> new TableCell<UIDataManager.MarketBarUI, Number>() {
            @Override
            protected void updateItem(Number item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setAlignment(Pos.CENTER_LEFT);
                } else {
                    setText(priceFormat.format(item.doubleValue()));
                    setAlignment(Pos.CENTER);
                }
            }
        });

        TableColumn<UIDataManager.MarketBarUI, Number> closeCol = new TableColumn<>("Close");
        closeCol.setCellValueFactory(cellData -> cellData.getValue().closeProperty());
        closeCol.setMaxWidth(1f * Integer.MAX_VALUE * 17);
        closeCol.setCellFactory(col -> new TableCell<UIDataManager.MarketBarUI, Number>() {
            @Override
            protected void updateItem(Number item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setAlignment(Pos.CENTER_LEFT);
                } else {
                    setText(priceFormat.format(item.doubleValue()));
                    setAlignment(Pos.CENTER);
                }
            }
        });

        TableColumn<UIDataManager.MarketBarUI, Number> bbUpperCol = new TableColumn<>("BB U");
        bbUpperCol.setCellValueFactory(cellData -> cellData.getValue().bbUpperProperty());
        bbUpperCol.setMaxWidth(1f * Integer.MAX_VALUE * 10);
        bbUpperCol.setCellFactory(col -> new TableCell<UIDataManager.MarketBarUI, Number>() {
            @Override
            protected void updateItem(Number item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null || item.doubleValue() == 0.0) {
                    setText("-");
                    setAlignment(Pos.CENTER);
                } else {
                    setText(priceFormat.format(item.doubleValue()));
                    setAlignment(Pos.CENTER);
                }
            }
        });

        TableColumn<UIDataManager.MarketBarUI, Number> bbLowerCol = new TableColumn<>("BB L");
        bbLowerCol.setCellValueFactory(cellData -> cellData.getValue().bbLowerProperty());
        bbLowerCol.setMaxWidth(1f * Integer.MAX_VALUE * 10);
        bbLowerCol.setCellFactory(col -> new TableCell<UIDataManager.MarketBarUI, Number>() {
            @Override
            protected void updateItem(Number item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null || item.doubleValue() == 0.0) {
                    setText("-");
                    setAlignment(Pos.CENTER);
                } else {
                    setText(priceFormat.format(item.doubleValue()));
                    setAlignment(Pos.CENTER);
                }
            }
        });

        TableColumn<UIDataManager.MarketBarUI, Number> bbBasisCol = new TableColumn<>("BB M");
        bbBasisCol.setCellValueFactory(cellData -> cellData.getValue().bbBasisProperty());
        bbBasisCol.setMaxWidth(1f * Integer.MAX_VALUE * 10);
        bbBasisCol.setCellFactory(col -> new TableCell<UIDataManager.MarketBarUI, Number>() {
            @Override
            protected void updateItem(Number item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null || item.doubleValue() == 0.0) {
                    setText("-");
                    setAlignment(Pos.CENTER);
                } else {
                    setText(priceFormat.format(item.doubleValue()));
                    setAlignment(Pos.CENTER);
                }
            }
        });

        tableView.getColumns().addAll(symbolCol, timeframeCol, timeCol, openCol, highCol, lowCol, closeCol, bbUpperCol, bbLowerCol, bbBasisCol);
        return tableView;
    }

    @SuppressWarnings("unchecked")
    private TableView<UIDataManager.TickUI> buildTickTableView() {
        TableView<UIDataManager.TickUI> tableView = new TableView<>();
        tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<UIDataManager.TickUI, String> symbolCol = new TableColumn<>("Symbol");
        symbolCol.setCellValueFactory(cellData -> cellData.getValue().symbolProperty());
        symbolCol.setMaxWidth(1f * Integer.MAX_VALUE * 15);
        symbolCol.setCellFactory(col -> new TableCell<UIDataManager.TickUI, String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setAlignment(Pos.CENTER_LEFT);
                } else {
                    setText(item);
                    setAlignment(Pos.CENTER);
                }
            }
        });

        TableColumn<UIDataManager.TickUI, String> timeCol = new TableColumn<>("Time");
        timeCol.setCellValueFactory(cellData -> cellData.getValue().timestampProperty());
        timeCol.setMaxWidth(1f * Integer.MAX_VALUE * 25);

        DecimalFormat priceFormat = new DecimalFormat("0.#####");

        TableColumn<UIDataManager.TickUI, Number> bidCol = new TableColumn<>("Bid");
        bidCol.setCellValueFactory(cellData -> cellData.getValue().bidProperty());
        bidCol.setMaxWidth(1f * Integer.MAX_VALUE * 20);
        bidCol.setCellFactory(col -> new TableCell<UIDataManager.TickUI, Number>() {
            @Override
            protected void updateItem(Number item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setAlignment(Pos.CENTER_LEFT);
                } else {
                    setText(priceFormat.format(item.doubleValue()));
                    setAlignment(Pos.CENTER);
                }
            }
        });

        TableColumn<UIDataManager.TickUI, Number> askCol = new TableColumn<>("Ask");
        askCol.setCellValueFactory(cellData -> cellData.getValue().askProperty());
        askCol.setMaxWidth(1f * Integer.MAX_VALUE * 20);
        askCol.setCellFactory(col -> new TableCell<UIDataManager.TickUI, Number>() {
            @Override
            protected void updateItem(Number item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setAlignment(Pos.CENTER_LEFT);
                } else {
                    setText(priceFormat.format(item.doubleValue()));
                    setAlignment(Pos.CENTER);
                }
            }
        });

        tableView.getColumns().addAll(symbolCol, timeCol, bidCol, askCol);
        return tableView;
    }

    public static void main(String[] args) {
        launch(args);
    }

    private static class OrthodoxCCBreachState {
        private final String breachType;
        private final long candleTime;

        public OrthodoxCCBreachState(String breachType, long candleTime) {
            this.breachType = breachType;
            this.candleTime = candleTime;
        }

        public String getBreachType() {
            return breachType;
        }

        public long getCandleTime() {
            return candleTime;
        }
    }
}
