package com.tradelogic.services;

import com.tradelogic.Logger;
import com.tradelogic.models.ExecutionFeedback;
import com.tradelogic.models.TradeCommand;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class PendingCommandsManager {
    private final Map<String, TradeCommand> pendingCommands = new ConcurrentHashMap<>();
    private final Map<String, TradeCommand> sentCommands = new ConcurrentHashMap<>();
    private static final int TIMEOUT_SECONDS = 30;

    public void addPending(TradeCommand command) {
        if (command.getCommandId() != null) {
            pendingCommands.put(command.getCommandId(), command);
            Logger.info("Added command to pending: " + command.getCommandId() + " (Action: " + command.getAction() + ", Magic: " + command.getMagicNumber() + ")");
        }
    }

    public void markAsSent(String commandId) {
        TradeCommand command = pendingCommands.remove(commandId);
        if (command != null) {
            command.markAsSent();
            sentCommands.put(commandId, command);
            Logger.info("Marked command as SENT: " + commandId);
        }
    }

    public TradeCommand getCommand(String commandId) {
        TradeCommand cmd = pendingCommands.get(commandId);
        if (cmd != null) return cmd;
        return sentCommands.get(commandId);
    }

    public boolean hasPending(String commandId) {
        return pendingCommands.containsKey(commandId);
    }

    public boolean hasSent(String commandId) {
        return sentCommands.containsKey(commandId);
    }

    public TradeCommand confirmCommand(ExecutionFeedback feedback) {
        String commandId = feedback.getCommandId();
        TradeCommand command = sentCommands.remove(commandId);

        if (command == null) {
            command = pendingCommands.remove(commandId);
        }

        if (command != null) {
            if (feedback.isSuccess()) {
                command.markAsConfirmed(feedback.getRetcode(), feedback.toJson());
                Logger.info("Command CONFIRMED: " + commandId + " (Action: " + command.getAction() + ", Magic: " + command.getMagicNumber() + ")");
            } else {
                command.markAsFailed(feedback.getRetcode(), feedback.getErrorMessage());
                Logger.warning("Command FAILED: " + commandId + " - " + feedback.getErrorMessage());
            }
        } else {
            Logger.warning("Received feedback for unknown command: " + commandId);
        }

        return command;
    }

    public List<TradeCommand> checkTimeouts() {
        List<TradeCommand> timedOut = new ArrayList<>();
        Instant now = Instant.now();

        sentCommands.values().removeIf(command -> {
            if (command.getQueuedAt() != null) {
                long elapsedSeconds = now.getEpochSecond() - command.getQueuedAt().getEpochSecond();
                if (elapsedSeconds > TIMEOUT_SECONDS) {
                    command.markAsTimeout();
                    timedOut.add(command);
                    Logger.warning("Command TIMEOUT: " + command.getCommandId() + " (Action: " + command.getAction() + ", Magic: " + command.getMagicNumber() + ")");
                    return true;
                }
            }
            return false;
        });

        pendingCommands.values().removeIf(command -> {
            if (command.getQueuedAt() != null) {
                long elapsedSeconds = now.getEpochSecond() - command.getQueuedAt().getEpochSecond();
                if (elapsedSeconds > TIMEOUT_SECONDS) {
                    command.markAsTimeout();
                    timedOut.add(command);
                    Logger.warning("Command TIMEOUT (never sent): " + command.getCommandId() + " (Action: " + command.getAction() + ", Magic: " + command.getMagicNumber() + ")");
                    return true;
                }
            }
            return false;
        });

        return timedOut;
    }

    public int getPendingCount() {
        return pendingCommands.size();
    }

    public int getSentCount() {
        return sentCommands.size();
    }

    public int getTotalAwaitingConfirmation() {
        return pendingCommands.size() + sentCommands.size();
    }

    public boolean hasCommandsAwaitingConfirmation(String magicNumber) {
        for (TradeCommand cmd : pendingCommands.values()) {
            if (magicNumber.equals(cmd.getMagicNumber())) {
                return true;
            }
        }
        for (TradeCommand cmd : sentCommands.values()) {
            if (magicNumber.equals(cmd.getMagicNumber())) {
                return true;
            }
        }
        return false;
    }

    public List<TradeCommand> getCommandsForMagic(String magicNumber) {
        List<TradeCommand> commands = new ArrayList<>();

        for (TradeCommand cmd : pendingCommands.values()) {
            if (magicNumber.equals(cmd.getMagicNumber())) {
                commands.add(cmd);
            }
        }

        for (TradeCommand cmd : sentCommands.values()) {
            if (magicNumber.equals(cmd.getMagicNumber())) {
                commands.add(cmd);
            }
        }

        return commands;
    }

    public void clear() {
        pendingCommands.clear();
        sentCommands.clear();
        Logger.info("Cleared all pending and sent commands");
    }
}
