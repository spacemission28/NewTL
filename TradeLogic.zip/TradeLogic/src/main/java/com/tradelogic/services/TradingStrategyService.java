package com.tradelogic.services;

import com.tradelogic.Logger;
import com.tradelogic.models.MarketBarData;
import com.tradelogic.models.RobotConfig;
import com.tradelogic.models.TradeCommand;
import java.util.*;

/**
 * Core trading strategy implementation that mirrors the MT5 EA's PlaceOcoOrders logic.
 *
 * For each valid signal candle (X1), this service:
 * 1. Validates candle timing and completion
 * 2. Checks leapfrog protection (has price already surpassed entry?)
 * 3. Calculates entry prices, stop losses, and take profit levels
 * 4. Generates 14 individual trade commands (7 BUY STOP + 7 SELL STOP)
 * 5. Each order has the same entry/SL but different TP levels
 *
 * The 14 orders form an OCO group - when one side fills, the opposite side is deleted.
 */
public class TradingStrategyService {

    private final LotSizeCalculator lotSizeCalculator;
    private final OcoManager ocoManager;
    private final TradeHistoryCache tradeHistoryCache;

    public TradingStrategyService(OcoManager ocoManager, TradeHistoryCache tradeHistoryCache) {
        this.lotSizeCalculator = new LotSizeCalculator();
        this.ocoManager = ocoManager;
        this.tradeHistoryCache = tradeHistoryCache;
    }

    /**
     * Analyzes a signal candle and generates trade commands if conditions are met
     *
     * @param robot Robot configuration
     * @param barData Signal candle data
     * @param currentBid Current bid price for leapfrog check
     * @param accountBalance Account balance for lot sizing
     * @param accountCurrency Account currency (e.g., "USD")
     * @param conversionRates Currency conversion rates
     * @return List of trade commands (14 if signal valid, empty if not)
     */
    public List<TradeCommand> analyzeSignalAndGenerateCommands(
            RobotConfig robot,
            MarketBarData barData,
            double currentBid,
            double accountBalance,
            String accountCurrency,
            Map<String, Double> conversionRates) {

        Logger.info("        [ENTRY] analyzeSignalAndGenerateCommands called for " + robot.getSymbol());

        List<TradeCommand> commands = new ArrayList<>();

        Logger.info("        [VALIDATION] Starting signal validation...");
        if (!validateSignalCandle(robot, barData)) {
            Logger.error("        [VALIDATION] Signal candle validation FAILED!");
            return commands;
        }
        Logger.info("        [VALIDATION] Signal candle validation PASSED");

        double barHeight = barData.getHigh() - barData.getLow();
        double minHeight = convertX1Height(
            robot.getMinX1Height(),
            robot.getX1Type(),
            robot.getSymbol()
        );

        if (barHeight < minHeight) {
            Logger.info("Signal rejected: Bar height " + String.format("%.5f", barHeight) +
                       " < minimum " + String.format("%.5f", minHeight));
            return commands;
        }

        double trigPercent = robot.getTrigPercent() / 100.0;
        double stopLossPercent = robot.getStopLossPercent() / 100.0;

        double buyEntry = barData.getHigh() + (barHeight * trigPercent);
        double buyStopLoss = barData.getLow() - (barHeight * stopLossPercent);

        double sellEntry = barData.getLow() - (barHeight * trigPercent);
        double sellStopLoss = barData.getHigh() + (barHeight * stopLossPercent);

        Logger.info("        Leapfrog Status: " + (robot.isDisableLeapfrog() ? "DISABLED (checkbox checked)" : "ENABLED (checkbox unchecked)"));
        Logger.info("        BUY Entry: " + String.format("%.5f", buyEntry) + " | SELL Entry: " + String.format("%.5f", sellEntry));

        if (!robot.isDisableLeapfrog()) {
            Logger.info("        → Applying leapfrog protection...");
            if (currentBid >= buyEntry) {
                Logger.info("        ✗ BUY orders blocked (bid " + String.format("%.5f", currentBid) + " >= entry " + String.format("%.5f", buyEntry) + ")");
            } else {
                Logger.info("        ✓ BUY orders OK (bid " + String.format("%.5f", currentBid) + " < entry " + String.format("%.5f", buyEntry) + ")");
                List<TradeCommand> buyCommands = generateOrdersForSide(
                    robot, "BUY", buyEntry, buyStopLoss, barHeight, barData,
                    accountBalance, accountCurrency, conversionRates
                );
                commands.addAll(buyCommands);
            }

            if (currentBid <= sellEntry) {
                Logger.info("        ✗ SELL orders blocked (bid " + String.format("%.5f", currentBid) + " <= entry " + String.format("%.5f", sellEntry) + ")");
            } else {
                Logger.info("        ✓ SELL orders OK (bid " + String.format("%.5f", currentBid) + " > entry " + String.format("%.5f", sellEntry) + ")");
                List<TradeCommand> sellCommands = generateOrdersForSide(
                    robot, "SELL", sellEntry, sellStopLoss, barHeight, barData,
                    accountBalance, accountCurrency, conversionRates
                );
                commands.addAll(sellCommands);
            }
        } else {
            Logger.info("        → Leapfrog disabled - generating ALL orders regardless of price");
            commands.addAll(generateOrdersForSide(
                robot, "BUY", buyEntry, buyStopLoss, barHeight, barData,
                accountBalance, accountCurrency, conversionRates
            ));
            commands.addAll(generateOrdersForSide(
                robot, "SELL", sellEntry, sellStopLoss, barHeight, barData,
                accountBalance, accountCurrency, conversionRates
            ));

            if (!commands.isEmpty()) {
                ocoManager.registerOrderGroup(
                    robot.getMagicNumber(),
                    robot.getId(),
                    true,
                    true
                );

                Logger.info(String.format("Registered OCO group with OcoManager: Magic=%s, Symbol=%s, Orders=%d",
                    robot.getMagicNumber(), robot.getSymbol(), commands.size()));
            }
        }

        return commands;
    }

    /**
     * Validates signal candle timing and completion
     */
    private boolean validateSignalCandle(RobotConfig robot, MarketBarData barData) {
        long actualDuration = barData.getCandleDuration();
        long expectedDuration = barData.getExpectedDuration();

        Logger.info("        [DURATION CHECK] Actual: " + actualDuration + "s | Expected: " + expectedDuration + "s | Valid: " + barData.isDurationValid());
        Logger.info("        [TIMES] Open: " + barData.getFormattedOpenTime() + " | Close: " + barData.getFormattedTimestamp());

        if (!barData.isDurationValid()) {
            Logger.warning("        Signal rejected: Candle duration anomaly (actual: " +
                          actualDuration + "s, expected: " +
                          expectedDuration + "s)");
            return false;
        }

        return true;
    }

    /**
     * Generates 7 trade commands for one side (BUY or SELL)
     */
    private List<TradeCommand> generateOrdersForSide(
            RobotConfig robot,
            String orderType,
            double entryPrice,
            double stopLoss,
            double barHeight,
            MarketBarData barData,
            double accountBalance,
            String accountCurrency,
            Map<String, Double> conversionRates) {

        List<TradeCommand> commands = new ArrayList<>();

        if (!lotSizeCalculator.validateTPVolumes(robot)) {
            Logger.error("        >>> VALIDATION FAILED - Cannot generate orders for " + orderType + " side");
            return commands;
        }

        double stopLossDistance = Math.abs(entryPrice - stopLoss);

        // CRITICAL: For JPY pairs, 1 pip = 0.01. For other pairs, 1 pip = 0.0001
        // The stop loss distance must be in the correct units for the symbol
        double pipSize = getSymbolPipSize(robot.getSymbol());
        double stopLossInPips = stopLossDistance / pipSize;

        Logger.info("        [SL DEBUG] Raw SL Distance: " + stopLossDistance);
        Logger.info("        [SL DEBUG] Pip Size: " + pipSize);
        Logger.info("        [SL DEBUG] SL in Pips: " + stopLossInPips);

        double[] lotSizes = lotSizeCalculator.calculateLotSizes(
            robot,
            accountBalance,
            stopLossDistance,
            robot.getSymbol(),
            accountCurrency,
            conversionRates
        );

        Logger.info("        [LOT SIZE DEBUG] Symbol: " + robot.getSymbol());
        Logger.info("        [LOT SIZE DEBUG] Account Balance: " + accountBalance);
        Logger.info("        [LOT SIZE DEBUG] Stop Loss Distance: " + stopLossDistance);
        Logger.info("        [LOT SIZE DEBUG] RPT %: " + robot.getRptPercent() + " | RPT Fixed: " + robot.getRptFixedAmount());
        Logger.info("        [LOT SIZE DEBUG] Calculated Lot Sizes: " +
            String.format("[%.2f, %.2f, %.2f, %.2f, %.2f, %.2f, %.2f]",
                lotSizes[0], lotSizes[1], lotSizes[2], lotSizes[3], lotSizes[4], lotSizes[5], lotSizes[6]));

        double[] tpPercents = {
            robot.getTp1Percent(),
            robot.getTp2Percent(),
            robot.getTp3Percent(),
            robot.getTp4Percent(),
            robot.getTp5Percent(),
            robot.getTp6Percent(),
            robot.getTp7Percent()
        };

        int[] tpVolumes = {
            robot.getTp1Volume(),
            robot.getTp2Volume(),
            robot.getTp3Volume(),
            robot.getTp4Volume(),
            robot.getTp5Volume(),
            robot.getTp6Volume(),
            robot.getTp7Volume()
        };

        for (int i = 0; i < 7; i++) {
            if (tpVolumes[i] > 0 && lotSizes[i] > 0) {
                double tpDistance = barHeight * (tpPercents[i] / 100.0);
                double takeProfit;

                if ("BUY".equals(orderType)) {
                    takeProfit = barData.getHigh() + tpDistance;
                } else {
                    takeProfit = barData.getLow() - tpDistance;
                }

                int tpLevel = i + 1;
                int tpPercentInt = (int) Math.round(tpPercents[i]);
                String comment = String.format("TP%d_%d_%s", tpLevel, tpPercentInt, robot.getMagicNumber());

                Map<String, Object> params = new HashMap<>();
                params.put("symbol", robot.getSymbol());
                params.put("order_type", orderType + "_STOP");
                params.put("entry_price", entryPrice);
                params.put("stop_loss", stopLoss);
                params.put("take_profit", takeProfit);
                params.put("volume", lotSizes[i]);
                params.put("price", entryPrice);
                params.put("comment", comment);
                params.put("tp_level", tpLevel);
                params.put("tp_percent", tpPercentInt);
                params.put("bar_height", barHeight);
                params.put("signal_candle_open", barData.getFormattedOpenTime());
                params.put("signal_candle_close", barData.getFormattedTimestamp());

                TradeCommand command = new TradeCommand(
                    robot.getId(),
                    robot.getMagicNumber(),
                    "PLACE_ORDER",
                    params
                );

                commands.add(command);
            }
        }

        return commands;
    }

    /**
     * Converts X1 height based on type (mirrors EA logic)
     */
    private double convertX1Height(double height, String x1Type, String symbol) {
        String normalized = x1Type.replace(" ", "").replace("-", "");

        switch (normalized) {
            case "NonYenPips":
                return height * 0.0001;
            case "YenPips":
                return height * 0.01;
            case "Cents":
                return height * 0.01;
            case "Points":
                return height;
            default:
                Logger.warning("Unknown X1 type: " + x1Type + ", using as-is");
                return height;
        }
    }

    /**
     * Checks if end-of-day time has been reached for a robot
     * ALWAYS uses EET timezone (Europe/Athens) to match MT5's internal time
     */
    public boolean isEndOfDayReached(RobotConfig robot) {
        if (!robot.isEndTimeEnabled()) {
            return false;
        }

        Calendar now = Calendar.getInstance(java.util.TimeZone.getTimeZone("Europe/Athens"));
        int currentHour = now.get(Calendar.HOUR_OF_DAY);
        int currentMinute = now.get(Calendar.MINUTE);

        int endHour = robot.getEndHour() != null ? robot.getEndHour() : 23;
        int endMinute = robot.getEndMinute() != null ? robot.getEndMinute() : 50;

        if (currentHour > endHour) {
            return true;
        } else if (currentHour == endHour && currentMinute >= endMinute) {
            return true;
        }

        return false;
    }

    /**
     * Generates DELETE commands for all pending orders of a magic number
     */
    public TradeCommand generateDeleteAllCommand(String magicNumber, UUID robotConfigId) {
        Map<String, Object> params = new HashMap<>();
        params.put("magic_number", magicNumber);

        TradeCommand command = new TradeCommand(
            robotConfigId,
            magicNumber,
            "DELETE_ALL_PENDING",
            params
        );

        Logger.info("Generated DELETE_ALL_PENDING command for magic " + magicNumber);
        return command;
    }

    /**
     * Generates DELETE commands for opposite side orders (OCO management)
     * Called when one side fills
     *
     * @param filledOrderType The side that filled ("BUY" or "SELL")
     * @param magicNumber Magic number of the robot
     * @param robotConfigId Robot config ID
     * @return Command to delete the opposite side's orders
     */
    public TradeCommand generateOcoDeleteCommand(
            String filledOrderType,
            String magicNumber,
            UUID robotConfigId) {

        String oppositeType = filledOrderType.equals("BUY") ? "SELL" : "BUY";

        Map<String, Object> params = new HashMap<>();
        params.put("magic_number", magicNumber);
        params.put("order_type", oppositeType + "_STOP");

        TradeCommand command = new TradeCommand(
            robotConfigId,
            magicNumber,
            "DELETE_OPPOSITE_SIDE",
            params
        );

        Logger.info("Generated OCO delete command: removing " + oppositeType +
                   " orders for magic " + magicNumber);
        return command;
    }

    /**
     * Returns the pip size for a given symbol.
     * JPY pairs: 1 pip = 0.01
     * Metals: XAU/XAG = 0.01
     * Indices: 1.0, 0.1, or 0.01 depending on instrument
     * Crypto: varies (BTC=1.0, ETH=0.01, etc)
     * Standard FX: 1 pip = 0.0001
     */
    private double getSymbolPipSize(String symbol) {
        String upper = symbol.toUpperCase();

        // JPY pairs
        if (upper.contains("JPY")) {
            return 0.01;
        }

        // Gold and Silver
        if (upper.contains("XAU") || upper.contains("GOLD")) {
            return 0.01;  // $0.01 per pip
        }
        if (upper.contains("XAG") || upper.contains("SILVER")) {
            return 0.01;  // $0.01 per pip
        }

        // Major indices
        if (upper.contains("FRA40") || upper.contains("CAC")) {
            return 1.0;  // French CAC 40
        }
        if (upper.contains("US30") || upper.contains("DOW")) {
            return 1.0;  // Dow Jones
        }
        if (upper.contains("NAS100") || upper.contains("NASDAQ")) {
            return 1.0;  // NASDAQ
        }
        if (upper.contains("SPX500") || upper.contains("SP500")) {
            return 0.1;  // S&P 500
        }
        if (upper.contains("DAX") || upper.contains("GER") || upper.contains("GER40")) {
            return 1.0;  // DAX
        }
        if (upper.contains("FTSE") || upper.contains("UK100")) {
            return 1.0;  // FTSE
        }
        if (upper.contains("JPN225") || upper.contains("NIKKEI")) {
            return 1.0;  // Nikkei
        }
        if (upper.contains("AUS200") || upper.contains("ASX")) {
            return 1.0;  // ASX 200
        }

        // Cryptocurrencies
        if (upper.contains("BTC")) {
            return 1.0;  // Bitcoin moves in dollars
        }
        if (upper.contains("ETH")) {
            return 0.01;  // Ethereum
        }
        if (upper.contains("XRP") || upper.contains("ADA") || upper.contains("DOGE")) {
            return 0.0001;  // Small cryptos
        }

        // Oil/Energy
        if (upper.contains("WTI") || upper.contains("BRENT") || upper.contains("OIL")) {
            return 0.01;  // Oil
        }

        // Standard forex pairs (EUR, GBP, AUD, NZD, CAD, CHF, etc)
        return 0.0001;
    }
}
