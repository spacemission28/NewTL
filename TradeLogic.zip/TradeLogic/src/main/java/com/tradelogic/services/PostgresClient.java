package com.tradelogic.services;

import com.google.gson.*;
import com.tradelogic.Logger;
import com.tradelogic.models.RobotConfig;

import java.sql.*;
import java.time.Instant;
import java.util.*;

public class PostgresClient implements DatabaseClient {
    private final String jdbcUrl;
    private final String username;
    private final String password;
    private final Gson gson;

    private static PostgresClient instance;

    private PostgresClient(String jdbcUrl, String username, String password) {
        this.jdbcUrl = jdbcUrl;
        this.username = username;
        this.password = password;
        this.gson = new GsonBuilder()
                .setDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
                .create();
        Logger.info("PostgresClient initialized: " + jdbcUrl);
        initializeSchema();
    }

    public static void initialize(String jdbcUrl, String username, String password) {
        instance = new PostgresClient(jdbcUrl, username, password);
    }

    public static PostgresClient getInstance() {
        if (instance == null) {
            throw new IllegalStateException("PostgresClient not initialized");
        }
        return instance;
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(jdbcUrl, username, password);
    }

    private void initializeSchema() {
        String createTablesSQL = """
            CREATE TABLE IF NOT EXISTS robot_configs (
                id SERIAL PRIMARY KEY,
                user_id UUID NOT NULL,
                robot_number INTEGER NOT NULL,
                symbol VARCHAR(20) NOT NULL,
                timeframe VARCHAR(10) NOT NULL,
                x1_type VARCHAR(20) NOT NULL,
                min_x1_height DOUBLE PRECISION NOT NULL,
                trig_percent DOUBLE PRECISION NOT NULL,
                stop_loss_percent DOUBLE PRECISION NOT NULL,
                tp1_percent DOUBLE PRECISION NOT NULL,
                tp2_percent DOUBLE PRECISION NOT NULL,
                tp3_percent DOUBLE PRECISION NOT NULL,
                tp4_percent DOUBLE PRECISION NOT NULL,
                tp5_percent DOUBLE PRECISION NOT NULL,
                tp6_percent DOUBLE PRECISION NOT NULL,
                tp7_percent DOUBLE PRECISION NOT NULL,
                tp1_volume INTEGER NOT NULL,
                tp2_volume INTEGER NOT NULL,
                tp3_volume INTEGER NOT NULL,
                tp4_volume INTEGER NOT NULL,
                tp5_volume INTEGER NOT NULL,
                tp6_volume INTEGER NOT NULL,
                tp7_volume INTEGER NOT NULL,
                rpt_percent DOUBLE PRECISION NOT NULL,
                rpt_fixed_amount DOUBLE PRECISION NOT NULL,
                close_hour INTEGER NOT NULL,
                close_minute INTEGER NOT NULL,
                daily_dd_limit DOUBLE PRECISION DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, robot_number)
            );

            CREATE TABLE IF NOT EXISTS default_values (
                id SERIAL PRIMARY KEY,
                user_id UUID NOT NULL UNIQUE,
                defaults JSONB NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            """;

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute(createTablesSQL);
            Logger.info("Database schema initialized");
        } catch (SQLException e) {
            Logger.error("Failed to initialize schema: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void upsertRobotConfig(String userId, RobotConfig config) throws SQLException {
        String sql = """
            INSERT INTO robot_configs (
                user_id, robot_number, symbol, timeframe, x1_type, min_x1_height,
                trig_percent, stop_loss_percent, tp1_percent, tp2_percent, tp3_percent,
                tp4_percent, tp5_percent, tp6_percent, tp7_percent, tp1_volume,
                tp2_volume, tp3_volume, tp4_volume, tp5_volume, tp6_volume, tp7_volume,
                rpt_percent, rpt_fixed_amount, close_hour, close_minute, daily_dd_limit
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT (user_id, robot_number) DO UPDATE SET
                symbol = EXCLUDED.symbol,
                timeframe = EXCLUDED.timeframe,
                x1_type = EXCLUDED.x1_type,
                min_x1_height = EXCLUDED.min_x1_height,
                trig_percent = EXCLUDED.trig_percent,
                stop_loss_percent = EXCLUDED.stop_loss_percent,
                tp1_percent = EXCLUDED.tp1_percent,
                tp2_percent = EXCLUDED.tp2_percent,
                tp3_percent = EXCLUDED.tp3_percent,
                tp4_percent = EXCLUDED.tp4_percent,
                tp5_percent = EXCLUDED.tp5_percent,
                tp6_percent = EXCLUDED.tp6_percent,
                tp7_percent = EXCLUDED.tp7_percent,
                tp1_volume = EXCLUDED.tp1_volume,
                tp2_volume = EXCLUDED.tp2_volume,
                tp3_volume = EXCLUDED.tp3_volume,
                tp4_volume = EXCLUDED.tp4_volume,
                tp5_volume = EXCLUDED.tp5_volume,
                tp6_volume = EXCLUDED.tp6_volume,
                tp7_volume = EXCLUDED.tp7_volume,
                rpt_percent = EXCLUDED.rpt_percent,
                rpt_fixed_amount = EXCLUDED.rpt_fixed_amount,
                close_hour = EXCLUDED.close_hour,
                close_minute = EXCLUDED.close_minute,
                daily_dd_limit = EXCLUDED.daily_dd_limit,
                updated_at = CURRENT_TIMESTAMP
            """;

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(userId));
            stmt.setInt(2, config.getRobotNumber());
            stmt.setString(3, config.getSymbol());
            stmt.setString(4, config.getTimeframe());
            stmt.setString(5, config.getX1Type());
            stmt.setDouble(6, config.getMinX1Height());
            stmt.setDouble(7, config.getTrigPercent());
            stmt.setDouble(8, config.getStopLossPercent());
            stmt.setDouble(9, config.getTp1Percent());
            stmt.setDouble(10, config.getTp2Percent());
            stmt.setDouble(11, config.getTp3Percent());
            stmt.setDouble(12, config.getTp4Percent());
            stmt.setDouble(13, config.getTp5Percent());
            stmt.setDouble(14, config.getTp6Percent());
            stmt.setDouble(15, config.getTp7Percent());
            stmt.setInt(16, config.getTp1Volume());
            stmt.setInt(17, config.getTp2Volume());
            stmt.setInt(18, config.getTp3Volume());
            stmt.setInt(19, config.getTp4Volume());
            stmt.setInt(20, config.getTp5Volume());
            stmt.setInt(21, config.getTp6Volume());
            stmt.setInt(22, config.getTp7Volume());
            stmt.setDouble(23, config.getRptPercent());
            stmt.setDouble(24, config.getRptFixedAmount());
            stmt.setInt(25, config.getCloseHour());
            stmt.setInt(26, config.getCloseMinute());
            stmt.setDouble(27, config.getDailyDdLimit());

            stmt.executeUpdate();
        }
    }

    public List<RobotConfig> loadRobotConfigs(String userId) throws SQLException {
        String sql = "SELECT * FROM robot_configs WHERE user_id = ? ORDER BY robot_number";
        List<RobotConfig> configs = new ArrayList<>();

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(userId));

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    RobotConfig config = new RobotConfig();
                    config.setRobotNumber(rs.getInt("robot_number"));
                    config.setSymbol(rs.getString("symbol"));
                    config.setTimeframe(rs.getString("timeframe"));
                    config.setX1Type(rs.getString("x1_type"));
                    config.setMinX1Height(rs.getDouble("min_x1_height"));
                    config.setTrigPercent(rs.getDouble("trig_percent"));
                    config.setStopLossPercent(rs.getDouble("stop_loss_percent"));
                    config.setTp1Percent(rs.getDouble("tp1_percent"));
                    config.setTp2Percent(rs.getDouble("tp2_percent"));
                    config.setTp3Percent(rs.getDouble("tp3_percent"));
                    config.setTp4Percent(rs.getDouble("tp4_percent"));
                    config.setTp5Percent(rs.getDouble("tp5_percent"));
                    config.setTp6Percent(rs.getDouble("tp6_percent"));
                    config.setTp7Percent(rs.getDouble("tp7_percent"));
                    config.setTp1Volume(rs.getInt("tp1_volume"));
                    config.setTp2Volume(rs.getInt("tp2_volume"));
                    config.setTp3Volume(rs.getInt("tp3_volume"));
                    config.setTp4Volume(rs.getInt("tp4_volume"));
                    config.setTp5Volume(rs.getInt("tp5_volume"));
                    config.setTp6Volume(rs.getInt("tp6_volume"));
                    config.setTp7Volume(rs.getInt("tp7_volume"));
                    config.setRptPercent(rs.getDouble("rpt_percent"));
                    config.setRptFixedAmount(rs.getDouble("rpt_fixed_amount"));
                    config.setCloseHour(rs.getInt("close_hour"));
                    config.setCloseMinute(rs.getInt("close_minute"));
                    config.setDailyDdLimit(rs.getDouble("daily_dd_limit"));
                    configs.add(config);
                }
            }
        }

        return configs;
    }

    public void saveDefaultValues(String userId, Map<String, Object> defaults) throws SQLException {
        String jsonDefaults = gson.toJson(defaults);
        String sql = """
            INSERT INTO default_values (user_id, defaults)
            VALUES (?, ?::jsonb)
            ON CONFLICT (user_id) DO UPDATE SET
                defaults = EXCLUDED.defaults,
                updated_at = CURRENT_TIMESTAMP
            """;

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(userId));
            stmt.setString(2, jsonDefaults);
            stmt.executeUpdate();
        }
    }

    public Map<String, Object> loadDefaultValues(String userId) throws SQLException {
        String sql = "SELECT defaults FROM default_values WHERE user_id = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(userId));

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String jsonDefaults = rs.getString("defaults");
                    return gson.fromJson(jsonDefaults, Map.class);
                }
            }
        }

        return null;
    }

    public void deleteRobotConfigs(String userId, List<Integer> robotNumbers) throws SQLException {
        if (robotNumbers.isEmpty()) return;

        String placeholders = String.join(",", Collections.nCopies(robotNumbers.size(), "?"));
        String sql = "DELETE FROM robot_configs WHERE user_id = ? AND robot_number IN (" + placeholders + ")";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(userId));
            for (int i = 0; i < robotNumbers.size(); i++) {
                stmt.setInt(i + 2, robotNumbers.get(i));
            }
            stmt.executeUpdate();
        }
    }
}
