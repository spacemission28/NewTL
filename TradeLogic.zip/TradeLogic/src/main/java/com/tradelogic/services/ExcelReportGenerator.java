package com.tradelogic.services;

import com.tradelogic.models.TradeHistoryEntry;
import com.tradelogic.models.TradeStatistics;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileOutputStream;
import java.text.DecimalFormat;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class ExcelReportGenerator {

    private static final DecimalFormat PRICE_FORMAT = new DecimalFormat("#,##0.00");
    private static final DecimalFormat PERCENT_FORMAT = new DecimalFormat("#,##0.00");
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter
        .ofPattern("yyyy.MM.dd HH:mm:ss")
        .withZone(ZoneId.of("Europe/Athens"));

    public static File generateReport(List<TradeHistoryEntry> trades, TradeStatistics stats,
                                     String outputPath) throws Exception {

        Workbook workbook = new XSSFWorkbook();

        createPositionsSheet(workbook, trades, stats);
        createResultsSheet(workbook, stats);

        File file = new File(outputPath);
        try (FileOutputStream outputStream = new FileOutputStream(file)) {
            workbook.write(outputStream);
        }
        workbook.close();

        return file;
    }

    private static void createPositionsSheet(Workbook workbook, List<TradeHistoryEntry> trades,
                                            TradeStatistics stats) {
        Sheet sheet = workbook.createSheet("Positions");

        CellStyle headerStyle = createHeaderStyle(workbook);
        CellStyle titleStyle = createTitleStyle(workbook);
        CellStyle dataStyle = createDataStyle(workbook);
        CellStyle numberStyle = createNumberStyle(workbook);

        int rowNum = 0;

        Row titleRow = sheet.createRow(rowNum++);
        Cell titleCell = titleRow.createCell(0);
        titleCell.setCellValue("Trade History Report");
        titleCell.setCellStyle(titleStyle);
        sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 11));

        Row nameRow = sheet.createRow(rowNum++);
        createInfoRow(nameRow, "Name:", stats.getAccountName(), dataStyle);

        Row accountRow = sheet.createRow(rowNum++);
        createInfoRow(accountRow, "Account:", stats.getAccountNumber(), dataStyle);

        Row companyRow = sheet.createRow(rowNum++);
        createInfoRow(companyRow, "Company:", stats.getCompany(), dataStyle);

        Row dateRow = sheet.createRow(rowNum++);
        createInfoRow(dateRow, "Date:", stats.getReportDate(), dataStyle);

        rowNum++;

        Row positionsLabelRow = sheet.createRow(rowNum++);
        Cell posLabel = positionsLabelRow.createCell(0);
        posLabel.setCellValue("Positions");
        posLabel.setCellStyle(titleStyle);
        sheet.addMergedRegion(new CellRangeAddress(rowNum - 1, rowNum - 1, 0, 11));

        rowNum++;

        Row headerRow = sheet.createRow(rowNum++);
        String[] headers = {"Time", "Position", "Symbol", "Type", "Volume", "Price", "S/L", "T/P",
                           "Time", "Price", "Commission", "Swap", "Profit"};
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(headerStyle);
        }

        for (TradeHistoryEntry trade : trades) {
            Row row = sheet.createRow(rowNum++);

            Cell timeCell = row.createCell(0);
            timeCell.setCellValue(formatTime(trade.getOpenTime()));
            timeCell.setCellStyle(dataStyle);

            Cell positionCell = row.createCell(1);
            positionCell.setCellValue(String.valueOf(trade.getTicket()));
            positionCell.setCellStyle(dataStyle);

            Cell symbolCell = row.createCell(2);
            symbolCell.setCellValue(trade.getSymbol());
            symbolCell.setCellStyle(dataStyle);

            Cell typeCell = row.createCell(3);
            typeCell.setCellValue(trade.getOrderType() != null ? trade.getOrderType().toLowerCase() : "");
            typeCell.setCellStyle(dataStyle);

            Cell volCell = row.createCell(4);
            volCell.setCellValue(trade.getVolume());
            volCell.setCellStyle(numberStyle);

            Cell priceCell = row.createCell(5);
            priceCell.setCellValue(trade.getEntryPrice());
            priceCell.setCellStyle(numberStyle);

            Cell slCell = row.createCell(6);
            slCell.setCellValue(0);
            slCell.setCellStyle(dataStyle);

            Cell tpCell = row.createCell(7);
            tpCell.setCellValue(0);
            tpCell.setCellStyle(dataStyle);

            Cell closeTimeCell = row.createCell(8);
            closeTimeCell.setCellValue(formatTime(trade.getCloseTime()));
            closeTimeCell.setCellStyle(dataStyle);

            Cell exitPriceCell = row.createCell(9);
            exitPriceCell.setCellValue(trade.getExitPrice());
            exitPriceCell.setCellStyle(numberStyle);

            Cell commCell = row.createCell(10);
            commCell.setCellValue(trade.getCommission());
            commCell.setCellStyle(numberStyle);

            Cell swapCell = row.createCell(11);
            swapCell.setCellValue(trade.getSwap());
            swapCell.setCellStyle(numberStyle);

            Cell profitCell = row.createCell(12);
            profitCell.setCellValue(trade.getProfit());
            profitCell.setCellStyle(numberStyle);
        }

        Row summaryRow = sheet.createRow(rowNum++);
        for (int i = 0; i < 10; i++) {
            Cell cell = summaryRow.createCell(i);
            cell.setCellStyle(dataStyle);
        }

        Cell summaryCommCell = summaryRow.createCell(10);
        double totalComm = trades.stream().mapToDouble(TradeHistoryEntry::getCommission).sum();
        summaryCommCell.setCellValue(totalComm);
        summaryCommCell.setCellStyle(numberStyle);

        Cell summarySwapCell = summaryRow.createCell(11);
        double totalSwap = trades.stream().mapToDouble(TradeHistoryEntry::getSwap).sum();
        summarySwapCell.setCellValue(totalSwap);
        summarySwapCell.setCellStyle(numberStyle);

        Cell summaryProfitCell = summaryRow.createCell(12);
        summaryProfitCell.setCellValue(stats.getTotalNetProfit());
        summaryProfitCell.setCellStyle(numberStyle);

        rowNum += 2;

        Row balanceRow = sheet.createRow(rowNum++);
        createInfoRow(balanceRow, "Balance:", PRICE_FORMAT.format(stats.getBalance()), dataStyle);

        for (int i = 0; i < headers.length; i++) {
            sheet.autoSizeColumn(i);
        }
    }

    private static void createResultsSheet(Workbook workbook, TradeStatistics stats) {
        Sheet sheet = workbook.createSheet("Results");

        CellStyle labelStyle = createDataStyle(workbook);
        CellStyle valueStyle = createDataStyle(workbook);
        CellStyle titleStyle = createTitleStyle(workbook);

        int rowNum = 0;

        Row titleRow = sheet.createRow(rowNum++);
        Cell titleCell = titleRow.createCell(1);
        titleCell.setCellValue("Results");
        titleCell.setCellStyle(titleStyle);

        rowNum++;

        addStatRow(sheet, rowNum++, "Total Net Profit:", formatNumber(stats.getTotalNetProfit()),
                  "Gross Profit:", formatNumber(stats.getGrossProfit()),
                  "Gross Loss:", formatNumber(stats.getGrossLoss()), labelStyle, valueStyle);

        addStatRow(sheet, rowNum++, "Profit Factor:", formatNumber(stats.getProfitFactor()),
                  "Expected Payoff:", formatNumber(stats.getExpectedPayoff()), "", "", labelStyle, valueStyle);

        addStatRow(sheet, rowNum++, "Recovery Factor:", formatNumber(stats.getRecoveryFactor()),
                  "Sharpe Ratio:", formatNumber(stats.getSharpeRatio()), "", "", labelStyle, valueStyle);

        addStatRow(sheet, rowNum++, "Balance Drawdown:", "", "", "", "", "", labelStyle, valueStyle);

        addStatRow(sheet, rowNum++, "Balance Drawdown Absolute:", formatNumber(stats.getBalanceDrawdownAbsolute()),
                  "Balance Drawdown Max:", formatNumber(stats.getBalanceDrawdownMax()) +
                  " (" + formatPercent(stats.getBalanceDrawdownMaxPercent()) + "%)",
                  "Balance Drawdown Relative:", formatPercent(stats.getBalanceDrawdownRelativePercent()) +
                  "% (" + formatNumber(stats.getBalanceDrawdownRelative()) + ")", labelStyle, valueStyle);

        addStatRow(sheet, rowNum++, "Total Trades:", String.valueOf(stats.getTotalTrades()),
                  "Short Trades (won %):", stats.getShortTrades() + " (" + formatPercent(stats.getShortTradesWonPercent()) + "%)",
                  "Long Trades (won %):", stats.getLongTrades() + " (" + formatPercent(stats.getLongTradesWonPercent()) + "%)",
                  labelStyle, valueStyle);

        addStatRow(sheet, rowNum++, "", "",
                  "Profit Trades (% of total):", stats.getProfitTrades() + " (" + formatPercent(stats.getProfitTradesPercent()) + "%)",
                  "Loss Trades (% of total):", stats.getLossTrades() + " (" + formatPercent(stats.getLossTradesPercent()) + "%)",
                  labelStyle, valueStyle);

        addStatRow(sheet, rowNum++, "", "",
                  "Largest profit trade:", formatNumber(stats.getLargestProfitTrade()),
                  "Largest loss trade:", formatNumber(stats.getLargestLossTrade()), labelStyle, valueStyle);

        addStatRow(sheet, rowNum++, "", "",
                  "Average profit trade:", formatNumber(stats.getAverageProfitTrade()),
                  "Average loss trade:", formatNumber(stats.getAverageLossTrade()), labelStyle, valueStyle);

        addStatRow(sheet, rowNum++, "", "",
                  "Maximum consecutive wins ($):", stats.getMaxConsecutiveWins() +
                  " (" + formatNumber(stats.getMaxConsecutiveWinsProfit()) + ")",
                  "Maximum consecutive losses ($):", stats.getMaxConsecutiveLosses() +
                  " (" + formatNumber(stats.getMaxConsecutiveLossesLoss()) + ")", labelStyle, valueStyle);

        addStatRow(sheet, rowNum++, "", "",
                  "Maximal consecutive profit (count):", formatNumber(stats.getMaxConsecutiveProfit()) +
                  " (" + stats.getMaxConsecutiveProfitCount() + ")",
                  "Maximal consecutive loss (count):", formatNumber(stats.getMaxConsecutiveLoss()) +
                  " (" + stats.getMaxConsecutiveLossCount() + ")", labelStyle, valueStyle);

        addStatRow(sheet, rowNum++, "", "",
                  "Average consecutive wins:", String.valueOf(stats.getAverageConsecutiveWins()),
                  "Average consecutive losses:", String.valueOf(stats.getAverageConsecutiveLosses()),
                  labelStyle, valueStyle);

        for (int i = 0; i < 7; i++) {
            sheet.autoSizeColumn(i);
        }
    }

    private static void addStatRow(Sheet sheet, int rowNum, String label1, String value1,
                                  String label2, String value2, String label3, String value3,
                                  CellStyle labelStyle, CellStyle valueStyle) {
        Row row = sheet.createRow(rowNum);

        if (label1 != null && !label1.isEmpty()) {
            Cell cell1 = row.createCell(1);
            cell1.setCellValue(label1);
            cell1.setCellStyle(labelStyle);
        }

        if (value1 != null && !value1.isEmpty()) {
            Cell cell2 = row.createCell(2);
            cell2.setCellValue(value1);
            cell2.setCellStyle(valueStyle);
        }

        if (label2 != null && !label2.isEmpty()) {
            Cell cell3 = row.createCell(3);
            cell3.setCellValue(label2);
            cell3.setCellStyle(labelStyle);
        }

        if (value2 != null && !value2.isEmpty()) {
            Cell cell4 = row.createCell(4);
            cell4.setCellValue(value2);
            cell4.setCellStyle(valueStyle);
        }

        if (label3 != null && !label3.isEmpty()) {
            Cell cell5 = row.createCell(5);
            cell5.setCellValue(label3);
            cell5.setCellStyle(labelStyle);
        }

        if (value3 != null && !value3.isEmpty()) {
            Cell cell6 = row.createCell(6);
            cell6.setCellValue(value3);
            cell6.setCellStyle(valueStyle);
        }
    }

    private static void createInfoRow(Row row, String label, String value, CellStyle style) {
        Cell labelCell = row.createCell(0);
        labelCell.setCellValue(label);
        labelCell.setCellStyle(style);

        Cell valueCell = row.createCell(1);
        valueCell.setCellValue(value);
        valueCell.setCellStyle(style);
    }

    private static CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        style.setFont(font);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    private static CellStyle createTitleStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 14);
        style.setFont(font);
        style.setAlignment(HorizontalAlignment.CENTER);
        return style;
    }

    private static CellStyle createDataStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    private static CellStyle createNumberStyle(Workbook workbook) {
        CellStyle style = createDataStyle(workbook);
        DataFormat format = workbook.createDataFormat();
        style.setDataFormat(format.getFormat("#,##0.00"));
        return style;
    }

    private static String formatTime(long timestamp) {
        if (timestamp == 0) return "";
        return TIME_FORMAT.format(Instant.ofEpochSecond(timestamp));
    }

    private static String formatNumber(double value) {
        return PRICE_FORMAT.format(value);
    }

    private static String formatPercent(double value) {
        return PERCENT_FORMAT.format(value);
    }
}
