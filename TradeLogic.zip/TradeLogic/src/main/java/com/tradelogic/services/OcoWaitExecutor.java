package com.tradelogic.services;

import com.tradelogic.Logger;
import com.tradelogic.models.TradeCommand;

import java.util.*;
import java.util.concurrent.*;

/**
 * OCO Wait Executor - Handles the 3-second countdown when "OCO Wait" checkbox is enabled.
 *
 * PURPOSE:
 * When a fill occurs and "OCO Wait" is enabled, this gives time for any "in-flight"
 * orders to finish placing before deletion. This prevents race conditions where orders
 * are still being placed while deletion commands are sent.
 *
 * BEHAVIOR:
 * 1. Triggered by OcoManager when fill detected AND "OCO Wait" enabled
 * 2. Counts opposite side orders at T+1s, T+2s, T+3s
 * 3. After 3 seconds, deletes ALL opposite orders found (regardless of count)
 * 4. This is separate from OcoImbalanceDetector (which is the final 5-second backstop)
 */
public class OcoWaitExecutor {
    private static OcoWaitExecutor instance;

    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(2);
    private final Map<String, ScheduledFuture<?>> activeCountdowns = new ConcurrentHashMap<>();

    private TradeCommandQueue commandQueue;
    private TradeHistoryCache tradeHistoryCache;

    private OcoWaitExecutor() {}

    public static synchronized OcoWaitExecutor getInstance() {
        if (instance == null) {
            instance = new OcoWaitExecutor();
        }
        return instance;
    }

    public void setCommandQueue(TradeCommandQueue queue) {
        this.commandQueue = queue;
    }

    public void setTradeHistoryCache(TradeHistoryCache cache) {
        this.tradeHistoryCache = cache;
    }

    /**
     * Starts the 3-second countdown with checks at T+1s, T+2s, T+3s
     *
     * @param magicNumber Magic number of the OCO group
     * @param filledSide Side that filled ("BUY" or "SELL")
     * @param robotConfigId Robot UUID for command creation
     */
    public void startCountdown(String magicNumber, String filledSide, UUID robotConfigId) {
        Logger.info("★★★ OCO WAIT: Starting 3-second countdown for magic " + magicNumber + " (filled: " + filledSide + ")");

        String oppositeSide = filledSide.equals("BUY") ? "SELL" : "BUY";

        scheduler.schedule(() -> checkAndCount(magicNumber, oppositeSide, "T+1s"), 1, TimeUnit.SECONDS);
        scheduler.schedule(() -> checkAndCount(magicNumber, oppositeSide, "T+2s"), 2, TimeUnit.SECONDS);

        ScheduledFuture<?> finalCheck = scheduler.schedule(
            () -> finalCheckAndDelete(magicNumber, oppositeSide, robotConfigId, "T+3s"),
            3,
            TimeUnit.SECONDS
        );

        activeCountdowns.put(magicNumber, finalCheck);
    }

    /**
     * Intermediate check - just counts and logs
     */
    private void checkAndCount(String magicNumber, String oppositeSide, String stage) {
        try {
            int count = countOppositeOrders(magicNumber, oppositeSide);
            Logger.info(String.format("OCO WAIT [%s]: Magic %s - %s orders found: %d",
                stage, magicNumber, oppositeSide, count));
        } catch (Exception e) {
            Logger.error("OCO WAIT [" + stage + "]: Error counting orders: " + e.getMessage());
        }
    }

    /**
     * Final check at T+3s - counts and executes deletion
     */
    private void finalCheckAndDelete(String magicNumber, String oppositeSide, UUID robotConfigId, String stage) {
        try {
            int count = countOppositeOrders(magicNumber, oppositeSide);
            Logger.info(String.format("★★★ OCO WAIT [%s FINAL]: Magic %s - %s orders found: %d",
                stage, magicNumber, oppositeSide, count));

            if (count > 0) {
                Logger.info("★★★ OCO WAIT: Deleting " + count + " " + oppositeSide + " orders for magic " + magicNumber);
                deleteOppositeOrders(magicNumber, oppositeSide, robotConfigId);
            } else {
                Logger.info("OCO WAIT: No " + oppositeSide + " orders to delete for magic " + magicNumber);
            }

        } catch (Exception e) {
            Logger.error("OCO WAIT [" + stage + "]: Error in final check: " + e.getMessage());
            e.printStackTrace();
        } finally {
            activeCountdowns.remove(magicNumber);
        }
    }

    /**
     * Counts how many opposite side pending orders exist
     * NOTE: Uses reflection to maintain compatibility with different TradeHistoryCache versions
     */
    private int countOppositeOrders(String magicNumber, String oppositeSide) {
        if (tradeHistoryCache == null) {
            Logger.warning("OCO WAIT: TradeHistoryCache not set, assuming 0 orders");
            return 0;
        }

        try {
            java.lang.reflect.Method method = tradeHistoryCache.getClass().getMethod("getAllEntries");
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> allEntries = (List<Map<String, Object>>) method.invoke(tradeHistoryCache);

            int count = 0;
            for (Map<String, Object> entry : allEntries) {
                String magic = String.valueOf(entry.get("magic_number"));
                String state = String.valueOf(entry.get("state"));
                String orderType = (String) entry.get("order_type");

                if (magicNumber.equals(magic) &&
                    state != null && state.contains("PLACED") &&
                    orderType != null && orderType.contains(oppositeSide)) {
                    count++;
                }
            }

            return count;
        } catch (Exception e) {
            Logger.error("OCO WAIT: Error counting orders (TradeHistoryCache method unavailable): " + e.getMessage());
            return 0;
        }
    }

    /**
     * Sends delete command for opposite side orders
     */
    private void deleteOppositeOrders(String magicNumber, String oppositeSide, UUID robotConfigId) {
        if (commandQueue == null) {
            Logger.error("OCO WAIT: CommandQueue not set, cannot delete orders");
            return;
        }

        String orderType = oppositeSide + "_STOP";

        Map<String, Object> params = new HashMap<>();
        params.put("magic_number", magicNumber);
        params.put("order_type", orderType);

        TradeCommand deleteCommand = new TradeCommand(
            robotConfigId,
            magicNumber,
            "DELETE_OPPOSITE_SIDE",
            params
        );

        commandQueue.addFirst(deleteCommand);
        Logger.info("OCO WAIT: Queued DELETE command for " + orderType + " orders (magic: " + magicNumber + ")");
    }

    /**
     * Cancels a countdown if needed (e.g., manual intervention)
     */
    public void cancelCountdown(String magicNumber) {
        ScheduledFuture<?> future = activeCountdowns.remove(magicNumber);
        if (future != null) {
            future.cancel(false);
            Logger.info("OCO WAIT: Cancelled countdown for magic " + magicNumber);
        }
    }

    /**
     * Checks if a countdown is active for a magic number
     */
    public boolean hasActiveCountdown(String magicNumber) {
        return activeCountdowns.containsKey(magicNumber);
    }

    /**
     * Shuts down the scheduler
     */
    public void shutdown() {
        scheduler.shutdownNow();
        activeCountdowns.clear();
        Logger.info("OCO WAIT: Executor shutdown complete");
    }

    /**
     * Gets count of active countdowns
     */
    public int getActiveCountdownCount() {
        return activeCountdowns.size();
    }
}
