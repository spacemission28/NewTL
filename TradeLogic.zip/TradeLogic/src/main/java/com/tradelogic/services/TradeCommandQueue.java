package com.tradelogic.services;

import com.tradelogic.models.TradeCommand;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

public class TradeCommandQueue {
    private final ConcurrentLinkedQueue<TradeCommand> queue = new ConcurrentLinkedQueue<>();

    public void add(TradeCommand command) {
        queue.offer(command);
    }

    public TradeCommand poll() {
        return queue.poll();
    }

    public List<TradeCommand> pollAll() {
        List<TradeCommand> commands = new ArrayList<>();
        TradeCommand cmd;
        while ((cmd = queue.poll()) != null) {
            commands.add(cmd);
        }
        return commands;
    }

    public int size() {
        return queue.size();
    }

    public boolean isEmpty() {
        return queue.isEmpty();
    }
}
