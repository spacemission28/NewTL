package com.tradelogic.services;

import com.tradelogic.Logger;
import com.tradelogic.models.ExecutionFeedback;
import com.tradelogic.models.TradeCommand;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * SmartTrailingStopMonitor - Tracks TP1 hits and triggers breakeven stop loss moves
 *
 * When Smart TS is enabled for a robot and ANY TP1 order is filled:
 * 1. Detect TP1 fill via execution feedback (comment contains "TP1_")
 * 2. Query MT5 for all open positions with same magic number
 * 3. Generate MODIFY_POSITION commands to move SL to entry price for ALL positions
 * 4. Mark magic number as "breakeven triggered" to avoid duplicate moves
 */
public class SmartTrailingStopMonitor {

    private static SmartTrailingStopMonitor instance;

    // Tracks which magic numbers have already triggered breakeven
    private final ConcurrentHashMap<String, Boolean> breakevenTriggered = new ConcurrentHashMap<>();

    // Tracks which robots have Smart TS enabled
    private final ConcurrentHashMap<String, Boolean> smartTSEnabled = new ConcurrentHashMap<>();

    // Stores entry prices for each magic number (needed to set SL to breakeven)
    private final ConcurrentHashMap<String, Double> entryPrices = new ConcurrentHashMap<>();

    private SmartTrailingStopMonitor() {
    }

    public static synchronized SmartTrailingStopMonitor getInstance() {
        if (instance == null) {
            instance = new SmartTrailingStopMonitor();
        }
        return instance;
    }

    /**
     * Register a robot's Smart TS setting
     * @param magicNumber Robot's magic number
     * @param enabled Whether Smart TS is enabled for this robot
     */
    public void registerSmartTS(String magicNumber, boolean enabled) {
        smartTSEnabled.put(magicNumber, enabled);
        if (!enabled) {
            // If disabled, clear any existing breakeven trigger
            breakevenTriggered.remove(magicNumber);
            entryPrices.remove(magicNumber);
        }
        Logger.info(String.format("Smart TS %s for Magic %s",
            enabled ? "ENABLED" : "DISABLED", magicNumber));
    }

    /**
     * Register entry price for a magic number (called when orders are placed)
     * @param magicNumber Robot's magic number
     * @param entryPrice The entry price of the pending orders
     */
    public void registerEntryPrice(String magicNumber, double entryPrice) {
        entryPrices.put(magicNumber, entryPrice);
        Logger.info(String.format("Smart TS: Registered entry price %.5f for Magic %s",
            entryPrice, magicNumber));
    }

    /**
     * Check if execution feedback indicates a TP1 fill and trigger breakeven if needed
     * @param feedback Execution feedback from MT5
     * @return TradeCommand to move SL to breakeven, or null if no action needed
     */
    public TradeCommand checkAndTriggerBreakeven(ExecutionFeedback feedback) {
        if (feedback == null || !feedback.isSuccess()) {
            return null;
        }

        // Get magic number from feedback
        String magicNumber = feedback.getMagicNumber();
        if (magicNumber == null || magicNumber.isEmpty()) {
            return null;
        }

        // Check if Smart TS is enabled for this magic number
        Boolean smartTSEnabledForMagic = smartTSEnabled.get(magicNumber);
        if (smartTSEnabledForMagic == null || !smartTSEnabledForMagic) {
            return null;
        }

        // Check if breakeven already triggered for this magic number
        if (breakevenTriggered.getOrDefault(magicNumber, false)) {
            return null;
        }

        // Check if this is a TP1 order fill by checking the comment or order_type
        // Primary check: comment (as set by TradingStrategyService)
        String comment = (String) feedback.getDetail("comment");
        String orderType = (String) feedback.getDetail("order_type");
        
        boolean isTp1 = (comment != null && comment.startsWith("TP1_")) || 
                        (orderType != null && orderType.startsWith("TP1_"));
                        
        if (!isTp1) {
            // Debug logging to help identify why it might be ignored
            if (smartTSEnabledForMagic && !breakevenTriggered.getOrDefault(magicNumber, false)) {
                // Only log if it's a potential candidate (enabled & not yet triggered) but missed the TP1 check
                // This avoids spamming logs for every non-TP1 fill
                // Logger.info("Smart TS: Ignored fill for Magic " + magicNumber + " - Not a TP1 fill (Comment: " + comment + ", Type: " + orderType + ")");
            }
            return null;
        }

        // Get entry price for this magic number
        Double entryPrice = entryPrices.get(magicNumber);
        if (entryPrice == null) {
            Logger.warning(String.format("Smart TS: No entry price registered for Magic %s, cannot move to breakeven",
                magicNumber));
            return null;
        }

        // Mark breakeven as triggered for this magic number
        breakevenTriggered.put(magicNumber, true);

        Logger.info(String.format("★★★ SMART TS TRIGGERED: TP1 hit for Magic %s - Moving ALL positions to breakeven (%.5f) ★★★",
            magicNumber, entryPrice));

        // Generate command to move all positions to breakeven
        return generateMoveToBreakevenCommand(magicNumber, entryPrice);
    }


    /**
     * Generate command to move all positions for a magic number to breakeven
     */
    private TradeCommand generateMoveToBreakevenCommand(String magicNumber, double breakevenPrice) {
        Map<String, Object> params = new HashMap<>();
        params.put("magic_number", magicNumber);
        params.put("new_sl", breakevenPrice);
        params.put("reason", "Smart_TS_Breakeven");

        return new TradeCommand(
            UUID.randomUUID(), // Robot config ID (not critical for this operation)
            magicNumber,
            "MOVE_ALL_SL_TO_BREAKEVEN",
            params
        );
    }

    /**
     * Reset breakeven trigger for a magic number (e.g., when all positions are closed)
     * @param magicNumber Robot's magic number
     */
    public void resetBreakevenTrigger(String magicNumber) {
        breakevenTriggered.remove(magicNumber);
        entryPrices.remove(magicNumber);
        Logger.info(String.format("Smart TS: Reset breakeven trigger for Magic %s", magicNumber));
    }

    /**
     * Check if breakeven has been triggered for a magic number
     */
    public boolean isBreakevenTriggered(String magicNumber) {
        return breakevenTriggered.getOrDefault(magicNumber, false);
    }

    /**
     * Clear all tracking data (for testing or reset)
     */
    public void clear() {
        breakevenTriggered.clear();
        smartTSEnabled.clear();
        entryPrices.clear();
        Logger.info("Smart TS Monitor cleared");
    }
}
