package com.tradelogic.ui;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.prefs.Preferences;

public class DatabaseConfigDialog {

    private static final String PREF_DB_TYPE = "db_type";
    private static final String PREF_POSTGRES_URL = "postgres_url";
    private static final String PREF_POSTGRES_USER = "postgres_user";
    private static final String PREF_POSTGRES_PASSWORD = "postgres_password";
    private static final String PREF_SUPABASE_URL = "supabase_url";
    private static final String PREF_SUPABASE_KEY = "supabase_key";
    private static final String PREF_BOLT_URL = "bolt_url";

    private final Preferences prefs;

    public DatabaseConfigDialog() {
        this.prefs = Preferences.userNodeForPackage(DatabaseConfigDialog.class);
    }

    public Optional<DatabaseConfig> showAndWait() {
        Dialog<DatabaseConfig> dialog = new Dialog<>();
        dialog.setTitle("Database Configuration");
        dialog.setHeaderText("Configure your database connection");

        ButtonType connectButtonType = new ButtonType("Connect", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(connectButtonType, ButtonType.CANCEL);

        VBox mainContainer = new VBox(15);
        mainContainer.setPadding(new Insets(20));

        // Database type selection
        Label typeLabel = new Label("Database Type:");
        typeLabel.setStyle("-fx-font-weight: bold;");

        ToggleGroup dbTypeGroup = new ToggleGroup();
        RadioButton postgresRadio = new RadioButton("PostgreSQL (Local/Remote Server)");
        RadioButton supabaseRadio = new RadioButton("Supabase (Cloud)");
        RadioButton boltRadio = new RadioButton("Bolt Database (Embedded)");

        postgresRadio.setToggleGroup(dbTypeGroup);
        supabaseRadio.setToggleGroup(dbTypeGroup);
        boltRadio.setToggleGroup(dbTypeGroup);

        // Load saved preference
        String savedType = prefs.get(PREF_DB_TYPE, "postgres");
        switch (savedType) {
            case "supabase" -> supabaseRadio.setSelected(true);
            case "bolt" -> boltRadio.setSelected(true);
            default -> postgresRadio.setSelected(true);
        }

        VBox radioBox = new VBox(10, postgresRadio, supabaseRadio, boltRadio);
        radioBox.setPadding(new Insets(10, 0, 10, 20));

        // PostgreSQL configuration
        GridPane postgresGrid = createPostgresConfigGrid();
        postgresGrid.setVisible(postgresRadio.isSelected());
        postgresGrid.setManaged(postgresRadio.isSelected());

        // Supabase configuration
        GridPane supabaseGrid = createSupabaseConfigGrid();
        supabaseGrid.setVisible(supabaseRadio.isSelected());
        supabaseGrid.setManaged(supabaseRadio.isSelected());

        // Bolt configuration
        GridPane boltGrid = createBoltConfigGrid();
        boltGrid.setVisible(boltRadio.isSelected());
        boltGrid.setManaged(boltRadio.isSelected());

        // Toggle visibility based on selection
        dbTypeGroup.selectedToggleProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal == postgresRadio) {
                postgresGrid.setVisible(true);
                postgresGrid.setManaged(true);
                supabaseGrid.setVisible(false);
                supabaseGrid.setManaged(false);
                boltGrid.setVisible(false);
                boltGrid.setManaged(false);
            } else if (newVal == supabaseRadio) {
                postgresGrid.setVisible(false);
                postgresGrid.setManaged(false);
                supabaseGrid.setVisible(true);
                supabaseGrid.setManaged(true);
                boltGrid.setVisible(false);
                boltGrid.setManaged(false);
            } else if (newVal == boltRadio) {
                postgresGrid.setVisible(false);
                postgresGrid.setManaged(false);
                supabaseGrid.setVisible(false);
                supabaseGrid.setManaged(false);
                boltGrid.setVisible(true);
                boltGrid.setManaged(true);
            }
            dialog.getDialogPane().getScene().getWindow().sizeToScene();
        });

        mainContainer.getChildren().addAll(
            typeLabel,
            radioBox,
            new Separator(),
            postgresGrid,
            supabaseGrid,
            boltGrid
        );

        dialog.getDialogPane().setContent(mainContainer);

        // Convert result
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == connectButtonType) {
                DatabaseConfig config = new DatabaseConfig();

                if (postgresRadio.isSelected()) {
                    config.type = "postgres";
                    config.postgresUrl = ((TextField) postgresGrid.lookup("#postgresUrl")).getText();
                    config.postgresUser = ((TextField) postgresGrid.lookup("#postgresUser")).getText();
                    config.postgresPassword = ((PasswordField) postgresGrid.lookup("#postgresPassword")).getText();

                    // Save preferences
                    prefs.put(PREF_DB_TYPE, "postgres");
                    prefs.put(PREF_POSTGRES_URL, config.postgresUrl);
                    prefs.put(PREF_POSTGRES_USER, config.postgresUser);
                    prefs.put(PREF_POSTGRES_PASSWORD, config.postgresPassword);

                } else if (supabaseRadio.isSelected()) {
                    config.type = "supabase";
                    config.supabaseUrl = ((TextField) supabaseGrid.lookup("#supabaseUrl")).getText();
                    config.supabaseKey = ((TextField) supabaseGrid.lookup("#supabaseKey")).getText();

                    // Save preferences
                    prefs.put(PREF_DB_TYPE, "supabase");
                    prefs.put(PREF_SUPABASE_URL, config.supabaseUrl);
                    prefs.put(PREF_SUPABASE_KEY, config.supabaseKey);

                } else if (boltRadio.isSelected()) {
                    config.type = "bolt";
                    config.boltUrl = ((TextField) boltGrid.lookup("#boltUrl")).getText();

                    // Save preferences
                    prefs.put(PREF_DB_TYPE, "bolt");
                    prefs.put(PREF_BOLT_URL, config.boltUrl);
                }

                return config;
            }
            return null;
        });

        // Make dialog resizable
        Stage stage = (Stage) dialog.getDialogPane().getScene().getWindow();
        stage.setResizable(false);

        return dialog.showAndWait();
    }

    private GridPane createPostgresConfigGrid() {
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10));

        Label titleLabel = new Label("PostgreSQL Connection Settings");
        titleLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 12px;");
        GridPane.setColumnSpan(titleLabel, 2);

        Label urlLabel = new Label("JDBC URL:");
        TextField urlField = new TextField(prefs.get(PREF_POSTGRES_URL, "jdbc:postgresql://localhost:5432/tradelogic"));
        urlField.setId("postgresUrl");
        urlField.setPrefWidth(350);

        Label userLabel = new Label("Username:");
        TextField userField = new TextField(prefs.get(PREF_POSTGRES_USER, "postgres"));
        userField.setId("postgresUser");

        Label passwordLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();
        passwordField.setText(prefs.get(PREF_POSTGRES_PASSWORD, "postgres"));
        passwordField.setId("postgresPassword");

        Label infoLabel = new Label("Tables will be created automatically on first connection.");
        infoLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: gray;");
        GridPane.setColumnSpan(infoLabel, 2);

        grid.add(titleLabel, 0, 0);
        grid.add(urlLabel, 0, 1);
        grid.add(urlField, 1, 1);
        grid.add(userLabel, 0, 2);
        grid.add(userField, 1, 2);
        grid.add(passwordLabel, 0, 3);
        grid.add(passwordField, 1, 3);
        grid.add(infoLabel, 0, 4);

        return grid;
    }

    private GridPane createSupabaseConfigGrid() {
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10));

        Label titleLabel = new Label("Supabase Connection Settings");
        titleLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 12px;");
        GridPane.setColumnSpan(titleLabel, 2);

        Label urlLabel = new Label("Project URL:");
        TextField urlField = new TextField(prefs.get(PREF_SUPABASE_URL, "https://your-project.supabase.co"));
        urlField.setId("supabaseUrl");
        urlField.setPrefWidth(350);

        Label keyLabel = new Label("Anon Key:");
        TextField keyField = new TextField(prefs.get(PREF_SUPABASE_KEY, ""));
        keyField.setId("supabaseKey");

        Label infoLabel = new Label("Get these from your Supabase project settings > API");
        infoLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: gray;");
        GridPane.setColumnSpan(infoLabel, 2);

        Hyperlink setupLink = new Hyperlink("Open Supabase Dashboard");
        setupLink.setStyle("-fx-font-size: 10px;");
        setupLink.setOnAction(e -> {
            try {
                java.awt.Desktop.getDesktop().browse(new java.net.URI("https://app.supabase.com"));
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        GridPane.setColumnSpan(setupLink, 2);

        grid.add(titleLabel, 0, 0);
        grid.add(urlLabel, 0, 1);
        grid.add(urlField, 1, 1);
        grid.add(keyLabel, 0, 2);
        grid.add(keyField, 1, 2);
        grid.add(infoLabel, 0, 3);
        grid.add(setupLink, 0, 4);

        return grid;
    }

    private GridPane createBoltConfigGrid() {
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10));

        Label titleLabel = new Label("Bolt Database Settings");
        titleLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 12px;");
        GridPane.setColumnSpan(titleLabel, 2);

        Label urlLabel = new Label("Database Path:");
        TextField urlField = new TextField(prefs.get(PREF_BOLT_URL, "./data/tradelogic.db"));
        urlField.setId("boltUrl");
        urlField.setPrefWidth(350);

        Label infoLabel = new Label("Embedded SQLite database. File will be created automatically.");
        infoLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: gray;");
        GridPane.setColumnSpan(infoLabel, 2);

        grid.add(titleLabel, 0, 0);
        grid.add(urlLabel, 0, 1);
        grid.add(urlField, 1, 1);
        grid.add(infoLabel, 0, 2);

        return grid;
    }

    public static class DatabaseConfig {
        public String type;

        // PostgreSQL
        public String postgresUrl;
        public String postgresUser;
        public String postgresPassword;

        // Supabase
        public String supabaseUrl;
        public String supabaseKey;

        // Bolt
        public String boltUrl;
    }
}
