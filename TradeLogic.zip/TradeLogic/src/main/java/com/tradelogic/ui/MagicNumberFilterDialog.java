package com.tradelogic.ui;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class MagicNumberFilterDialog extends Dialog<List<Long>> {

    private CheckBox allMagicNumbersCheckBox;
    private VBox magicNumbersBox;
    private List<CheckBox> magicNumberCheckBoxes;

    public MagicNumberFilterDialog(Set<Long> availableMagicNumbers) {
        setTitle("Select Magic Numbers");
        setHeaderText("Choose which magic numbers to include in the report:");

        ButtonType generateButtonType = new ButtonType("Generate Report", ButtonBar.ButtonData.OK_DONE);
        getDialogPane().getButtonTypes().addAll(generateButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        allMagicNumbersCheckBox = new CheckBox("All Magic Numbers");
        allMagicNumbersCheckBox.setSelected(true);
        allMagicNumbersCheckBox.setOnAction(e -> updateMagicNumberCheckBoxes());

        magicNumbersBox = new VBox(5);
        magicNumbersBox.setPadding(new Insets(10, 0, 0, 20));

        magicNumberCheckBoxes = new ArrayList<>();

        List<Long> sortedMagicNumbers = new ArrayList<>(availableMagicNumbers);
        sortedMagicNumbers.sort(Long::compareTo);

        for (Long magicNumber : sortedMagicNumbers) {
            CheckBox checkBox = new CheckBox("Magic Number: " + magicNumber);
            checkBox.setDisable(true);
            magicNumberCheckBoxes.add(checkBox);
            magicNumbersBox.getChildren().add(checkBox);
        }

        grid.add(allMagicNumbersCheckBox, 0, 0);
        grid.add(magicNumbersBox, 0, 1);

        getDialogPane().setContent(grid);

        setResultConverter(dialogButton -> {
            if (dialogButton == generateButtonType) {
                if (allMagicNumbersCheckBox.isSelected()) {
                    return new ArrayList<>(availableMagicNumbers);
                } else {
                    List<Long> selectedMagicNumbers = new ArrayList<>();
                    for (int i = 0; i < magicNumberCheckBoxes.size(); i++) {
                        if (magicNumberCheckBoxes.get(i).isSelected()) {
                            selectedMagicNumbers.add(sortedMagicNumbers.get(i));
                        }
                    }
                    return selectedMagicNumbers;
                }
            }
            return null;
        });
    }

    private void updateMagicNumberCheckBoxes() {
        boolean allSelected = allMagicNumbersCheckBox.isSelected();
        for (CheckBox checkBox : magicNumberCheckBoxes) {
            checkBox.setDisable(allSelected);
            if (!allSelected) {
                checkBox.setSelected(false);
            }
        }
    }
}
