package com.tradelogic.ui;

import com.tradelogic.Logger;
import com.tradelogic.models.SystemConfig;
import com.tradelogic.services.DrawdownMonitor;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Control panel for the right side of the Trade Logic interface (250px width).
 * Features:
 * - Large round master start/stop button (MUTED/ON)
 * - System-wide parameters display
 * - Daily drawdown monitoring
 * - Active robots count
 * - Real-time P&L display
 */
public class ControlPanelPane extends VBox {
    private final UUID userId;
    private final SystemConfig systemConfig;
    private final DrawdownMonitor drawdownMonitor;

    // UI Components
    private Button masterButton;
    private Circle masterButtonCircle;
    private Label masterButtonLabel;
    private Label activeRobotsLabel;
    private Label currentDrawdownLabel;
    private TextField dailyLimitField;
    private Label totalRptLabel;
    private Label accountBalanceLabel;
    private Label accountEquityLabel;
    private Button saveLayoutButton;
    private Button setDefaultsButton;

    private ScheduledExecutorService updateScheduler;
    private boolean isMasterEnabled = false;
    private Runnable onSaveLayoutCallback;
    private Runnable onSetDefaultsCallback;

    public ControlPanelPane(UUID userId, SystemConfig systemConfig, Runnable onSaveLayoutCallback, Runnable onSetDefaultsCallback) {
        this.userId = userId;
        this.systemConfig = systemConfig;
        this.drawdownMonitor = DrawdownMonitor.getInstance();
        this.onSaveLayoutCallback = onSaveLayoutCallback;
        this.onSetDefaultsCallback = onSetDefaultsCallback;

        initialize();
        startRealtimeUpdates();
    }

    private void initialize() {
        setMinWidth(250);
        setMaxWidth(250);
        setPadding(new Insets(10, 10, 10, 10));
        setSpacing(10);
        setStyle("-fx-background-color: #2e2e2e; -fx-border-color: #444; -fx-border-width: 0 0 0 2;");

        // Master Button (Round, Large)
        createMasterButton();

        // Divider
        Separator separator1 = new Separator();
        separator1.setStyle("-fx-background-color: #444;");

        // System Parameters Section
        Label systemParamsTitle = createSectionTitle("System Parameters");

        HBox dailyLimitBox = createDailyLimitField();
        currentDrawdownLabel = createParameterLabel("Current DD:", "0.0%");
        activeRobotsLabel = createParameterLabel("Active Robots:", "0/500");
        totalRptLabel = createParameterLabel("Total RPT:", "$0.00");

        // Divider
        Separator separator2 = new Separator();
        separator2.setStyle("-fx-background-color: #444;");

        // Account Info Section
        Label accountInfoTitle = createSectionTitle("Account Info");

        accountBalanceLabel = createParameterLabel("Balance:", "$0.00");
        accountEquityLabel = createParameterLabel("Equity:", "$0.00");

        // Divider
        Separator separator3 = new Separator();
        separator3.setStyle("-fx-background-color: #444;");

        // Set Defaults Button
        setDefaultsButton = new Button("Set Defaults");
        setDefaultsButton.setPrefWidth(200);
        setDefaultsButton.setPrefHeight(35);
        setDefaultsButton.setStyle(
            "-fx-background-color: #ff9800; " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 13px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 5;"
        );
        setDefaultsButton.setOnAction(e -> handleSetDefaults());
        VBox.setMargin(setDefaultsButton, new Insets(5, 25, 0, 25));

        // Save Layout Button
        saveLayoutButton = new Button("Save Layout");
        saveLayoutButton.setPrefWidth(200);
        saveLayoutButton.setPrefHeight(35);
        saveLayoutButton.setStyle(
            "-fx-background-color: #4a86e8; " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 13px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 5;"
        );
        saveLayoutButton.setOnAction(e -> handleSaveLayout());
        VBox.setMargin(saveLayoutButton, new Insets(5, 25, 0, 25));

        // Add all components
        getChildren().addAll(
            masterButton,
            separator1,
            systemParamsTitle,
            dailyLimitBox,
            currentDrawdownLabel,
            activeRobotsLabel,
            totalRptLabel,
            separator2,
            accountInfoTitle,
            accountBalanceLabel,
            accountEquityLabel,
            separator3,
            setDefaultsButton,
            saveLayoutButton
        );

        Logger.info("ControlPanelPane initialized (250px width) with Set Defaults and Save Layout buttons");
    }

    /**
     * Creates the master button (60px diameter)
     */
    private void createMasterButton() {
        masterButton = new Button();
        masterButton.setPrefSize(60, 60);
        masterButton.setMaxSize(60, 60);
        masterButton.setMinSize(60, 60);

        // Create circular appearance
        masterButtonCircle = new Circle(30);
        masterButtonCircle.setFill(Color.GRAY);
        masterButtonCircle.setStroke(Color.web("#555"));
        masterButtonCircle.setStrokeWidth(2);

        masterButtonLabel = new Label("MUTED");
        masterButtonLabel.setFont(Font.font("System", FontWeight.BOLD, 10));
        masterButtonLabel.setTextFill(Color.WHITE);

        // Stack circle and label
        VBox buttonContent = new VBox(masterButtonCircle, masterButtonLabel);
        buttonContent.setAlignment(Pos.CENTER);
        buttonContent.setSpacing(-40); // Overlap to center text on circle

        masterButton.setGraphic(buttonContent);
        masterButton.setStyle("-fx-background-color: transparent; -fx-padding: 0;");

        // Center in pane with less margin at top
        VBox.setMargin(masterButton, new Insets(0, 0, 15, 0));
        setAlignment(Pos.TOP_CENTER);

        // Handle click
        masterButton.setOnAction(e -> toggleMasterTrading());
    }

    /**
     * Creates a section title label
     */
    private Label createSectionTitle(String text) {
        Label label = new Label(text);
        label.setFont(Font.font("System", FontWeight.BOLD, 14));
        label.setTextFill(Color.web("#cccccc"));
        label.setStyle("-fx-padding: 5 0 0 0;");
        return label;
    }

    /**
     * Creates a parameter display label
     */
    private Label createParameterLabel(String name, String initialValue) {
        Label label = new Label(name + " " + initialValue);
        label.setFont(Font.font("System", 12));
        label.setTextFill(Color.web("#999999"));
        label.setWrapText(true);
        return label;
    }

    /**
     * Creates the editable Daily DD Limit field
     */
    private HBox createDailyLimitField() {
        Label label = new Label("Daily DD Limit:");
        label.setFont(Font.font("System", 12));
        label.setTextFill(Color.web("#999999"));

        dailyLimitField = new TextField(String.format("%.1f", systemConfig.getDailyDrawdownHardStop()));
        dailyLimitField.setPrefWidth(60);
        dailyLimitField.setMaxWidth(60);
        dailyLimitField.setStyle(
            "-fx-background-color: #3e3e3e; " +
            "-fx-text-fill: #cccccc; " +
            "-fx-border-color: #555; " +
            "-fx-border-radius: 3; " +
            "-fx-background-radius: 3;"
        );

        Label percentLabel = new Label("%");
        percentLabel.setFont(Font.font("System", 12));
        percentLabel.setTextFill(Color.web("#999999"));

        dailyLimitField.focusedProperty().addListener((obs, wasFocused, isNowFocused) -> {
            if (!isNowFocused) {
                handleDailyLimitChange();
            }
        });

        dailyLimitField.setOnAction(e -> handleDailyLimitChange());

        HBox box = new HBox(4, label, dailyLimitField, percentLabel);
        box.setAlignment(Pos.CENTER_LEFT);
        return box;
    }

    /**
     * Handles Daily DD Limit field changes
     */
    private void handleDailyLimitChange() {
        if (isMasterEnabled) {
            Platform.runLater(() -> {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Cannot Change DD Limit");
                alert.setHeaderText(null);
                alert.setContentText("Daily DD Limit can only be changed when Master is MUTED.");
                alert.showAndWait();

                dailyLimitField.setText(String.format("%.1f", systemConfig.getDailyDrawdownHardStop()));
            });
            Logger.warning("Attempted to change DD Limit while Master is ON");
            return;
        }

        try {
            double newLimit = Double.parseDouble(dailyLimitField.getText().trim());

            if (newLimit <= 0 || newLimit > 100) {
                throw new IllegalArgumentException("DD Limit must be between 0.1 and 100.0");
            }

            systemConfig.setDailyDrawdownHardStop(newLimit);
            saveDailyLimitToDatabase(newLimit);

            dailyLimitField.setText(String.format("%.1f", newLimit));
            Logger.info("Daily DD Limit updated to " + newLimit + "%");

        } catch (NumberFormatException e) {
            Platform.runLater(() -> {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Invalid Input");
                alert.setHeaderText(null);
                alert.setContentText("Please enter a valid decimal number.");
                alert.showAndWait();

                dailyLimitField.setText(String.format("%.1f", systemConfig.getDailyDrawdownHardStop()));
            });
            Logger.error("Invalid DD Limit input: " + dailyLimitField.getText());
        } catch (IllegalArgumentException e) {
            Platform.runLater(() -> {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Invalid Range");
                alert.setHeaderText(null);
                alert.setContentText(e.getMessage());
                alert.showAndWait();

                dailyLimitField.setText(String.format("%.1f", systemConfig.getDailyDrawdownHardStop()));
            });
            Logger.error("DD Limit out of range: " + e.getMessage());
        }
    }

    /**
     * Saves Daily DD Limit to database
     */
    private void saveDailyLimitToDatabase(double newLimit) {
        try {
            systemConfig.setDailyDrawdownHardStop(newLimit);
            Logger.info("Daily DD Limit updated: " + newLimit);
        } catch (Exception e) {
            Logger.error("Failed to update Daily DD Limit: " + e.getMessage());
        }
    }

    /**
     * Toggles master trading ON/MUTED
     */
    private void toggleMasterTrading() {
        isMasterEnabled = !isMasterEnabled;

        if (isMasterEnabled) {
            double currentDD = Math.abs((Double) drawdownMonitor.getDrawdownStats().getOrDefault("drawdown_percent", 0.0));
            double ddLimit = systemConfig.getDailyDrawdownHardStop();

            if (currentDD >= ddLimit) {
                Platform.runLater(() -> {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Cannot Start Trading");
                    alert.setHeaderText("Daily DD Limit Already Breached");
                    alert.setContentText(String.format(
                        "Current DD: %.2f%%\nDD Limit: %.1f%%\n\nPlease wait until a new trading day.",
                        currentDD, ddLimit
                    ));
                    alert.showAndWait();
                });

                isMasterEnabled = false;
                Logger.error("Cannot enable Master - DD limit already breached: " + currentDD + "% >= " + ddLimit + "%");
                return;
            }

            masterButtonCircle.setFill(Color.web("#4cff4c"));
            masterButtonLabel.setText("ON");
            systemConfig.setMasterTradingEnabled(true);
            dailyLimitField.setDisable(true);
            Logger.info("Master trading ENABLED");

        } else {
            masterButtonCircle.setFill(Color.GRAY);
            masterButtonLabel.setText("MUTED");
            systemConfig.setMasterTradingEnabled(false);
            dailyLimitField.setDisable(false);
            Logger.info("Master trading MUTED");
        }
    }

    /**
     * Starts real-time updates (1 second interval)
     */
    private void startRealtimeUpdates() {
        updateScheduler = Executors.newScheduledThreadPool(1);
        updateScheduler.scheduleAtFixedRate(
            this::updateDisplay,
            0,
            1,
            TimeUnit.SECONDS
        );

        Logger.info("ControlPanel real-time updates started (1s interval)");
    }

    /**
     * Updates all display values from services
     */
    private void updateDisplay() {
        Platform.runLater(() -> {
            try {
                // Update drawdown stats
                Map<String, Object> drawdownStats = drawdownMonitor.getDrawdownStats();

                double ddLimit = systemConfig.getDailyDrawdownHardStop();
                double currentDD = (Double) drawdownStats.getOrDefault("drawdown_percent", 0.0);
                int activeRobots = systemConfig.getActiveRobotsCount();
                double totalRpt = systemConfig.getTotalRptAcrossRobots();

                // Update daily limit field if not focused
                if (!dailyLimitField.isFocused()) {
                    dailyLimitField.setText(String.format("%.1f", ddLimit));
                }

                // Color code current drawdown
                String ddColor = "#4cff4c"; // Green
                if (Math.abs(currentDD) >= ddLimit * 0.8) {
                    ddColor = "#ff6b6b"; // Red
                } else if (Math.abs(currentDD) >= ddLimit * 0.5) {
                    ddColor = "#ffaa00"; // Orange
                }
                currentDrawdownLabel.setText("Current DD: " + String.format("%.2f%%", currentDD));
                currentDrawdownLabel.setTextFill(Color.web(ddColor));

                activeRobotsLabel.setText("Active Robots: " + activeRobots + "/500");
                totalRptLabel.setText("Total RPT: $" + String.format("%.2f", totalRpt));

                // Update account info
                double balance = (Double) drawdownStats.getOrDefault("starting_equity", 0.0);
                double equity = (Double) drawdownStats.getOrDefault("current_equity", 0.0);

                accountBalanceLabel.setText("Balance: $" + String.format("%.2f", balance));
                accountEquityLabel.setText("Equity: $" + String.format("%.2f", equity));

                // Check if drawdown limit breached
                if (isMasterEnabled && Math.abs(currentDD) >= ddLimit) {
                    triggerEmergencyStop();
                    systemConfig.setMaxDailyDrawdownReached(true);
                    showEmergencyStopAlert();
                }

            } catch (Exception e) {
                Logger.error("ERROR updating control panel: " + e.getMessage());
            }
        });
    }

    /**
     * Triggers emergency stop - liquidates all positions
     */
    private void triggerEmergencyStop() {
        isMasterEnabled = false;
        masterButtonCircle.setFill(Color.web("#ff6b6b"));
        masterButtonLabel.setText("STOPPED");
        systemConfig.setMasterTradingEnabled(false);
        dailyLimitField.setDisable(false);

        Logger.error("EMERGENCY STOP TRIGGERED - DD limit breached");

        // TODO: Liquidate all positions
        // TODO: Cancel all pending orders
    }

    /**
     * Shows critical alert when emergency stop is triggered
     */
    private void showEmergencyStopAlert() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("EMERGENCY STOP");
        alert.setHeaderText("Daily Drawdown Limit Breached!");
        alert.setContentText("All positions have been closed.\nTrading is stopped for the day.\nPlease review your strategies.");
        alert.showAndWait();

        Logger.error("CRITICAL: Emergency stop alert shown to user");
    }

    /**
     * Stops real-time updates
     */
    public void stopRealtimeUpdates() {
        if (updateScheduler != null && !updateScheduler.isShutdown()) {
            updateScheduler.shutdown();
            try {
                if (!updateScheduler.awaitTermination(2, TimeUnit.SECONDS)) {
                    updateScheduler.shutdownNow();
                }
            } catch (InterruptedException e) {
                updateScheduler.shutdownNow();
                Thread.currentThread().interrupt();
            }
            Logger.info("ControlPanel real-time updates stopped");
        }
    }

    /**
     * Gets current master trading state
     */
    public boolean isMasterEnabled() {
        return isMasterEnabled;
    }

    /**
     * Programmatically sets master button state
     */
    public void setMasterEnabled(boolean enabled) {
        if (enabled != isMasterEnabled) {
            toggleMasterTrading();
        }
    }

    /**
     * Sets the callback for Save Layout button
     */
    public void setOnSaveLayoutCallback(Runnable callback) {
        this.onSaveLayoutCallback = callback;
    }

    /**
     * Handles Save Layout button click
     */
    private void handleSaveLayout() {
        Logger.info("Save Layout button clicked");
        System.out.println("[DEBUG] Save Layout button clicked");

        if (onSaveLayoutCallback != null) {
            System.out.println("[DEBUG] Executing Save Layout callback");
            try {
                onSaveLayoutCallback.run();
                System.out.println("[DEBUG] Save Layout callback completed");
            } catch (Exception e) {
                System.err.println("[ERROR] Save Layout callback failed: " + e.getMessage());
                e.printStackTrace();
                throw e;
            }
        } else {
            System.err.println("[ERROR] No Save Layout callback configured");
            Logger.warning("No Save Layout callback configured");
        }
    }

    /**
     * Sets the callback for Set Defaults button
     */
    public void setOnSetDefaultsCallback(Runnable callback) {
        this.onSetDefaultsCallback = callback;
    }

    /**
     * Handles Set Defaults button click
     */
    private void handleSetDefaults() {
        Logger.info("Set Defaults button clicked");
        System.out.println("[DEBUG] Set Defaults button clicked");

        if (onSetDefaultsCallback != null) {
            System.out.println("[DEBUG] Executing Set Defaults callback");
            try {
                onSetDefaultsCallback.run();
                System.out.println("[DEBUG] Set Defaults callback completed");
            } catch (Exception e) {
                System.err.println("[ERROR] Set Defaults callback failed: " + e.getMessage());
                e.printStackTrace();
                throw e;
            }
        } else {
            System.err.println("[ERROR] No Set Defaults callback configured");
            Logger.warning("No Set Defaults callback configured");
        }
    }
}
