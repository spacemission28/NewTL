package com.tradelogic.ui;

import com.tradelogic.Logger;
import com.tradelogic.models.RobotConfig;
import com.tradelogic.models.RobotState;
import com.tradelogic.models.SystemConfig;
import com.tradelogic.services.DatabaseClient;
import com.tradelogic.services.DatabaseFactory;
import com.tradelogic.ui.NumberConverters.DoubleNumberConverter;
import com.tradelogic.ui.NumberConverters.IntegerNumberConverter;
import javafx.application.Platform;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.util.StringConverter;
import javafx.util.converter.DoubleStringConverter;
import javafx.util.converter.IntegerStringConverter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class RobotMatrixTable extends BorderPane {

    private final TableView<RobotRow> tableView;
    private final ObservableList<RobotRow> robotRows;
    private final UUID userId;
    private DatabaseClient dbClient;
    private SystemConfig systemConfig;
    private ControlPanelPane controlPanel;
    private Map<Integer, RobotConfig> savedConfigs;

    public static class RobotRow {
        private final IntegerProperty rowNumber;
        private final BooleanProperty active;
        private final StringProperty magicNumber;
        private final StringProperty robotName;
        private final StringProperty symbol;
        private final StringProperty timeframe;
        private final IntegerProperty closeHour;
        private final IntegerProperty closeMinute;
        private final DoubleProperty minX1Height;
        private final StringProperty x1Type;
        private final DoubleProperty trigPercent;
        private final DoubleProperty stopLossPercent;
        private final DoubleProperty rptPercent;
        private final DoubleProperty rptFixedAmount;
        private final DoubleProperty tp1Percent;
        private final IntegerProperty tp1Volume;
        private final DoubleProperty tp2Percent;
        private final IntegerProperty tp2Volume;
        private final DoubleProperty tp3Percent;
        private final IntegerProperty tp3Volume;
        private final DoubleProperty tp4Percent;
        private final IntegerProperty tp4Volume;
        private final DoubleProperty tp5Percent;
        private final IntegerProperty tp5Volume;
        private final DoubleProperty tp6Percent;
        private final IntegerProperty tp6Volume;
        private final DoubleProperty tp7Percent;
        private final IntegerProperty tp7Volume;
        private final StringProperty status;
        private final StringProperty lastSignal;
        private final StringProperty activeTrade;
        private final DoubleProperty profitLoss;

        private UUID robotConfigId;
        private boolean isPlaceholder;

        public RobotRow(int rowNumber) {
            this.rowNumber = new SimpleIntegerProperty(rowNumber);
            this.active = new SimpleBooleanProperty(false);
            this.magicNumber = new SimpleStringProperty("");
            this.robotName = new SimpleStringProperty("");
            this.symbol = new SimpleStringProperty("");
            this.timeframe = new SimpleStringProperty("");
            this.closeHour = new SimpleIntegerProperty(0);
            this.closeMinute = new SimpleIntegerProperty(0);
            this.minX1Height = new SimpleDoubleProperty(0.0);
            this.x1Type = new SimpleStringProperty("");
            this.trigPercent = new SimpleDoubleProperty(0.0);
            this.stopLossPercent = new SimpleDoubleProperty(0.0);
            this.rptPercent = new SimpleDoubleProperty(0.0);
            this.rptFixedAmount = new SimpleDoubleProperty(0.0);
            this.tp1Percent = new SimpleDoubleProperty(0.0);
            this.tp1Volume = new SimpleIntegerProperty(0);
            this.tp2Percent = new SimpleDoubleProperty(0.0);
            this.tp2Volume = new SimpleIntegerProperty(0);
            this.tp3Percent = new SimpleDoubleProperty(0.0);
            this.tp3Volume = new SimpleIntegerProperty(0);
            this.tp4Percent = new SimpleDoubleProperty(0.0);
            this.tp4Volume = new SimpleIntegerProperty(0);
            this.tp5Percent = new SimpleDoubleProperty(0.0);
            this.tp5Volume = new SimpleIntegerProperty(0);
            this.tp6Percent = new SimpleDoubleProperty(0.0);
            this.tp6Volume = new SimpleIntegerProperty(0);
            this.tp7Percent = new SimpleDoubleProperty(0.0);
            this.tp7Volume = new SimpleIntegerProperty(0);
            this.status = new SimpleStringProperty("⚪");
            this.lastSignal = new SimpleStringProperty("--");
            this.activeTrade = new SimpleStringProperty("--");
            this.profitLoss = new SimpleDoubleProperty(0.0);
            this.isPlaceholder = true;
        }

        // Getters for properties
        public IntegerProperty rowNumberProperty() { return rowNumber; }
        public BooleanProperty activeProperty() { return active; }
        public StringProperty magicNumberProperty() { return magicNumber; }
        public StringProperty robotNameProperty() { return robotName; }
        public StringProperty symbolProperty() { return symbol; }
        public StringProperty timeframeProperty() { return timeframe; }
        public IntegerProperty closeHourProperty() { return closeHour; }
        public IntegerProperty closeMinuteProperty() { return closeMinute; }
        public DoubleProperty minX1HeightProperty() { return minX1Height; }
        public StringProperty x1TypeProperty() { return x1Type; }
        public DoubleProperty trigPercentProperty() { return trigPercent; }
        public DoubleProperty stopLossPercentProperty() { return stopLossPercent; }
        public DoubleProperty rptPercentProperty() { return rptPercent; }
        public DoubleProperty rptFixedAmountProperty() { return rptFixedAmount; }
        public DoubleProperty tp1PercentProperty() { return tp1Percent; }
        public IntegerProperty tp1VolumeProperty() { return tp1Volume; }
        public DoubleProperty tp2PercentProperty() { return tp2Percent; }
        public IntegerProperty tp2VolumeProperty() { return tp2Volume; }
        public DoubleProperty tp3PercentProperty() { return tp3Percent; }
        public IntegerProperty tp3VolumeProperty() { return tp3Volume; }
        public DoubleProperty tp4PercentProperty() { return tp4Percent; }
        public IntegerProperty tp4VolumeProperty() { return tp4Volume; }
        public DoubleProperty tp5PercentProperty() { return tp5Percent; }
        public IntegerProperty tp5VolumeProperty() { return tp5Volume; }
        public DoubleProperty tp6PercentProperty() { return tp6Percent; }
        public IntegerProperty tp6VolumeProperty() { return tp6Volume; }
        public DoubleProperty tp7PercentProperty() { return tp7Percent; }
        public IntegerProperty tp7VolumeProperty() { return tp7Volume; }
        public StringProperty statusProperty() { return status; }
        public StringProperty lastSignalProperty() { return lastSignal; }
        public StringProperty activeTradeProperty() { return activeTrade; }
        public DoubleProperty profitLossProperty() { return profitLoss; }

        public UUID getRobotConfigId() { return robotConfigId; }
        public void setRobotConfigId(UUID id) { this.robotConfigId = id; }
        public boolean isPlaceholder() { return isPlaceholder; }
        public void setPlaceholder(boolean placeholder) { isPlaceholder = placeholder; }

        public void updateFromConfig(RobotConfig config) {
            this.robotConfigId = config.getId();
            this.active.set(config.isActive());
            this.magicNumber.set(config.getMagicNumber() != null ? config.getMagicNumber() : "");
            this.robotName.set(config.getRobotName());
            this.symbol.set(config.getSymbol());
            this.timeframe.set(config.getTimeframe());
            this.closeHour.set(config.getCloseHour());
            this.closeMinute.set(config.getCloseMinute());
            this.minX1Height.set(config.getMinX1Height());
            this.x1Type.set(config.getX1Type());
            this.trigPercent.set(config.getTrigPercent());
            this.stopLossPercent.set(config.getStopLossPercent());
            this.rptPercent.set(config.getRptPercent() != null ? config.getRptPercent() : 0.0);
            this.rptFixedAmount.set(config.getRptFixedAmount() != null ? config.getRptFixedAmount() : 0.0);
            this.tp1Percent.set(config.getTp1Percent());
            this.tp1Volume.set(config.getTp1Volume());
            this.tp2Percent.set(config.getTp2Percent());
            this.tp2Volume.set(config.getTp2Volume());
            this.tp3Percent.set(config.getTp3Percent());
            this.tp3Volume.set(config.getTp3Volume());
            this.tp4Percent.set(config.getTp4Percent());
            this.tp4Volume.set(config.getTp4Volume());
            this.tp5Percent.set(config.getTp5Percent());
            this.tp5Volume.set(config.getTp5Volume());
            this.tp6Percent.set(config.getTp6Percent());
            this.tp6Volume.set(config.getTp6Volume());
            this.tp7Percent.set(config.getTp7Percent());
            this.tp7Volume.set(config.getTp7Volume());
            this.isPlaceholder = false;
        }

        public void updateFromState(RobotState state) {
            if (state == null) return;
            this.status.set(state.getStatusEmoji());
            this.lastSignal.set(state.getLastSignalDate() != null ?
                state.getLastSignalDate().toString() : "--");
            this.activeTrade.set(state.getActivePositionTicket() != null ?
                "#" + state.getActivePositionTicket() : "--");
            this.profitLoss.set(state.getCurrentProfitLoss());
        }
    }

    public RobotMatrixTable(UUID userId) {
        this.userId = userId;
        this.robotRows = FXCollections.observableArrayList();
        this.tableView = new TableView<>();
        this.dbClient = DatabaseFactory.getInstance();
        this.systemConfig = new SystemConfig();
        this.systemConfig.setUserId(userId);
        this.savedConfigs = new HashMap<>();
        this.controlPanel = new ControlPanelPane(userId, systemConfig, this::saveLayout, this::saveDefaultValues);

        initialize();
        loadRobots();
    }

    private void initialize() {
        tableView.setItems(robotRows);
        tableView.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);
        tableView.setEditable(true);

        // Apply row factory for conditional styling
        tableView.setRowFactory(tv -> {
            TableRow<RobotRow> row = new TableRow<>() {
                @Override
                protected void updateItem(RobotRow item, boolean empty) {
                    super.updateItem(item, empty);

                    if (item == null || empty) {
                        setStyle("");
                        setContextMenu(null);
                    } else {
                        // Listen to active property changes
                        item.activeProperty().addListener((obs, oldVal, newVal) -> {
                            if (newVal) {
                                setStyle("-fx-background-color: #ffcccc;");
                            } else {
                                setStyle("");
                            }
                        });

                        // Set initial style
                        if (item.activeProperty().get()) {
                            setStyle("-fx-background-color: #ffcccc;");
                        } else {
                            setStyle("");
                        }

                        // Add context menu for right-click actions
                        setContextMenu(createRowContextMenu(item));
                    }
                }
            };
            return row;
        });

        // Create columns
        createRowNumberColumn();
        createActiveColumn();
        createMagicNumberColumn();
        createRobotNameColumn();
        createSymbolColumn();
        createTimeframeColumn();
        createCloseHourColumn();
        createCloseMinuteColumn();
        createMinX1HeightColumn();
        createX1TypeColumn();
        createTrigPercentColumn();
        createStopLossPercentColumn();
        createRptPercentColumn();
        createRptFixedAmountColumn();
        createTPColumns();
        createStatusColumn();
        createLastSignalColumn();
        createActiveTradeColumn();

        // Add listener to commit edits when focus changes
        tableView.editingCellProperty().addListener((obs, oldCell, newCell) -> {
            if (oldCell != null && newCell == null) {
                // Edit was canceled, but that's normal when moving between cells
                Logger.info("Table editing stopped");
            }
        });

        // Add listener to commit edit when clicking outside the table
        tableView.focusedProperty().addListener((obs, wasFocused, isNowFocused) -> {
            if (wasFocused && !isNowFocused) {
                // Table lost focus, commit any pending edits
                tableView.getSelectionModel().clearSelection();
                Logger.info("Table lost focus");
            }
        });

        setPadding(new Insets(10));
        setCenter(tableView);
        setRight(controlPanel);

        controlPanel.setOnSaveLayoutCallback(this::saveLayout);
        controlPanel.setOnSetDefaultsCallback(this::showSetDefaultsDialog);

        Logger.info("RobotMatrixTable initialized with 500 rows and control panel");
    }

    private void createRowNumberColumn() {
        TableColumn<RobotRow, Number> col = new TableColumn<>("#");
        col.setCellValueFactory(cellData -> cellData.getValue().rowNumberProperty());
        col.setEditable(false);
        col.setMinWidth(50);
        col.setMaxWidth(50);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createActiveColumn() {
        TableColumn<RobotRow, Boolean> col = new TableColumn<>("✓");
        col.setCellValueFactory(cellData -> cellData.getValue().activeProperty());
        col.setCellFactory(CheckBoxTableCell.forTableColumn(col));
        col.setEditable(true);
        col.setMinWidth(40);
        col.setMaxWidth(40);
        tableView.getColumns().add(col);
    }

    private void createMagicNumberColumn() {
        TableColumn<RobotRow, String> col = new TableColumn<>("Magic#");
        col.setCellValueFactory(cellData -> cellData.getValue().magicNumberProperty());
        col.setCellFactory(createEditableTextCell(new StringConverter<String>() {
            @Override
            public String toString(String value) {
                return value == null ? "" : value;
            }

            @Override
            public String fromString(String text) {
                return text == null ? "" : text.trim();
            }
        }));
        col.setEditable(true);

        // Handle edit commit to mark row as non-placeholder
        col.setOnEditCommit(event -> {
            RobotRow row = event.getRowValue();
            if (row != null && event.getNewValue() != null) {
                row.magicNumber.set(event.getNewValue());
                if (row.isPlaceholder()) {
                    row.setPlaceholder(false);
                }
            }
        });

        col.setMinWidth(80);
        col.setMaxWidth(80);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createRobotNameColumn() {
        TableColumn<RobotRow, String> col = new TableColumn<>("Robot Name");
        col.setCellValueFactory(cellData -> cellData.getValue().robotNameProperty());
        col.setCellFactory(createEditableTextCell(new javafx.util.converter.DefaultStringConverter()));
        col.setEditable(true);
        col.setMinWidth(150);
        tableView.getColumns().add(col);
    }

    private void createSymbolColumn() {
        TableColumn<RobotRow, String> col = new TableColumn<>("Symbol");
        col.setCellValueFactory(cellData -> cellData.getValue().symbolProperty());
        col.setCellFactory(createEditableTextCell(new javafx.util.converter.DefaultStringConverter()));
        col.setEditable(true);
        col.setMinWidth(80);
        col.setMaxWidth(100);
        tableView.getColumns().add(col);
    }

    private void createTimeframeColumn() {
        TableColumn<RobotRow, String> col = new TableColumn<>("TF");
        col.setCellValueFactory(cellData -> cellData.getValue().timeframeProperty());

        ObservableList<String> timeframes = FXCollections.observableArrayList(
            "M1", "M2", "M3", "M5", "M10", "M15", "M30", "H1", "H3", "H4", "D1"
        );
        col.setCellFactory(createComboBoxCell(timeframes));
        col.setEditable(true);
        col.setMinWidth(70);
        col.setMaxWidth(80);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createCloseHourColumn() {
        TableColumn<RobotRow, Number> col = new TableColumn<>("Hr");
        col.setCellValueFactory(cellData -> cellData.getValue().closeHourProperty());

        // Create observable list of hours 0-23
        ObservableList<Integer> hours = FXCollections.observableArrayList();
        for (int i = 0; i <= 23; i++) {
            hours.add(i);
        }

        col.setCellFactory(column -> {
            ComboBoxTableCell<RobotRow, Number> cell = new ComboBoxTableCell<RobotRow, Number>(hours.toArray(new Integer[0])) {
                @Override
                public void updateItem(Number item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setText("");
                    } else {
                        setText(String.valueOf(item.intValue()));
                    }
                }
            };

            // Block editing if Matrix is ON and row is active
            cell.setOnMouseClicked(event -> {
                RobotRow row = cell.getTableRow().getItem();
                if (row != null && systemConfig.isMasterTradingEnabled() && row.activeProperty().get()) {
                    event.consume();
                }
            });

            return cell;
        });

        col.setEditable(true);
        col.setMinWidth(45);
        col.setMaxWidth(50);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createCloseMinuteColumn() {
        TableColumn<RobotRow, Number> col = new TableColumn<>("Min");
        col.setCellValueFactory(cellData -> cellData.getValue().closeMinuteProperty());

        // Create observable list of minutes 0-59
        ObservableList<Integer> minutes = FXCollections.observableArrayList();
        for (int i = 0; i <= 59; i++) {
            minutes.add(i);
        }

        col.setCellFactory(column -> {
            ComboBoxTableCell<RobotRow, Number> cell = new ComboBoxTableCell<RobotRow, Number>(minutes.toArray(new Integer[0])) {
                @Override
                public void updateItem(Number item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setText("");
                    } else {
                        setText(String.valueOf(item.intValue()));
                    }
                }
            };

            // Block editing if Matrix is ON and row is active
            cell.setOnMouseClicked(event -> {
                RobotRow row = cell.getTableRow().getItem();
                if (row != null && systemConfig.isMasterTradingEnabled() && row.activeProperty().get()) {
                    event.consume();
                }
            });

            return cell;
        });

        col.setEditable(true);
        col.setMinWidth(45);
        col.setMaxWidth(50);
        col.setStyle("-fx-alignment: CENTER;");
        tableView.getColumns().add(col);
    }

    private void createMinX1HeightColumn() {
        TableColumn<RobotRow, Number> col = new TableColumn<>("MinX1");
        col.setCellValueFactory(cellData -> cellData.getValue().minX1HeightProperty());
        col.setCellFactory(createEditableTextCell(new DoubleNumberConverter()));
        col.setEditable(true);
        col.setMinWidth(60);
        col.setMaxWidth(70);
        tableView.getColumns().add(col);
    }

    private void createX1TypeColumn() {
        TableColumn<RobotRow, String> col = new TableColumn<>("X1Type");
        col.setCellValueFactory(cellData -> cellData.getValue().x1TypeProperty());

        ObservableList<String> x1Types = FXCollections.observableArrayList(
            "Yen Pips", "Non-Yen Pips", "Cents", "Points"
        );
        col.setCellFactory(createComboBoxCell(x1Types));
        col.setEditable(true);
        col.setMinWidth(120);
        col.setMaxWidth(130);
        tableView.getColumns().add(col);
    }

    private void createTrigPercentColumn() {
        TableColumn<RobotRow, Number> col = new TableColumn<>("Trig%");
        col.setCellValueFactory(cellData -> cellData.getValue().trigPercentProperty());
        col.setCellFactory(createEditableTextCell(new DoubleNumberConverter()));
        col.setEditable(true);
        col.setMinWidth(60);
        tableView.getColumns().add(col);
    }

    private void createStopLossPercentColumn() {
        TableColumn<RobotRow, Number> col = new TableColumn<>("SL%");
        col.setCellValueFactory(cellData -> cellData.getValue().stopLossPercentProperty());
        col.setCellFactory(createEditableTextCell(new DoubleNumberConverter()));
        col.setEditable(true);
        col.setMinWidth(60);
        tableView.getColumns().add(col);
    }

    private void createRptPercentColumn() {
        TableColumn<RobotRow, Number> col = new TableColumn<>("RPT%");
        col.setCellValueFactory(cellData -> cellData.getValue().rptPercentProperty());
        col.setCellFactory(createEditableTextCell(new DoubleNumberConverter()));
        col.setEditable(true);
        col.setMinWidth(60);
        tableView.getColumns().add(col);
    }

    private void createRptFixedAmountColumn() {
        TableColumn<RobotRow, Number> col = new TableColumn<>("RPT$");
        col.setCellValueFactory(cellData -> cellData.getValue().rptFixedAmountProperty());
        col.setCellFactory(createEditableTextCell(new DoubleNumberConverter()));
        col.setEditable(true);
        col.setMinWidth(70);
        tableView.getColumns().add(col);
    }

    private void createTPColumns() {
        for (int i = 1; i <= 7; i++) {
            final int tpNum = i;

            TableColumn<RobotRow, Number> percentCol = new TableColumn<>("TP" + i + "%");
            percentCol.setCellFactory(createEditableTextCell(new DoubleNumberConverter()));
            percentCol.setEditable(true);
            percentCol.setMinWidth(60);

            TableColumn<RobotRow, Number> volumeCol = new TableColumn<>("Vol");
            volumeCol.setCellFactory(createEditableTextCell(new IntegerNumberConverter()));
            volumeCol.setEditable(true);
            volumeCol.setMinWidth(50);

            switch (tpNum) {
                case 1:
                    percentCol.setCellValueFactory(cellData -> cellData.getValue().tp1PercentProperty());
                    volumeCol.setCellValueFactory(cellData -> cellData.getValue().tp1VolumeProperty());
                    break;
                case 2:
                    percentCol.setCellValueFactory(cellData -> cellData.getValue().tp2PercentProperty());
                    volumeCol.setCellValueFactory(cellData -> cellData.getValue().tp2VolumeProperty());
                    break;
                case 3:
                    percentCol.setCellValueFactory(cellData -> cellData.getValue().tp3PercentProperty());
                    volumeCol.setCellValueFactory(cellData -> cellData.getValue().tp3VolumeProperty());
                    break;
                case 4:
                    percentCol.setCellValueFactory(cellData -> cellData.getValue().tp4PercentProperty());
                    volumeCol.setCellValueFactory(cellData -> cellData.getValue().tp4VolumeProperty());
                    break;
                case 5:
                    percentCol.setCellValueFactory(cellData -> cellData.getValue().tp5PercentProperty());
                    volumeCol.setCellValueFactory(cellData -> cellData.getValue().tp5VolumeProperty());
                    break;
                case 6:
                    percentCol.setCellValueFactory(cellData -> cellData.getValue().tp6PercentProperty());
                    volumeCol.setCellValueFactory(cellData -> cellData.getValue().tp6VolumeProperty());
                    break;
                case 7:
                    percentCol.setCellValueFactory(cellData -> cellData.getValue().tp7PercentProperty());
                    volumeCol.setCellValueFactory(cellData -> cellData.getValue().tp7VolumeProperty());
                    break;
            }

            tableView.getColumns().addAll(percentCol, volumeCol);
        }
    }

    private void createStatusColumn() {
        TableColumn<RobotRow, String> col = new TableColumn<>("Status");
        col.setCellValueFactory(cellData -> cellData.getValue().statusProperty());
        col.setEditable(false);
        col.setMinWidth(60);
        col.setMaxWidth(70);
        col.setStyle("-fx-alignment: CENTER; -fx-font-size: 16px;");
        tableView.getColumns().add(col);
    }

    private void createLastSignalColumn() {
        TableColumn<RobotRow, String> col = new TableColumn<>("Last Signal");
        col.setCellValueFactory(cellData -> cellData.getValue().lastSignalProperty());
        col.setEditable(false);
        col.setMinWidth(100);
        tableView.getColumns().add(col);
    }

    private void createActiveTradeColumn() {
        TableColumn<RobotRow, String> col = new TableColumn<>("Active Trade");
        col.setCellValueFactory(cellData -> cellData.getValue().activeTradeProperty());
        col.setEditable(false);
        col.setMinWidth(100);
        tableView.getColumns().add(col);
    }

    /**
     * Creates a context menu for right-click actions on rows
     */
    private ContextMenu createRowContextMenu(RobotRow row) {
        ContextMenu contextMenu = new ContextMenu();

        MenuItem fillColumnItem = new MenuItem("Fill Column (entire column with this value)");
        fillColumnItem.setOnAction(e -> fillColumn(row));

        MenuItem fillDownItem = new MenuItem("Fill Down (from this row to bottom)");
        fillDownItem.setOnAction(e -> fillDown(row));

        MenuItem duplicateRowItem = new MenuItem("Duplicate Row Below");
        duplicateRowItem.setOnAction(e -> duplicateRow(row));

        MenuItem clearRowItem = new MenuItem("Clear This Row");
        clearRowItem.setOnAction(e -> clearRow(row));

        MenuItem clearAllRowsItem = new MenuItem("Clear All Rows (from this row to bottom)");
        clearAllRowsItem.setOnAction(e -> clearAllRows(row));

        contextMenu.getItems().addAll(fillColumnItem, fillDownItem, duplicateRowItem,
                                       new SeparatorMenuItem(), clearRowItem, clearAllRowsItem);

        return contextMenu;
    }

    /**
     * Creates a text field cell that commits on focus loss and supports context menu
     * Blocks editing if Matrix is ON and row is active (pink/checked)
     */
    private <T> javafx.util.Callback<TableColumn<RobotRow, T>, TableCell<RobotRow, T>>
            createEditableTextCell(StringConverter<T> converter) {
        return column -> {
            TableCell<RobotRow, T> cell = new TableCell<RobotRow, T>() {
                private javafx.scene.control.TextField textField;

                @Override
                public void startEdit() {
                    RobotRow row = getTableRow().getItem();

                    // Block editing if Matrix is ON and row is active (pink/checked)
                    if (row != null && systemConfig.isMasterTradingEnabled() && row.activeProperty().get()) {
                        return;
                    }

                    super.startEdit();

                    if (textField == null) {
                        textField = new javafx.scene.control.TextField();

                        // Commit on Enter
                        textField.setOnAction(e -> commitFromTextField());

                        // Commit on focus lost
                        textField.focusedProperty().addListener((obs, was, is) -> {
                            if (was && !is) {
                                Platform.runLater(() -> {
                                    if (isEditing()) {
                                        commitFromTextField();
                                    }
                                });
                            }
                        });
                    }

                    T item = getItem();
                    String text = item == null ? "" : converter.toString(item);
                    textField.setText(text);

                    setText(null);
                    setGraphic(textField);

                    Platform.runLater(() -> {
                        textField.requestFocus();
                        textField.selectAll();
                    });
                }

                @Override
                public void cancelEdit() {
                    // Convert cancel into commit if there's a textField with content
                    if (textField != null && isEditing()) {
                        commitFromTextField();
                    } else {
                        super.cancelEdit();
                        setText(getItem() == null ? "" : converter.toString(getItem()));
                        setGraphic(null);
                    }
                }

                @Override
                public void updateItem(T item, boolean empty) {
                    super.updateItem(item, empty);

                    if (empty) {
                        setText(null);
                        setGraphic(null);
                    } else {
                        if (isEditing()) {
                            if (textField != null) {
                                textField.setText(converter.toString(item));
                            }
                            setText(null);
                            setGraphic(textField);
                        } else {
                            setText(converter.toString(item));
                            setGraphic(null);
                        }
                    }
                }

                private void commitFromTextField() {
                    if (!isEditing()) return;

                    try {
                        String text = textField.getText();
                        if (text == null) text = "";
                        T newValue = converter.fromString(text);

                        commitEdit(newValue);
                    } catch (Exception e) {
                        cancelEdit();
                    }
                }
            };

            // Add context menu to cell
            cell.setOnContextMenuRequested(event -> {
                RobotRow row = cell.getTableRow().getItem();
                if (row != null && !row.isPlaceholder()) {
                    ContextMenu menu = createRowContextMenu(row);
                    menu.show(cell, event.getScreenX(), event.getScreenY());
                    event.consume();
                }
            });

            return cell;
        };
    }

    /**
     * Creates a combo box cell with context menu support
     * Blocks editing if Matrix is ON and row is active (pink/checked)
     */
    private <T> javafx.util.Callback<TableColumn<RobotRow, T>, TableCell<RobotRow, T>>
            createComboBoxCell(ObservableList<T> items) {
        return column -> {
            ComboBoxTableCell<RobotRow, T> cell = new ComboBoxTableCell<RobotRow, T>(items) {
                @Override
                public void startEdit() {
                    RobotRow row = getTableRow().getItem();

                    // Block editing if Matrix is ON and row is active (pink/checked)
                    if (row != null && systemConfig.isMasterTradingEnabled() && row.activeProperty().get()) {
                        // Don't allow editing - row has live positions/orders
                        return;
                    }

                    super.startEdit();
                }
            };

            // Add context menu to cell
            cell.setOnContextMenuRequested(event -> {
                RobotRow row = cell.getTableRow().getItem();
                if (row != null && !row.isPlaceholder()) {
                    ContextMenu menu = createRowContextMenu(row);
                    menu.show(cell, event.getScreenX(), event.getScreenY());
                    event.consume();
                }
            });

            return cell;
        };
    }

    /**
     * Fills down from the selected row to the bottom of the table
     */
    private void fillDown(RobotRow sourceRow) {
        int startRow = sourceRow.rowNumber.get();

        Logger.info("Fill down from row " + startRow);

        for (int i = startRow; i < robotRows.size(); i++) {
            RobotRow targetRow = robotRows.get(i);
            if (targetRow.rowNumber.get() > startRow) {
                copyRowValues(sourceRow, targetRow);
            }
        }

        tableView.refresh();
        Logger.info("Filled down from row " + startRow + " to row " + robotRows.size());
    }

    /**
     * Fills the entire column with values from the selected row
     */
    private void fillColumn(RobotRow sourceRow) {
        Logger.info("Fill column from row " + sourceRow.rowNumber.get());

        for (RobotRow targetRow : robotRows) {
            if (targetRow != sourceRow) {
                copyRowValues(sourceRow, targetRow);
            }
        }

        tableView.refresh();
        Logger.info("Filled entire column from row " + sourceRow.rowNumber.get());
    }

    /**
     * Duplicates a row into the row immediately below it
     */
    private void duplicateRow(RobotRow sourceRow) {
        int sourceRowNum = sourceRow.rowNumber.get();

        if (sourceRowNum >= 500) {
            Logger.warning("Cannot duplicate last row - no row below");
            return;
        }

        int targetRowNum = sourceRowNum + 1;
        RobotRow targetRow = robotRows.get(targetRowNum - 1);

        Logger.info("Duplicating row " + sourceRowNum + " to row " + targetRowNum);

        copyRowValues(sourceRow, targetRow);

        tableView.refresh();
        Logger.info("Row " + sourceRowNum + " duplicated to row " + targetRowNum);
    }

    /**
     * Copies all values from source row to target row (except row number)
     */
    private void copyRowValues(RobotRow source, RobotRow target) {
        // Copy magic number and robot name
        target.magicNumber.set(source.magicNumber.get());
        target.robotName.set(source.robotName.get());

        // Copy all other fields
        target.symbol.set(source.symbol.get());
        target.timeframe.set(source.timeframe.get());
        target.closeHour.set(source.closeHour.get());
        target.closeMinute.set(source.closeMinute.get());
        target.minX1Height.set(source.minX1Height.get());
        target.x1Type.set(source.x1Type.get());
        target.trigPercent.set(source.trigPercent.get());
        target.stopLossPercent.set(source.stopLossPercent.get());
        target.rptPercent.set(source.rptPercent.get());
        target.rptFixedAmount.set(source.rptFixedAmount.get());
        target.tp1Percent.set(source.tp1Percent.get());
        target.tp1Volume.set(source.tp1Volume.get());
        target.tp2Percent.set(source.tp2Percent.get());
        target.tp2Volume.set(source.tp2Volume.get());
        target.tp3Percent.set(source.tp3Percent.get());
        target.tp3Volume.set(source.tp3Volume.get());
        target.tp4Percent.set(source.tp4Percent.get());
        target.tp4Volume.set(source.tp4Volume.get());
        target.tp5Percent.set(source.tp5Percent.get());
        target.tp5Volume.set(source.tp5Volume.get());
        target.tp6Percent.set(source.tp6Percent.get());
        target.tp6Volume.set(source.tp6Volume.get());
        target.tp7Percent.set(source.tp7Percent.get());
        target.tp7Volume.set(source.tp7Volume.get());

        // Mark target as no longer a placeholder if source isn't
        if (!source.isPlaceholder()) {
            target.setPlaceholder(false);
        }
    }

    private void clearRow(RobotRow row) {
        Logger.info("Clearing row " + row.rowNumber.get());

        row.active.set(false);
        row.magicNumber.set("");
        row.robotName.set("");
        row.symbol.set("");
        row.timeframe.set("");
        row.closeHour.set(0);
        row.closeMinute.set(0);
        row.minX1Height.set(0.0);
        row.x1Type.set("");
        row.trigPercent.set(0.0);
        row.stopLossPercent.set(0.0);
        row.rptPercent.set(0.0);
        row.rptFixedAmount.set(0.0);
        row.tp1Percent.set(0.0);
        row.tp1Volume.set(0);
        row.tp2Percent.set(0.0);
        row.tp2Volume.set(0);
        row.tp3Percent.set(0.0);
        row.tp3Volume.set(0);
        row.tp4Percent.set(0.0);
        row.tp4Volume.set(0);
        row.tp5Percent.set(0.0);
        row.tp5Volume.set(0);
        row.tp6Percent.set(0.0);
        row.tp6Volume.set(0);
        row.tp7Percent.set(0.0);
        row.tp7Volume.set(0);

        row.setPlaceholder(true);

        tableView.refresh();
        Logger.info("Row " + row.rowNumber.get() + " cleared");
    }

    private void clearAllRows(RobotRow startRow) {
        int startRowNum = startRow.rowNumber.get();
        Logger.info("Clearing all rows from row " + startRowNum + " to bottom");

        for (int i = startRowNum; i <= 500; i++) {
            RobotRow row = robotRows.get(i - 1);
            clearRow(row);
        }

        tableView.refresh();
        Logger.info("Cleared rows from " + startRowNum + " to 500");
    }

    private void loadRobots() {
        // Create 500 placeholder rows
        for (int i = 1; i <= 500; i++) {
            RobotRow row = new RobotRow(i);
            robotRows.add(row);

            // Add listener for active property changes ONLY
            row.activeProperty().addListener((obs, oldValue, newValue) -> {
                // Only trigger if user toggled the checkbox
                if (oldValue != newValue) {
                    Logger.info("Active property changed for row " + row.rowNumber.get() + ": " + oldValue + " -> " + newValue);
                    if (newValue && row.isPlaceholder()) {
                        // Activate robot - populate with defaults
                        activateRobot(row);
                    } else if (!newValue && !row.isPlaceholder()) {
                        // Deactivate robot
                        deactivateRobot(row);
                    } else if (newValue && !row.isPlaceholder()) {
                        // Re-activating an already configured row - just set active flag
                        row.active.set(true);
                        Logger.info("Re-activated row " + row.rowNumber.get() + " without resetting values");
                    }
                }
            });
        }

        // Load saved robot configs from database
        try {
            List<RobotConfig> configs = dbClient.loadRobotConfigs(userId.toString());
            for (RobotConfig config : configs) {
                int rowNum = config.getRobotNumber();
                if (rowNum >= 1 && rowNum <= 500) {
                    RobotRow row = robotRows.get(rowNum - 1);
                    row.updateFromConfig(config);
                    savedConfigs.put(rowNum, config);
                }
            }
            Logger.info("Loaded " + configs.size() + " saved robot configs from database");
        } catch (Exception e) {
            Logger.error("Failed to load robot configs: " + e.getMessage());
        }

        Logger.info("Initialized 500 robot rows");
    }

    private void activateRobot(RobotRow row) {
        int rowNum = row.rowNumber.get();
        Logger.info("Activating robot at row " + rowNum);

        try {
            RobotConfig config = savedConfigs.get(rowNum);

            if (config == null) {
                // FIRST TIME ACTIVATION - Load default values from system_config
                Map<String, Object> defaults = getDefaultValues();

                Logger.info("Applying defaults to row " + rowNum + ": " + defaults);

                // Apply defaults to the row
                row.symbol.set((String) defaults.getOrDefault("symbol", "XAUUSD"));
                row.timeframe.set((String) defaults.getOrDefault("timeframe", "H1"));
                row.closeHour.set(((Number) defaults.getOrDefault("close_hour", 15)).intValue());
                row.closeMinute.set(((Number) defaults.getOrDefault("close_minute", 30)).intValue());
                row.minX1Height.set(((Number) defaults.getOrDefault("min_x1_height", 7.0)).doubleValue());
                row.x1Type.set((String) defaults.getOrDefault("x1_type", "Cents"));
                row.trigPercent.set(((Number) defaults.getOrDefault("trig_percent", 13.0)).doubleValue());
                row.stopLossPercent.set(((Number) defaults.getOrDefault("stop_loss_percent", 13.0)).doubleValue());
                row.rptPercent.set(((Number) defaults.getOrDefault("rpt_percent", 0.3)).doubleValue());
                row.rptFixedAmount.set(((Number) defaults.getOrDefault("rpt_fixed_amount", 0.0)).doubleValue());
                row.tp1Percent.set(((Number) defaults.getOrDefault("tp1_percent", 100.0)).doubleValue());
                row.tp1Volume.set(((Number) defaults.getOrDefault("tp1_volume", 14)).intValue());
                row.tp2Percent.set(((Number) defaults.getOrDefault("tp2_percent", 110.0)).doubleValue());
                row.tp2Volume.set(((Number) defaults.getOrDefault("tp2_volume", 14)).intValue());
                row.tp3Percent.set(((Number) defaults.getOrDefault("tp3_percent", 125.0)).doubleValue());
                row.tp3Volume.set(((Number) defaults.getOrDefault("tp3_volume", 14)).intValue());
                row.tp4Percent.set(((Number) defaults.getOrDefault("tp4_percent", 150.0)).doubleValue());
                row.tp4Volume.set(((Number) defaults.getOrDefault("tp4_volume", 14)).intValue());
                row.tp5Percent.set(((Number) defaults.getOrDefault("tp5_percent", 200.0)).doubleValue());
                row.tp5Volume.set(((Number) defaults.getOrDefault("tp5_volume", 14)).intValue());
                row.tp6Percent.set(((Number) defaults.getOrDefault("tp6_percent", 250.0)).doubleValue());
                row.tp6Volume.set(((Number) defaults.getOrDefault("tp6_volume", 14)).intValue());
                row.tp7Percent.set(((Number) defaults.getOrDefault("tp7_percent", 300.0)).doubleValue());
                row.tp7Volume.set(((Number) defaults.getOrDefault("tp7_volume", 16)).intValue());

                // Mark as no longer placeholder IMMEDIATELY after setting values
                row.setPlaceholder(false);

                Logger.info("Row " + rowNum + " activated with default values");
            } else {
                // SUBSEQUENT ACTIVATION - Load saved values
                row.updateFromConfig(config);
                Logger.info("Row " + rowNum + " activated with saved values");
            }

            // Force table refresh
            tableView.refresh();

            // Request magic number from MT5
            // TODO: Implement MT5 magic number assignment

        } catch (Exception e) {
            Logger.error("Failed to activate robot at row " + rowNum + ": " + e.getMessage());
            e.printStackTrace();
            row.active.set(false);
        }
    }

    private void deactivateRobot(RobotRow row) {
        int rowNum = row.rowNumber.get();
        Logger.info("Deactivating robot at row " + rowNum);

        row.active.set(false);
        // Keep values visible - don't clear them
        // TODO: Update is_active in database
    }

    public TableView<RobotRow> getTableView() {
        return tableView;
    }

    public ObservableList<RobotRow> getRobotRows() {
        return robotRows;
    }

    /**
     * Saves all active robot configurations to Supabase
     */
    private void saveLayout() {
        Logger.info("Saving layout to Supabase...");
        System.out.println("[DEBUG] saveLayout() method called");
        System.out.println("[DEBUG] userId: " + userId);
        System.out.println("[DEBUG] Total rows: " + robotRows.size());

        try {
            int savedCount = 0;

            for (RobotRow row : robotRows) {
                System.out.println("[DEBUG] Checking row " + row.rowNumber.get() + ", active: " + row.active.get());
                if (row.active.get()) {
                    System.out.println("[DEBUG] Saving active row " + row.rowNumber.get());
                    // Create RobotConfig from row
                    RobotConfig config = createConfigFromRow(row);
                    System.out.println("[DEBUG] Created config from row: " + config.getRowNumber());

                    // Save or update in database
                    System.out.println("[DEBUG] Calling upsertRobotConfig...");
                    RobotConfig saved = upsertRobotConfig(config);
                    System.out.println("[DEBUG] upsertRobotConfig completed");

                    // Update local cache
                    savedConfigs.put(row.rowNumber.get(), saved);
                    row.setRobotConfigId(saved.getId());

                    savedCount++;
                }
            }

            final int finalSavedCount = savedCount;
            Logger.info("Successfully saved " + finalSavedCount + " robot configurations");

            // Show confirmation to user
            Platform.runLater(() -> {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Layout Saved");
                alert.setHeaderText(null);
                alert.setContentText("Successfully saved " + finalSavedCount + " robot configurations to database.");
                alert.showAndWait();
            });

        } catch (Exception e) {
            Logger.error("Failed to save layout: " + e.getMessage());
            System.err.println("[ERROR] saveLayout failed: " + e.getMessage());
            e.printStackTrace();

            final String errorMessage = e.getMessage();
            Platform.runLater(() -> {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Save Failed");
                alert.setHeaderText("Failed to save layout");
                alert.setContentText(errorMessage);
                alert.showAndWait();
            });
        }
    }

    /**
     * Gets default robot values from system config or uses hardcoded defaults
     */
    private Map<String, Object> getDefaultValues() {
        try {
            Map<String, Object> defaults = dbClient.loadDefaultValues(userId.toString());
            if (defaults != null) {
                return defaults;
            }
        } catch (Exception e) {
            Logger.error("Failed to load default values from database: " + e.getMessage());
        }

        // Return hardcoded defaults
        Map<String, Object> defaults = new HashMap<>();
        defaults.put("symbol", "XAUUSD");
        defaults.put("timeframe", "H1");
        defaults.put("close_hour", 15);
        defaults.put("close_minute", 30);
        defaults.put("min_x1_height", 7.0);
        defaults.put("x1_type", "Cents");
        defaults.put("trig_percent", 13.0);
        defaults.put("stop_loss_percent", 13.0);
        defaults.put("rpt_percent", 0.3);
        defaults.put("rpt_fixed_amount", 0.0);
        defaults.put("tp1_percent", 100.0);
        defaults.put("tp1_volume", 14);
        defaults.put("tp2_percent", 110.0);
        defaults.put("tp2_volume", 14);
        defaults.put("tp3_percent", 125.0);
        defaults.put("tp3_volume", 14);
        defaults.put("tp4_percent", 150.0);
        defaults.put("tp4_volume", 14);
        defaults.put("tp5_percent", 200.0);
        defaults.put("tp5_volume", 14);
        defaults.put("tp6_percent", 250.0);
        defaults.put("tp6_volume", 14);
        defaults.put("tp7_percent", 300.0);
        defaults.put("tp7_volume", 16);

        return defaults;
    }

    /**
     * Upserts (insert or update) a robot config
     */
    private RobotConfig upsertRobotConfig(RobotConfig config) throws Exception {
        Logger.info("Upserting robot config for robot " + config.getRobotNumber());

        try {
            dbClient.upsertRobotConfig(config.getUserId().toString(), config);
            Logger.info("Successfully saved robot config");
            return config;
        } catch (Exception e) {
            Logger.error("Failed to upsert robot config: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * Creates a RobotConfig from a RobotRow
     */
    private RobotConfig createConfigFromRow(RobotRow row) {
        RobotConfig config = new RobotConfig();

        config.setId(row.getRobotConfigId());
        config.setUserId(userId);
        config.setRobotNumber(row.rowNumber.get());
        config.setActive(row.active.get());
        config.setMagicNumber(row.magicNumber.get());
        config.setRobotName(row.robotName.get());
        config.setSymbol(row.symbol.get());
        config.setTimeframe(row.timeframe.get());
        config.setCloseHour(row.closeHour.get());
        config.setCloseMinute(row.closeMinute.get());
        config.setMinX1Height(row.minX1Height.get());
        config.setX1Type(row.x1Type.get());
        config.setTrigPercent(row.trigPercent.get());
        config.setStopLossPercent(row.stopLossPercent.get());
        config.setRptPercent(row.rptPercent.get());
        config.setRptFixedAmount(row.rptFixedAmount.get());
        config.setTp1Percent(row.tp1Percent.get());
        config.setTp1Volume(row.tp1Volume.get());
        config.setTp2Percent(row.tp2Percent.get());
        config.setTp2Volume(row.tp2Volume.get());
        config.setTp3Percent(row.tp3Percent.get());
        config.setTp3Volume(row.tp3Volume.get());
        config.setTp4Percent(row.tp4Percent.get());
        config.setTp4Volume(row.tp4Volume.get());
        config.setTp5Percent(row.tp5Percent.get());
        config.setTp5Volume(row.tp5Volume.get());
        config.setTp6Percent(row.tp6Percent.get());
        config.setTp6Volume(row.tp6Volume.get());
        config.setTp7Percent(row.tp7Percent.get());
        config.setTp7Volume(row.tp7Volume.get());

        System.out.println("[DEBUG] Config from row " + row.rowNumber.get() + ": symbol=" + config.getSymbol() + ", timeframe=" + config.getTimeframe());
        return config;
    }

    /**
     * Shows dialog to set default values for new robots
     */
    private void showSetDefaultsDialog() {
        System.out.println("[DEBUG] showSetDefaultsDialog() called");
        Map<String, Object> currentDefaults = getDefaultValues();
        System.out.println("[DEBUG] Current defaults: " + currentDefaults);

        DefaultValuesDialog dialog = new DefaultValuesDialog(currentDefaults);
        dialog.showAndWait().ifPresent(newDefaults -> {
            System.out.println("[DEBUG] User confirmed new defaults: " + newDefaults);
            try {
                System.out.println("[DEBUG] Calling saveDefaultValues...");
                saveDefaultValues(newDefaults);
                System.out.println("[DEBUG] saveDefaultValues completed");
                Logger.info("Default values updated successfully");

                Platform.runLater(() -> {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Defaults Updated");
                    alert.setHeaderText(null);
                    alert.setContentText("Default values have been saved. New activated robots will use these values.");
                    alert.showAndWait();
                });

            } catch (Exception e) {
                Logger.error("Failed to save default values: " + e.getMessage());
                System.err.println("[ERROR] Failed to save default values: " + e.getMessage());
                e.printStackTrace();

                final String errorMessage = "Error: " + e.getMessage() + "\n\nCheck the console log for details.";
                Platform.runLater(() -> {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Save Failed");
                    alert.setHeaderText("Failed to save default values");
                    alert.setContentText(errorMessage);
                    alert.showAndWait();
                });
            }
        });
    }

    /**
     * Shows default values dialog (called from control panel)
     */
    private void saveDefaultValues() {
        showSetDefaultsDialog();
    }

    /**
     * Saves default values to system config in database
     */
    private void saveDefaultValues(Map<String, Object> defaults) throws Exception {
        System.out.println("[DEBUG] saveDefaultValues called with userId: " + userId);
        System.out.println("[DEBUG] Raw defaults map: " + defaults);

        Map<String, Object> typedDefaults = new HashMap<>();

        typedDefaults.put("symbol", defaults.get("symbol").toString());
        typedDefaults.put("timeframe", defaults.get("timeframe").toString());
        typedDefaults.put("x1_type", defaults.get("x1_type").toString());
        typedDefaults.put("close_hour", Integer.parseInt(defaults.get("close_hour").toString()));
        typedDefaults.put("close_minute", Integer.parseInt(defaults.get("close_minute").toString()));
        typedDefaults.put("min_x1_height", Double.parseDouble(defaults.get("min_x1_height").toString()));
        typedDefaults.put("trig_percent", Double.parseDouble(defaults.get("trig_percent").toString()));
        typedDefaults.put("stop_loss_percent", Double.parseDouble(defaults.get("stop_loss_percent").toString()));
        typedDefaults.put("rpt_percent", Double.parseDouble(defaults.get("rpt_percent").toString()));
        typedDefaults.put("rpt_fixed_amount", Double.parseDouble(defaults.get("rpt_fixed_amount").toString()));
        typedDefaults.put("tp1_percent", Double.parseDouble(defaults.get("tp1_percent").toString()));
        typedDefaults.put("tp1_volume", Integer.parseInt(defaults.get("tp1_volume").toString()));
        typedDefaults.put("tp2_percent", Double.parseDouble(defaults.get("tp2_percent").toString()));
        typedDefaults.put("tp2_volume", Integer.parseInt(defaults.get("tp2_volume").toString()));
        typedDefaults.put("tp3_percent", Double.parseDouble(defaults.get("tp3_percent").toString()));
        typedDefaults.put("tp3_volume", Integer.parseInt(defaults.get("tp3_volume").toString()));
        typedDefaults.put("tp4_percent", Double.parseDouble(defaults.get("tp4_percent").toString()));
        typedDefaults.put("tp4_volume", Integer.parseInt(defaults.get("tp4_volume").toString()));
        typedDefaults.put("tp5_percent", Double.parseDouble(defaults.get("tp5_percent").toString()));
        typedDefaults.put("tp5_volume", Integer.parseInt(defaults.get("tp5_volume").toString()));
        typedDefaults.put("tp6_percent", Double.parseDouble(defaults.get("tp6_percent").toString()));
        typedDefaults.put("tp6_volume", Integer.parseInt(defaults.get("tp6_volume").toString()));
        typedDefaults.put("tp7_percent", Double.parseDouble(defaults.get("tp7_percent").toString()));
        typedDefaults.put("tp7_volume", Integer.parseInt(defaults.get("tp7_volume").toString()));

        System.out.println("[DEBUG] Typed defaults map: " + typedDefaults);

        try {
            dbClient.saveDefaultValues(userId.toString(), typedDefaults);
            Logger.info("Default values saved successfully");
        } catch (Exception e) {
            Logger.error("Failed to save default values: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }
}
