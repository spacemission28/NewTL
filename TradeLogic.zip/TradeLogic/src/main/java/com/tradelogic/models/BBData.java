package com.tradelogic.models;

public class BBData {
    private final String symbol;
    private final String timeframe;
    private final long timestampSeconds;
    private final double bbUpper;
    private final double bbMiddle;
    private final double bbLower;
    private final double bbValue;

    public BBData(String symbol, String timeframe, long timestampSeconds, double bbUpper, double bbMiddle, double bbLower, double bbValue) {
        this.symbol = symbol;
        this.timeframe = timeframe != null ? timeframe : "M1";
        this.timestampSeconds = timestampSeconds;
        this.bbUpper = bbUpper;
        this.bbMiddle = bbMiddle;
        this.bbLower = bbLower;
        this.bbValue = bbValue;
    }

    public String getKey() {
        return symbol + "_" + timeframe;
    }

    public String getSymbol() {
        return symbol;
    }

    public String getTimeframe() {
        return timeframe;
    }

    public long getTimestampSeconds() {
        return timestampSeconds;
    }

    public double getBbUpper() {
        return bbUpper;
    }

    public double getBbMiddle() {
        return bbMiddle;
    }

    public double getBbLower() {
        return bbLower;
    }

    public double getBbValue() {
        return bbValue;
    }
}
