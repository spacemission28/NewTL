package com.tradelogic.models;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Model class representing a trade command in the RRC (Request-Response-Confirmation) mechanism.
 * Maps to the trade_commands table in Supabase.
 * Commands are queued by Java, polled by MT5 EA, and confirmed via execution feedback.
 */
public class TradeCommand {
    private UUID id;
    private String commandId; // Unique identifier for this command (UUID string)
    private UUID robotConfigId;
    private String magicNumber;

    // Command Details
    private String action; // PLACE_ORDER, MODIFY_ORDER, CLOSE_POSITION, CANCEL_ORDER, EMERGENCY_CLOSE_ALL
    private Map<String, Object> parameters;

    // Status Tracking
    private String status; // QUEUED, SENT, CONFIRMED, FAILED, TIMEOUT
    private Instant queuedAt;
    private Instant sentAt;
    private Instant confirmedAt;

    // Execution Feedback
    private Integer retcode;
    private String feedback; // JSON string
    private String errorMessage;

    // Metadata
    private Instant createdAt;

    private static final Gson gson = new GsonBuilder().create();

    // Default constructor
    public TradeCommand() {
        this.commandId = UUID.randomUUID().toString();
        this.parameters = new HashMap<>();
        this.status = "QUEUED";
        this.queuedAt = Instant.now();
        this.createdAt = Instant.now();
    }

    // Constructor for creating a new command
    public TradeCommand(UUID robotConfigId, String magicNumber, String action, Map<String, Object> parameters) {
        this();
        this.robotConfigId = robotConfigId;
        this.magicNumber = magicNumber;
        this.action = action;
        this.parameters = parameters;
    }

    // Getters and Setters
    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getCommandId() {
        return commandId;
    }

    public void setCommandId(String commandId) {
        this.commandId = commandId;
    }

    public UUID getRobotConfigId() {
        return robotConfigId;
    }

    public void setRobotConfigId(UUID robotConfigId) {
        this.robotConfigId = robotConfigId;
    }

    public String getMagicNumber() {
        return magicNumber;
    }

    public void setMagicNumber(String magicNumber) {
        this.magicNumber = magicNumber;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public Map<String, Object> getParameters() {
        return parameters;
    }

    public void setParameters(Map<String, Object> parameters) {
        this.parameters = parameters;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Instant getQueuedAt() {
        return queuedAt;
    }

    public void setQueuedAt(Instant queuedAt) {
        this.queuedAt = queuedAt;
    }

    public Instant getSentAt() {
        return sentAt;
    }

    public void setSentAt(Instant sentAt) {
        this.sentAt = sentAt;
    }

    public Instant getConfirmedAt() {
        return confirmedAt;
    }

    public void setConfirmedAt(Instant confirmedAt) {
        this.confirmedAt = confirmedAt;
    }

    public Integer getRetcode() {
        return retcode;
    }

    public void setRetcode(Integer retcode) {
        this.retcode = retcode;
    }

    public String getFeedback() {
        return feedback;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    /**
     * Converts the command to JSON format for transmission to MT5 EA
     * Format: {"command_id":"...", "magic":1001, "action":"...", "params":{...}}
     */
    public String toJson() {
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("command_id", commandId);
        jsonMap.put("magic", magicNumber);
        jsonMap.put("action", action);
        jsonMap.put("params", parameters);
        return gson.toJson(jsonMap);
    }

    /**
     * Marks the command as sent
     */
    public void markAsSent() {
        this.status = "SENT";
        this.sentAt = Instant.now();
    }

    /**
     * Marks the command as confirmed
     */
    public void markAsConfirmed(int retcode, String feedback) {
        this.status = "CONFIRMED";
        this.confirmedAt = Instant.now();
        this.retcode = retcode;
        this.feedback = feedback;
    }

    /**
     * Marks the command as failed
     */
    public void markAsFailed(int retcode, String errorMessage) {
        this.status = "FAILED";
        this.retcode = retcode;
        this.errorMessage = errorMessage;
    }

    /**
     * Marks the command as timed out
     */
    public void markAsTimeout() {
        this.status = "TIMEOUT";
        this.errorMessage = "Command timed out waiting for execution feedback";
    }

    /**
     * Checks if the command has exceeded timeout threshold (30 seconds)
     */
    public boolean isTimedOut() {
        if (queuedAt == null) {
            return false;
        }
        return Instant.now().getEpochSecond() - queuedAt.getEpochSecond() > 30;
    }
}
