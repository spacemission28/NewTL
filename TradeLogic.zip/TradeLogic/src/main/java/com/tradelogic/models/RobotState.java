package com.tradelogic.models;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

/**
 * Model class representing real-time state of a trading robot.
 * Maps to the robot_states table in Supabase.
 * Updated continuously by the state monitor service.
 */
public class RobotState {
    private UUID id;
    private UUID robotConfigId;

    // Current Signal Candle State
    private Instant lastSignalDate;
    private Double signalCandleHigh;
    private Double signalCandleLow;
    private boolean signalProcessed;
    private boolean tradePlacedToday;

    // Active Trade Info
    private boolean tradingActive;
    private Long activePositionTicket;
    private int activeOrdersCount;
    private List<Long> pendingOrderTickets;

    // Connection Status
    private String connectionStatus; // CONNECTED, DISCONNECTED, ERROR, UNKNOWN
    private Instant lastHeartbeat;

    // Real-time P&L
    private double currentProfitLoss;

    // Metadata
    private Instant updatedAt;

    // Default constructor
    public RobotState() {
        this.connectionStatus = "UNKNOWN";
        this.currentProfitLoss = 0.0;
        this.signalProcessed = false;
        this.tradePlacedToday = false;
        this.tradingActive = false;
        this.activeOrdersCount = 0;
    }

    // Getters and Setters
    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public UUID getRobotConfigId() {
        return robotConfigId;
    }

    public void setRobotConfigId(UUID robotConfigId) {
        this.robotConfigId = robotConfigId;
    }

    public Instant getLastSignalDate() {
        return lastSignalDate;
    }

    public void setLastSignalDate(Instant lastSignalDate) {
        this.lastSignalDate = lastSignalDate;
    }

    public Double getSignalCandleHigh() {
        return signalCandleHigh;
    }

    public void setSignalCandleHigh(Double signalCandleHigh) {
        this.signalCandleHigh = signalCandleHigh;
    }

    public Double getSignalCandleLow() {
        return signalCandleLow;
    }

    public void setSignalCandleLow(Double signalCandleLow) {
        this.signalCandleLow = signalCandleLow;
    }

    public boolean isSignalProcessed() {
        return signalProcessed;
    }

    public void setSignalProcessed(boolean signalProcessed) {
        this.signalProcessed = signalProcessed;
    }

    public boolean isTradePlacedToday() {
        return tradePlacedToday;
    }

    public void setTradePlacedToday(boolean tradePlacedToday) {
        this.tradePlacedToday = tradePlacedToday;
    }

    public boolean isTradingActive() {
        return tradingActive;
    }

    public void setTradingActive(boolean tradingActive) {
        this.tradingActive = tradingActive;
    }

    public Long getActivePositionTicket() {
        return activePositionTicket;
    }

    public void setActivePositionTicket(Long activePositionTicket) {
        this.activePositionTicket = activePositionTicket;
    }

    public int getActiveOrdersCount() {
        return activeOrdersCount;
    }

    public void setActiveOrdersCount(int activeOrdersCount) {
        this.activeOrdersCount = activeOrdersCount;
    }

    public List<Long> getPendingOrderTickets() {
        return pendingOrderTickets;
    }

    public void setPendingOrderTickets(List<Long> pendingOrderTickets) {
        this.pendingOrderTickets = pendingOrderTickets;
    }

    public String getConnectionStatus() {
        return connectionStatus;
    }

    public void setConnectionStatus(String connectionStatus) {
        this.connectionStatus = connectionStatus;
    }

    public Instant getLastHeartbeat() {
        return lastHeartbeat;
    }

    public void setLastHeartbeat(Instant lastHeartbeat) {
        this.lastHeartbeat = lastHeartbeat;
    }

    public double getCurrentProfitLoss() {
        return currentProfitLoss;
    }

    public void setCurrentProfitLoss(double currentProfitLoss) {
        this.currentProfitLoss = currentProfitLoss;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    /**
     * Checks if the robot is connected (heartbeat within last 5 seconds)
     */
    public boolean isConnected() {
        if (lastHeartbeat == null) {
            return false;
        }
        return Instant.now().getEpochSecond() - lastHeartbeat.getEpochSecond() < 5;
    }

    /**
     * Returns status emoji for UI display
     */
    public String getStatusEmoji() {
        if (!isConnected()) {
            return "⚪"; // Disconnected
        }
        switch (connectionStatus) {
            case "CONNECTED":
                return tradingActive ? "🟢" : "🟡"; // Green if trading, yellow if idle
            case "ERROR":
                return "🔴"; // Red for errors
            default:
                return "⚪"; // Unknown
        }
    }
}
