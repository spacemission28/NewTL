package com.tradelogic.models;

import java.time.Instant;
import java.util.UUID;

/**
 * Model class representing a trading robot configuration.
 * Maps to the robot_configs table in Supabase.
 * Each robot represents one asset/timeframe combination with specific trading parameters.
 */
public class RobotConfig {
    private UUID id;
    private UUID userId;
    private int rowNumber;

    // Identity
    private String magicNumber;
    private String robotName;
    private String symbol;
    private String timeframe;

    // Signal Candle Timing
    private int closeHour;
    private int closeMinute;

    // Risk Parameters
    private double minX1Height;
    private String x1Type;
    private double trigPercent;
    private double stopLossPercent;
    private Double rptPercent;
    private Double rptFixedAmount;
    private double dailyDdLimit;

    // Take Profit Levels
    private double tp1Percent;
    private int tp1Volume;
    private double tp2Percent;
    private int tp2Volume;
    private double tp3Percent;
    private int tp3Volume;
    private double tp4Percent;
    private int tp4Volume;
    private double tp5Percent;
    private int tp5Volume;
    private double tp6Percent;
    private int tp6Volume;
    private double tp7Percent;
    private int tp7Volume;

    // Trading Controls
    private boolean autoTradingEnabled;
    private boolean disableLeapfrog;
    private boolean smartTS;
    private Integer profitCandleLimit;
    private boolean endTimeEnabled;
    private Integer endHour;
    private Integer endMinute;
    private boolean eodEnabled;

    // Pattern Detection
    private boolean x3StrictEnabled;
    private boolean x3RelaxedEnabled;
    private boolean x1BreachRequired;

    // Bollinger Band Controls
    private boolean bbEntryCheck;
    private boolean counterTrendBB;
    private boolean useSequenceSL;

    // Strong Thrust
    private boolean strongThrust;

    // Orthodox CC (Orthodox Crossover)
    private boolean orthodoxCC;

    // All Day (hunt for entries all day for Strong Thrust and Orthodox CC)
    private boolean allDay;

    // Commissions
    private boolean commissionsEnabled;
    private String commissionType;
    private Double commissionValue;

    // Activation State
    private boolean active;
    private String lastActiveConfig; // JSON string

    // Metadata
    private Instant createdAt;
    private Instant updatedAt;

    // Default constructor
    public RobotConfig() {
    }

    // Getters and Setters
    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public UUID getUserId() {
        return userId;
    }

    public void setUserId(UUID userId) {
        this.userId = userId;
    }

    public int getRowNumber() {
        return rowNumber;
    }

    public void setRowNumber(int rowNumber) {
        this.rowNumber = rowNumber;
    }

    public String getMagicNumber() {
        return magicNumber;
    }

    public void setMagicNumber(String magicNumber) {
        this.magicNumber = magicNumber;
    }

    public String getRobotName() {
        return robotName;
    }

    public void setRobotName(String robotName) {
        this.robotName = robotName;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getTimeframe() {
        return timeframe;
    }

    public void setTimeframe(String timeframe) {
        this.timeframe = timeframe;
    }

    public int getCloseHour() {
        return closeHour;
    }

    public void setCloseHour(int closeHour) {
        this.closeHour = closeHour;
    }

    public int getCloseMinute() {
        return closeMinute;
    }

    public void setCloseMinute(int closeMinute) {
        this.closeMinute = closeMinute;
    }

    public double getMinX1Height() {
        return minX1Height;
    }

    public void setMinX1Height(double minX1Height) {
        this.minX1Height = minX1Height;
    }

    public String getX1Type() {
        return x1Type;
    }

    public void setX1Type(String x1Type) {
        this.x1Type = x1Type;
    }

    public double getTrigPercent() {
        return trigPercent;
    }

    public void setTrigPercent(double trigPercent) {
        this.trigPercent = trigPercent;
    }

    public double getStopLossPercent() {
        return stopLossPercent;
    }

    public void setStopLossPercent(double stopLossPercent) {
        this.stopLossPercent = stopLossPercent;
    }

    public Double getRptPercent() {
        return rptPercent;
    }

    public void setRptPercent(Double rptPercent) {
        this.rptPercent = rptPercent;
    }

    public Double getRptFixedAmount() {
        return rptFixedAmount;
    }

    public void setRptFixedAmount(Double rptFixedAmount) {
        this.rptFixedAmount = rptFixedAmount;
    }

    public double getTp1Percent() {
        return tp1Percent;
    }

    public void setTp1Percent(double tp1Percent) {
        this.tp1Percent = tp1Percent;
    }

    public int getTp1Volume() {
        return tp1Volume;
    }

    public void setTp1Volume(int tp1Volume) {
        this.tp1Volume = tp1Volume;
    }

    public double getTp2Percent() {
        return tp2Percent;
    }

    public void setTp2Percent(double tp2Percent) {
        this.tp2Percent = tp2Percent;
    }

    public int getTp2Volume() {
        return tp2Volume;
    }

    public void setTp2Volume(int tp2Volume) {
        this.tp2Volume = tp2Volume;
    }

    public double getTp3Percent() {
        return tp3Percent;
    }

    public void setTp3Percent(double tp3Percent) {
        this.tp3Percent = tp3Percent;
    }

    public int getTp3Volume() {
        return tp3Volume;
    }

    public void setTp3Volume(int tp3Volume) {
        this.tp3Volume = tp3Volume;
    }

    public double getTp4Percent() {
        return tp4Percent;
    }

    public void setTp4Percent(double tp4Percent) {
        this.tp4Percent = tp4Percent;
    }

    public int getTp4Volume() {
        return tp4Volume;
    }

    public void setTp4Volume(int tp4Volume) {
        this.tp4Volume = tp4Volume;
    }

    public double getTp5Percent() {
        return tp5Percent;
    }

    public void setTp5Percent(double tp5Percent) {
        this.tp5Percent = tp5Percent;
    }

    public int getTp5Volume() {
        return tp5Volume;
    }

    public void setTp5Volume(int tp5Volume) {
        this.tp5Volume = tp5Volume;
    }

    public double getTp6Percent() {
        return tp6Percent;
    }

    public void setTp6Percent(double tp6Percent) {
        this.tp6Percent = tp6Percent;
    }

    public int getTp6Volume() {
        return tp6Volume;
    }

    public void setTp6Volume(int tp6Volume) {
        this.tp6Volume = tp6Volume;
    }

    public double getTp7Percent() {
        return tp7Percent;
    }

    public void setTp7Percent(double tp7Percent) {
        this.tp7Percent = tp7Percent;
    }

    public int getTp7Volume() {
        return tp7Volume;
    }

    public void setTp7Volume(int tp7Volume) {
        this.tp7Volume = tp7Volume;
    }

    public boolean isAutoTradingEnabled() {
        return autoTradingEnabled;
    }

    public void setAutoTradingEnabled(boolean autoTradingEnabled) {
        this.autoTradingEnabled = autoTradingEnabled;
    }

    public boolean isDisableLeapfrog() {
        return disableLeapfrog;
    }

    public void setDisableLeapfrog(boolean disableLeapfrog) {
        this.disableLeapfrog = disableLeapfrog;
    }

    public boolean isSmartTS() {
        return smartTS;
    }

    public void setSmartTS(boolean smartTS) {
        this.smartTS = smartTS;
    }

    public Integer getProfitCandleLimit() {
        return profitCandleLimit;
    }

    public void setProfitCandleLimit(Integer profitCandleLimit) {
        this.profitCandleLimit = profitCandleLimit;
    }

    public boolean isEndTimeEnabled() {
        return endTimeEnabled;
    }

    public void setEndTimeEnabled(boolean endTimeEnabled) {
        this.endTimeEnabled = endTimeEnabled;
    }

    public Integer getEndHour() {
        return endHour;
    }

    public void setEndHour(Integer endHour) {
        this.endHour = endHour;
    }

    public Integer getEndMinute() {
        return endMinute;
    }

    public void setEndMinute(Integer endMinute) {
        this.endMinute = endMinute;
    }

    public boolean isEodEnabled() {
        return eodEnabled;
    }

    public void setEodEnabled(boolean eodEnabled) {
        this.eodEnabled = eodEnabled;
    }

    public boolean isX3StrictEnabled() {
        return x3StrictEnabled;
    }

    public void setX3StrictEnabled(boolean x3StrictEnabled) {
        this.x3StrictEnabled = x3StrictEnabled;
    }

    public boolean isX3RelaxedEnabled() {
        return x3RelaxedEnabled;
    }

    public void setX3RelaxedEnabled(boolean x3RelaxedEnabled) {
        this.x3RelaxedEnabled = x3RelaxedEnabled;
    }

    public boolean isX1BreachRequired() {
        return x1BreachRequired;
    }

    public void setX1BreachRequired(boolean x1BreachRequired) {
        this.x1BreachRequired = x1BreachRequired;
    }

    public boolean isBbEntryCheck() {
        return bbEntryCheck;
    }

    public void setBbEntryCheck(boolean bbEntryCheck) {
        this.bbEntryCheck = bbEntryCheck;
    }

    public boolean isCounterTrendBB() {
        return counterTrendBB;
    }

    public void setCounterTrendBB(boolean counterTrendBB) {
        this.counterTrendBB = counterTrendBB;
    }

    public boolean isUseSequenceSL() {
        return useSequenceSL;
    }

    public void setUseSequenceSL(boolean useSequenceSL) {
        this.useSequenceSL = useSequenceSL;
    }

    public boolean isStrongThrust() {
        return strongThrust;
    }

    public void setStrongThrust(boolean strongThrust) {
        this.strongThrust = strongThrust;
    }

    public boolean isOrthodoxCC() {
        return orthodoxCC;
    }

    public void setOrthodoxCC(boolean orthodoxCC) {
        this.orthodoxCC = orthodoxCC;
    }

    public boolean isAllDay() {
        return allDay;
    }

    public void setAllDay(boolean allDay) {
        this.allDay = allDay;
    }

    public boolean isCommissionsEnabled() {
        return commissionsEnabled;
    }

    public void setCommissionsEnabled(boolean commissionsEnabled) {
        this.commissionsEnabled = commissionsEnabled;
    }

    public String getCommissionType() {
        return commissionType;
    }

    public void setCommissionType(String commissionType) {
        this.commissionType = commissionType;
    }

    public Double getCommissionValue() {
        return commissionValue;
    }

    public void setCommissionValue(Double commissionValue) {
        this.commissionValue = commissionValue;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getLastActiveConfig() {
        return lastActiveConfig;
    }

    public void setLastActiveConfig(String lastActiveConfig) {
        this.lastActiveConfig = lastActiveConfig;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    public double getDailyDdLimit() {
        return dailyDdLimit;
    }

    public void setDailyDdLimit(double dailyDdLimit) {
        this.dailyDdLimit = dailyDdLimit;
    }

    public int getRobotNumber() {
        return rowNumber;
    }

    public void setRobotNumber(int robotNumber) {
        this.rowNumber = robotNumber;
    }

    /**
     * Validates that TP volumes sum to 100%
     * @return true if valid, false otherwise
     */
    public boolean validateTPVolumes() {
        int total = tp1Volume + tp2Volume + tp3Volume + tp4Volume +
                   tp5Volume + tp6Volume + tp7Volume;
        return total == 100;
    }

    /**
     * Returns formatted signal time as HH:MM
     */
    public String getFormattedSignalTime() {
        return String.format("%02d:%02d", closeHour, closeMinute);
    }
}
