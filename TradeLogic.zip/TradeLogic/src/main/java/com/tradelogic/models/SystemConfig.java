package com.tradelogic.models;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Model class representing system-wide configuration.
 * Maps to the system_config table in Supabase.
 * Single row per user - stores portfolio-level settings and default values.
 */
public class SystemConfig {
    private UUID id;
    private UUID userId;

    // Portfolio Risk Management
    private double dailyDrawdownHardStop; // Percentage
    private double currentUnrealisedDrawdown; // Percentage
    private boolean maxDailyDrawdownReached;

    // System State
    private boolean masterTradingEnabled; // Master ON/MUTED button state
    private int activeRobotsCount;
    private double totalRptAcrossRobots;

    // Default Values for New Robots
    private String defaultValuesJson; // JSON string

    // Metadata
    private Instant createdAt;
    private Instant updatedAt;

    private static final Gson gson = new GsonBuilder().create();

    // Default constructor
    public SystemConfig() {
        this.dailyDrawdownHardStop = 5.0;
        this.currentUnrealisedDrawdown = 0.0;
        this.maxDailyDrawdownReached = false;
        this.masterTradingEnabled = false;
        this.activeRobotsCount = 0;
        this.totalRptAcrossRobots = 0.0;
        this.createdAt = Instant.now();
        initializeDefaultValues();
    }

    /**
     * Initializes default values with standard settings
     */
    private void initializeDefaultValues() {
        Map<String, Object> defaults = new HashMap<>();
        defaults.put("robot_name", "");
        defaults.put("symbol", "XAUUSD");
        defaults.put("timeframe", "H1");
        defaults.put("close_hour", 15);
        defaults.put("close_minute", 30);
        defaults.put("min_x1_height", 7.0);
        defaults.put("x1_type", "Cents");
        defaults.put("trig_percent", 13.0);
        defaults.put("stop_loss_percent", 13.0);
        defaults.put("rpt_percent", 0.3);
        defaults.put("rpt_fixed_amount", 0.0);
        defaults.put("tp1_percent", 100.0);
        defaults.put("tp1_volume", 14);
        defaults.put("tp2_percent", 110.0);
        defaults.put("tp2_volume", 14);
        defaults.put("tp3_percent", 125.0);
        defaults.put("tp3_volume", 14);
        defaults.put("tp4_percent", 150.0);
        defaults.put("tp4_volume", 14);
        defaults.put("tp5_percent", 200.0);
        defaults.put("tp5_volume", 14);
        defaults.put("tp6_percent", 250.0);
        defaults.put("tp6_volume", 14);
        defaults.put("tp7_percent", 300.0);
        defaults.put("tp7_volume", 16);
        defaults.put("auto_trading_enabled", true);
        defaults.put("disable_leapfrog", true);
        defaults.put("end_time_enabled", true);
        defaults.put("end_hour", 23);
        defaults.put("end_minute", 50);
        defaults.put("commissions_enabled", false);
        defaults.put("commission_type", "FX_per_Lot");
        defaults.put("commission_value", 7.0);

        this.defaultValuesJson = gson.toJson(defaults);
    }

    // Getters and Setters
    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public UUID getUserId() {
        return userId;
    }

    public void setUserId(UUID userId) {
        this.userId = userId;
    }

    public double getDailyDrawdownHardStop() {
        return dailyDrawdownHardStop;
    }

    public void setDailyDrawdownHardStop(double dailyDrawdownHardStop) {
        this.dailyDrawdownHardStop = dailyDrawdownHardStop;
    }

    public double getCurrentUnrealisedDrawdown() {
        return currentUnrealisedDrawdown;
    }

    public void setCurrentUnrealisedDrawdown(double currentUnrealisedDrawdown) {
        this.currentUnrealisedDrawdown = currentUnrealisedDrawdown;
    }

    public boolean isMaxDailyDrawdownReached() {
        return maxDailyDrawdownReached;
    }

    public void setMaxDailyDrawdownReached(boolean maxDailyDrawdownReached) {
        this.maxDailyDrawdownReached = maxDailyDrawdownReached;
    }

    public boolean isMasterTradingEnabled() {
        return masterTradingEnabled;
    }

    public void setMasterTradingEnabled(boolean masterTradingEnabled) {
        this.masterTradingEnabled = masterTradingEnabled;
    }

    public int getActiveRobotsCount() {
        return activeRobotsCount;
    }

    public void setActiveRobotsCount(int activeRobotsCount) {
        this.activeRobotsCount = activeRobotsCount;
    }

    public double getTotalRptAcrossRobots() {
        return totalRptAcrossRobots;
    }

    public void setTotalRptAcrossRobots(double totalRptAcrossRobots) {
        this.totalRptAcrossRobots = totalRptAcrossRobots;
    }

    public String getDefaultValuesJson() {
        return defaultValuesJson;
    }

    public void setDefaultValuesJson(String defaultValuesJson) {
        this.defaultValuesJson = defaultValuesJson;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    /**
     * Gets default values as a Map
     */
    @SuppressWarnings("unchecked")
    public Map<String, Object> getDefaultValues() {
        if (defaultValuesJson == null || defaultValuesJson.isEmpty()) {
            return new HashMap<>();
        }
        return gson.fromJson(defaultValuesJson, Map.class);
    }

    /**
     * Sets default values from a Map
     */
    public void setDefaultValues(Map<String, Object> defaults) {
        this.defaultValuesJson = gson.toJson(defaults);
    }

    /**
     * Gets a specific default value
     */
    public Object getDefaultValue(String key) {
        return getDefaultValues().get(key);
    }

    /**
     * Sets a specific default value
     */
    public void setDefaultValue(String key, Object value) {
        Map<String, Object> defaults = getDefaultValues();
        defaults.put(key, value);
        setDefaultValues(defaults);
    }

    /**
     * Checks if drawdown limit is breached
     */
    public boolean isDrawdownLimitBreached() {
        return Math.abs(currentUnrealisedDrawdown) >= dailyDrawdownHardStop;
    }

    /**
     * Resets drawdown tracking (called at start of new day)
     */
    public void resetDailyDrawdown() {
        this.currentUnrealisedDrawdown = 0.0;
        this.maxDailyDrawdownReached = false;
    }

    /**
     * Returns master button text based on state
     */
    public String getMasterButtonText() {
        return masterTradingEnabled ? "ON" : "MUTED";
    }

    /**
     * Returns master button color CSS class
     */
    public String getMasterButtonColorClass() {
        return masterTradingEnabled ? "button-on" : "button-muted";
    }

    /**
     * Toggles master trading enabled state
     */
    public void toggleMasterTrading() {
        this.masterTradingEnabled = !this.masterTradingEnabled;
    }
}
