package com.tradelogic.models;

public class TradeStatistics {
    private String accountName;
    private String accountNumber;
    private String company;
    private String reportDate;
    private double totalNetProfit;
    private double grossProfit;
    private double grossLoss;
    private double profitFactor;
    private double expectedPayoff;
    private double sharpeRatio;
    private double recoveryFactor;
    private double balanceDrawdown;
    private double balanceDrawdownAbsolute;
    private double balanceDrawdownMax;
    private double balanceDrawdownMaxPercent;
    private double balanceDrawdownRelative;
    private double balanceDrawdownRelativePercent;
    private int totalTrades;
    private int shortTrades;
    private int shortTradesWon;
    private double shortTradesWonPercent;
    private int longTrades;
    private int longTradesWon;
    private double longTradesWonPercent;
    private int profitTrades;
    private double profitTradesPercent;
    private int lossTrades;
    private double lossTradesPercent;
    private double largestProfitTrade;
    private double largestLossTrade;
    private double averageProfitTrade;
    private double averageLossTrade;
    private int maxConsecutiveWins;
    private double maxConsecutiveWinsProfit;
    private int maxConsecutiveLosses;
    private double maxConsecutiveLossesLoss;
    private int maxConsecutiveProfitCount;
    private double maxConsecutiveProfit;
    private int maxConsecutiveLossCount;
    private double maxConsecutiveLoss;
    private int averageConsecutiveWins;
    private int averageConsecutiveLosses;
    private double balance;
    private double equity;
    private double margin;
    private double freeMargin;
    private double marginLevel;

    public String getAccountName() { return accountName; }
    public void setAccountName(String accountName) { this.accountName = accountName; }

    public String getAccountNumber() { return accountNumber; }
    public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }

    public String getCompany() { return company; }
    public void setCompany(String company) { this.company = company; }

    public String getReportDate() { return reportDate; }
    public void setReportDate(String reportDate) { this.reportDate = reportDate; }

    public double getTotalNetProfit() { return totalNetProfit; }
    public void setTotalNetProfit(double totalNetProfit) { this.totalNetProfit = totalNetProfit; }

    public double getGrossProfit() { return grossProfit; }
    public void setGrossProfit(double grossProfit) { this.grossProfit = grossProfit; }

    public double getGrossLoss() { return grossLoss; }
    public void setGrossLoss(double grossLoss) { this.grossLoss = grossLoss; }

    public double getProfitFactor() { return profitFactor; }
    public void setProfitFactor(double profitFactor) { this.profitFactor = profitFactor; }

    public double getExpectedPayoff() { return expectedPayoff; }
    public void setExpectedPayoff(double expectedPayoff) { this.expectedPayoff = expectedPayoff; }

    public double getSharpeRatio() { return sharpeRatio; }
    public void setSharpeRatio(double sharpeRatio) { this.sharpeRatio = sharpeRatio; }

    public double getRecoveryFactor() { return recoveryFactor; }
    public void setRecoveryFactor(double recoveryFactor) { this.recoveryFactor = recoveryFactor; }

    public double getBalanceDrawdown() { return balanceDrawdown; }
    public void setBalanceDrawdown(double balanceDrawdown) { this.balanceDrawdown = balanceDrawdown; }

    public double getBalanceDrawdownAbsolute() { return balanceDrawdownAbsolute; }
    public void setBalanceDrawdownAbsolute(double balanceDrawdownAbsolute) { this.balanceDrawdownAbsolute = balanceDrawdownAbsolute; }

    public double getBalanceDrawdownMax() { return balanceDrawdownMax; }
    public void setBalanceDrawdownMax(double balanceDrawdownMax) { this.balanceDrawdownMax = balanceDrawdownMax; }

    public double getBalanceDrawdownMaxPercent() { return balanceDrawdownMaxPercent; }
    public void setBalanceDrawdownMaxPercent(double balanceDrawdownMaxPercent) { this.balanceDrawdownMaxPercent = balanceDrawdownMaxPercent; }

    public double getBalanceDrawdownRelative() { return balanceDrawdownRelative; }
    public void setBalanceDrawdownRelative(double balanceDrawdownRelative) { this.balanceDrawdownRelative = balanceDrawdownRelative; }

    public double getBalanceDrawdownRelativePercent() { return balanceDrawdownRelativePercent; }
    public void setBalanceDrawdownRelativePercent(double balanceDrawdownRelativePercent) { this.balanceDrawdownRelativePercent = balanceDrawdownRelativePercent; }

    public int getTotalTrades() { return totalTrades; }
    public void setTotalTrades(int totalTrades) { this.totalTrades = totalTrades; }

    public int getShortTrades() { return shortTrades; }
    public void setShortTrades(int shortTrades) { this.shortTrades = shortTrades; }

    public int getShortTradesWon() { return shortTradesWon; }
    public void setShortTradesWon(int shortTradesWon) { this.shortTradesWon = shortTradesWon; }

    public double getShortTradesWonPercent() { return shortTradesWonPercent; }
    public void setShortTradesWonPercent(double shortTradesWonPercent) { this.shortTradesWonPercent = shortTradesWonPercent; }

    public int getLongTrades() { return longTrades; }
    public void setLongTrades(int longTrades) { this.longTrades = longTrades; }

    public int getLongTradesWon() { return longTradesWon; }
    public void setLongTradesWon(int longTradesWon) { this.longTradesWon = longTradesWon; }

    public double getLongTradesWonPercent() { return longTradesWonPercent; }
    public void setLongTradesWonPercent(double longTradesWonPercent) { this.longTradesWonPercent = longTradesWonPercent; }

    public int getProfitTrades() { return profitTrades; }
    public void setProfitTrades(int profitTrades) { this.profitTrades = profitTrades; }

    public double getProfitTradesPercent() { return profitTradesPercent; }
    public void setProfitTradesPercent(double profitTradesPercent) { this.profitTradesPercent = profitTradesPercent; }

    public int getLossTrades() { return lossTrades; }
    public void setLossTrades(int lossTrades) { this.lossTrades = lossTrades; }

    public double getLossTradesPercent() { return lossTradesPercent; }
    public void setLossTradesPercent(double lossTradesPercent) { this.lossTradesPercent = lossTradesPercent; }

    public double getLargestProfitTrade() { return largestProfitTrade; }
    public void setLargestProfitTrade(double largestProfitTrade) { this.largestProfitTrade = largestProfitTrade; }

    public double getLargestLossTrade() { return largestLossTrade; }
    public void setLargestLossTrade(double largestLossTrade) { this.largestLossTrade = largestLossTrade; }

    public double getAverageProfitTrade() { return averageProfitTrade; }
    public void setAverageProfitTrade(double averageProfitTrade) { this.averageProfitTrade = averageProfitTrade; }

    public double getAverageLossTrade() { return averageLossTrade; }
    public void setAverageLossTrade(double averageLossTrade) { this.averageLossTrade = averageLossTrade; }

    public int getMaxConsecutiveWins() { return maxConsecutiveWins; }
    public void setMaxConsecutiveWins(int maxConsecutiveWins) { this.maxConsecutiveWins = maxConsecutiveWins; }

    public double getMaxConsecutiveWinsProfit() { return maxConsecutiveWinsProfit; }
    public void setMaxConsecutiveWinsProfit(double maxConsecutiveWinsProfit) { this.maxConsecutiveWinsProfit = maxConsecutiveWinsProfit; }

    public int getMaxConsecutiveLosses() { return maxConsecutiveLosses; }
    public void setMaxConsecutiveLosses(int maxConsecutiveLosses) { this.maxConsecutiveLosses = maxConsecutiveLosses; }

    public double getMaxConsecutiveLossesLoss() { return maxConsecutiveLossesLoss; }
    public void setMaxConsecutiveLossesLoss(double maxConsecutiveLossesLoss) { this.maxConsecutiveLossesLoss = maxConsecutiveLossesLoss; }

    public int getMaxConsecutiveProfitCount() { return maxConsecutiveProfitCount; }
    public void setMaxConsecutiveProfitCount(int maxConsecutiveProfitCount) { this.maxConsecutiveProfitCount = maxConsecutiveProfitCount; }

    public double getMaxConsecutiveProfit() { return maxConsecutiveProfit; }
    public void setMaxConsecutiveProfit(double maxConsecutiveProfit) { this.maxConsecutiveProfit = maxConsecutiveProfit; }

    public int getMaxConsecutiveLossCount() { return maxConsecutiveLossCount; }
    public void setMaxConsecutiveLossCount(double maxConsecutiveLossCount) { this.maxConsecutiveLossCount = (int) maxConsecutiveLossCount; }

    public double getMaxConsecutiveLoss() { return maxConsecutiveLoss; }
    public void setMaxConsecutiveLoss(double maxConsecutiveLoss) { this.maxConsecutiveLoss = maxConsecutiveLoss; }

    public int getAverageConsecutiveWins() { return averageConsecutiveWins; }
    public void setAverageConsecutiveWins(int averageConsecutiveWins) { this.averageConsecutiveWins = averageConsecutiveWins; }

    public int getAverageConsecutiveLosses() { return averageConsecutiveLosses; }
    public void setAverageConsecutiveLosses(int averageConsecutiveLosses) { this.averageConsecutiveLosses = averageConsecutiveLosses; }

    public double getBalance() { return balance; }
    public void setBalance(double balance) { this.balance = balance; }

    public double getEquity() { return equity; }
    public void setEquity(double equity) { this.equity = equity; }

    public double getMargin() { return margin; }
    public void setMargin(double margin) { this.margin = margin; }

    public double getFreeMargin() { return freeMargin; }
    public void setFreeMargin(double freeMargin) { this.freeMargin = freeMargin; }

    public double getMarginLevel() { return marginLevel; }
    public void setMarginLevel(double marginLevel) { this.marginLevel = marginLevel; }
}
