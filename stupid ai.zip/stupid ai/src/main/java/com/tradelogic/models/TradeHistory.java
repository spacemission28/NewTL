package com.tradelogic.models;

import java.time.Instant;
import java.util.UUID;

public class TradeHistory {
    private UUID id;
    private UUID robotConfigId;
    private Long magicNumber;
    private Long ticketNumber;
    private String symbol;
    private String tradeType;
    private Double volume;
    private Double openPrice;
    private Double closePrice;
    private Double stopLoss;
    private Double takeProfit;
    private Double profit;
    private Double commission;
    private Double swap;
    private Instant openTime;
    private Instant closeTime;
    private String comment;

    public TradeHistory() {
    }

    public TradeHistory(UUID robotConfigId, Long magicNumber, Long ticketNumber, String symbol, String tradeType) {
        this.robotConfigId = robotConfigId;
        this.magicNumber = magicNumber;
        this.ticketNumber = ticketNumber;
        this.symbol = symbol;
        this.tradeType = tradeType;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public UUID getRobotConfigId() {
        return robotConfigId;
    }

    public void setRobotConfigId(UUID robotConfigId) {
        this.robotConfigId = robotConfigId;
    }

    public Long getMagicNumber() {
        return magicNumber;
    }

    public void setMagicNumber(Long magicNumber) {
        this.magicNumber = magicNumber;
    }

    public Long getTicketNumber() {
        return ticketNumber;
    }

    public void setTicketNumber(Long ticketNumber) {
        this.ticketNumber = ticketNumber;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getTradeType() {
        return tradeType;
    }

    public void setTradeType(String tradeType) {
        this.tradeType = tradeType;
    }

    public Double getVolume() {
        return volume;
    }

    public void setVolume(Double volume) {
        this.volume = volume;
    }

    public Double getOpenPrice() {
        return openPrice;
    }

    public void setOpenPrice(Double openPrice) {
        this.openPrice = openPrice;
    }

    public Double getClosePrice() {
        return closePrice;
    }

    public void setClosePrice(Double closePrice) {
        this.closePrice = closePrice;
    }

    public Double getStopLoss() {
        return stopLoss;
    }

    public void setStopLoss(Double stopLoss) {
        this.stopLoss = stopLoss;
    }

    public Double getTakeProfit() {
        return takeProfit;
    }

    public void setTakeProfit(Double takeProfit) {
        this.takeProfit = takeProfit;
    }

    public Double getProfit() {
        return profit;
    }

    public void setProfit(Double profit) {
        this.profit = profit;
    }

    public Double getCommission() {
        return commission;
    }

    public void setCommission(Double commission) {
        this.commission = commission;
    }

    public Double getSwap() {
        return swap;
    }

    public void setSwap(Double swap) {
        this.swap = swap;
    }

    public Instant getOpenTime() {
        return openTime;
    }

    public void setOpenTime(Instant openTime) {
        this.openTime = openTime;
    }

    public Instant getCloseTime() {
        return closeTime;
    }

    public void setCloseTime(Instant closeTime) {
        this.closeTime = closeTime;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Double getNetProfit() {
        if (profit == null) return 0.0;
        double net = profit;
        if (commission != null) net += commission;
        if (swap != null) net += swap;
        return net;
    }

    public boolean isOpen() {
        return closeTime == null;
    }

    public boolean isClosed() {
        return closeTime != null;
    }
}
