package com.tradelogic.services;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.tradelogic.Logger;
import com.tradelogic.models.TradeCommand;
import com.tradelogic.models.TradeHistoryEntry;

import java.io.File;
import java.io.FileReader;
import java.lang.reflect.Type;
import java.util.*;
import java.util.concurrent.*;

/**
 * OCO Imbalance Detector - FINAL BACKSTOP for OCO system (v2)
 *
 * PURPOSE:
 * This is the LAST LINE OF DEFENSE that catches any orphaned opposite side orders
 * that may have slipped through OcoManager and OcoWaitExecutor.
 *
 * TIMING:
 * - Runs 5 SECONDS after initial signal placement
 * - This gives time for:
 *   1. OcoManager to halt placement immediately (0s)
 *   2. OcoWaitExecutor to do its 3-second countdown (if enabled)
 *   3. Any network delays or race conditions to resolve
 *
 * BEHAVIOR:
 * - Checks if ANY opposite entry pending orders are still open
 * - If found → DELETE them WITHOUT HESITATION (no thresholds, no questions)
 * - This is a safety net, not the primary OCO mechanism
 *
 * PREVIOUS BEHAVIOR (removed):
 * - Used to check at 5s, 10s, 20s intervals
 * - Used to have ≥5 vs 0 threshold logic
 * - Now simplified to single 5-second final check
 */
public class OcoImbalanceDetector {
    private static OcoImbalanceDetector instance;

    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    private final Map<String, ScheduledFuture<?>> scheduledChecks = new ConcurrentHashMap<>();

    private TradeCommandQueue commandQueue;
    private TradeHistoryCache tradeHistoryCache;

    private OcoImbalanceDetector() {}

    public static synchronized OcoImbalanceDetector getInstance() {
        if (instance == null) {
            instance = new OcoImbalanceDetector();
        }
        return instance;
    }

    public void setCommandQueue(TradeCommandQueue queue) {
        this.commandQueue = queue;
    }

    public void setTradeHistoryCache(TradeHistoryCache cache) {
        this.tradeHistoryCache = cache;
    }

    /**
     * Backward compatibility - no longer used but kept to avoid compilation errors
     */
    public void setSupabaseClient(Object client) {
        Logger.info("OCO BACKSTOP: setSupabaseClient() called (deprecated - using TradeHistoryCache instead)");
    }

    /**
     * Backward compatibility - no longer used but kept to avoid compilation errors
     */
    public void setFileMode(String tradeHistoryFilePath) {
        Logger.info("OCO BACKSTOP: setFileMode() called (deprecated - using TradeHistoryCache instead)");
    }

    /**
     * Schedules imbalance checks (backward compatibility - now just calls scheduleBackstopCheck)
     */
    public void scheduleImbalanceCheck(String magicNumber, UUID robotConfigId) {
        scheduleBackstopCheck(magicNumber, robotConfigId);
    }

    /**
     * Schedules the final 5-second backstop check
     *
     * @param magicNumber Magic number of the OCO group
     * @param robotConfigId Robot UUID for logging
     */
    public void scheduleBackstopCheck(String magicNumber, UUID robotConfigId) {
        Logger.info("OCO BACKSTOP: Scheduled 5-second final check for magic " + magicNumber);

        ScheduledFuture<?> future = scheduler.schedule(
            () -> performBackstopCheck(magicNumber, robotConfigId),
            5,
            TimeUnit.SECONDS
        );

        scheduledChecks.put(magicNumber, future);
    }

    /**
     * Performs the final backstop check - deletes ANY opposite orders found
     */
    private void performBackstopCheck(String magicNumber, UUID robotConfigId) {
        try {
            Logger.info("OCO BACKSTOP: Starting 5-second final check for magic " + magicNumber);

            if (tradeHistoryCache == null) {
                Logger.warning("OCO BACKSTOP: TradeHistoryCache not set, skipping check (will rely on OcoManager/OcoWaitExecutor)");
                return;
            }

            List<Map<String, Object>> pendingOrders = queryPendingOrders(magicNumber);

            if (pendingOrders == null || pendingOrders.isEmpty()) {
                Logger.info("OCO BACKSTOP: No pending orders found for magic " + magicNumber + " - all clean");
                return;
            }

            int buyCount = 0;
            int sellCount = 0;

            for (Map<String, Object> order : pendingOrders) {
                String orderType = (String) order.get("order_type");
                if (orderType != null) {
                    if (orderType.contains("BUY")) {
                        buyCount++;
                    } else if (orderType.contains("SELL")) {
                        sellCount++;
                    }
                }
            }

            Logger.info(String.format("OCO BACKSTOP: Magic %s pending orders - BUY: %d, SELL: %d",
                magicNumber, buyCount, sellCount));

            if (buyCount > 0 && sellCount > 0) {
                Logger.warning(String.format(
                    "⚠️ OCO BACKSTOP: Magic %s has BOTH sides open (BUY:%d, SELL:%d) - This is a hedge! Determining which side filled first...",
                    magicNumber, buyCount, sellCount));

                String sideToDelete = determineSideToDelete(magicNumber);
                if (sideToDelete != null) {
                    Logger.warning("⚠️ OCO BACKSTOP: Deleting " + sideToDelete + " orders for magic " + magicNumber);
                    deleteOrdersOfType(magicNumber, sideToDelete, robotConfigId);
                } else {
                    Logger.error("OCO BACKSTOP: Could not determine which side filled first - manual intervention required!");
                }

            } else if (buyCount > 0 || sellCount > 0) {
                Logger.info("OCO BACKSTOP: Only one side remains open - this is normal, no action needed");

            } else {
                Logger.info("OCO BACKSTOP: No pending orders remain - all clean");
            }

        } catch (Exception e) {
            Logger.error("OCO BACKSTOP: Error in final check for magic " + magicNumber + ": " + e.getMessage());
            e.printStackTrace();
        } finally {
            scheduledChecks.remove(magicNumber);
        }
    }

    /**
     * Queries pending orders from TradeHistoryCache
     * NOTE: This method uses reflection to call whatever method exists on TradeHistoryCache
     * to maintain compatibility across different versions
     */
    private List<Map<String, Object>> queryPendingOrders(String magicNumber) {
        try {
            java.lang.reflect.Method method = tradeHistoryCache.getClass().getMethod("getAllEntries");
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> allEntries = (List<Map<String, Object>>) method.invoke(tradeHistoryCache);

            List<Map<String, Object>> pendingOrders = new ArrayList<>();
            for (Map<String, Object> entry : allEntries) {
                String magic = String.valueOf(entry.get("magic_number"));
                String state = String.valueOf(entry.get("state"));
                if (magicNumber.equals(magic) && state != null && state.contains("PLACED")) {
                    pendingOrders.add(entry);
                }
            }
            return pendingOrders;
        } catch (Exception e) {
            Logger.error("OCO BACKSTOP: Error querying pending orders (TradeHistoryCache method unavailable): " + e.getMessage());
            return new ArrayList<>();
        }
    }

    /**
     * Queries filled orders from TradeHistoryCache
     * NOTE: This method uses reflection to call whatever method exists on TradeHistoryCache
     * to maintain compatibility across different versions
     */
    private List<Map<String, Object>> queryFilledOrders(String magicNumber) {
        try {
            java.lang.reflect.Method method = tradeHistoryCache.getClass().getMethod("getAllEntries");
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> allEntries = (List<Map<String, Object>>) method.invoke(tradeHistoryCache);

            List<Map<String, Object>> filledOrders = new ArrayList<>();
            for (Map<String, Object> entry : allEntries) {
                String magic = String.valueOf(entry.get("magic_number"));
                String state = String.valueOf(entry.get("state"));
                if (magicNumber.equals(magic) && state != null && state.contains("FILLED")) {
                    filledOrders.add(entry);
                }
            }
            return filledOrders;
        } catch (Exception e) {
            Logger.error("OCO BACKSTOP: Error querying filled orders (TradeHistoryCache method unavailable): " + e.getMessage());
            return new ArrayList<>();
        }
    }

    /**
     * Determines which side to delete by checking which side has filled orders
     */
    private String determineSideToDelete(String magicNumber) {
        try {
            List<Map<String, Object>> filledOrders = queryFilledOrders(magicNumber);

            for (Map<String, Object> order : filledOrders) {
                String orderType = (String) order.get("order_type");
                if (orderType != null) {
                    if (orderType.contains("BUY")) {
                        return "SELL";
                    } else if (orderType.contains("SELL")) {
                        return "BUY";
                    }
                }
            }
        } catch (Exception e) {
            Logger.error("OCO BACKSTOP: Error determining side to delete: " + e.getMessage());
        }
        return null;
    }

    /**
     * Deletes all orders of a specific type for a magic number
     */
    private void deleteOrdersOfType(String magicNumber, String side, UUID robotConfigId) {
        if (commandQueue == null) {
            Logger.error("OCO BACKSTOP: CommandQueue not set, cannot delete orders");
            return;
        }

        String orderType = side + "_STOP";

        Map<String, Object> params = new HashMap<>();
        params.put("magic_number", magicNumber);
        params.put("order_type", orderType);

        TradeCommand deleteCommand = new TradeCommand(
            robotConfigId,
            magicNumber,
            "DELETE_OPPOSITE_SIDE",
            params
        );

        commandQueue.addFirst(deleteCommand);
        Logger.info(String.format(
            "OCO BACKSTOP: Queued DELETE command for %s orders with magic %s",
            orderType, magicNumber));
    }

    /**
     * Cancels a scheduled check (e.g., if manual intervention occurred)
     */
    public void cancelScheduledCheck(String magicNumber) {
        ScheduledFuture<?> future = scheduledChecks.remove(magicNumber);
        if (future != null) {
            future.cancel(false);
            Logger.info("OCO BACKSTOP: Cancelled scheduled check for magic " + magicNumber);
        }
    }

    /**
     * Shuts down the scheduler
     */
    public void shutdown() {
        scheduler.shutdownNow();
        scheduledChecks.clear();
        Logger.info("OCO BACKSTOP: Detector shutdown complete");
    }

    /**
     * Gets count of active scheduled checks
     */
    public int getActiveCheckCount() {
        return scheduledChecks.size();
    }
}
