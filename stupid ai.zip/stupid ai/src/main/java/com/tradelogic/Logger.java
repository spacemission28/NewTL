package com.tradelogic;

import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Logger {
    private static final String LOG_FOLDER = "market_data/logs";
    private static final ZoneId EET_ZONE = ZoneId.of("Europe/Helsinki");
    private static final DateTimeFormatter FILE_DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter LOG_TIMESTAMP_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    private static Logger instance;

    private Path currentLogFile;
    private BufferedWriter logWriter;
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

    public Logger() {
        initializeLogFolder();
        rotateLogFile();
        scheduleWeeklyRotation();
    }

    private void initializeLogFolder() {
        try {
            Path logPath = Paths.get(LOG_FOLDER);
            if (!Files.exists(logPath)) {
                Files.createDirectories(logPath);
            }
        } catch (IOException e) {
            System.err.println("ERROR: Failed to create log folder: " + e.getMessage());
        }
    }

    private void rotateLogFile() {
        try {
            if (logWriter != null) {
                logWriter.close();
            }

            LocalDate today = LocalDate.now(EET_ZONE);
            String filename = "log_" + today.format(FILE_DATE_FORMAT) + ".txt";
            currentLogFile = Paths.get(LOG_FOLDER, filename);

            logWriter = new BufferedWriter(new FileWriter(currentLogFile.toFile(), true));

            logInternal(LogLevel.INFO, "Log file rotated: " + filename);
        } catch (IOException e) {
            System.err.println("ERROR: Failed to rotate log file: " + e.getMessage());
        }
    }

    private void scheduleWeeklyRotation() {
        ZonedDateTime now = ZonedDateTime.now(EET_ZONE);
        ZonedDateTime nextSunday = now.with(DayOfWeek.SUNDAY).withHour(22).withMinute(0).withSecond(0).withNano(0);

        if (now.isAfter(nextSunday)) {
            nextSunday = nextSunday.plusWeeks(1);
        }

        long initialDelay = ChronoUnit.SECONDS.between(now, nextSunday);
        long period = TimeUnit.DAYS.toSeconds(7);

        scheduler.scheduleAtFixedRate(this::rotateLogFile, initialDelay, period, TimeUnit.SECONDS);

        logInternal(LogLevel.INFO, "Weekly log rotation scheduled for Sundays at 22:00 EET. Next rotation: " +
                    nextSunday.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
    }

    private void logInternal(LogLevel level, String message) {
        try {
            String timestamp = ZonedDateTime.now(EET_ZONE).format(LOG_TIMESTAMP_FORMAT);
            String logLine = String.format("[%s] [%s] %s", timestamp, level, message);

            if (logWriter != null) {
                logWriter.write(logLine);
                logWriter.newLine();
                logWriter.flush();
            }
        } catch (IOException e) {
            System.err.println("ERROR: Failed to write to log file: " + e.getMessage());
        }
    }

    public Path getCurrentLogFile() {
        return currentLogFile;
    }

    public void shutdown() {
        try {
            scheduler.shutdown();
            if (logWriter != null) {
                logWriter.close();
            }
        } catch (IOException e) {
            System.err.println("ERROR: Failed to close log writer: " + e.getMessage());
        }
    }

    // Static methods for convenient logging
    public static void info(String message) {
        if (instance == null) {
            instance = new Logger();
        }
        instance.logInternal(LogLevel.INFO, message);
    }

    public static void warning(String message) {
        if (instance == null) {
            instance = new Logger();
        }
        instance.logInternal(LogLevel.WARNING, message);
    }

    public static void error(String message) {
        if (instance == null) {
            instance = new Logger();
        }
        instance.logInternal(LogLevel.ERROR, message);
    }

    public static void connection(String message) {
        if (instance == null) {
            instance = new Logger();
        }
        instance.logInternal(LogLevel.CONNECTION, message);
    }

    public enum LogLevel {
        INFO,
        WARNING,
        ERROR,
        CONNECTION
    }
}
