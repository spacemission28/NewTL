package com.tradelogic.models;

public class TradeHistoryEntry {
    private long ticket;
    private long magic;
    private String symbol;
    private long timestamp;

    public TradeHistoryEntry() {}

    public TradeHistoryEntry(long ticket, long magic, String symbol, long timestamp) {
        this.ticket = ticket;
        this.magic = magic;
        this.symbol = symbol;
        this.timestamp = timestamp;
    }

    public long getTicket() {
        return ticket;
    }

    public void setTicket(long ticket) {
        this.ticket = ticket;
    }

    public long getMagic() {
        return magic;
    }

    public void setMagic(long magic) {
        this.magic = magic;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return String.format("TradeHistoryEntry{ticket=%d, magic=%d, symbol='%s', timestamp=%d}",
            ticket, magic, symbol, timestamp);
    }
}
