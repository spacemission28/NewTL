package com.tradelogic.models;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

/**
 * Lightweight POJO for storing market bar data without JavaFX properties.
 * Used for efficient storage and file I/O operations.
 */
public class MarketBarData {
    private final String symbol;
    private final String timeframe;
    private final long openTime;           // NEW: Open time in seconds
    private final long closeTime;          // RENAMED: Was timestampSeconds
    private final double open;
    private final double high;
    private final double low;
    private final double close;

    private static final DateTimeFormatter DISPLAY_FORMATTER =
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    private static final DateTimeFormatter EET_TIME_FORMATTER =
        DateTimeFormatter.ofPattern("HH:mm");
    private static final ZoneId EET_ZONE = ZoneId.of("Europe/Helsinki");

    public MarketBarData(String symbol, String timeframe, long timestampSeconds,
                         double open, double high, double low, double close) {
        this.symbol = symbol;
        this.timeframe = timeframe.replace("PERIOD_", "");
        // MT5 sends the OPEN time of the bar, not close time!
        this.openTime = timestampSeconds;
        this.closeTime = calculateCloseTime(timestampSeconds, this.timeframe);
        this.open = open;
        this.high = high;
        this.low = low;
        this.close = close;
    }

    public String getKey() {
        return symbol + "_" + timeframe;
    }

    public String getSymbol() {
        return symbol;
    }

    public String getTimeframe() {
        return timeframe;
    }

    public long getOpenTime() {
        return openTime;
    }

    public long getCloseTime() {
        return closeTime;
    }

    @Deprecated
    public long getTimestampSeconds() {
        return closeTime;
    }

    public String getFormattedTimestamp() {
        return LocalDateTime.ofEpochSecond(
            closeTime,
            0,
            java.time.ZoneOffset.UTC
        ).format(DISPLAY_FORMATTER);
    }

    public String getFormattedOpenTime() {
        return LocalDateTime.ofEpochSecond(
            openTime,
            0,
            java.time.ZoneOffset.UTC
        ).format(DISPLAY_FORMATTER);
    }

    public long getCandleDuration() {
        return closeTime - openTime;
    }

    public long getExpectedDuration() {
        return getTimeframeMinutes(timeframe) * 60;
    }

    public boolean isDurationValid() {
        long duration = getCandleDuration();
        long expected = getExpectedDuration();
        long buffer = 60; // 60 second tolerance
        return duration <= (expected + buffer);
    }

    public double getOpen() {
        return open;
    }

    public double getHigh() {
        return high;
    }

    public double getLow() {
        return low;
    }

    public double getClose() {
        return close;
    }

    public String toFileFormat() {
        LocalDateTime eetTime = LocalDateTime.ofInstant(
            Instant.ofEpochSecond(closeTime),
            EET_ZONE
        );
        String eetTimeStr = eetTime.format(EET_TIME_FORMATTER);

        return String.format("%s, %s, %.5f, %.5f, %.5f, %.5f",
            timeframe, eetTimeStr, open, high, low, close);
    }

    /**
     * Calculate close time from open time and timeframe.
     * MT5 sends open time, so we add the duration to get close time.
     */
    private static long calculateCloseTime(long openTime, String timeframe) {
        int minutes = getTimeframeMinutes(timeframe);
        return openTime + (minutes * 60);
    }

    /**
     * Get timeframe duration in minutes.
     * Supported: M1, M2, M3, M5, M10, M15, M30, H1, H3, H4, D1
     */
    private static int getTimeframeMinutes(String timeframe) {
        return switch (timeframe) {
            case "M1" -> 1;
            case "M2" -> 2;
            case "M3" -> 3;
            case "M5" -> 5;
            case "M10" -> 10;
            case "M15" -> 15;
            case "M30" -> 30;
            case "H1" -> 60;
            case "H3" -> 180;
            case "H4" -> 240;
            case "D1" -> 1440;
            default -> {
                System.err.println("WARNING: Unknown timeframe '" + timeframe + "', defaulting to H1 (60 minutes)");
                yield 60;
            }
        };
    }
}
