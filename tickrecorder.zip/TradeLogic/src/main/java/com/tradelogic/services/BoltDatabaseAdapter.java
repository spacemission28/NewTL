package com.tradelogic.services;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.tradelogic.Logger;
import com.tradelogic.models.RobotConfig;
import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BoltDatabaseAdapter implements DatabaseClient {
    private final String boltDatabaseUrl;
    private final String boltDatabaseKey;
    private final HttpClient httpClient;
    private final Gson gson = new Gson();

    private static BoltDatabaseAdapter instance;

    private BoltDatabaseAdapter(String boltDatabaseUrl, String boltDatabaseKey) {
        this.boltDatabaseUrl = boltDatabaseUrl;
        this.boltDatabaseKey = boltDatabaseKey;
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(10))
                .build();
        Logger.info("BoltDatabaseAdapter initialized: " + boltDatabaseUrl);
    }

    public static void initialize(String boltDatabaseUrl, String boltDatabaseKey) {
        instance = new BoltDatabaseAdapter(boltDatabaseUrl, boltDatabaseKey);
    }

    public static BoltDatabaseAdapter getInstance() {
        if (instance == null) {
            throw new IllegalStateException("BoltDatabaseAdapter not initialized");
        }
        return instance;
    }

    private HttpRequest.Builder createRequestBuilder(String endpoint) {
        return HttpRequest.newBuilder()
                .uri(URI.create(boltDatabaseUrl + "/rest/v1/" + endpoint))
                .header("apikey", boltDatabaseKey)
                .header("Authorization", "Bearer " + boltDatabaseKey)
                .header("Content-Type", "application/json")
                .header("Prefer", "return=representation");
    }

    @Override
    public void upsertRobotConfig(String userId, RobotConfig config) throws Exception {
        Map<String, Object> data = new HashMap<>();
        data.put("user_id", userId);
        data.put("robot_number", config.getRobotNumber());
        data.put("symbol", config.getSymbol());
        data.put("timeframe", config.getTimeframe());
        data.put("x1_type", config.getX1Type());
        data.put("min_x1_height", config.getMinX1Height());
        data.put("trig_percent", config.getTrigPercent());
        data.put("stop_loss_percent", config.getStopLossPercent());
        data.put("tp1_percent", config.getTp1Percent());
        data.put("tp2_percent", config.getTp2Percent());
        data.put("tp3_percent", config.getTp3Percent());
        data.put("tp4_percent", config.getTp4Percent());
        data.put("tp5_percent", config.getTp5Percent());
        data.put("tp6_percent", config.getTp6Percent());
        data.put("tp7_percent", config.getTp7Percent());
        data.put("tp1_volume", config.getTp1Volume());
        data.put("tp2_volume", config.getTp2Volume());
        data.put("tp3_volume", config.getTp3Volume());
        data.put("tp4_volume", config.getTp4Volume());
        data.put("tp5_volume", config.getTp5Volume());
        data.put("tp6_volume", config.getTp6Volume());
        data.put("tp7_volume", config.getTp7Volume());
        data.put("rpt_percent", config.getRptPercent());
        data.put("rpt_fixed_amount", config.getRptFixedAmount());
        data.put("close_hour", config.getCloseHour());
        data.put("close_minute", config.getCloseMinute());
        data.put("daily_dd_limit", config.getDailyDdLimit());

        String jsonBody = gson.toJson(data);

        HttpRequest request = createRequestBuilder("robot_configs?user_id=eq." + userId + "&robot_number=eq." + config.getRobotNumber())
                .method("POST", HttpRequest.BodyPublishers.ofString(jsonBody))
                .header("Prefer", "resolution=merge-duplicates")
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() >= 400) {
            throw new Exception("Failed to upsert robot config: " + response.statusCode() + " - " + response.body());
        }
    }

    @Override
    public List<RobotConfig> loadRobotConfigs(String userId) throws Exception {
        HttpRequest request = createRequestBuilder("robot_configs?user_id=eq." + userId + "&order=robot_number.asc")
                .GET()
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() != 200) {
            throw new Exception("Failed to load robot configs: " + response.statusCode());
        }

        List<Map<String, Object>> rawConfigs = gson.fromJson(response.body(), new TypeToken<List<Map<String, Object>>>(){}.getType());
        List<RobotConfig> configs = new ArrayList<>();

        if (rawConfigs != null) {
            for (Map<String, Object> raw : rawConfigs) {
                RobotConfig config = new RobotConfig();
                config.setRobotNumber(((Number) raw.get("robot_number")).intValue());
                config.setSymbol((String) raw.get("symbol"));
                config.setTimeframe((String) raw.get("timeframe"));
                config.setX1Type((String) raw.get("x1_type"));
                config.setMinX1Height(((Number) raw.get("min_x1_height")).doubleValue());
                config.setTrigPercent(((Number) raw.get("trig_percent")).doubleValue());
                config.setStopLossPercent(((Number) raw.get("stop_loss_percent")).doubleValue());
                config.setTp1Percent(((Number) raw.get("tp1_percent")).doubleValue());
                config.setTp2Percent(((Number) raw.get("tp2_percent")).doubleValue());
                config.setTp3Percent(((Number) raw.get("tp3_percent")).doubleValue());
                config.setTp4Percent(((Number) raw.get("tp4_percent")).doubleValue());
                config.setTp5Percent(((Number) raw.get("tp5_percent")).doubleValue());
                config.setTp6Percent(((Number) raw.get("tp6_percent")).doubleValue());
                config.setTp7Percent(((Number) raw.get("tp7_percent")).doubleValue());
                config.setTp1Volume(((Number) raw.get("tp1_volume")).intValue());
                config.setTp2Volume(((Number) raw.get("tp2_volume")).intValue());
                config.setTp3Volume(((Number) raw.get("tp3_volume")).intValue());
                config.setTp4Volume(((Number) raw.get("tp4_volume")).intValue());
                config.setTp5Volume(((Number) raw.get("tp5_volume")).intValue());
                config.setTp6Volume(((Number) raw.get("tp6_volume")).intValue());
                config.setTp7Volume(((Number) raw.get("tp7_volume")).intValue());
                config.setRptPercent(((Number) raw.get("rpt_percent")).doubleValue());
                config.setRptFixedAmount(((Number) raw.get("rpt_fixed_amount")).doubleValue());
                config.setCloseHour(((Number) raw.get("close_hour")).intValue());
                config.setCloseMinute(((Number) raw.get("close_minute")).intValue());

                Object ddLimit = raw.get("daily_dd_limit");
                if (ddLimit != null) {
                    config.setDailyDdLimit(((Number) ddLimit).doubleValue());
                } else {
                    config.setDailyDdLimit(0.0);
                }

                configs.add(config);
            }
        }

        return configs;
    }

    @Override
    public void saveDefaultValues(String userId, Map<String, Object> defaults) throws Exception {
        Map<String, Object> data = new HashMap<>();
        data.put("user_id", userId);
        data.put("defaults", defaults);

        String jsonBody = gson.toJson(data);

        HttpRequest request = createRequestBuilder("default_values?user_id=eq." + userId)
                .method("POST", HttpRequest.BodyPublishers.ofString(jsonBody))
                .header("Prefer", "resolution=merge-duplicates")
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() >= 400) {
            throw new Exception("Failed to save default values: " + response.statusCode() + " - " + response.body());
        }
    }

    @Override
    public Map<String, Object> loadDefaultValues(String userId) throws Exception {
        HttpRequest request = createRequestBuilder("default_values?user_id=eq." + userId)
                .GET()
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() != 200) {
            throw new Exception("Failed to load default values: " + response.statusCode());
        }

        List<Map<String, Object>> results = gson.fromJson(response.body(), new TypeToken<List<Map<String, Object>>>(){}.getType());

        if (results != null && !results.isEmpty()) {
            Object defaultsObj = results.get(0).get("defaults");
            if (defaultsObj instanceof Map) {
                return (Map<String, Object>) defaultsObj;
            }
        }

        return null;
    }

    @Override
    public void deleteRobotConfigs(String userId, List<Integer> robotNumbers) throws Exception {
        if (robotNumbers.isEmpty()) return;

        for (Integer robotNumber : robotNumbers) {
            HttpRequest request = createRequestBuilder("robot_configs?user_id=eq." + userId + "&robot_number=eq." + robotNumber)
                    .DELETE()
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() >= 400) {
                throw new Exception("Failed to delete robot config: " + response.statusCode());
            }
        }
    }
}
