package com.tradelogic.services;

public class DatabaseFactory {
    private static DatabaseClient instance;

    public static void initialize(DatabaseClient client) {
        instance = client;
    }

    public static DatabaseClient getInstance() {
        if (instance == null) {
            throw new IllegalStateException("DatabaseFactory not initialized");
        }
        return instance;
    }
}
