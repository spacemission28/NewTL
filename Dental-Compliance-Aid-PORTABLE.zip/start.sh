#!/bin/bash
cd "$(dirname "$0")"
echo ""
echo "Starting Dental Compliance Aid..."
echo "Open your browser to: http://localhost:3000"
echo "Press Ctrl+C to stop the server."
echo ""

if ! command -v node &> /dev/null; then
  echo "ERROR: Node.js is not installed."
  echo "Please install Node.js from https://nodejs.org/"
  exit 1
fi

export NODE_ENV=production
export PORT=3000
exec node dist/index.cjs
