Dental Compliance Aid - Portable Version
========================================

QUICK START (Windows):
  1. Double-click start.bat
  2. Open your browser to http://localhost:3000
  3. Press Ctrl+C in the window to stop

QUICK START (Mac/Linux):
  1. Open Terminal in this folder
  2. Run: ./start.sh
  3. Open your browser to http://localhost:3000

REQUIREMENTS:
  - Node.js must be installed: https://nodejs.org/
  - No database setup needed - data is stored in memory

The app runs entirely on your computer. Data is not sent anywhere.
