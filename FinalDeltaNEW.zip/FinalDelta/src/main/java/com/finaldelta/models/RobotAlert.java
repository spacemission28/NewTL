package com.finaldelta.models;

import java.time.Instant;
import java.util.UUID;

public class RobotAlert {
    private UUID id;
    private UUID robotConfigId;
    private String alertType;
    private String severity;
    private String message;
    private boolean acknowledged;
    private Instant createdAt;
    private Instant acknowledgedAt;

    public RobotAlert() {
        this.acknowledged = false;
    }

    public RobotAlert(UUID robotConfigId, String alertType, String severity, String message) {
        this.robotConfigId = robotConfigId;
        this.alertType = alertType;
        this.severity = severity;
        this.message = message;
        this.acknowledged = false;
        this.createdAt = Instant.now();
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public UUID getRobotConfigId() {
        return robotConfigId;
    }

    public void setRobotConfigId(UUID robotConfigId) {
        this.robotConfigId = robotConfigId;
    }

    public String getAlertType() {
        return alertType;
    }

    public void setAlertType(String alertType) {
        this.alertType = alertType;
    }

    public String getSeverity() {
        return severity;
    }

    public void setSeverity(String severity) {
        this.severity = severity;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isAcknowledged() {
        return acknowledged;
    }

    public void setAcknowledged(boolean acknowledged) {
        this.acknowledged = acknowledged;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Instant getAcknowledgedAt() {
        return acknowledgedAt;
    }

    public void setAcknowledgedAt(Instant acknowledgedAt) {
        this.acknowledgedAt = acknowledgedAt;
    }

    public String getSeverityEmoji() {
        switch (severity) {
            case "CRITICAL":
                return "🔴";
            case "WARNING":
                return "🟡";
            case "INFO":
                return "🔵";
            default:
                return "⚪";
        }
    }
}
