package com.finaldelta.services;

import com.finaldelta.Logger;
import com.finaldelta.models.RobotConfig;

import java.sql.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class ProfitCandleLimitMonitor {

    private final Map<String, TrackedPosition> activePositions = new ConcurrentHashMap<>();

    private static class TrackedPosition {
        String magicNumber;
        String symbol;
        String timeframe;
        long triggerTimestamp;
        int candleLimit;
        int candlesSinceTrigger;

        TrackedPosition(String magicNumber, String symbol, String timeframe, long triggerTimestamp, int candleLimit) {
            this.magicNumber = magicNumber;
            this.symbol = symbol;
            this.timeframe = timeframe;
            this.triggerTimestamp = triggerTimestamp;
            this.candleLimit = candleLimit;
            this.candlesSinceTrigger = 0;
        }
    }

    public ProfitCandleLimitMonitor() {
        loadActivePositionsFromDatabase();
    }

    public void registerTrigger(String magicNumber, String symbol, String timeframe, long triggerTimestamp, int candleLimit) {
        if (candleLimit <= 0) {
            Logger.info("Profit Candle Limit: Skipping registration for magic " + magicNumber + " (limit disabled: " + candleLimit + ")");
            return;
        }

        TrackedPosition position = new TrackedPosition(magicNumber, symbol, timeframe, triggerTimestamp, candleLimit);
        activePositions.put(magicNumber, position);

        saveToDatabase(position);

        Logger.info("★ Profit Candle Limit: Registered magic " + magicNumber +
                   " (" + symbol + "/" + timeframe + ") with " + candleLimit + " candle limit");
    }

    public List<String> checkCandleClose(String symbol, String timeframe, long candleCloseTimestamp) {
        List<String> magicNumbersToClose = new ArrayList<>();

        for (TrackedPosition position : activePositions.values()) {
            if (!position.symbol.equals(symbol) || !position.timeframe.equals(timeframe)) {
                continue;
            }

            if (candleCloseTimestamp > position.triggerTimestamp) {
                position.candlesSinceTrigger++;

                Logger.info("Profit Candle Limit: Magic " + position.magicNumber +
                           " - Candle " + position.candlesSinceTrigger + " of " + position.candleLimit);

                if (position.candlesSinceTrigger >= position.candleLimit) {
                    Logger.info("★★★ Profit Candle Limit REACHED: Magic " + position.magicNumber +
                               " (" + position.candlesSinceTrigger + "/" + position.candleLimit + " candles)");
                    magicNumbersToClose.add(position.magicNumber);
                }
            }
        }

        return magicNumbersToClose;
    }

    public void removeMagicNumber(String magicNumber) {
        if (activePositions.remove(magicNumber) != null) {
            removeFromDatabase(magicNumber);
            Logger.info("Profit Candle Limit: Removed tracking for magic " + magicNumber);
        }
    }

    public boolean isTracking(String magicNumber) {
        return activePositions.containsKey(magicNumber);
    }

    public int getActiveTrackingCount() {
        return activePositions.size();
    }

    private void saveToDatabase(TrackedPosition position) {
        PostgresClient postgresClient = getPostgresClient();
        if (postgresClient == null) {
            return;
        }

        try {

            String sql = """
                INSERT INTO profit_candle_tracking (magic_number, symbol, timeframe, trigger_timestamp, candle_limit)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT (magic_number) DO UPDATE SET
                    symbol = EXCLUDED.symbol,
                    timeframe = EXCLUDED.timeframe,
                    trigger_timestamp = EXCLUDED.trigger_timestamp,
                    candle_limit = EXCLUDED.candle_limit
                """;

            Connection conn = postgresClient.createConnection();

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, position.magicNumber);
                stmt.setString(2, position.symbol);
                stmt.setString(3, position.timeframe);
                stmt.setLong(4, position.triggerTimestamp);
                stmt.setInt(5, position.candleLimit);
                stmt.executeUpdate();
            } finally {
                conn.close();
            }
        } catch (SQLException e) {
            Logger.error("Failed to save profit candle tracking: " + e.getMessage());
        }
    }

    private void removeFromDatabase(String magicNumber) {
        PostgresClient postgresClient = getPostgresClient();
        if (postgresClient == null) {
            return;
        }

        try {

            Connection conn = postgresClient.createConnection();

            String sql = "DELETE FROM profit_candle_tracking WHERE magic_number = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, magicNumber);
                stmt.executeUpdate();
            } finally {
                conn.close();
            }
        } catch (SQLException e) {
            Logger.error("Failed to remove profit candle tracking: " + e.getMessage());
        }
    }

    private void loadActivePositionsFromDatabase() {
        PostgresClient postgresClient = getPostgresClient();
        if (postgresClient == null) {
            return;
        }

        try {

            Connection conn = postgresClient.createConnection();

            String sql = "SELECT magic_number, symbol, timeframe, trigger_timestamp, candle_limit FROM profit_candle_tracking";
            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {

                while (rs.next()) {
                    String magicNumber = rs.getString("magic_number");
                    String symbol = rs.getString("symbol");
                    String timeframe = rs.getString("timeframe");
                    long triggerTimestamp = rs.getLong("trigger_timestamp");
                    int candleLimit = rs.getInt("candle_limit");

                    TrackedPosition position = new TrackedPosition(magicNumber, symbol, timeframe, triggerTimestamp, candleLimit);
                    activePositions.put(magicNumber, position);
                }

                Logger.info("Profit Candle Limit: Loaded " + activePositions.size() + " tracked positions from database");
            } finally {
                conn.close();
            }
        } catch (SQLException e) {
            Logger.error("Failed to load profit candle tracking: " + e.getMessage());
        }
    }

    public void clearAll() {
        activePositions.clear();

        PostgresClient postgresClient = getPostgresClient();
        if (postgresClient == null) {
            return;
        }

        try {

            Connection conn = postgresClient.createConnection();

            String sql = "DELETE FROM profit_candle_tracking";
            try (Statement stmt = conn.createStatement()) {
                stmt.executeUpdate(sql);
            } finally {
                conn.close();
            }
            Logger.info("Profit Candle Limit: Cleared all tracking data");
        } catch (SQLException e) {
            Logger.error("Failed to clear profit candle tracking: " + e.getMessage());
        }
    }

    private PostgresClient getPostgresClient() {
        try {
            DatabaseClient client = DatabaseFactory.getInstance();
            if (client instanceof PostgresClient) {
                return (PostgresClient) client;
            }
        } catch (Exception e) {
            Logger.warning("Profit Candle Limit: PostgresClient not available");
        }
        return null;
    }
}
