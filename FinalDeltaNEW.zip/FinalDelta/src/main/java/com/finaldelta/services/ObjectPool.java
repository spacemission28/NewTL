package com.finaldelta.services;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Generic object pool to reduce GC pressure by reusing objects.
 * Thread-safe implementation using ConcurrentLinkedQueue.
 *
 * Usage:
 * <pre>
 * ObjectPool<TradeCommand> pool = new ObjectPool<>(
 *     TradeCommand::new,
 *     cmd -> cmd.reset()
 * );
 *
 * TradeCommand cmd = pool.acquire();
 * try {
 *     // Use the object
 * } finally {
 *     pool.release(cmd);
 * }
 * </pre>
 */
public class ObjectPool<T> {
    private final Queue<T> pool = new ConcurrentLinkedQueue<>();
    private final Supplier<T> factory;
    private final Consumer<T> reset;
    private final int maxSize;

    /**
     * Create an object pool with unlimited size.
     *
     * @param factory Function to create new objects when pool is empty
     * @param reset Function to reset object state before reuse
     */
    public ObjectPool(Supplier<T> factory, Consumer<T> reset) {
        this(factory, reset, Integer.MAX_VALUE);
    }

    /**
     * Create an object pool with maximum size limit.
     *
     * @param factory Function to create new objects when pool is empty
     * @param reset Function to reset object state before reuse
     * @param maxSize Maximum number of objects to keep in pool
     */
    public ObjectPool(Supplier<T> factory, Consumer<T> reset, int maxSize) {
        this.factory = factory;
        this.reset = reset;
        this.maxSize = maxSize;
    }

    /**
     * Acquire an object from the pool.
     * If pool is empty, creates a new object using the factory.
     *
     * @return An object ready for use
     */
    public T acquire() {
        T obj = pool.poll();
        return obj != null ? obj : factory.get();
    }

    /**
     * Release an object back to the pool.
     * The object will be reset before being returned to the pool.
     * If pool is at max capacity, the object is discarded.
     *
     * @param obj The object to return to the pool
     */
    public void release(T obj) {
        if (obj == null) return;

        reset.accept(obj);

        if (pool.size() < maxSize) {
            pool.offer(obj);
        }
    }

    /**
     * Get current pool size (for monitoring/debugging).
     *
     * @return Number of objects currently in pool
     */
    public int size() {
        return pool.size();
    }

    /**
     * Clear all objects from the pool.
     */
    public void clear() {
        pool.clear();
    }
}
