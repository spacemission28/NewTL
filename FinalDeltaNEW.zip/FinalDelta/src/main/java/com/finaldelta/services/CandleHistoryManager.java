package com.finaldelta.services;

import com.finaldelta.Logger;
import com.finaldelta.models.MarketBarData;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class CandleHistoryManager {

    private static final int MAX_CANDLE_HISTORY = 500;

    private final Map<String, LinkedList<MarketBarData>> candleBuffers = new ConcurrentHashMap<>();
    private final FileDataReader fileDataReader;
    private final CandleStorageService storageService;

    public CandleHistoryManager(FileDataReader fileDataReader, CandleStorageService storageService) {
        this.fileDataReader = fileDataReader;
        this.storageService = storageService;
    }

    public void preloadHistoricalCandles(String symbol, String timeframe) {
        String key = symbol + "_" + timeframe;

        if (candleBuffers.containsKey(key) && !candleBuffers.get(key).isEmpty()) {
            Logger.debug("CandleHistory: " + key + " already has " + candleBuffers.get(key).size() + " candles loaded");
            return;
        }

        List<MarketBarData> historicalCandles = new ArrayList<>();

        if (fileDataReader != null) {
            List<MarketBarData> fileCandles = fileDataReader.getRecentCompletedBars(symbol, timeframe, MAX_CANDLE_HISTORY);
            if (fileCandles != null && !fileCandles.isEmpty()) {
                historicalCandles.addAll(fileCandles);
                Logger.info("Preloaded " + fileCandles.size() + " candles from file for " + key);
            }
        }

        if (historicalCandles.isEmpty() && storageService != null && storageService.isDatabaseAvailable()) {
            List<MarketBarData> dbCandles = storageService.loadRecentCandles(symbol, timeframe, MAX_CANDLE_HISTORY);
            if (dbCandles != null && !dbCandles.isEmpty()) {
                historicalCandles.addAll(dbCandles);
                Logger.info("Preloaded " + dbCandles.size() + " candles from database for " + key);
            }
        }

        if (!historicalCandles.isEmpty()) {
            candleBuffers.putIfAbsent(key, new LinkedList<>());
            LinkedList<MarketBarData> buffer = candleBuffers.get(key);
            synchronized (buffer) {
                buffer.addAll(historicalCandles);
                Logger.info("CandleHistory: Preloaded " + buffer.size() + " historical candles for " + key);
            }
        } else {
            Logger.warning("CandleHistory: No historical candles found for " + key + " - will start fresh");
        }
    }

    public void addCandle(MarketBarData candle) {
        String key = candle.getKey();

        candleBuffers.putIfAbsent(key, new LinkedList<>());
        LinkedList<MarketBarData> buffer = candleBuffers.get(key);

        synchronized (buffer) {
            if (buffer.isEmpty() || candle.getCloseTime() > buffer.getLast().getCloseTime()) {
                buffer.addLast(candle);

                while (buffer.size() > MAX_CANDLE_HISTORY) {
                    buffer.removeFirst();
                }

                Logger.info("CandleHistory: Added " + key + " candle @ " + candle.getFormattedTimestamp() +
                           " (Buffer size: " + buffer.size() + ")");

                if (storageService != null && storageService.isDatabaseAvailable()) {
                    storageService.storeCandle(candle);
                }
            }
        }
    }

    public List<MarketBarData> getRecentCandles(String symbol, String timeframe, int count) {
        String key = symbol + "_" + timeframe;
        LinkedList<MarketBarData> buffer = candleBuffers.get(key);

        if (buffer != null && !buffer.isEmpty()) {
            synchronized (buffer) {
                int size = buffer.size();
                int fromIndex = Math.max(0, size - count);
                return new ArrayList<>(buffer.subList(fromIndex, size));
            }
        }

        if (fileDataReader != null) {
            List<MarketBarData> fileCandles = fileDataReader.getRecentCompletedBars(symbol, timeframe, count);
            if (fileCandles != null && !fileCandles.isEmpty()) {
                Logger.info("Loaded " + fileCandles.size() + " candles from file for " + symbol + " " + timeframe);
                return fileCandles;
            }
        }

        if (storageService != null && storageService.isDatabaseAvailable()) {
            List<MarketBarData> dbCandles = storageService.loadRecentCandles(symbol, timeframe, count);
            if (dbCandles != null && !dbCandles.isEmpty()) {
                return dbCandles;
            }
        }

        return Collections.emptyList();
    }

    public MarketBarData getLatestCandle(String symbol, String timeframe) {
        String key = symbol + "_" + timeframe;
        LinkedList<MarketBarData> buffer = candleBuffers.get(key);

        if (buffer == null || buffer.isEmpty()) {
            return null;
        }

        synchronized (buffer) {
            return buffer.getLast();
        }
    }

    public int getBufferSize(String symbol, String timeframe) {
        String key = symbol + "_" + timeframe;
        LinkedList<MarketBarData> buffer = candleBuffers.get(key);
        return (buffer != null) ? buffer.size() : 0;
    }

    public void clear() {
        candleBuffers.clear();
        Logger.info("CandleHistory: All buffers cleared");
    }
}
