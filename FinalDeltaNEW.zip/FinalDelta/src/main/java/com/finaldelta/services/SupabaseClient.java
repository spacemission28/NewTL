package com.finaldelta.services;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import com.finaldelta.Logger;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

/**
 * Client for interacting with Supabase REST API.
 * Provides methods for CRUD operations on database tables.
 */
public class SupabaseClient {
    private final String supabaseUrl;
    private final String supabaseAnonKey;
    private final HttpClient httpClient;
    private final Gson gson;

    private static SupabaseClient instance;

    private SupabaseClient(String url, String anonKey) {
        this.supabaseUrl = url;
        this.supabaseAnonKey = anonKey;
        this.httpClient = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_2)
                .build();
        this.gson = new GsonBuilder()
                .registerTypeAdapter(Instant.class, new InstantTypeAdapter())
                .setDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
                .create();
        Logger.info("SupabaseClient initialized: " + url);
    }

    /**
     * Initializes the singleton instance
     */
    public static void initialize(String url, String anonKey) {
        instance = new SupabaseClient(url, anonKey);
    }

    /**
     * Gets the singleton instance
     */
    public static SupabaseClient getInstance() {
        if (instance == null) {
            throw new IllegalStateException("SupabaseClient not initialized. Call initialize() first.");
        }
        return instance;
    }

    /**
     * Performs a SELECT query
     * @param table Table name
     * @param select Columns to select (e.g., "*" or "id,name")
     * @param filters Query filters (e.g., "id=eq.123")
     * @return JSON response as string
     */
    public String select(String table, String select, String filters) throws IOException, InterruptedException {
        String url = supabaseUrl + "/rest/v1/" + table + "?select=" + select;
        if (filters != null && !filters.isEmpty()) {
            url += "&" + filters;
        }

        System.out.println("[DEBUG SELECT] Table=" + table + ", URL=" + url);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("apikey", supabaseAnonKey)
                .header("Authorization", "Bearer " + supabaseAnonKey)
                .header("Content-Type", "application/json")
                .GET()
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() >= 400) {
            System.err.println("[DEBUG SELECT ERROR] Code=" + response.statusCode() + ", Body=" + response.body());
            Logger.error("Supabase SELECT failed: " + response.statusCode() + " - " + response.body());
            throw new IOException("Supabase request failed: " + response.statusCode());
        }

        System.out.println("[DEBUG SELECT SUCCESS] Rows returned: " + response.body().length() + " bytes");
        return response.body();
    }

    /**
     * Performs an INSERT operation
     */
    public String insert(String table, String jsonBody) throws IOException, InterruptedException {
        String url = supabaseUrl + "/rest/v1/" + table;

        System.out.println("[DEBUG INSERT] Table=" + table + ", Body=" + jsonBody);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("apikey", supabaseAnonKey)
                .header("Authorization", "Bearer " + supabaseAnonKey)
                .header("Content-Type", "application/json")
                .header("Prefer", "return=representation")
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() >= 400) {
            System.err.println("[DEBUG INSERT ERROR] Code=" + response.statusCode() + ", Body=" + response.body());
            Logger.error("Supabase INSERT failed: " + response.statusCode() + " - " + response.body());
            throw new IOException("Supabase request failed: " + response.statusCode());
        }

        System.out.println("[DEBUG INSERT SUCCESS] Response: " + response.body());
        return response.body();
    }

    /**
     * Performs an UPDATE operation
     */
    public String update(String table, String filters, String jsonBody) throws IOException, InterruptedException {
        String url = supabaseUrl + "/rest/v1/" + table + "?" + filters;

        System.out.println("[DEBUG UPDATE] Table=" + table + ", Filters=" + filters + ", Body=" + jsonBody);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("apikey", supabaseAnonKey)
                .header("Authorization", "Bearer " + supabaseAnonKey)
                .header("Content-Type", "application/json")
                .header("Prefer", "return=representation")
                .method("PATCH", HttpRequest.BodyPublishers.ofString(jsonBody))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() >= 400) {
            System.err.println("[DEBUG UPDATE ERROR] Code=" + response.statusCode() + ", Body=" + response.body());
            Logger.error("Supabase UPDATE failed: " + response.statusCode() + " - " + response.body());
            throw new IOException("Supabase request failed: " + response.statusCode());
        }

        System.out.println("[DEBUG UPDATE SUCCESS] Response: " + response.body());
        return response.body();
    }

    /**
     * Performs a DELETE operation
     */
    public void delete(String table, String filters) throws IOException, InterruptedException {
        String url = supabaseUrl + "/rest/v1/" + table + "?" + filters;

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("apikey", supabaseAnonKey)
                .header("Authorization", "Bearer " + supabaseAnonKey)
                .DELETE()
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() >= 400) {
            Logger.error("Supabase DELETE failed: " + response.statusCode() + " - " + response.body());
            throw new IOException("Supabase request failed: " + response.statusCode());
        }
    }

    /**
     * Parses JSON response to a list of objects
     */
    public <T> List<T> parseList(String json, Class<T> clazz) {
        Type listType = TypeToken.getParameterized(List.class, clazz).getType();
        return gson.fromJson(json, listType);
    }

    /**
     * Parses JSON response to a single object
     */
    public <T> T parseObject(String json, Class<T> clazz) {
        List<T> list = parseList(json, clazz);
        return list.isEmpty() ? null : list.get(0);
    }

    /**
     * Converts an object to JSON
     */
    public String toJson(Object obj) {
        return gson.toJson(obj);
    }


    /**
     * Converts an object to JSON (pretty printed)
     */
    public String toJsonPretty(Object obj) {
        return new GsonBuilder().setPrettyPrinting().create().toJson(obj);
    }

    /**
     * Custom TypeAdapter for java.time.Instant to handle serialization/deserialization
     */
    private static class InstantTypeAdapter extends TypeAdapter<Instant> {
        private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ISO_INSTANT;

        @Override
        public void write(JsonWriter out, Instant value) throws IOException {
            if (value == null) {
                out.nullValue();
            } else {
                out.value(FORMATTER.format(value));
            }
        }

        @Override
        public Instant read(JsonReader in) throws IOException {
            if (in.peek() == com.google.gson.stream.JsonToken.NULL) {
                in.nextNull();
                return null;
            }
            String timestamp = in.nextString();
            return Instant.parse(timestamp);
        }
    }
}
