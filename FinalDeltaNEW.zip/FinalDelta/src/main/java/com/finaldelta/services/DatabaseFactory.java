package com.finaldelta.services;

public class DatabaseFactory {
    private static DatabaseClient instance;

    public static void initialize(DatabaseClient client) {
        instance = client;
    }

    public static DatabaseClient getInstance() {
        return instance;
    }

    public static boolean isInitialized() {
        return instance != null;
    }

    public static DatabaseClient getClient() {
        return getInstance();
    }
}
