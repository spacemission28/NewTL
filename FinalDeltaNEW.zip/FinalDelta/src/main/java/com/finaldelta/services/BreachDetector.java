package com.finaldelta.services;

import com.finaldelta.Logger;
import com.finaldelta.models.MarketBarData;
import com.finaldelta.models.PendingPatternSetup;
import com.finaldelta.models.TickData;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class BreachDetector {

    public static class BreachCheckResult {
        private final List<PendingPatternSetup> breachedSetups;
        private final List<PendingPatternSetup> expiredSetups;

        public BreachCheckResult(List<PendingPatternSetup> breachedSetups, List<PendingPatternSetup> expiredSetups) {
            this.breachedSetups = breachedSetups;
            this.expiredSetups = expiredSetups;
        }

        public List<PendingPatternSetup> getBreachedSetups() {
            return breachedSetups;
        }

        public List<PendingPatternSetup> getExpiredSetups() {
            return expiredSetups;
        }
    }

    private final Map<String, PendingPatternSetup> pendingSetups = new ConcurrentHashMap<>();
    private final CandleHistoryManager candleHistory;
    private static final int MAX_CANDLES_TO_WAIT = 0;

    public BreachDetector(CandleHistoryManager candleHistory) {
        this.candleHistory = candleHistory;
    }

    public void registerPendingSetup(PendingPatternSetup setup) {
        String key = setup.getKey();
        pendingSetups.put(key, setup);

        Logger.info(String.format("  → BreachDetector: Registered %s setup for %s @ %.5f (Magic: %s)",
            setup.getDirection(), setup.getSymbol(), setup.getBreachLevel(), setup.getMagicNumber()));
    }

    public BreachCheckResult checkBreaches(TickData tick) {
        List<PendingPatternSetup> breachedSetups = new ArrayList<>();
        List<PendingPatternSetup> expiredSetups = new ArrayList<>();
        List<String> toRemove = new ArrayList<>();

        for (Map.Entry<String, PendingPatternSetup> entry : pendingSetups.entrySet()) {
            PendingPatternSetup setup = entry.getValue();

            if (!setup.getSymbol().equals(tick.getSymbol())) {
                continue;
            }

            List<MarketBarData> recentCandles = candleHistory.getRecentCandles(
                setup.getSymbol(),
                setup.getTimeframe(),
                MAX_CANDLES_TO_WAIT + 2
            );

            if (!recentCandles.isEmpty()) {
                MarketBarData latestCandle = recentCandles.get(recentCandles.size() - 1);

                int candlesSinceTrigger = 0;
                for (int i = recentCandles.size() - 1; i >= 0; i--) {
                    if (recentCandles.get(i).getCloseTime() > setup.getTriggerCandle().getCloseTime()) {
                        candlesSinceTrigger++;
                    } else {
                        break;
                    }
                }

                if (candlesSinceTrigger >= MAX_CANDLES_TO_WAIT && candlesSinceTrigger > 0) {
                    Logger.info(String.format("  ✗ Setup EXPIRED: %s waited %d candles (trigger candle closed without breach) - Magic: %s - DELETING PENDING ORDERS",
                        setup.getDirection(), candlesSinceTrigger, setup.getMagicNumber()));
                    expiredSetups.add(setup);
                    toRemove.add(entry.getKey());
                    continue;
                }
            }

            boolean breached = false;

            if ("BUY".equals(setup.getDirection())) {
                if (tick.getBid() >= setup.getBreachLevel() || tick.getAsk() >= setup.getBreachLevel()) {
                    breached = true;
                    Logger.info(String.format("  ★★★ BREACH DETECTED (BUY): %s @ %.5f >= %.5f (Magic: %s)",
                        setup.getSymbol(), tick.getBid(), setup.getBreachLevel(), setup.getMagicNumber()));
                }
            } else if ("SELL".equals(setup.getDirection())) {
                if (tick.getBid() <= setup.getBreachLevel() || tick.getAsk() <= setup.getBreachLevel()) {
                    breached = true;
                    Logger.info(String.format("  ★★★ BREACH DETECTED (SELL): %s @ %.5f <= %.5f (Magic: %s)",
                        setup.getSymbol(), tick.getBid(), setup.getBreachLevel(), setup.getMagicNumber()));
                }
            }

            if (breached) {
                breachedSetups.add(setup);
                toRemove.add(entry.getKey());
            }
        }

        for (String key : toRemove) {
            pendingSetups.remove(key);
        }

        return new BreachCheckResult(breachedSetups, expiredSetups);
    }

    public int getPendingCount() {
        return pendingSetups.size();
    }

    public void clear() {
        pendingSetups.clear();
        Logger.info("BreachDetector: All pending setups cleared");
    }
}
