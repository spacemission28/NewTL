package com.finaldelta.services;

import com.finaldelta.Logger;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class DataPurgeManager {

    private final String marketDataFolder;
    private final ScheduledExecutorService scheduler;
    private final long appLaunchTime;
    private static final String CANDLES_SUFFIX = "_candles.txt";

    private static final long HOURS_24_MS = 24 * 60 * 60 * 1000L;
    private static final long HOURS_30_MS = 30 * 60 * 60 * 1000L;
    private static final long DAYS_7_MS = 7 * 24 * 60 * 60 * 1000L;

    public DataPurgeManager(String marketDataFolder) {
        this.marketDataFolder = marketDataFolder;
        this.scheduler = Executors.newSingleThreadScheduledExecutor();
        this.appLaunchTime = System.currentTimeMillis();
    }

    public void start() {
        performStartupPurgeCheck();

        scheduler.scheduleAtFixedRate(
            this::performPeriodicPurge,
            1,
            1,
            TimeUnit.HOURS
        );

        Logger.info("DataPurgeManager started - checking for stale files every hour");
    }

    private void performStartupPurgeCheck() {
        try {
            Path dataPath = Paths.get(marketDataFolder);
            if (!Files.exists(dataPath)) {
                Logger.info("DataPurgeManager: Market data folder does not exist yet");
                return;
            }

            long now = System.currentTimeMillis();
            int purgedCount = 0;

            Files.walkFileTree(dataPath, new SimpleFileVisitor<Path>() {
                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                    String fileName = file.getFileName().toString();
                    if (!fileName.endsWith(CANDLES_SUFFIX)) {
                        return FileVisitResult.CONTINUE;
                    }

                    try {
                        long lastModified = attrs.lastModifiedTime().toMillis();
                        long ageMs = now - lastModified;

                        if (ageMs > HOURS_30_MS) {
                            Files.delete(file);
                            Logger.info("DataPurgeManager: Deleted stale file: " + fileName +
                                       " (age: " + (ageMs / (60 * 60 * 1000)) + " hours)");
                        }
                    } catch (IOException e) {
                        Logger.error("Failed to delete stale file " + fileName + ": " + e.getMessage());
                    }

                    return FileVisitResult.CONTINUE;
                }
            });

            Logger.info("DataPurgeManager: Startup purge check completed");

        } catch (Exception e) {
            Logger.error("DataPurgeManager startup purge failed: " + e.getMessage());
        }
    }

    private void performPeriodicPurge() {
        try {
            Path dataPath = Paths.get(marketDataFolder);
            if (!Files.exists(dataPath)) {
                return;
            }

            long now = System.currentTimeMillis();
            long appRuntime = now - appLaunchTime;
            int purgedCount = 0;

            if (appRuntime < HOURS_24_MS) {
                return;
            }

            Files.walkFileTree(dataPath, new SimpleFileVisitor<Path>() {
                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                    String fileName = file.getFileName().toString();
                    if (!fileName.endsWith(CANDLES_SUFFIX)) {
                        return FileVisitResult.CONTINUE;
                    }

                    try {
                        String symbol = fileName.substring(0, fileName.length() - CANDLES_SUFFIX.length());

                        long lastModified = attrs.lastModifiedTime().toMillis();
                        long ageMs = now - lastModified;

                        boolean shouldPurge = checkIfShouldPurge(file, ageMs);

                        if (shouldPurge) {
                            Files.delete(file);
                            Logger.info("DataPurgeManager: Purged " + fileName +
                                       " (age: " + (ageMs / (60 * 60 * 1000)) + " hours)");
                        }
                    } catch (IOException e) {
                        Logger.error("Failed to purge file " + fileName + ": " + e.getMessage());
                    }

                    return FileVisitResult.CONTINUE;
                }
            });

        } catch (Exception e) {
            Logger.error("DataPurgeManager periodic purge failed: " + e.getMessage());
        }
    }

    private boolean checkIfShouldPurge(Path file, long ageMs) throws IOException {
        String content = Files.readString(file);
        String[] lines = content.split("\\r?\\n");

        for (String line : lines) {
            if (line.trim().isEmpty() || line.startsWith("#")) {
                continue;
            }

            String[] parts = line.split(",");
            if (parts.length < 1) {
                continue;
            }

            String timeframe = parts[0].trim().replace("PERIOD_", "");

            if (isHigherThanH1(timeframe)) {
                if (ageMs > DAYS_7_MS) {
                    return true;
                }
            } else {
                if (ageMs > HOURS_24_MS) {
                    return true;
                }
            }

            break;
        }

        return false;
    }

    private boolean isHigherThanH1(String timeframe) {
        switch (timeframe.toUpperCase()) {
            case "M1":
            case "M2":
            case "M3":
            case "M5":
            case "M10":
            case "M15":
            case "M30":
            case "H1":
                return false;
            case "H3":
            case "H4":
            case "D1":
            case "W1":
            case "MN1":
                return true;
            default:
                Logger.warning("Unknown timeframe: " + timeframe + ", treating as ≤H1");
                return false;
        }
    }

    public void shutdown() {
        if (scheduler != null && !scheduler.isShutdown()) {
            scheduler.shutdown();
            try {
                if (!scheduler.awaitTermination(5, TimeUnit.SECONDS)) {
                    scheduler.shutdownNow();
                }
            } catch (InterruptedException e) {
                scheduler.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
        Logger.info("DataPurgeManager shutdown");
    }
}
