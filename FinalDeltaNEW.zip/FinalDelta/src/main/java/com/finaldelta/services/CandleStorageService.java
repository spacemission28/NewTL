package com.finaldelta.services;

import com.finaldelta.Logger;
import com.finaldelta.models.MarketBarData;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CandleStorageService {

    private final SupabaseClient supabaseClient;
    private final boolean isDatabaseAvailable;
    private final Gson gson = new Gson();

    public CandleStorageService(SupabaseClient supabaseClient) {
        this.supabaseClient = supabaseClient;
        this.isDatabaseAvailable = (supabaseClient != null);
    }

    public void storeCandle(MarketBarData candle) {
        if (!isDatabaseAvailable) {
            return;
        }

        try {
            Map<String, Object> candleData = new HashMap<>();
            candleData.put("symbol", candle.getSymbol());
            candleData.put("timeframe", candle.getTimeframe());

            String openTimeStr = Instant.ofEpochSecond(candle.getOpenTime())
                .atZone(ZoneOffset.UTC)
                .format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);
            String closeTimeStr = Instant.ofEpochSecond(candle.getCloseTime())
                .atZone(ZoneOffset.UTC)
                .format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);

            candleData.put("open_time", openTimeStr);
            candleData.put("close_time", closeTimeStr);
            candleData.put("open", candle.getOpen());
            candleData.put("high", candle.getHigh());
            candleData.put("low", candle.getLow());
            candleData.put("close", candle.getClose());

            String jsonBody = gson.toJson(candleData);
            supabaseClient.insert("market_candles", jsonBody);

        } catch (Exception e) {
            Logger.error("Failed to store candle in database: " + e.getMessage());
        }
    }

    public List<MarketBarData> loadRecentCandles(String symbol, String timeframe, int count) {
        List<MarketBarData> candles = new ArrayList<>();

        if (!isDatabaseAvailable) {
            return candles;
        }

        try {
            String filters = "symbol=eq." + symbol + "&timeframe=eq." + timeframe +
                           "&order=close_time.desc&limit=" + count;

            String response = supabaseClient.select("market_candles", "*", filters);

            JsonArray results = JsonParser.parseString(response).getAsJsonArray();

            for (int i = results.size() - 1; i >= 0; i--) {
                JsonObject row = results.get(i).getAsJsonObject();

                String sym = row.get("symbol").getAsString();
                String tf = row.get("timeframe").getAsString();

                String openTimeStr = row.get("open_time").getAsString();
                long openTime = Instant.parse(openTimeStr).getEpochSecond();

                double open = row.get("open").getAsDouble();
                double high = row.get("high").getAsDouble();
                double low = row.get("low").getAsDouble();
                double close = row.get("close").getAsDouble();

                Double bbUpper = row.has("bb_upper") && !row.get("bb_upper").isJsonNull()
                    ? row.get("bb_upper").getAsDouble()
                    : null;
                Double bbBasis = row.has("bb_basis") && !row.get("bb_basis").isJsonNull()
                    ? row.get("bb_basis").getAsDouble()
                    : null;
                Double bbLower = row.has("bb_lower") && !row.get("bb_lower").isJsonNull()
                    ? row.get("bb_lower").getAsDouble()
                    : null;

                MarketBarData candle = new MarketBarData(sym, tf, openTime, open, high, low, close, bbUpper, bbBasis, bbLower);
                candles.add(candle);
            }

            Logger.info("Loaded " + candles.size() + " candles from database for " + symbol + " " + timeframe);

        } catch (Exception e) {
            Logger.error("Failed to load candles from database: " + e.getMessage());
        }

        return candles;
    }

    public boolean isDatabaseAvailable() {
        return isDatabaseAvailable;
    }
}
