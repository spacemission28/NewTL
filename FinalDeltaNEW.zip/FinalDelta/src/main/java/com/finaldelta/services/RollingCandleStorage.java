package com.finaldelta.services;

import com.finaldelta.Logger;
import com.finaldelta.models.MarketBarData;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class RollingCandleStorage {
    private static final int MAX_CANDLES_PER_ROW = 5;

    private final Map<String, LinkedList<MarketBarData>> candleStorage;

    public RollingCandleStorage() {
        this.candleStorage = new ConcurrentHashMap<>();
        Logger.info("RollingCandleStorage initialized");
    }

    public void addCandle(int rowNumber, String symbol, String timeframe, MarketBarData candle) {
        String key = createKey(rowNumber, symbol, timeframe);

        candleStorage.computeIfAbsent(key, k -> new LinkedList<>());
        LinkedList<MarketBarData> candles = candleStorage.get(key);

        candles.addLast(candle);

        while (candles.size() > MAX_CANDLES_PER_ROW) {
            candles.removeFirst();
        }

        Logger.debug("Row " + rowNumber + " (" + symbol + "/" + timeframe + "): stored candle, total=" + candles.size());
    }

    public List<MarketBarData> getCandles(int rowNumber, String symbol, String timeframe) {
        String key = createKey(rowNumber, symbol, timeframe);
        LinkedList<MarketBarData> candles = candleStorage.get(key);

        if (candles == null || candles.isEmpty()) {
            return new ArrayList<>();
        }

        return new ArrayList<>(candles);
    }

    public int getCandleCount(int rowNumber, String symbol, String timeframe) {
        String key = createKey(rowNumber, symbol, timeframe);
        LinkedList<MarketBarData> candles = candleStorage.get(key);
        return (candles != null) ? candles.size() : 0;
    }

    public void clearCandles(int rowNumber, String symbol, String timeframe) {
        String key = createKey(rowNumber, symbol, timeframe);
        candleStorage.remove(key);
        Logger.info("Cleared candle storage for row " + rowNumber + " (" + symbol + "/" + timeframe + ")");
    }

    public void clearAllCandles(int rowNumber) {
        Iterator<String> iterator = candleStorage.keySet().iterator();
        while (iterator.hasNext()) {
            String key = iterator.next();
            if (key.startsWith("row_" + rowNumber + "_")) {
                iterator.remove();
            }
        }
        Logger.info("Cleared all candle storage for row " + rowNumber);
    }

    public void clearAll() {
        candleStorage.clear();
        Logger.info("Cleared all candle storage");
    }

    private String createKey(int rowNumber, String symbol, String timeframe) {
        return "row_" + rowNumber + "_" + symbol + "_" + timeframe;
    }

    public Map<String, Integer> getStorageStats() {
        Map<String, Integer> stats = new HashMap<>();
        for (Map.Entry<String, LinkedList<MarketBarData>> entry : candleStorage.entrySet()) {
            stats.put(entry.getKey(), entry.getValue().size());
        }
        return stats;
    }
}
