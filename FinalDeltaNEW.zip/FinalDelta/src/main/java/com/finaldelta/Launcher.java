package com.finaldelta;

/**
 * A separate launcher class to work around the JavaFX fat jar
 * module-path vs. classpath conflict.
 */
public class Launcher {
    public static void main(String[] args) {
        // This just calls the main method of your real application
        FinalDeltaApplication.main(args);
    }
}