package com.finaldelta.auth;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.spec.KeySpec;
import java.util.Base64;
import java.util.Properties;

public class CredentialManager {
    private static final String CONFIG_DIR = ".finaldelta";
    private static final String CRED_FILE = "credentials.enc";
    private static final String SALT = "TradeLogicSalt2025";

    private final Path credentialPath;

    public CredentialManager() {
        String userHome = System.getProperty("user.home");
        Path configDir = Paths.get(userHome, CONFIG_DIR);

        try {
            if (!Files.exists(configDir)) {
                Files.createDirectories(configDir);
            }
        } catch (IOException e) {
            System.err.println("Failed to create config directory: " + e.getMessage());
        }

        this.credentialPath = configDir.resolve(CRED_FILE);
    }

    public void saveCredentials(String login, String password, String server, boolean savePassword) {
        try {
            Properties props = new Properties();
            props.setProperty("login", encrypt(login));
            props.setProperty("server", encrypt(server));

            if (savePassword) {
                props.setProperty("password", encrypt(password));
                props.setProperty("savePassword", "true");
            } else {
                props.setProperty("savePassword", "false");
            }

            try (OutputStream out = Files.newOutputStream(credentialPath)) {
                props.store(out, "TradeLogic Credentials");
            }
        } catch (Exception e) {
            System.err.println("Failed to save credentials: " + e.getMessage());
        }
    }

    public Credentials loadCredentials() {
        if (!Files.exists(credentialPath)) {
            return null;
        }

        try {
            Properties props = new Properties();
            try (InputStream in = Files.newInputStream(credentialPath)) {
                props.load(in);
            }

            String login = decrypt(props.getProperty("login", ""));
            String server = decrypt(props.getProperty("server", ""));
            boolean savePassword = Boolean.parseBoolean(props.getProperty("savePassword", "false"));
            String password = savePassword ? decrypt(props.getProperty("password", "")) : "";

            return new Credentials(login, password, server, savePassword);
        } catch (Exception e) {
            System.err.println("Failed to load credentials: " + e.getMessage());
            return null;
        }
    }

    public void clearCredentials() {
        try {
            Files.deleteIfExists(credentialPath);
        } catch (IOException e) {
            System.err.println("Failed to clear credentials: " + e.getMessage());
        }
    }

    private String encrypt(String value) throws Exception {
        SecretKey key = generateKey();
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] encrypted = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(encrypted);
    }

    private String decrypt(String encrypted) throws Exception {
        SecretKey key = generateKey();
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, key);
        byte[] decoded = Base64.getDecoder().decode(encrypted);
        byte[] decrypted = cipher.doFinal(decoded);
        return new String(decrypted, StandardCharsets.UTF_8);
    }

    private SecretKey generateKey() throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(SALT.getBytes(StandardCharsets.UTF_8));
        byte[] key = new byte[16];
        System.arraycopy(hash, 0, key, 0, 16);
        return new SecretKeySpec(key, "AES");
    }

    public static class Credentials {
        private final String login;
        private final String password;
        private final String server;
        private final boolean savePassword;

        public Credentials(String login, String password, String server, boolean savePassword) {
            this.login = login;
            this.password = password;
            this.server = server;
            this.savePassword = savePassword;
        }

        public String getLogin() { return login; }
        public String getPassword() { return password; }
        public String getServer() { return server; }
        public boolean isSavePassword() { return savePassword; }
    }
}
