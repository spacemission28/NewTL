package com.finaldelta.ui;

import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class ConnectionIndicator extends VBox {

    public enum Status {
        GREY("Not Connected", Color.GREY),
        GREEN("Connected", Color.web("#4cff4c")),
        RED("Login Failed", Color.web("#ff6b6b")),
        BLUE("Connection Lost", Color.web("#3498db"));

        private final String text;
        private final Color color;

        Status(String text, Color color) {
            this.text = text;
            this.color = color;
        }

        public String getText() { return text; }
        public Color getColor() { return color; }
    }

    private final Circle light;
    private final Label statusLabel;
    private final Tooltip tooltip;
    private Status currentStatus = Status.GREY;

    public ConnectionIndicator() {
        light = new Circle(10);
        light.setFill(Status.GREY.getColor());
        light.setStroke(Color.web("#333"));
        light.setStrokeWidth(1.5);

        statusLabel = new Label(Status.GREY.getText());
        statusLabel.setStyle("-fx-text-fill: #cccccc; -fx-font-size: 10px;");

        tooltip = new Tooltip();
        tooltip.setStyle("-fx-font-size: 11px;");
        Tooltip.install(light, tooltip);

        setAlignment(Pos.CENTER);
        setSpacing(3);
        getChildren().addAll(light, statusLabel);

        setOnMouseClicked(e -> {
            tooltip.show(light, e.getScreenX(), e.getScreenY() + 10);
        });

        updateStatus(Status.GREY, "No login attempt");
    }

    public void updateStatus(Status status, String detailedMessage) {
        Platform.runLater(() -> {
            currentStatus = status;
            light.setFill(status.getColor());
            statusLabel.setText(status.getText());
            tooltip.setText(detailedMessage);
        });
    }

    public Status getCurrentStatus() {
        return currentStatus;
    }

    public void setConnected(boolean connected) {
        if (connected) {
            updateStatus(Status.GREEN, "Connected to TickRecorder");
        } else {
            updateStatus(Status.RED, "TickRecorder not responding");
        }
    }
}
