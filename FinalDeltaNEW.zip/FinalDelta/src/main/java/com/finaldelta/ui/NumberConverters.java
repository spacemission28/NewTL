package com.finaldelta.ui;

import javafx.util.StringConverter;

/**
 * Custom converters for Number types in TableView cells
 */
public class NumberConverters {

    /**
     * Converter for Integer to/from String
     */
    public static class IntegerStringConverter extends StringConverter<Number> {
        @Override
        public String toString(Number number) {
            if (number == null) {
                return "0";
            }
            return String.valueOf(number.intValue());
        }

        @Override
        public Number fromString(String string) {
            if (string == null || string.trim().isEmpty()) {
                return 0;
            }
            try {
                return Integer.parseInt(string.trim());
            } catch (NumberFormatException e) {
                return 0;
            }
        }
    }

    /**
     * Converter for Integer to/from Number
     */
    public static class IntegerNumberConverter extends StringConverter<Number> {
        @Override
        public String toString(Number number) {
            if (number == null) {
                return "0";
            }
            return String.valueOf(number.intValue());
        }

        @Override
        public Number fromString(String string) {
            if (string == null || string.trim().isEmpty()) {
                return 0;
            }
            try {
                return Integer.parseInt(string.trim());
            } catch (NumberFormatException e) {
                return 0;
            }
        }
    }

    /**
     * Converter for Double to/from Number
     */
    public static class DoubleNumberConverter extends StringConverter<Number> {
        @Override
        public String toString(Number number) {
            if (number == null) {
                return "0.0";
            }
            return String.format("%.2f", number.doubleValue());
        }

        @Override
        public Number fromString(String string) {
            if (string == null || string.trim().isEmpty()) {
                return 0.0;
            }
            try {
                return Double.parseDouble(string.trim());
            } catch (NumberFormatException e) {
                return 0.0;
            }
        }
    }
}
