package com.finaldelta.ui;

import com.finaldelta.ui.NumberConverters.IntegerNumberConverter;
import com.finaldelta.ui.NumberConverters.DoubleNumberConverter;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.util.StringConverter;

import java.util.HashMap;
import java.util.Map;

public class DefaultValuesDialog extends Dialog<Map<String, Object>> {

    private final ComboBox<String> symbolCombo;
    private final ComboBox<String> timeframeCombo;
    private final ComboBox<Integer> startHourCombo;
    private final ComboBox<Integer> startMinuteCombo;
    private final TextField minX1HeightField;
    private final ComboBox<String> x1TypeCombo;
    private final TextField trigPercentField;
    private final TextField stopLossPercentField;
    private final TextField rptPercentField;
    private final TextField rptFixedAmountField;
    private final TextField tp1PercentField;
    private final Spinner<Integer> tp1VolumeSpinner;
    private final TextField tp2PercentField;
    private final Spinner<Integer> tp2VolumeSpinner;
    private final TextField tp3PercentField;
    private final Spinner<Integer> tp3VolumeSpinner;
    private final Spinner<Integer> profitCandleLimitSpinner;
    private final CheckBox commissionsEnabledCheckBox;
    private final ComboBox<String> commissionTypeCombo;
    private final TextField commissionValueField;
    private final CheckBox disableLeapfrogCheckBox;
    private final CheckBox x2StrictEnabledCheckBox;
    private final CheckBox x2RelaxedEnabledCheckBox;
    private final CheckBox eodEnabledCheckBox;
    private final ComboBox<Integer> endHourCombo;
    private final ComboBox<Integer> endMinuteCombo;

    public DefaultValuesDialog(Map<String, Object> currentDefaults, ObservableList<String> availableSymbols) {
        setTitle("Set Default Values");
        setHeaderText("Configure default values for new robot rows");

        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        int row = 0;

        ObservableList<String> symbolList = (availableSymbols != null && !availableSymbols.isEmpty())
            ? availableSymbols
            : FXCollections.observableArrayList("XAUUSD", "EURUSD", "GBPUSD", "USDJPY");

        symbolCombo = new ComboBox<>(symbolList);
        symbolCombo.setEditable(false);
        String defaultSymbol = (String) currentDefaults.getOrDefault("symbol", "XAUUSD");
        if (symbolList.contains(defaultSymbol)) {
            symbolCombo.setValue(defaultSymbol);
        } else if (!symbolList.isEmpty()) {
            symbolCombo.setValue(symbolList.get(0));
        }
        grid.add(new Label("Symbol:"), 0, row);
        grid.add(symbolCombo, 1, row++);

        timeframeCombo = new ComboBox<>(FXCollections.observableArrayList(
            "M1", "M2", "M3", "M5", "M10", "M15", "M30", "H1", "H3", "H4", "D1"
        ));
        timeframeCombo.setValue((String) currentDefaults.getOrDefault("timeframe", "H1"));
        grid.add(new Label("Timeframe:"), 0, row);
        grid.add(timeframeCombo, 1, row++);

        // Create Close Hour ComboBox with values 0-23
        ObservableList<Integer> hours = FXCollections.observableArrayList();
        for (int i = 0; i <= 23; i++) {
            hours.add(i);
        }
        startHourCombo = new ComboBox<>(hours);
        startHourCombo.setValue(((Number) currentDefaults.getOrDefault("start_hour", 0)).intValue());
        grid.add(new Label("Start Hour:"), 0, row);
        grid.add(startHourCombo, 1, row++);

        // Create Close Minute ComboBox with values 0-59
        ObservableList<Integer> minutes = FXCollections.observableArrayList();
        for (int i = 0; i <= 59; i++) {
            minutes.add(i);
        }
        startMinuteCombo = new ComboBox<>(minutes);
        startMinuteCombo.setValue(((Number) currentDefaults.getOrDefault("start_minute", 0)).intValue());
        grid.add(new Label("Start Minute:"), 0, row);
        grid.add(startMinuteCombo, 1, row++);

        minX1HeightField = new TextField(String.valueOf(((Number) currentDefaults.getOrDefault("min_x1_height", 7.0)).doubleValue()));
        grid.add(new Label("Min X1 Height:"), 0, row);
        grid.add(minX1HeightField, 1, row++);

        x1TypeCombo = new ComboBox<>(FXCollections.observableArrayList(
            "Yen Pips", "Non-Yen Pips", "Cents", "Points"
        ));
        x1TypeCombo.setValue((String) currentDefaults.getOrDefault("x1_type", "Cents"));
        grid.add(new Label("X1 Type:"), 0, row);
        grid.add(x1TypeCombo, 1, row++);

        trigPercentField = new TextField(String.valueOf(((Number) currentDefaults.getOrDefault("trig_percent", 13.0)).doubleValue()));
        grid.add(new Label("Trig %:"), 0, row);
        grid.add(trigPercentField, 1, row++);

        stopLossPercentField = new TextField(String.valueOf(((Number) currentDefaults.getOrDefault("stop_loss_percent", 13.0)).doubleValue()));
        grid.add(new Label("Stop Loss %:"), 0, row);
        grid.add(stopLossPercentField, 1, row++);

        rptPercentField = new TextField(String.valueOf(((Number) currentDefaults.getOrDefault("rpt_percent", 0.3)).doubleValue()));
        grid.add(new Label("RPT %:"), 0, row);
        grid.add(rptPercentField, 1, row++);

        rptFixedAmountField = new TextField(String.valueOf(((Number) currentDefaults.getOrDefault("rpt_fixed_amount", 0.0)).doubleValue()));
        grid.add(new Label("RPT Fixed $:"), 0, row);
        grid.add(rptFixedAmountField, 1, row++);

        tp1PercentField = new TextField(String.valueOf(((Number) currentDefaults.getOrDefault("tp1_percent", 100.0)).doubleValue()));
        tp1VolumeSpinner = new Spinner<>(0, 100, ((Number) currentDefaults.getOrDefault("tp1_volume", 14)).intValue());
        grid.add(new Label("TP1 %:"), 0, row);
        grid.add(tp1PercentField, 1, row);
        grid.add(new Label("Vol:"), 2, row);
        grid.add(tp1VolumeSpinner, 3, row++);

        tp2PercentField = new TextField(String.valueOf(((Number) currentDefaults.getOrDefault("tp2_percent", 110.0)).doubleValue()));
        tp2VolumeSpinner = new Spinner<>(0, 100, ((Number) currentDefaults.getOrDefault("tp2_volume", 14)).intValue());
        grid.add(new Label("TP2 %:"), 0, row);
        grid.add(tp2PercentField, 1, row);
        grid.add(new Label("Vol:"), 2, row);
        grid.add(tp2VolumeSpinner, 3, row++);

        tp3PercentField = new TextField(String.valueOf(((Number) currentDefaults.getOrDefault("tp3_percent", 125.0)).doubleValue()));
        tp3VolumeSpinner = new Spinner<>(0, 100, ((Number) currentDefaults.getOrDefault("tp3_volume", 14)).intValue());
        grid.add(new Label("TP3 %:"), 0, row);
        grid.add(tp3PercentField, 1, row);
        grid.add(new Label("Vol:"), 2, row);
        grid.add(tp3VolumeSpinner, 3, row++);

        profitCandleLimitSpinner = new Spinner<>(0, 999, ((Number) currentDefaults.getOrDefault("profit_candle_limit", 0)).intValue());
        grid.add(new Label("Prof Cndl Lmt:"), 0, row);
        grid.add(profitCandleLimitSpinner, 1, row++);

        commissionsEnabledCheckBox = new CheckBox();
        commissionsEnabledCheckBox.setSelected((Boolean) currentDefaults.getOrDefault("commissions_enabled", false));
        grid.add(new Label("Commissions Enabled:"), 0, row);
        grid.add(commissionsEnabledCheckBox, 1, row++);

        commissionTypeCombo = new ComboBox<>(FXCollections.observableArrayList(
            "No_Commissions", "FX_per_Lot", "ETF_Stock"
        ));
        commissionTypeCombo.setValue((String) currentDefaults.getOrDefault("commission_type", "No_Commissions"));
        grid.add(new Label("Commission Type:"), 0, row);
        grid.add(commissionTypeCombo, 1, row++);

        commissionValueField = new TextField(String.valueOf(((Number) currentDefaults.getOrDefault("commission_value", 0.0)).doubleValue()));
        grid.add(new Label("Commission Value:"), 0, row);
        grid.add(commissionValueField, 1, row++);

        disableLeapfrogCheckBox = new CheckBox();
        disableLeapfrogCheckBox.setSelected((Boolean) currentDefaults.getOrDefault("disable_leapfrog", false));
        grid.add(new Label("Disable Leapfrog:"), 0, row);
        grid.add(disableLeapfrogCheckBox, 1, row++);

        x2StrictEnabledCheckBox = new CheckBox();
        x2StrictEnabledCheckBox.setSelected((Boolean) currentDefaults.getOrDefault("x2_strict_enabled", true));
        grid.add(new Label("X2 Strict:"), 0, row);
        grid.add(x2StrictEnabledCheckBox, 1, row++);

        x2RelaxedEnabledCheckBox = new CheckBox();
        x2RelaxedEnabledCheckBox.setSelected((Boolean) currentDefaults.getOrDefault("x2_relaxed_enabled", true));
        grid.add(new Label("X2 Relaxed:"), 0, row);
        grid.add(x2RelaxedEnabledCheckBox, 1, row++);

        eodEnabledCheckBox = new CheckBox();
        eodEnabledCheckBox.setSelected((Boolean) currentDefaults.getOrDefault("eod_enabled", false));
        grid.add(new Label("EOD Enabled:"), 0, row);
        grid.add(eodEnabledCheckBox, 1, row++);

        // EOD fields
        ObservableList<Integer> endHours = FXCollections.observableArrayList();
        for (int i = 0; i <= 23; i++) {
            endHours.add(i);
        }
        endHourCombo = new ComboBox<>(endHours);
        endHourCombo.setValue(((Number) currentDefaults.getOrDefault("end_hour", 23)).intValue());
        grid.add(new Label("End Hour:"), 0, row);
        grid.add(endHourCombo, 1, row++);

        ObservableList<Integer> endMinutes = FXCollections.observableArrayList();
        for (int i = 0; i <= 59; i++) {
            endMinutes.add(i);
        }
        endMinuteCombo = new ComboBox<>(endMinutes);
        endMinuteCombo.setValue(((Number) currentDefaults.getOrDefault("end_minute", 50)).intValue());
        grid.add(new Label("End Minute:"), 0, row);
        grid.add(endMinuteCombo, 1, row++);

        ScrollPane scrollPane = new ScrollPane(grid);
        scrollPane.setFitToWidth(true);
        scrollPane.setPrefViewportHeight(600);
        scrollPane.setStyle("-fx-background-color: transparent;");
        getDialogPane().setContent(scrollPane);

        setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                Map<String, Object> defaults = new HashMap<>();
                defaults.put("symbol", symbolCombo.getValue());
                defaults.put("timeframe", timeframeCombo.getValue());
                defaults.put("start_hour", startHourCombo.getValue());
                defaults.put("start_minute", startMinuteCombo.getValue());
                defaults.put("min_x1_height", Double.parseDouble(minX1HeightField.getText()));
                defaults.put("x1_type", x1TypeCombo.getValue());
                defaults.put("trig_percent", Double.parseDouble(trigPercentField.getText()));
                defaults.put("stop_loss_percent", Double.parseDouble(stopLossPercentField.getText()));
                defaults.put("rpt_percent", Double.parseDouble(rptPercentField.getText()));
                defaults.put("rpt_fixed_amount", Double.parseDouble(rptFixedAmountField.getText()));
                defaults.put("tp1_percent", Double.parseDouble(tp1PercentField.getText()));
                defaults.put("tp1_volume", tp1VolumeSpinner.getValue());
                defaults.put("tp2_percent", Double.parseDouble(tp2PercentField.getText()));
                defaults.put("tp2_volume", tp2VolumeSpinner.getValue());
                defaults.put("tp3_percent", Double.parseDouble(tp3PercentField.getText()));
                defaults.put("tp3_volume", tp3VolumeSpinner.getValue());
                defaults.put("profit_candle_limit", profitCandleLimitSpinner.getValue());
                defaults.put("commissions_enabled", commissionsEnabledCheckBox.isSelected());
                defaults.put("commission_type", commissionTypeCombo.getValue());
                defaults.put("commission_value", Double.parseDouble(commissionValueField.getText()));
                defaults.put("disable_leapfrog", disableLeapfrogCheckBox.isSelected());
                defaults.put("x2_strict_enabled", x2StrictEnabledCheckBox.isSelected());
                defaults.put("x2_relaxed_enabled", x2RelaxedEnabledCheckBox.isSelected());
                defaults.put("eod_enabled", eodEnabledCheckBox.isSelected());
                defaults.put("end_hour", endHourCombo.getValue());
                defaults.put("end_minute", endMinuteCombo.getValue());
                return defaults;
            }
            return null;
        });
    }
}
