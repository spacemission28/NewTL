package com.finaldelta.models;

import java.time.Instant;
import java.util.UUID;

public class RobotConfig {
    private UUID id;
    private UUID userId;
    private int robotNumber;
    private String magicNumber;
    private String robotName;
    private String symbol;
    private String timeframe;
    private int startHour;
    private int startMinute;
    private int endHour;
    private int endMinute;
    private boolean endTimeEnabled;
    private double minX1Height;
    private String x1Type;
    private double trigPercent;
    private double stopLossPercent;
    private double rptPercent;
    private double rptFixedAmount;
    private double tp1Percent;
    private int tp1Volume;
    private double tp2Percent;
    private int tp2Volume;
    private double tp3Percent;
    private int tp3Volume;
    private double tp4Percent;
    private int tp4Volume;
    private double tp5Percent;
    private int tp5Volume;
    private double tp6Percent;
    private int tp6Volume;
    private double tp7Percent;
    private int tp7Volume;
    private int profitCandleLimit;
    private boolean commissionsEnabled;
    private String commissionType;
    private double commissionValue;
    private boolean disableLeapfrog;
    private double dailyDdLimit;
    private boolean x4StrictEnabled;
    private boolean x4RelaxedEnabled;
    private boolean x5StrictEnabled;
    private boolean x5RelaxedEnabled;
    private boolean active;
    private Instant createdAt;

    public RobotConfig() {
        this.id = UUID.randomUUID();
        this.endTimeEnabled = true;
        this.x4StrictEnabled = true;
        this.x4RelaxedEnabled = true;
        this.x5StrictEnabled = true;
        this.x5RelaxedEnabled = true;
        this.commissionsEnabled = false;
        this.disableLeapfrog = false;
        this.active = false;
        this.createdAt = Instant.now();
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public int getRobotNumber() {
        return robotNumber;
    }

    public void setRobotNumber(int robotNumber) {
        this.robotNumber = robotNumber;
    }

    public String getMagicNumber() {
        return magicNumber;
    }

    public void setMagicNumber(String magicNumber) {
        this.magicNumber = magicNumber;
    }

    public String getRobotName() {
        return robotName;
    }

    public void setRobotName(String robotName) {
        this.robotName = robotName;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getTimeframe() {
        return timeframe;
    }

    public void setTimeframe(String timeframe) {
        this.timeframe = timeframe;
    }

    public int getStartHour() {
        return startHour;
    }

    public void setStartHour(int startHour) {
        this.startHour = startHour;
    }

    public int getStartMinute() {
        return startMinute;
    }

    public void setStartMinute(int startMinute) {
        this.startMinute = startMinute;
    }

    public int getEndHour() {
        return endHour;
    }

    public void setEndHour(int endHour) {
        this.endHour = endHour;
    }

    public int getEndMinute() {
        return endMinute;
    }

    public void setEndMinute(int endMinute) {
        this.endMinute = endMinute;
    }

    public boolean isEndTimeEnabled() {
        return endTimeEnabled;
    }

    public void setEndTimeEnabled(boolean endTimeEnabled) {
        this.endTimeEnabled = endTimeEnabled;
    }

    public double getMinX1Height() {
        return minX1Height;
    }

    public void setMinX1Height(double minX1Height) {
        this.minX1Height = minX1Height;
    }

    public String getX1Type() {
        return x1Type;
    }

    public void setX1Type(String x1Type) {
        this.x1Type = x1Type;
    }

    public double getTrigPercent() {
        return trigPercent;
    }

    public void setTrigPercent(double trigPercent) {
        this.trigPercent = trigPercent;
    }

    public double getStopLossPercent() {
        return stopLossPercent;
    }

    public void setStopLossPercent(double stopLossPercent) {
        this.stopLossPercent = stopLossPercent;
    }

    public double getRptPercent() {
        return rptPercent;
    }

    public void setRptPercent(double rptPercent) {
        this.rptPercent = rptPercent;
    }

    public double getRptFixedAmount() {
        return rptFixedAmount;
    }

    public void setRptFixedAmount(double rptFixedAmount) {
        this.rptFixedAmount = rptFixedAmount;
    }

    public double getTp1Percent() {
        return tp1Percent;
    }

    public void setTp1Percent(double tp1Percent) {
        this.tp1Percent = tp1Percent;
    }

    public double getTp1Pct() {
        return tp1Percent;
    }

    public void setTp1Pct(double tp1Pct) {
        this.tp1Percent = tp1Pct;
    }

    public int getTp1Volume() {
        return tp1Volume;
    }

    public void setTp1Volume(int tp1Volume) {
        this.tp1Volume = tp1Volume;
    }

    public double getTp2Percent() {
        return tp2Percent;
    }

    public void setTp2Percent(double tp2Percent) {
        this.tp2Percent = tp2Percent;
    }

    public double getTp2Pct() {
        return tp2Percent;
    }

    public void setTp2Pct(double tp2Pct) {
        this.tp2Percent = tp2Pct;
    }

    public int getTp2Volume() {
        return tp2Volume;
    }

    public void setTp2Volume(int tp2Volume) {
        this.tp2Volume = tp2Volume;
    }

    public double getTp3Percent() {
        return tp3Percent;
    }

    public void setTp3Percent(double tp3Percent) {
        this.tp3Percent = tp3Percent;
    }

    public double getTp3Pct() {
        return tp3Percent;
    }

    public void setTp3Pct(double tp3Pct) {
        this.tp3Percent = tp3Pct;
    }

    public int getTp3Volume() {
        return tp3Volume;
    }

    public void setTp3Volume(int tp3Volume) {
        this.tp3Volume = tp3Volume;
    }

    public double getTp4Percent() {
        return tp4Percent;
    }

    public void setTp4Percent(double tp4Percent) {
        this.tp4Percent = tp4Percent;
    }

    public double getTp4Pct() {
        return tp4Percent;
    }

    public void setTp4Pct(double tp4Pct) {
        this.tp4Percent = tp4Pct;
    }

    public int getTp4Volume() {
        return tp4Volume;
    }

    public void setTp4Volume(int tp4Volume) {
        this.tp4Volume = tp4Volume;
    }

    public double getTp5Percent() {
        return tp5Percent;
    }

    public void setTp5Percent(double tp5Percent) {
        this.tp5Percent = tp5Percent;
    }

    public double getTp5Pct() {
        return tp5Percent;
    }

    public void setTp5Pct(double tp5Pct) {
        this.tp5Percent = tp5Pct;
    }

    public int getTp5Volume() {
        return tp5Volume;
    }

    public void setTp5Volume(int tp5Volume) {
        this.tp5Volume = tp5Volume;
    }

    public double getTp6Percent() {
        return tp6Percent;
    }

    public void setTp6Percent(double tp6Percent) {
        this.tp6Percent = tp6Percent;
    }

    public double getTp6Pct() {
        return tp6Percent;
    }

    public void setTp6Pct(double tp6Pct) {
        this.tp6Percent = tp6Pct;
    }

    public int getTp6Volume() {
        return tp6Volume;
    }

    public void setTp6Volume(int tp6Volume) {
        this.tp6Volume = tp6Volume;
    }

    public double getTp7Percent() {
        return tp7Percent;
    }

    public void setTp7Percent(double tp7Percent) {
        this.tp7Percent = tp7Percent;
    }

    public double getTp7Pct() {
        return tp7Percent;
    }

    public void setTp7Pct(double tp7Pct) {
        this.tp7Percent = tp7Pct;
    }

    public int getTp7Volume() {
        return tp7Volume;
    }

    public void setTp7Volume(int tp7Volume) {
        this.tp7Volume = tp7Volume;
    }

    public int getProfitCandleLimit() {
        return profitCandleLimit;
    }

    public void setProfitCandleLimit(int profitCandleLimit) {
        this.profitCandleLimit = profitCandleLimit;
    }

    public boolean isCommissionsEnabled() {
        return commissionsEnabled;
    }

    public void setCommissionsEnabled(boolean commissionsEnabled) {
        this.commissionsEnabled = commissionsEnabled;
    }

    public String getCommissionType() {
        return commissionType;
    }

    public void setCommissionType(String commissionType) {
        this.commissionType = commissionType;
    }

    public double getCommissionValue() {
        return commissionValue;
    }

    public void setCommissionValue(double commissionValue) {
        this.commissionValue = commissionValue;
    }

    public boolean isDisableLeapfrog() {
        return disableLeapfrog;
    }

    public void setDisableLeapfrog(boolean disableLeapfrog) {
        this.disableLeapfrog = disableLeapfrog;
    }

    public double getDailyDdLimit() {
        return dailyDdLimit;
    }

    public void setDailyDdLimit(double dailyDdLimit) {
        this.dailyDdLimit = dailyDdLimit;
    }

    public boolean isX4StrictEnabled() {
        return x4StrictEnabled;
    }

    public void setX4StrictEnabled(boolean x4StrictEnabled) {
        this.x4StrictEnabled = x4StrictEnabled;
    }

    public boolean isX4RelaxedEnabled() {
        return x4RelaxedEnabled;
    }

    public void setX4RelaxedEnabled(boolean x4RelaxedEnabled) {
        this.x4RelaxedEnabled = x4RelaxedEnabled;
    }

    public boolean isX5StrictEnabled() {
        return x5StrictEnabled;
    }

    public void setX5StrictEnabled(boolean x5StrictEnabled) {
        this.x5StrictEnabled = x5StrictEnabled;
    }

    public boolean isX5RelaxedEnabled() {
        return x5RelaxedEnabled;
    }

    public void setX5RelaxedEnabled(boolean x5RelaxedEnabled) {
        this.x5RelaxedEnabled = x5RelaxedEnabled;
    }

    public UUID getUserId() {
        return userId;
    }

    public void setUserId(UUID userId) {
        this.userId = userId;
    }

    public int getRowNumber() {
        return robotNumber;
    }

    public void setRowNumber(int rowNumber) {
        this.robotNumber = rowNumber;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }
}
