package com.finaldelta.models;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.util.Map;

/**
 * Model class representing execution feedback from MT5 EA.
 * Part of the RRC (Request-Response-Confirmation) mechanism.
 * Sent by MT5 EA to Java after executing a trade command.
 */
public class ExecutionFeedback {
    private String commandId;
    private String magicNumber;
    private int retcode; // 0 = success, non-zero = error code
    private String status; // SUCCESS, FAILED, PARTIAL
    private Map<String, Object> details; // Ticket numbers, prices, volumes, etc.
    private long timestamp;

    private static final Gson gson = new GsonBuilder().create();

    // Default constructor
    public ExecutionFeedback() {
    }

    // Constructor with all fields
    public ExecutionFeedback(String commandId, String magicNumber, int retcode, String status, Map<String, Object> details) {
        this.commandId = commandId;
        this.magicNumber = magicNumber;
        this.retcode = retcode;
        this.status = status;
        this.details = details;
        this.timestamp = System.currentTimeMillis() / 1000;
    }

    // Getters and Setters
    public String getCommandId() {
        return commandId;
    }

    public void setCommandId(String commandId) {
        this.commandId = commandId;
    }

    public String getMagicNumber() {
        return magicNumber;
    }

    public void setMagicNumber(String magicNumber) {
        this.magicNumber = magicNumber;
    }

    public int getRetcode() {
        return retcode;
    }

    public void setRetcode(int retcode) {
        this.retcode = retcode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Map<String, Object> getDetails() {
        return details;
    }

    public void setDetails(Map<String, Object> details) {
        this.details = details;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * Checks if the execution was successful
     * MT5 Trade Server Return Codes:
     * - 0 = Generic success (used for fills)
     * - 10009 = Order placed (TRADE_RETCODE_DONE)
     */
    public boolean isSuccess() {
        return "SUCCESS".equals(status) || (retcode == 0) || (retcode == 10009);
    }

    /**
     * Checks if the execution failed
     */
    public boolean isFailed() {
        return "FAILED".equals(status);
    }

    /**
     * Checks if the execution was partial
     */
    public boolean isPartial() {
        return "PARTIAL".equals(status);
    }

    /**
     * Converts feedback to JSON string
     */
    public String toJson() {
        return gson.toJson(this);
    }

    /**
     * Creates ExecutionFeedback from JSON string
     */
    public static ExecutionFeedback fromJson(String json) {
        return gson.fromJson(json, ExecutionFeedback.class);
    }

    /**
     * Gets a detail value by key
     */
    public Object getDetail(String key) {
        return details != null ? details.get(key) : null;
    }

    /**
     * Gets ticket number from details if available
     */
    public Long getTicket() {
        Object ticket = getDetail("ticket");
        if (ticket instanceof Number) {
            return ((Number) ticket).longValue();
        }
        return null;
    }

    /**
     * Gets error message from details if available
     */
    public String getErrorMessage() {
        Object error = getDetail("error");
        if (error != null) {
            return error.toString();
        }
        Object message = getDetail("message");
        if (message != null) {
            return message.toString();
        }
        return "";
    }

    @Override
    public String toString() {
        return String.format("ExecutionFeedback{commandId='%s', magic=%s, retcode=%d, status='%s'}",
                commandId, magicNumber, retcode, status);
    }
}
