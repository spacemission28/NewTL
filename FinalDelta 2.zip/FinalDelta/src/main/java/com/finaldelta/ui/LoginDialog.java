package com.finaldelta.ui;

import com.finaldelta.auth.CredentialManager;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class LoginDialog {

    private final Stage dialog;
    private final TextField loginField;
    private final TextField passwordField;
    private final ComboBox<String> serverCombo;
    private final CheckBox savePasswordCheckbox;
    private final ConnectionIndicator connectionIndicator;
    private final CredentialManager credentialManager;

    private boolean loginSuccess = false;
    private String authenticatedLogin;
    private String authenticatedPassword;
    private String authenticatedServer;

    public LoginDialog(Stage owner) {
        this.credentialManager = new CredentialManager();

        dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initOwner(owner);
        dialog.initStyle(StageStyle.UTILITY);
        dialog.setTitle("Login");
        dialog.setResizable(false);

        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #f5f5f5;");
        root.setPadding(new Insets(20));

        connectionIndicator = new ConnectionIndicator();
        HBox topRight = new HBox(connectionIndicator);
        topRight.setAlignment(Pos.TOP_RIGHT);
        topRight.setPadding(new Insets(0, 0, 10, 0));
        root.setTop(topRight);

        VBox content = new VBox(15);
        content.setAlignment(Pos.CENTER_LEFT);
        content.setPadding(new Insets(20, 40, 20, 40));

        HBox headerBox = new HBox(15);
        headerBox.setAlignment(Pos.CENTER_LEFT);

        VBox iconBox = new VBox();
        iconBox.setAlignment(Pos.CENTER);
        iconBox.setStyle("-fx-background-color: #4caf50; -fx-background-radius: 8px;");
        iconBox.setPrefSize(80, 80);
        iconBox.setMaxSize(80, 80);

        Label iconLabel = new Label("***\n👤");
        iconLabel.setStyle("-fx-text-fill: white; -fx-font-size: 24px; -fx-font-weight: bold;");
        iconLabel.setAlignment(Pos.CENTER);
        iconBox.getChildren().add(iconLabel);

        Label descLabel = new Label("Authorization allows to get access to the trade account");
        descLabel.setStyle("-fx-font-size: 13px; -fx-text-fill: #333;");
        descLabel.setWrapText(true);
        descLabel.setMaxWidth(350);

        headerBox.getChildren().addAll(iconBox, descLabel);

        GridPane formGrid = new GridPane();
        formGrid.setHgap(10);
        formGrid.setVgap(12);
        formGrid.setAlignment(Pos.CENTER_LEFT);

        Label loginLabel = new Label("Login:");
        loginLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #333;");
        loginField = new TextField();
        loginField.setPrefWidth(250);
        Button loginDropdown = new Button("▼");
        loginDropdown.setStyle("-fx-font-size: 10px; -fx-padding: 5px;");
        HBox loginBox = new HBox(5, loginField, loginDropdown);

        Label passwordLabel = new Label("Password:");
        passwordLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #333;");
        passwordField = new TextField();
        passwordField.setPrefWidth(250);
        savePasswordCheckbox = new CheckBox("Save password");
        savePasswordCheckbox.setStyle("-fx-font-size: 12px;");
        HBox passwordBox = new HBox(5, passwordField, savePasswordCheckbox);

        Label serverLabel = new Label("Server:");
        serverLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #333;");
        serverCombo = new ComboBox<>();
        serverCombo.setEditable(true);
        serverCombo.setPrefWidth(320);
        serverCombo.getItems().addAll("Pepperstone-Demo", "Pepperstone-Live", "ICMarkets-Demo", "ICMarkets-Live");

        formGrid.add(loginLabel, 0, 0);
        formGrid.add(loginBox, 1, 0);
        formGrid.add(passwordLabel, 0, 1);
        formGrid.add(passwordBox, 1, 1);
        formGrid.add(serverLabel, 0, 2);
        formGrid.add(serverCombo, 1, 2);

        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(10, 0, 0, 0));

        Button okButton = new Button("OK");
        okButton.setPrefWidth(120);
        okButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white; -fx-font-size: 12px; -fx-padding: 8px;");
        okButton.setOnAction(e -> handleLogin());

        Button cancelButton = new Button("Cancel");
        cancelButton.setPrefWidth(120);
        cancelButton.setStyle("-fx-background-color: #e0e0e0; -fx-text-fill: #333; -fx-font-size: 12px; -fx-padding: 8px;");
        cancelButton.setOnAction(e -> {
            loginSuccess = false;
            dialog.close();
        });

        buttonBox.getChildren().addAll(okButton, cancelButton);

        content.getChildren().addAll(headerBox, formGrid, buttonBox);
        root.setCenter(content);

        Scene scene = new Scene(root, 550, 350);
        dialog.setScene(scene);

        loadSavedCredentials();
    }

    private void loadSavedCredentials() {
        CredentialManager.Credentials creds = credentialManager.loadCredentials();
        if (creds != null) {
            loginField.setText(creds.getLogin());
            serverCombo.setValue(creds.getServer());
            if (creds.isSavePassword()) {
                passwordField.setText(creds.getPassword());
                savePasswordCheckbox.setSelected(true);
            }
        }
    }

    private void handleLogin() {
        String login = loginField.getText().trim();
        String password = passwordField.getText().trim();
        String server = serverCombo.getValue();

        if (login.isEmpty() || password.isEmpty() || server == null || server.isEmpty()) {
            connectionIndicator.updateStatus(ConnectionIndicator.Status.RED, "Please fill all fields");
            showAlert("Login Error", "Please fill in all fields.");
            return;
        }

        credentialManager.saveCredentials(login, password, server, savePasswordCheckbox.isSelected());

        connectionIndicator.updateStatus(ConnectionIndicator.Status.GREEN, "Login successful - Connected to " + server);

        authenticatedLogin = login;
        authenticatedPassword = password;
        authenticatedServer = server;
        loginSuccess = true;

        dialog.close();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public boolean showAndWait() {
        dialog.showAndWait();
        return loginSuccess;
    }

    public String getAuthenticatedLogin() {
        return authenticatedLogin;
    }

    public String getAuthenticatedPassword() {
        return authenticatedPassword;
    }

    public String getAuthenticatedServer() {
        return authenticatedServer;
    }

    public ConnectionIndicator getConnectionIndicator() {
        return connectionIndicator;
    }

    public VBox getLoginContent(ConnectionIndicator sharedIndicator, LoginCallback callback) {
        VBox content = new VBox(15);
        content.setAlignment(Pos.CENTER);
        content.setPadding(new Insets(20, 40, 20, 40));
        content.setMaxWidth(600);
        content.setStyle("-fx-background-color: #f5f5f5; -fx-background-radius: 10px;");

        HBox headerBox = new HBox(15);
        headerBox.setAlignment(Pos.CENTER_LEFT);

        VBox iconBox = new VBox();
        iconBox.setAlignment(Pos.CENTER);
        iconBox.setStyle("-fx-background-color: #4caf50; -fx-background-radius: 8px;");
        iconBox.setPrefSize(80, 80);
        iconBox.setMaxSize(80, 80);

        Label iconLabel = new Label("***\n👤");
        iconLabel.setStyle("-fx-text-fill: white; -fx-font-size: 24px; -fx-font-weight: bold;");
        iconLabel.setAlignment(Pos.CENTER);
        iconBox.getChildren().add(iconLabel);

        Label descLabel = new Label("Authorization allows to get access to the trade account");
        descLabel.setStyle("-fx-font-size: 13px; -fx-text-fill: #333;");
        descLabel.setWrapText(true);
        descLabel.setMaxWidth(350);

        headerBox.getChildren().addAll(iconBox, descLabel);

        GridPane formGrid = new GridPane();
        formGrid.setHgap(10);
        formGrid.setVgap(12);
        formGrid.setAlignment(Pos.CENTER_LEFT);

        Label loginLabel = new Label("Login:");
        loginLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #333;");
        TextField loginFieldTab = new TextField();
        loginFieldTab.setPrefWidth(250);
        Button loginDropdown = new Button("▼");
        loginDropdown.setStyle("-fx-font-size: 10px; -fx-padding: 5px;");
        HBox loginBox = new HBox(5, loginFieldTab, loginDropdown);

        Label passwordLabel = new Label("Password:");
        passwordLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #333;");
        TextField passwordFieldTab = new TextField();
        passwordFieldTab.setPrefWidth(250);
        CheckBox savePasswordCheckboxTab = new CheckBox("Save password");
        savePasswordCheckboxTab.setStyle("-fx-font-size: 12px;");
        HBox passwordBox = new HBox(5, passwordFieldTab, savePasswordCheckboxTab);

        Label serverLabel = new Label("Server:");
        serverLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #333;");
        ComboBox<String> serverComboTab = new ComboBox<>();
        serverComboTab.setEditable(true);
        serverComboTab.setPrefWidth(320);
        serverComboTab.getItems().addAll("Pepperstone-Demo", "Pepperstone-Live", "ICMarkets-Demo", "ICMarkets-Live");

        CredentialManager.Credentials creds = credentialManager.loadCredentials();
        if (creds != null) {
            loginFieldTab.setText(creds.getLogin());
            serverComboTab.setValue(creds.getServer());
            if (creds.isSavePassword()) {
                passwordFieldTab.setText(creds.getPassword());
                savePasswordCheckboxTab.setSelected(true);
            }
        }

        formGrid.add(loginLabel, 0, 0);
        formGrid.add(loginBox, 1, 0);
        formGrid.add(passwordLabel, 0, 1);
        formGrid.add(passwordBox, 1, 1);
        formGrid.add(serverLabel, 0, 2);
        formGrid.add(serverComboTab, 1, 2);

        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(10, 0, 0, 0));

        Button okButton = new Button("OK");
        okButton.setPrefWidth(120);
        okButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white; -fx-font-size: 12px; -fx-padding: 8px;");
        okButton.setOnAction(e -> {
            String login = loginFieldTab.getText().trim();
            String password = passwordFieldTab.getText().trim();
            String server = serverComboTab.getValue();

            if (login.isEmpty() || password.isEmpty() || server == null || server.isEmpty()) {
                sharedIndicator.updateStatus(ConnectionIndicator.Status.RED, "Please fill all fields");
                showAlert("Login Error", "Please fill in all fields.");
                return;
            }

            credentialManager.saveCredentials(login, password, server, savePasswordCheckboxTab.isSelected());
            sharedIndicator.updateStatus(ConnectionIndicator.Status.GREEN, "Login successful - Connected to " + server);

            callback.onLogin(login, password, server);
        });

        Button cancelButton = new Button("Cancel");
        cancelButton.setPrefWidth(120);
        cancelButton.setStyle("-fx-background-color: #e0e0e0; -fx-text-fill: #333; -fx-font-size: 12px; -fx-padding: 8px;");
        cancelButton.setOnAction(e -> {
            sharedIndicator.updateStatus(ConnectionIndicator.Status.RED, "Login cancelled");
        });

        buttonBox.getChildren().addAll(okButton, cancelButton);

        content.getChildren().addAll(headerBox, formGrid, buttonBox);
        return content;
    }

    @FunctionalInterface
    public interface LoginCallback {
        void onLogin(String login, String password, String server);
    }
}
