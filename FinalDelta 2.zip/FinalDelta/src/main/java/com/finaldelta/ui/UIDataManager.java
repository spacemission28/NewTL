package com.finaldelta.ui;

import com.finaldelta.models.MarketBarData;
import com.finaldelta.models.TickData;
import javafx.application.Platform;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages UI data updates with O(1) lookups and batched Platform.runLater calls.
 * Significantly reduces UI thread overhead by batching multiple updates into single operations.
 */
public class UIDataManager {

    // Observable lists for JavaFX TableViews
    private final ObservableList<MarketBarUI> ohlcObservableList = FXCollections.observableArrayList();
    private final ObservableList<TickUI> tickObservableList = FXCollections.observableArrayList();

    // O(1) lookup maps: key -> index in observable list
    private final Map<String, Integer> ohlcIndexMap = new ConcurrentHashMap<>();
    private final Map<String, Integer> tickIndexMap = new ConcurrentHashMap<>();

    // Pending updates queues for batching
    private final Queue<MarketBarData> pendingOhlcUpdates = new LinkedList<>();
    private final Queue<TickData> pendingTickUpdates = new LinkedList<>();
    private final Object updateLock = new Object();

    /**
     * UI wrapper for market bar data with JavaFX properties for TableView binding.
     */
    public static class MarketBarUI {
        private final SimpleStringProperty symbol;
        private final SimpleStringProperty timeframe;
        private final SimpleStringProperty timestamp;
        private final SimpleDoubleProperty open;
        private final SimpleDoubleProperty high;
        private final SimpleDoubleProperty low;
        private final SimpleDoubleProperty close;

        public MarketBarUI(MarketBarData data) {
            this.symbol = new SimpleStringProperty(data.getSymbol());
            this.timeframe = new SimpleStringProperty(data.getTimeframe());
            this.timestamp = new SimpleStringProperty(data.getFormattedTimestamp());
            this.open = new SimpleDoubleProperty(data.getOpen());
            this.high = new SimpleDoubleProperty(data.getHigh());
            this.low = new SimpleDoubleProperty(data.getLow());
            this.close = new SimpleDoubleProperty(data.getClose());
        }

        public void update(MarketBarData data) {
            timestamp.set(data.getFormattedTimestamp());
            open.set(data.getOpen());
            high.set(data.getHigh());
            low.set(data.getLow());
            close.set(data.getClose());
        }

        public String getKey() { return symbol.get() + "_" + timeframe.get(); }
        public SimpleStringProperty symbolProperty() { return symbol; }
        public SimpleStringProperty timeframeProperty() { return timeframe; }
        public SimpleStringProperty timestampProperty() { return timestamp; }
        public SimpleDoubleProperty openProperty() { return open; }
        public SimpleDoubleProperty highProperty() { return high; }
        public SimpleDoubleProperty lowProperty() { return low; }
        public SimpleDoubleProperty closeProperty() { return close; }

        public String getSymbol() { return symbol.get(); }
        public String getTimeframe() { return timeframe.get(); }
    }

    /**
     * UI wrapper for tick data with JavaFX properties for TableView binding.
     */
    public static class TickUI {
        private final SimpleStringProperty symbol;
        private final SimpleStringProperty timestamp;
        private final SimpleDoubleProperty bid;
        private final SimpleDoubleProperty ask;
        private final SimpleLongProperty volume;

        public TickUI(TickData data) {
            this.symbol = new SimpleStringProperty(data.getSymbol());
            this.timestamp = new SimpleStringProperty(data.getFormattedTimestamp());
            this.bid = new SimpleDoubleProperty(data.getBid());
            this.ask = new SimpleDoubleProperty(data.getAsk());
            this.volume = new SimpleLongProperty(data.getVolume());
        }

        public void update(TickData data) {
            timestamp.set(data.getFormattedTimestamp());
            bid.set(data.getBid());
            ask.set(data.getAsk());
            volume.set(data.getVolume());
        }

        public String getKey() { return symbol.get(); }
        public SimpleStringProperty symbolProperty() { return symbol; }
        public SimpleStringProperty timestampProperty() { return timestamp; }
        public SimpleDoubleProperty bidProperty() { return bid; }
        public SimpleDoubleProperty askProperty() { return ask; }
        public SimpleLongProperty volumeProperty() { return volume; }

        public String getSymbol() { return symbol.get(); }
    }

    /**
     * Queues a market bar update. Does not immediately update the UI.
     * Call processPendingUpdates() to batch-apply all queued updates.
     */
    public void queueOhlcUpdate(MarketBarData data) {
        synchronized (updateLock) {
            pendingOhlcUpdates.offer(data);
        }
    }

    /**
     * Queues a tick update. Does not immediately update the UI.
     * Call processPendingUpdates() to batch-apply all queued updates.
     */
    public void queueTickUpdate(TickData data) {
        synchronized (updateLock) {
            pendingTickUpdates.offer(data);
        }
    }

    /**
     * Processes all pending updates in a SINGLE Platform.runLater call.
     * This dramatically reduces UI thread overhead compared to individual updates.
     */
    public void processPendingUpdates() {
        List<MarketBarData> ohlcBatch;
        List<TickData> tickBatch;

        synchronized (updateLock) {
            if (pendingOhlcUpdates.isEmpty() && pendingTickUpdates.isEmpty()) {
                return; // Nothing to process
            }

            ohlcBatch = new ArrayList<>(pendingOhlcUpdates);
            tickBatch = new ArrayList<>(pendingTickUpdates);
            pendingOhlcUpdates.clear();
            pendingTickUpdates.clear();
        }

        // Single Platform.runLater call for ALL updates
        Platform.runLater(() -> {
            // Process OHLC updates
            for (MarketBarData data : ohlcBatch) {
                String key = data.getKey();
                Integer index = ohlcIndexMap.get(key);

                if (index != null && index < ohlcObservableList.size()) {
                    // Update existing entry
                    ohlcObservableList.get(index).update(data);
                } else {
                    // Add new entry
                    MarketBarUI uiBar = new MarketBarUI(data);
                    ohlcObservableList.add(uiBar);
                    ohlcIndexMap.put(key, ohlcObservableList.size() - 1);
                }
            }

            // Process tick updates
            for (TickData data : tickBatch) {
                String key = data.getKey();
                Integer index = tickIndexMap.get(key);

                if (index != null && index < tickObservableList.size()) {
                    // Update existing entry
                    tickObservableList.get(index).update(data);
                } else {
                    // Add new entry
                    TickUI uiTick = new TickUI(data);
                    tickObservableList.add(uiTick);
                    tickIndexMap.put(key, tickObservableList.size() - 1);
                }
            }

            // Re-sort if new items were added
            if (!ohlcBatch.isEmpty()) {
                FXCollections.sort(ohlcObservableList,
                    Comparator.comparing(MarketBarUI::getSymbol)
                        .thenComparing(MarketBarUI::getTimeframe, UIDataManager::compareTimeframes));
                rebuildOhlcIndex();
            }

            if (!tickBatch.isEmpty()) {
                FXCollections.sort(tickObservableList,
                    Comparator.comparing(TickUI::getSymbol));
                rebuildTickIndex();
            }
        });
    }

    /**
     * Rebuilds the OHLC index map after sorting.
     */
    private void rebuildOhlcIndex() {
        ohlcIndexMap.clear();
        for (int i = 0; i < ohlcObservableList.size(); i++) {
            ohlcIndexMap.put(ohlcObservableList.get(i).getKey(), i);
        }
    }

    /**
     * Rebuilds the tick index map after sorting.
     */
    private void rebuildTickIndex() {
        tickIndexMap.clear();
        for (int i = 0; i < tickObservableList.size(); i++) {
            tickIndexMap.put(tickObservableList.get(i).getKey(), i);
        }
    }

    public ObservableList<MarketBarUI> getOhlcObservableList() {
        return ohlcObservableList;
    }

    public ObservableList<TickUI> getTickObservableList() {
        return tickObservableList;
    }

    /**
     * Custom comparator for timeframes to ensure logical ordering:
     * M1, M2, M3, M5, M10, M15, M30, H1, H3, H4, D1
     */
    private static int compareTimeframes(String tf1, String tf2) {
        // Define the logical order
        List<String> order = Arrays.asList("M1", "M2", "M3", "M5", "M10", "M15", "M30", "H1", "H3", "H4", "D1");

        // Normalize timeframes: remove "PERIOD_" prefix if present
        String normalized1 = tf1.replace("PERIOD_", "");
        String normalized2 = tf2.replace("PERIOD_", "");

        int index1 = order.indexOf(normalized1);
        int index2 = order.indexOf(normalized2);

        // If both are in the defined order, compare by position
        if (index1 != -1 && index2 != -1) {
            return Integer.compare(index1, index2);
        }

        // If only one is in the defined order, prioritize it
        if (index1 != -1) return -1;
        if (index2 != -1) return 1;

        // If neither is in the defined order, fall back to alphabetical
        return normalized1.compareTo(normalized2);
    }
}
