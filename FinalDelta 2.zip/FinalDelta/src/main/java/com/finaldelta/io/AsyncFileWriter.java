package com.finaldelta.io;

import com.finaldelta.models.MarketBarData;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Asynchronous file writer that batches market bar data writes to reduce I/O overhead.
 * Writes are queued and flushed to disk every 5 seconds, significantly improving
 * performance when processing high-frequency data updates.
 */
public class AsyncFileWriter {
    private final ConcurrentLinkedQueue<MarketBarData> writeQueue = new ConcurrentLinkedQueue<>();
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
    private final String dataFolder;
    private final String fileSuffix;
    private final Consumer<String> errorLogger;

    public AsyncFileWriter(String dataFolder, String fileSuffix, Consumer<String> errorLogger) {
        this.dataFolder = dataFolder;
        this.fileSuffix = fileSuffix;
        this.errorLogger = errorLogger;
    }

    /**
     * Starts the background writer thread that flushes queued data every 5 seconds.
     */
    public void start() {
        scheduler.scheduleAtFixedRate(this::flushWrites, 5, 5, TimeUnit.SECONDS);
    }

    /**
     * Queues a market bar for asynchronous writing.
     * This method returns immediately without blocking on I/O.
     */
    public void queueWrite(MarketBarData bar) {
        writeQueue.offer(bar);
    }

    /**
     * Flushes all queued market bars to their respective files.
     * Groups writes by symbol to minimize file open/close operations.
     */
    private void flushWrites() {
        if (writeQueue.isEmpty()) {
            return;
        }

        // Group bars by symbol for efficient batch writing
        Map<String, List<MarketBarData>> barsBySymbol = new HashMap<>();
        MarketBarData bar;

        while ((bar = writeQueue.poll()) != null) {
            barsBySymbol.computeIfAbsent(bar.getSymbol(), k -> new ArrayList<>()).add(bar);
        }

        // Write each symbol's data in a single file operation
        for (Map.Entry<String, List<MarketBarData>> entry : barsBySymbol.entrySet()) {
            String symbol = entry.getKey();
            List<MarketBarData> bars = entry.getValue();

            try {
                String filename = symbol + fileSuffix;
                Path filePath = Paths.get(dataFolder, filename);

                // Build all lines for this symbol
                StringBuilder sb = new StringBuilder();
                for (MarketBarData b : bars) {
                    sb.append(b.toFileFormat()).append(System.lineSeparator());
                }

                // Single write operation for all bars of this symbol
                Files.write(filePath, sb.toString().getBytes(),
                    StandardOpenOption.CREATE,
                    StandardOpenOption.APPEND);

            } catch (IOException e) {
                errorLogger.accept("Failed to write data for " + symbol + ": " + e.getMessage());
            }
        }
    }

    /**
     * Immediately flushes all pending writes and shuts down the writer thread.
     * Should be called during application shutdown.
     */
    public void shutdown() {
        flushWrites(); // Flush any remaining data
        scheduler.shutdown();
        try {
            if (!scheduler.awaitTermination(5, TimeUnit.SECONDS)) {
                scheduler.shutdownNow();
            }
        } catch (InterruptedException e) {
            scheduler.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Returns the number of bars currently queued for writing.
     */
    public int getQueueSize() {
        return writeQueue.size();
    }
}
