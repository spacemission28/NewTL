package com.finaldelta.services;

import com.finaldelta.Logger;
import com.finaldelta.models.*;
import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class BoltDatabaseClient {
    private final String boltDatabaseUrl;
    private final String boltDatabaseKey;
    private final HttpClient httpClient;

    public BoltDatabaseClient(String boltDatabaseUrl, String boltDatabaseKey) {
        this.boltDatabaseUrl = boltDatabaseUrl;
        this.boltDatabaseKey = boltDatabaseKey;
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(10))
                .build();
        Logger.info("BoltDatabaseClient initialized");
    }

    private HttpRequest.Builder createRequestBuilder(String endpoint) {
        return HttpRequest.newBuilder()
                .uri(URI.create(boltDatabaseUrl + "/rest/v1/" + endpoint))
                .header("apikey", boltDatabaseKey)
                .header("Authorization", "Bearer " + boltDatabaseKey)
                .header("Content-Type", "application/json")
                .header("Prefer", "return=representation");
    }

    public List<RobotConfig> fetchRobotConfigs() {
        List<RobotConfig> configs = new ArrayList<>();
        try {
            HttpRequest request = createRequestBuilder("robot_configs?select=*")
                    .GET()
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                JSONArray jsonArray = new JSONArray(response.body());
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject json = jsonArray.getJSONObject(i);
                    RobotConfig config = parseRobotConfig(json);
                    configs.add(config);
                }
                Logger.info("Fetched " + configs.size() + " robot configurations");
            } else {
                Logger.error("Failed to fetch robot configs: " + response.statusCode());
            }
        } catch (Exception e) {
            Logger.error("Error fetching robot configs: " + e.getMessage());
        }
        return configs;
    }

    private RobotConfig parseRobotConfig(JSONObject json) {
        RobotConfig config = new RobotConfig();
        config.setId(UUID.fromString(json.getString("id")));
        config.setMagicNumber(json.optString("magic_number", ""));
        config.setSymbol(json.getString("symbol"));
        config.setTimeframe(json.getString("timeframe"));
        config.setActive(json.getBoolean("is_active"));
        config.setStopLossPercent(json.optDouble("stop_loss_percent", 0.0));
        config.setTp1Percent(json.optDouble("tp1_percent", 0.0));
        if (!json.isNull("created_at")) {
            config.setCreatedAt(Instant.parse(json.getString("created_at")));
        }
        return config;
    }

    public boolean updateRobotConfig(RobotConfig config) {
        try {
            JSONObject json = new JSONObject();
            json.put("is_active", config.isActive());
            json.put("stop_loss_percent", config.getStopLossPercent());
            json.put("tp1_percent", config.getTp1Percent());

            HttpRequest request = createRequestBuilder("robot_configs?id=eq." + config.getId())
                    .method("PATCH", HttpRequest.BodyPublishers.ofString(json.toString()))
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200 || response.statusCode() == 204) {
                Logger.info("Updated robot config: " + config.getMagicNumber());
                return true;
            } else {
                Logger.error("Failed to update robot config: " + response.statusCode());
                return false;
            }
        } catch (Exception e) {
            Logger.error("Error updating robot config: " + e.getMessage());
            return false;
        }
    }

    public boolean insertRobotState(RobotState state) {
        try {
            JSONObject json = new JSONObject();
            json.put("robot_config_id", state.getRobotConfigId().toString());
            json.put("connection_status", state.getConnectionStatus());
            json.put("current_profit_loss", state.getCurrentProfitLoss());
            json.put("trading_active", state.isTradingActive());
            json.put("active_orders_count", state.getActiveOrdersCount());

            HttpRequest request = createRequestBuilder("robot_states")
                    .POST(HttpRequest.BodyPublishers.ofString(json.toString()))
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            return response.statusCode() == 201 || response.statusCode() == 200;
        } catch (Exception e) {
            Logger.error("Error inserting robot state: " + e.getMessage());
            return false;
        }
    }

    public boolean insertTradeHistory(TradeHistory trade) {
        try {
            JSONObject json = new JSONObject();
            json.put("robot_config_id", trade.getRobotConfigId().toString());
            json.put("magic_number", trade.getMagicNumber());
            json.put("ticket_number", trade.getTicketNumber());
            json.put("symbol", trade.getSymbol());
            json.put("trade_type", trade.getTradeType());
            json.put("volume", trade.getVolume());
            json.put("open_price", trade.getOpenPrice());
            json.put("close_price", trade.getClosePrice());
            json.put("stop_loss", trade.getStopLoss());
            json.put("take_profit", trade.getTakeProfit());
            json.put("profit", trade.getProfit());
            json.put("commission", trade.getCommission());
            json.put("swap", trade.getSwap());
            if (trade.getOpenTime() != null) {
                json.put("open_time", trade.getOpenTime().toString());
            }
            if (trade.getCloseTime() != null) {
                json.put("close_time", trade.getCloseTime().toString());
            }
            json.put("comment", trade.getComment());

            HttpRequest request = createRequestBuilder("trade_history")
                    .POST(HttpRequest.BodyPublishers.ofString(json.toString()))
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            return response.statusCode() == 201 || response.statusCode() == 200;
        } catch (Exception e) {
            Logger.error("Error inserting trade history: " + e.getMessage());
            return false;
        }
    }
}
