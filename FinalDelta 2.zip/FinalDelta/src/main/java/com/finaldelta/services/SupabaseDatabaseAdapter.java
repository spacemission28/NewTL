package com.finaldelta.services;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.finaldelta.Logger;
import com.finaldelta.models.RobotConfig;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SupabaseDatabaseAdapter implements DatabaseClient {
    private final SupabaseClient supabaseClient;
    private final Gson gson = new Gson();

    public SupabaseDatabaseAdapter(SupabaseClient supabaseClient) {
        this.supabaseClient = supabaseClient;
    }

    @Override
    public void upsertRobotConfig(String userId, RobotConfig config) throws Exception {
        System.out.println("[DEBUG upsertRobotConfig] userId=" + userId + ", robotNumber=" + config.getRobotNumber());

        Map<String, Object> data = new HashMap<>();
        data.put("user_id", userId);
        data.put("row_number", config.getRobotNumber());
        data.put("symbol", config.getSymbol());
        data.put("timeframe", config.getTimeframe());
        data.put("x1_type", config.getX1Type());
        data.put("min_x1_height", config.getMinX1Height());
        data.put("trig_percent", config.getTrigPercent());
        data.put("stop_loss_percent", config.getStopLossPercent());
        data.put("tp1_percent", config.getTp1Percent());
        data.put("tp2_percent", config.getTp2Percent());
        data.put("tp3_percent", config.getTp3Percent());
        data.put("tp4_percent", config.getTp4Percent());
        data.put("tp5_percent", config.getTp5Percent());
        data.put("tp6_percent", config.getTp6Percent());
        data.put("tp7_percent", config.getTp7Percent());
        data.put("tp1_volume", config.getTp1Volume());
        data.put("tp2_volume", config.getTp2Volume());
        data.put("tp3_volume", config.getTp3Volume());
        data.put("tp4_volume", config.getTp4Volume());
        data.put("tp5_volume", config.getTp5Volume());
        data.put("tp6_volume", config.getTp6Volume());
        data.put("tp7_volume", config.getTp7Volume());
        data.put("rpt_percent", config.getRptPercent());
        data.put("rpt_fixed_amount", config.getRptFixedAmount());
        data.put("start_hour", config.getStartHour());
        data.put("start_minute", config.getStartMinute());
        data.put("end_hour", config.getEndHour());
        data.put("end_minute", config.getEndMinute());
        data.put("daily_dd_limit", config.getDailyDdLimit());
        data.put("x4_strict_enabled", config.isX4StrictEnabled());
        data.put("x4_relaxed_enabled", config.isX4RelaxedEnabled());
        data.put("x5_strict_enabled", config.isX5StrictEnabled());
        data.put("x5_relaxed_enabled", config.isX5RelaxedEnabled());
        data.put("disable_leapfrog", config.isDisableLeapfrog());

        String encodedUserId = URLEncoder.encode(userId, StandardCharsets.UTF_8);
        String query = "user_id=eq." + encodedUserId + "&row_number=eq." + config.getRobotNumber();
        System.out.println("[DEBUG upsertRobotConfig] Query: " + query);
        String existingJson = supabaseClient.select("robot_configs", "*", query);
        List<Map<String, Object>> existing = gson.fromJson(existingJson, new TypeToken<List<Map<String, Object>>>(){}.getType());

        if (existing != null && !existing.isEmpty()) {
            System.out.println("[DEBUG upsertRobotConfig] Updating existing config");
            supabaseClient.update("robot_configs", query, gson.toJson(data));
        } else {
            System.out.println("[DEBUG upsertRobotConfig] Inserting new config");
            supabaseClient.insert("robot_configs", gson.toJson(data));
        }
        System.out.println("[DEBUG upsertRobotConfig] SUCCESS");
    }

    @Override
    public List<RobotConfig> loadRobotConfigs(String userId) throws Exception {
        String encodedUserId = URLEncoder.encode(userId, StandardCharsets.UTF_8);
        String query = "user_id=eq." + encodedUserId + "&order=row_number.asc";
        System.out.println("[DEBUG loadRobotConfigs] Query: " + query);
        String json = supabaseClient.select("robot_configs", "*", query);

        List<Map<String, Object>> rawConfigs = gson.fromJson(json, new TypeToken<List<Map<String, Object>>>(){}.getType());
        List<RobotConfig> configs = new ArrayList<>();

        if (rawConfigs != null) {
            for (Map<String, Object> raw : rawConfigs) {
                RobotConfig config = new RobotConfig();
                config.setRobotNumber(((Number) raw.get("row_number")).intValue());
                config.setSymbol((String) raw.get("symbol"));
                config.setTimeframe((String) raw.get("timeframe"));
                config.setX1Type((String) raw.get("x1_type"));
                config.setMinX1Height(((Number) raw.get("min_x1_height")).doubleValue());
                config.setTrigPercent(((Number) raw.get("trig_percent")).doubleValue());
                config.setStopLossPercent(((Number) raw.get("stop_loss_percent")).doubleValue());
                config.setTp1Percent(((Number) raw.get("tp1_percent")).doubleValue());
                config.setTp2Percent(((Number) raw.get("tp2_percent")).doubleValue());
                config.setTp3Percent(((Number) raw.get("tp3_percent")).doubleValue());
                config.setTp4Percent(((Number) raw.get("tp4_percent")).doubleValue());
                config.setTp5Percent(((Number) raw.get("tp5_percent")).doubleValue());
                config.setTp6Percent(((Number) raw.get("tp6_percent")).doubleValue());
                config.setTp7Percent(((Number) raw.get("tp7_percent")).doubleValue());
                config.setTp1Volume(((Number) raw.get("tp1_volume")).intValue());
                config.setTp2Volume(((Number) raw.get("tp2_volume")).intValue());
                config.setTp3Volume(((Number) raw.get("tp3_volume")).intValue());
                config.setTp4Volume(((Number) raw.get("tp4_volume")).intValue());
                config.setTp5Volume(((Number) raw.get("tp5_volume")).intValue());
                config.setTp6Volume(((Number) raw.get("tp6_volume")).intValue());
                config.setTp7Volume(((Number) raw.get("tp7_volume")).intValue());
                config.setRptPercent(((Number) raw.get("rpt_percent")).doubleValue());
                config.setRptFixedAmount(((Number) raw.get("rpt_fixed_amount")).doubleValue());
                config.setStartHour(((Number) raw.get("start_hour")).intValue());
                config.setStartMinute(((Number) raw.get("start_minute")).intValue());
                config.setEndHour(((Number) raw.get("end_hour")).intValue());
                config.setEndMinute(((Number) raw.get("end_minute")).intValue());

                Object ddLimit = raw.get("daily_dd_limit");
                if (ddLimit != null) {
                    config.setDailyDdLimit(((Number) ddLimit).doubleValue());
                } else {
                    config.setDailyDdLimit(0.0);
                }

                Object disableLeapfrog = raw.get("disable_leapfrog");
                if (disableLeapfrog != null) {
                    config.setDisableLeapfrog((Boolean) disableLeapfrog);
                } else {
                    config.setDisableLeapfrog(false);
                }

                Object x4Strict = raw.get("x4_strict_enabled");
                config.setX4StrictEnabled(x4Strict != null ? (Boolean) x4Strict : true);

                Object x4Relaxed = raw.get("x4_relaxed_enabled");
                config.setX4RelaxedEnabled(x4Relaxed != null ? (Boolean) x4Relaxed : true);

                Object x5Strict = raw.get("x5_strict_enabled");
                config.setX5StrictEnabled(x5Strict != null ? (Boolean) x5Strict : true);

                Object x5Relaxed = raw.get("x5_relaxed_enabled");
                config.setX5RelaxedEnabled(x5Relaxed != null ? (Boolean) x5Relaxed : true);

                configs.add(config);
            }
        }

        return configs;
    }

    @Override
    public void saveDefaultValues(String userId, Map<String, Object> defaults) throws Exception {
        System.out.println("[DEBUG saveDefaultValues] userId=" + userId);
        System.out.println("[DEBUG saveDefaultValues] defaults=" + defaults);

        Map<String, Object> data = new HashMap<>();
        data.put("user_id", userId);
        data.put("defaults", defaults);

        String encodedUserId = URLEncoder.encode(userId, StandardCharsets.UTF_8);
        String query = "user_id=eq." + encodedUserId;
        System.out.println("[DEBUG saveDefaultValues] Query: " + query);
        String existingJson = supabaseClient.select("default_values", "*", query);
        List<Map<String, Object>> existing = gson.fromJson(existingJson, new TypeToken<List<Map<String, Object>>>(){}.getType());

        if (existing != null && !existing.isEmpty()) {
            System.out.println("[DEBUG saveDefaultValues] Updating existing defaults");
            supabaseClient.update("default_values", query, gson.toJson(data));
        } else {
            System.out.println("[DEBUG saveDefaultValues] Inserting new defaults");
            supabaseClient.insert("default_values", gson.toJson(data));
        }
        System.out.println("[DEBUG saveDefaultValues] SUCCESS");
    }

    @Override
    public Map<String, Object> loadDefaultValues(String userId) throws Exception {
        String encodedUserId = URLEncoder.encode(userId, StandardCharsets.UTF_8);
        String query = "user_id=eq." + encodedUserId;
        System.out.println("[DEBUG loadDefaultValues] Query: " + query);
        String json = supabaseClient.select("default_values", "*", query);

        List<Map<String, Object>> results = gson.fromJson(json, new TypeToken<List<Map<String, Object>>>(){}.getType());

        if (results != null && !results.isEmpty()) {
            Object defaultsObj = results.get(0).get("defaults");
            if (defaultsObj instanceof Map) {
                return (Map<String, Object>) defaultsObj;
            }
        }

        return null;
    }

    @Override
    public void deleteRobotConfigs(String userId, List<Integer> robotNumbers) throws Exception {
        if (robotNumbers.isEmpty()) return;

        String encodedUserId = URLEncoder.encode(userId, StandardCharsets.UTF_8);
        for (Integer robotNumber : robotNumbers) {
            String query = "user_id=eq." + encodedUserId + "&row_number=eq." + robotNumber;
            supabaseClient.delete("robot_configs", query);
        }
    }


    @Override
    public List<com.finaldelta.models.MarketBarData> getRecentCompletedBars(String symbol, String timeframe, int count) throws Exception {
        return new ArrayList<>();
    }

    @Override
    public double getLatestBid(String symbol) throws Exception {
        return 0.0;
    }

    @Override
    public double getLatestAsk(String symbol) throws Exception {
        return 0.0;
    }

    @Override
    public long getLatestTickTimestamp() throws Exception {
        try {
            String response = supabaseClient.select("tick_data", "timestamp", "order=timestamp.desc&limit=1");

            List<Map<String, Object>> results = gson.fromJson(response,
                new com.google.gson.reflect.TypeToken<List<Map<String, Object>>>(){}.getType());

            if (results != null && !results.isEmpty()) {
                Object timestamp = results.get(0).get("timestamp");
                if (timestamp instanceof Number) {
                    return ((Number) timestamp).longValue();
                }
            }
            return 0;
        } catch (Exception e) {
            Logger.error("Failed to get latest tick timestamp: " + e.getMessage());
            return 0;
        }
    }

    @Override
    public void insertTradeCommand(com.finaldelta.models.TradeCommand command) throws Exception {
        Map<String, Object> data = new HashMap<>();
        data.put("magic_number", command.getMagicNumber());
        data.put("order_type", command.getOrderType());
        data.put("symbol", command.getSymbol());
        data.put("lots", command.getLots());
        data.put("price", command.getPrice());
        data.put("stop_loss", command.getStopLoss());
        data.put("take_profit", command.getTakeProfit());
        data.put("comment", command.getComment());
        data.put("status", "PENDING");

        supabaseClient.insert("trade_commands", gson.toJson(data));
        Logger.info("Trade command inserted: " + command.getOrderType() + " " + command.getSymbol() + " @ " + command.getPrice());
    }

    @Override
    public void close() {
    }
}
