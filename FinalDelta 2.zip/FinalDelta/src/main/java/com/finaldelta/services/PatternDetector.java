package com.finaldelta.services;

import com.finaldelta.Logger;
import com.finaldelta.models.MarketBarData;
import com.finaldelta.models.RobotConfig;

import java.util.List;

public class PatternDetector {

    public enum PatternType {
        OG_BUY,
        OG_SELL,
        X4_STRICT_BUY,
        X4_STRICT_SELL,
        X4_RELAXED_BUY,
        X4_RELAXED_SELL,
        X5_STRICT_BUY,
        X5_STRICT_SELL,
        X5_RELAXED_BUY,
        X5_RELAXED_SELL,
        NONE
    }

    public static class PatternResult {
        public final PatternType type;
        public final MarketBarData triggerCandle;
        public final String direction;

        public PatternResult(PatternType type, MarketBarData triggerCandle, String direction) {
            this.type = type;
            this.triggerCandle = triggerCandle;
            this.direction = direction;
        }

        public boolean isValid() {
            return type != PatternType.NONE;
        }
    }

    public PatternResult detectPattern(RobotConfig robot, List<MarketBarData> candles) {
        if (candles == null || candles.isEmpty()) {
            return new PatternResult(PatternType.NONE, null, null);
        }

        MarketBarData x1 = candles.get(candles.size() - 1);
        String x1Type = isBullish(x1) ? "BULL" : isBearish(x1) ? "BEAR" : "DOJI";

        Logger.info(String.format("  🔍 X1 Candle: %s | %s | O:%.5f H:%.5f L:%.5f C:%.5f",
            x1.getFormattedTimestamp(), x1Type, x1.getOpen(), x1.getHigh(), x1.getLow(), x1.getClose()));

        if (robot.isX5StrictEnabled() && candles.size() >= 5) {
            PatternResult result = detectX5Strict(candles);
            if (result.isValid()) {
                logPatternDetails("X5 STRICT", result, candles, 5);
                return result;
            }
        }

        if (robot.isX5RelaxedEnabled() && candles.size() >= 5) {
            PatternResult result = detectX5Relaxed(candles);
            if (result.isValid()) {
                logPatternDetails("X5 RELAXED", result, candles, 5);
                return result;
            }
        }

        if (robot.isX4StrictEnabled() && candles.size() >= 4) {
            PatternResult result = detectX4Strict(candles);
            if (result.isValid()) {
                logPatternDetails("X4 STRICT", result, candles, 4);
                return result;
            }
        }

        if (robot.isX4RelaxedEnabled() && candles.size() >= 4) {
            PatternResult result = detectX4Relaxed(candles);
            if (result.isValid()) {
                logPatternDetails("X4 RELAXED", result, candles, 4);
                return result;
            }
        }

        boolean noX4X5Enabled = !robot.isX4StrictEnabled() && !robot.isX4RelaxedEnabled()
                                && !robot.isX5StrictEnabled() && !robot.isX5RelaxedEnabled();

        if (noX4X5Enabled && candles.size() >= 3) {
            PatternResult result = detectOG(candles);
            if (result.isValid()) {
                logPatternDetails("OG", result, candles, 3);
                return result;
            }
        }

        return new PatternResult(PatternType.NONE, null, null);
    }

    private void logPatternDetails(String patternName, PatternResult result, List<MarketBarData> candles, int candleCount) {
        Logger.info("  ★★★ " + patternName + " PATTERN DETECTED ★★★");
        Logger.info("    Type: " + result.type + " | Direction: " + result.direction);
        Logger.info("    Candle Sequence:");

        int size = candles.size();
        for (int i = candleCount; i >= 1; i--) {
            MarketBarData candle = candles.get(size - i);
            String label = (i == 1) ? "X1 (Trigger)" : "X" + i;
            String type = isBullish(candle) ? "BULL" : isBearish(candle) ? "BEAR" : "DOJI";
            Logger.info(String.format("      %s: %s | O:%.5f H:%.5f L:%.5f C:%.5f | %s",
                label, type, candle.getOpen(), candle.getHigh(), candle.getLow(), candle.getClose(),
                candle.getFormattedTimestamp()));
        }
    }

    private PatternResult detectOG(List<MarketBarData> candles) {
        int size = candles.size();
        MarketBarData x1 = candles.get(size - 1);
        MarketBarData x2 = candles.get(size - 2);

        boolean x2Bullish = isBullish(x2);
        boolean x1Bearish = isBearish(x1);

        if (x2Bullish && x1Bearish) {
            return new PatternResult(PatternType.OG_BUY, x1, "BUY");
        }

        boolean x2Bearish = isBearish(x2);
        boolean x1Bullish = isBullish(x1);

        if (x2Bearish && x1Bullish) {
            return new PatternResult(PatternType.OG_SELL, x1, "SELL");
        }

        return new PatternResult(PatternType.NONE, null, null);
    }

    private PatternResult detectX4Strict(List<MarketBarData> candles) {
        int size = candles.size();
        MarketBarData x1 = candles.get(size - 1);
        MarketBarData x2 = candles.get(size - 2);
        MarketBarData x3 = candles.get(size - 3);

        if (isBullish(x3) && isBullish(x2) && isBearish(x1)) {
            if (x2.getLow() > x3.getLow() && x2.getHigh() > x3.getHigh()) {
                return new PatternResult(PatternType.X4_STRICT_BUY, x1, "BUY");
            }
        }

        if (isBearish(x3) && isBearish(x2) && isBullish(x1)) {
            if (x2.getLow() < x3.getLow() && x2.getHigh() < x3.getHigh()) {
                return new PatternResult(PatternType.X4_STRICT_SELL, x1, "SELL");
            }
        }

        return new PatternResult(PatternType.NONE, null, null);
    }

    private PatternResult detectX4Relaxed(List<MarketBarData> candles) {
        int size = candles.size();
        MarketBarData x1 = candles.get(size - 1);
        MarketBarData x2 = candles.get(size - 2);
        MarketBarData x3 = candles.get(size - 3);

        if (isBullish(x3) && isBullish(x2) && isBearish(x1)) {
            return new PatternResult(PatternType.X4_RELAXED_BUY, x1, "BUY");
        }

        if (isBearish(x3) && isBearish(x2) && isBullish(x1)) {
            return new PatternResult(PatternType.X4_RELAXED_SELL, x1, "SELL");
        }

        return new PatternResult(PatternType.NONE, null, null);
    }

    private PatternResult detectX5Strict(List<MarketBarData> candles) {
        int size = candles.size();
        MarketBarData x1 = candles.get(size - 1);
        MarketBarData x2 = candles.get(size - 2);
        MarketBarData x3 = candles.get(size - 3);
        MarketBarData x4 = candles.get(size - 4);

        if (isBullish(x4) && isBullish(x3) && isBullish(x2) && isBearish(x1)) {
            if (x3.getLow() > x4.getLow() && x3.getHigh() > x4.getHigh() &&
                x2.getLow() > x3.getLow() && x2.getHigh() > x3.getHigh()) {
                return new PatternResult(PatternType.X5_STRICT_BUY, x1, "BUY");
            }
        }

        if (isBearish(x4) && isBearish(x3) && isBearish(x2) && isBullish(x1)) {
            if (x3.getLow() < x4.getLow() && x3.getHigh() < x4.getHigh() &&
                x2.getLow() < x3.getLow() && x2.getHigh() < x3.getHigh()) {
                return new PatternResult(PatternType.X5_STRICT_SELL, x1, "SELL");
            }
        }

        return new PatternResult(PatternType.NONE, null, null);
    }

    private PatternResult detectX5Relaxed(List<MarketBarData> candles) {
        int size = candles.size();
        MarketBarData x1 = candles.get(size - 1);
        MarketBarData x2 = candles.get(size - 2);
        MarketBarData x3 = candles.get(size - 3);
        MarketBarData x4 = candles.get(size - 4);

        if (isBullish(x4) && isBullish(x3) && isBullish(x2) && isBearish(x1)) {
            return new PatternResult(PatternType.X5_RELAXED_BUY, x1, "BUY");
        }

        if (isBearish(x4) && isBearish(x3) && isBearish(x2) && isBullish(x1)) {
            return new PatternResult(PatternType.X5_RELAXED_SELL, x1, "SELL");
        }

        return new PatternResult(PatternType.NONE, null, null);
    }

    private boolean isBullish(MarketBarData candle) {
        return candle.getClose() > candle.getOpen();
    }

    private boolean isBearish(MarketBarData candle) {
        return candle.getClose() < candle.getOpen();
    }
}
