package com.finaldelta.models;

import java.time.Instant;
import java.util.UUID;

public class RobotConfig {
    private UUID id;
    private UUID userId;
    private int robotNumber;
    private String magicNumber;
    private String robotName;
    private String symbol;
    private String timeframe;
    private int startHour;
    private int startMinute;
    private int endHour;
    private int endMinute;
    private boolean endTimeEnabled;
    private double minX1Height;
    private String x1Type;
    private double trigPercent;
    private double stopLossPercent;
    private double rptPercent;
    private double rptFixedAmount;
    private double tp1Percent;
    private int tp1Volume;
    private double tp2Percent;
    private int tp2Volume;
    private double tp3Percent;
    private int tp3Volume;
    private int profitCandleLimit;
    private boolean commissionsEnabled;
    private String commissionType;
    private double commissionValue;
    private boolean disableLeapfrog;
    private double dailyDdLimit;
    private boolean x2StrictEnabled;
    private boolean x2RelaxedEnabled;
    private boolean active;
    private Instant createdAt;

    public RobotConfig() {
        this.id = UUID.randomUUID();
        this.endTimeEnabled = true;
        this.x2StrictEnabled = true;
        this.x2RelaxedEnabled = true;
        this.commissionsEnabled = false;
        this.disableLeapfrog = false;
        this.active = false;
        this.createdAt = Instant.now();
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public int getRobotNumber() {
        return robotNumber;
    }

    public void setRobotNumber(int robotNumber) {
        this.robotNumber = robotNumber;
    }

    public String getMagicNumber() {
        return magicNumber;
    }

    public void setMagicNumber(String magicNumber) {
        this.magicNumber = magicNumber;
    }

    public String getRobotName() {
        return robotName;
    }

    public void setRobotName(String robotName) {
        this.robotName = robotName;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getTimeframe() {
        return timeframe;
    }

    public void setTimeframe(String timeframe) {
        this.timeframe = timeframe;
    }

    public int getStartHour() {
        return startHour;
    }

    public void setStartHour(int startHour) {
        this.startHour = startHour;
    }

    public int getStartMinute() {
        return startMinute;
    }

    public void setStartMinute(int startMinute) {
        this.startMinute = startMinute;
    }

    public int getEndHour() {
        return endHour;
    }

    public void setEndHour(int endHour) {
        this.endHour = endHour;
    }

    public int getEndMinute() {
        return endMinute;
    }

    public void setEndMinute(int endMinute) {
        this.endMinute = endMinute;
    }

    public boolean isEndTimeEnabled() {
        return endTimeEnabled;
    }

    public void setEndTimeEnabled(boolean endTimeEnabled) {
        this.endTimeEnabled = endTimeEnabled;
    }

    public double getMinX1Height() {
        return minX1Height;
    }

    public void setMinX1Height(double minX1Height) {
        this.minX1Height = minX1Height;
    }

    public String getX1Type() {
        return x1Type;
    }

    public void setX1Type(String x1Type) {
        this.x1Type = x1Type;
    }

    public double getTrigPercent() {
        return trigPercent;
    }

    public void setTrigPercent(double trigPercent) {
        this.trigPercent = trigPercent;
    }

    public double getStopLossPercent() {
        return stopLossPercent;
    }

    public void setStopLossPercent(double stopLossPercent) {
        this.stopLossPercent = stopLossPercent;
    }

    public double getRptPercent() {
        return rptPercent;
    }

    public void setRptPercent(double rptPercent) {
        this.rptPercent = rptPercent;
    }

    public double getRptFixedAmount() {
        return rptFixedAmount;
    }

    public void setRptFixedAmount(double rptFixedAmount) {
        this.rptFixedAmount = rptFixedAmount;
    }

    public double getTp1Percent() {
        return tp1Percent;
    }

    public void setTp1Percent(double tp1Percent) {
        this.tp1Percent = tp1Percent;
    }

    public double getTp1Pct() {
        return tp1Percent;
    }

    public void setTp1Pct(double tp1Pct) {
        this.tp1Percent = tp1Pct;
    }

    public int getTp1Volume() {
        return tp1Volume;
    }

    public void setTp1Volume(int tp1Volume) {
        this.tp1Volume = tp1Volume;
    }

    public double getTp2Percent() {
        return tp2Percent;
    }

    public void setTp2Percent(double tp2Percent) {
        this.tp2Percent = tp2Percent;
    }

    public double getTp2Pct() {
        return tp2Percent;
    }

    public void setTp2Pct(double tp2Pct) {
        this.tp2Percent = tp2Pct;
    }

    public int getTp2Volume() {
        return tp2Volume;
    }

    public void setTp2Volume(int tp2Volume) {
        this.tp2Volume = tp2Volume;
    }

    public double getTp3Percent() {
        return tp3Percent;
    }

    public void setTp3Percent(double tp3Percent) {
        this.tp3Percent = tp3Percent;
    }

    public double getTp3Pct() {
        return tp3Percent;
    }

    public void setTp3Pct(double tp3Pct) {
        this.tp3Percent = tp3Pct;
    }

    public int getTp3Volume() {
        return tp3Volume;
    }

    public void setTp3Volume(int tp3Volume) {
        this.tp3Volume = tp3Volume;
    }

    public int getProfitCandleLimit() {
        return profitCandleLimit;
    }

    public void setProfitCandleLimit(int profitCandleLimit) {
        this.profitCandleLimit = profitCandleLimit;
    }

    public boolean isCommissionsEnabled() {
        return commissionsEnabled;
    }

    public void setCommissionsEnabled(boolean commissionsEnabled) {
        this.commissionsEnabled = commissionsEnabled;
    }

    public String getCommissionType() {
        return commissionType;
    }

    public void setCommissionType(String commissionType) {
        this.commissionType = commissionType;
    }

    public double getCommissionValue() {
        return commissionValue;
    }

    public void setCommissionValue(double commissionValue) {
        this.commissionValue = commissionValue;
    }

    public boolean isDisableLeapfrog() {
        return disableLeapfrog;
    }

    public void setDisableLeapfrog(boolean disableLeapfrog) {
        this.disableLeapfrog = disableLeapfrog;
    }

    public double getDailyDdLimit() {
        return dailyDdLimit;
    }

    public void setDailyDdLimit(double dailyDdLimit) {
        this.dailyDdLimit = dailyDdLimit;
    }

    public boolean isX2StrictEnabled() {
        return x2StrictEnabled;
    }

    public void setX2StrictEnabled(boolean x2StrictEnabled) {
        this.x2StrictEnabled = x2StrictEnabled;
    }

    public boolean isX2RelaxedEnabled() {
        return x2RelaxedEnabled;
    }

    public void setX2RelaxedEnabled(boolean x2RelaxedEnabled) {
        this.x2RelaxedEnabled = x2RelaxedEnabled;
    }

    public UUID getUserId() {
        return userId;
    }

    public void setUserId(UUID userId) {
        this.userId = userId;
    }

    public int getRowNumber() {
        return robotNumber;
    }

    public void setRowNumber(int rowNumber) {
        this.robotNumber = rowNumber;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }
}
