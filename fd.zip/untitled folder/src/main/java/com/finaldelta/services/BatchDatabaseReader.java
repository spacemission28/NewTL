package com.finaldelta.services;

import com.finaldelta.Logger;
import com.finaldelta.models.RobotConfig;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Batch database reader for READ-ONLY operations to improve performance.
 *
 * CRITICAL SAFETY GUARANTEES:
 * - ONLY performs READ operations (loadRobotConfigs)
 * - NEVER touches TradeCommandQueue or command writes
 * - NEVER modifies trade execution flow
 * - Uses in-memory cache to reduce database round-trips
 *
 * This class is COMMAND QUEUE SAFE because it only optimizes reads,
 * not writes or command generation.
 */
public class BatchDatabaseReader {

    private final DatabaseClient dbClient;
    private final ScheduledExecutorService scheduler;

    private final Map<UUID, List<RobotConfig>> robotConfigsCache = new ConcurrentHashMap<>();

    private static final long CACHE_REFRESH_SECONDS = 5;
    private boolean cacheEnabled = true;

    public BatchDatabaseReader(DatabaseClient dbClient) {
        this.dbClient = dbClient;
        this.scheduler = Executors.newScheduledThreadPool(1, r -> {
            Thread t = new Thread(r, "batch-db-reader");
            t.setDaemon(true);
            return t;
        });
    }

    /**
     * Start automatic cache refresh.
     * Cache is refreshed every 5 seconds to keep UI updated while reducing DB load.
     */
    public void start() {
        scheduler.scheduleAtFixedRate(
            this::refreshAllCaches,
            0,
            CACHE_REFRESH_SECONDS,
            TimeUnit.SECONDS
        );
        Logger.info("BatchDatabaseReader started (cache refresh every " + CACHE_REFRESH_SECONDS + "s)");
    }

    /**
     * Stop cache refresh.
     */
    public void stop() {
        scheduler.shutdown();
        Logger.info("BatchDatabaseReader stopped");
    }

    /**
     * Load robot configurations with caching.
     *
     * SAFETY: This is a READ-ONLY operation that does NOT affect command queue.
     *
     * @param userId User ID
     * @return List of robot configurations (may be from cache)
     */
    public List<RobotConfig> loadRobotConfigs(UUID userId) {
        if (cacheEnabled && robotConfigsCache.containsKey(userId)) {
            return new ArrayList<>(robotConfigsCache.get(userId));
        }

        try {
            List<RobotConfig> configs = dbClient.loadRobotConfigs(userId.toString());
            if (cacheEnabled) {
                robotConfigsCache.put(userId, new ArrayList<>(configs));
            }
            return configs;
        } catch (Exception e) {
            Logger.error("Failed to load robot configs: " + e.getMessage());
            return new ArrayList<>();
        }
    }


    /**
     * Invalidate cache for a specific user.
     * Forces fresh read from database on next request.
     *
     * @param userId User ID to invalidate
     */
    public void invalidateCache(UUID userId) {
        robotConfigsCache.remove(userId);
    }

    /**
     * Clear all caches.
     */
    public void clearCache() {
        robotConfigsCache.clear();
        Logger.info("Database read cache cleared");
    }

    /**
     * Enable or disable caching.
     * Useful for testing or when you need real-time data.
     *
     * @param enabled true to enable caching, false to always read from DB
     */
    public void setCacheEnabled(boolean enabled) {
        this.cacheEnabled = enabled;
        if (!enabled) {
            clearCache();
        }
    }

    /**
     * Get cache statistics.
     *
     * @return Human-readable stats string
     */
    public String getStats() {
        return String.format(
            "DB Read Cache: %d users (%d configs) | Refresh: %ds",
            robotConfigsCache.size(),
            robotConfigsCache.values().stream().mapToInt(List::size).sum(),
            CACHE_REFRESH_SECONDS
        );
    }

    /**
     * Refresh all caches in background.
     * Called automatically every CACHE_REFRESH_SECONDS.
     */
    private void refreshAllCaches() {
        try {
            if (!cacheEnabled) return;

            for (UUID userId : robotConfigsCache.keySet()) {
                try {
                    List<RobotConfig> freshConfigs = dbClient.loadRobotConfigs(userId.toString());
                    robotConfigsCache.put(userId, new ArrayList<>(freshConfigs));
                } catch (Exception e) {
                    Logger.error("Failed to refresh configs for user " + userId + ": " + e.getMessage());
                }
            }
        } catch (Throwable t) {
            String errorMsg = "CRITICAL ERROR in BatchDatabaseReader: " + t.getClass().getName() + " - " + t.getMessage();
            try {
                Logger.error(errorMsg);
            } catch (Throwable logError) {
                System.err.println(errorMsg);
                t.printStackTrace(System.err);
            }
            t.printStackTrace(System.err);
        }
    }
}
