package com.finaldelta.services;

import com.google.gson.*;
import com.finaldelta.Logger;
import com.finaldelta.models.RobotConfig;

import java.sql.*;
import java.time.Instant;
import java.util.*;

public class PostgresClient implements DatabaseClient {
    private final String jdbcUrl;
    private final String username;
    private final String password;
    private final Gson gson;

    private static PostgresClient instance;

    private PostgresClient(String jdbcUrl, String username, String password) {
        this.jdbcUrl = jdbcUrl;
        this.username = username;
        this.password = password;
        this.gson = new GsonBuilder()
                .setDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
                .create();
        Logger.info("PostgresClient initialized: " + jdbcUrl);
        initializeSchema();
    }

    public static void initialize(String jdbcUrl, String username, String password) {
        instance = new PostgresClient(jdbcUrl, username, password);
    }

    public static PostgresClient getInstance() {
        if (instance == null) {
            throw new IllegalStateException("PostgresClient not initialized");
        }
        return instance;
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(jdbcUrl, username, password);
    }

    private void initializeSchema() {
        String createTablesSQL = """
            CREATE TABLE IF NOT EXISTS robot_configs (
                id SERIAL PRIMARY KEY,
                user_id UUID NOT NULL,
                robot_number INTEGER NOT NULL,
                symbol VARCHAR(20) NOT NULL,
                timeframe VARCHAR(10) NOT NULL,
                x1_type VARCHAR(20) NOT NULL,
                min_x1_height DOUBLE PRECISION NOT NULL,
                trig_percent DOUBLE PRECISION NOT NULL,
                stop_loss_percent DOUBLE PRECISION NOT NULL,
                tp1_percent DOUBLE PRECISION NOT NULL,
                tp2_percent DOUBLE PRECISION NOT NULL,
                tp3_percent DOUBLE PRECISION NOT NULL,
                tp1_volume INTEGER NOT NULL,
                tp2_volume INTEGER NOT NULL,
                tp3_volume INTEGER NOT NULL,
                profit_candle_limit INTEGER DEFAULT 0,
                rpt_percent DOUBLE PRECISION NOT NULL,
                rpt_fixed_amount DOUBLE PRECISION NOT NULL,
                start_hour INTEGER NOT NULL,
                start_minute INTEGER NOT NULL,
                end_hour INTEGER NOT NULL,
                end_minute INTEGER NOT NULL,
                daily_dd_limit DOUBLE PRECISION DEFAULT 0.0,
                x2_strict_enabled BOOLEAN DEFAULT true,
                x2_relaxed_enabled BOOLEAN DEFAULT true,
                disable_leapfrog BOOLEAN DEFAULT false,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, robot_number)
            );

            CREATE TABLE IF NOT EXISTS default_values (
                id SERIAL PRIMARY KEY,
                user_id UUID NOT NULL UNIQUE,
                defaults JSONB NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS profit_candle_tracking (
                id SERIAL PRIMARY KEY,
                magic_number VARCHAR(50) NOT NULL UNIQUE,
                symbol VARCHAR(20) NOT NULL,
                timeframe VARCHAR(10) NOT NULL,
                trigger_timestamp BIGINT NOT NULL,
                candle_limit INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            """;

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute(createTablesSQL);
            Logger.info("Database schema initialized");
        } catch (SQLException e) {
            Logger.error("Failed to initialize schema: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void upsertRobotConfig(String userId, RobotConfig config) throws SQLException {
        String sql = """
            INSERT INTO robot_configs (
                user_id, robot_number, symbol, timeframe, x1_type, min_x1_height,
                trig_percent, stop_loss_percent, tp1_percent, tp2_percent, tp3_percent,
                tp1_volume, tp2_volume, tp3_volume,
                profit_candle_limit, rpt_percent, rpt_fixed_amount, start_hour, start_minute, end_time_enabled, end_hour, end_minute, daily_dd_limit,
                x2_strict_enabled, x2_relaxed_enabled,
                disable_leapfrog
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT (user_id, robot_number) DO UPDATE SET
                symbol = EXCLUDED.symbol,
                timeframe = EXCLUDED.timeframe,
                x1_type = EXCLUDED.x1_type,
                min_x1_height = EXCLUDED.min_x1_height,
                trig_percent = EXCLUDED.trig_percent,
                stop_loss_percent = EXCLUDED.stop_loss_percent,
                tp1_percent = EXCLUDED.tp1_percent,
                tp2_percent = EXCLUDED.tp2_percent,
                tp3_percent = EXCLUDED.tp3_percent,
                tp1_volume = EXCLUDED.tp1_volume,
                tp2_volume = EXCLUDED.tp2_volume,
                tp3_volume = EXCLUDED.tp3_volume,
                profit_candle_limit = EXCLUDED.profit_candle_limit,
                rpt_percent = EXCLUDED.rpt_percent,
                rpt_fixed_amount = EXCLUDED.rpt_fixed_amount,
                start_hour = EXCLUDED.start_hour,
                start_minute = EXCLUDED.start_minute,
                end_time_enabled = EXCLUDED.end_time_enabled,
                end_hour = EXCLUDED.end_hour,
                end_minute = EXCLUDED.end_minute,
                daily_dd_limit = EXCLUDED.daily_dd_limit,
                x2_strict_enabled = EXCLUDED.x2_strict_enabled,
                x2_relaxed_enabled = EXCLUDED.x2_relaxed_enabled,
                disable_leapfrog = EXCLUDED.disable_leapfrog,
                updated_at = CURRENT_TIMESTAMP
            """;

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(userId));
            stmt.setInt(2, config.getRobotNumber());
            stmt.setString(3, config.getSymbol());
            stmt.setString(4, config.getTimeframe());
            stmt.setString(5, config.getX1Type());
            stmt.setDouble(6, config.getMinX1Height());
            stmt.setDouble(7, config.getTrigPercent());
            stmt.setDouble(8, config.getStopLossPercent());
            stmt.setDouble(9, config.getTp1Percent());
            stmt.setDouble(10, config.getTp2Percent());
            stmt.setDouble(11, config.getTp3Percent());
            stmt.setInt(12, config.getTp1Volume());
            stmt.setInt(13, config.getTp2Volume());
            stmt.setInt(14, config.getTp3Volume());
            stmt.setInt(15, config.getProfitCandleLimit());
            stmt.setDouble(16, config.getRptPercent());
            stmt.setDouble(17, config.getRptFixedAmount());
            stmt.setInt(18, config.getStartHour());
            stmt.setInt(19, config.getStartMinute());
            stmt.setBoolean(20, config.isEndTimeEnabled());
            stmt.setInt(21, config.getEndHour());
            stmt.setInt(22, config.getEndMinute());
            stmt.setDouble(23, config.getDailyDdLimit());
            stmt.setBoolean(24, config.isX2StrictEnabled());
            stmt.setBoolean(25, config.isX2RelaxedEnabled());
            stmt.setBoolean(26, config.isDisableLeapfrog());

            stmt.executeUpdate();
        }
    }

    public List<RobotConfig> loadRobotConfigs(String userId) throws SQLException {
        String sql = "SELECT * FROM robot_configs WHERE user_id = ? ORDER BY robot_number";
        List<RobotConfig> configs = new ArrayList<>();

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(userId));

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    RobotConfig config = new RobotConfig();
                    config.setRobotNumber(rs.getInt("robot_number"));
                    config.setSymbol(rs.getString("symbol"));
                    config.setTimeframe(rs.getString("timeframe"));
                    config.setX1Type(rs.getString("x1_type"));
                    config.setMinX1Height(rs.getDouble("min_x1_height"));
                    config.setTrigPercent(rs.getDouble("trig_percent"));
                    config.setStopLossPercent(rs.getDouble("stop_loss_percent"));
                    config.setTp1Percent(rs.getDouble("tp1_percent"));
                    config.setTp2Percent(rs.getDouble("tp2_percent"));
                    config.setTp3Percent(rs.getDouble("tp3_percent"));
                    config.setTp1Volume(rs.getInt("tp1_volume"));
                    config.setTp2Volume(rs.getInt("tp2_volume"));
                    config.setTp3Volume(rs.getInt("tp3_volume"));
                    config.setProfitCandleLimit(rs.getInt("profit_candle_limit"));
                    config.setRptPercent(rs.getDouble("rpt_percent"));
                    config.setRptFixedAmount(rs.getDouble("rpt_fixed_amount"));
                    config.setStartHour(rs.getInt("start_hour"));
                    config.setStartMinute(rs.getInt("start_minute"));
                    config.setEndTimeEnabled(rs.getBoolean("end_time_enabled"));
                    config.setEndHour(rs.getInt("end_hour"));
                    config.setEndMinute(rs.getInt("end_minute"));
                    config.setDailyDdLimit(rs.getDouble("daily_dd_limit"));
                    config.setX2StrictEnabled(rs.getBoolean("x2_strict_enabled"));
                    config.setX2RelaxedEnabled(rs.getBoolean("x2_relaxed_enabled"));
                    config.setDisableLeapfrog(rs.getBoolean("disable_leapfrog"));
                    configs.add(config);
                }
            }
        }

        return configs;
    }

    public void saveDefaultValues(String userId, Map<String, Object> defaults) throws SQLException {
        String jsonDefaults = gson.toJson(defaults);
        String sql = """
            INSERT INTO default_values (user_id, defaults)
            VALUES (?, ?::jsonb)
            ON CONFLICT (user_id) DO UPDATE SET
                defaults = EXCLUDED.defaults,
                updated_at = CURRENT_TIMESTAMP
            """;

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(userId));
            stmt.setString(2, jsonDefaults);
            stmt.executeUpdate();
        }
    }

    public Map<String, Object> loadDefaultValues(String userId) throws SQLException {
        String sql = "SELECT defaults FROM default_values WHERE user_id = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(userId));

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String jsonDefaults = rs.getString("defaults");
                    return gson.fromJson(jsonDefaults, Map.class);
                }
            }
        }

        return null;
    }

    public void deleteRobotConfigs(String userId, List<Integer> robotNumbers) throws SQLException {
        if (robotNumbers.isEmpty()) return;

        String placeholders = String.join(",", Collections.nCopies(robotNumbers.size(), "?"));
        String sql = "DELETE FROM robot_configs WHERE user_id = ? AND robot_number IN (" + placeholders + ")";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(userId));
            for (int i = 0; i < robotNumbers.size(); i++) {
                stmt.setInt(i + 2, robotNumbers.get(i));
            }
            stmt.executeUpdate();
        }
    }

    @Override
    public List<com.finaldelta.models.MarketBarData> getRecentCompletedBars(String symbol, String timeframe, int count) throws Exception {
        return new ArrayList<>();
    }

    @Override
    public double getLatestBid(String symbol) throws Exception {
        return 0.0;
    }

    @Override
    public double getLatestAsk(String symbol) throws Exception {
        return 0.0;
    }

    @Override
    public long getLatestTickTimestamp() throws Exception {
        return System.currentTimeMillis();
    }

    @Override
    public void insertTradeCommand(com.finaldelta.models.TradeCommand command) throws Exception {
        throw new UnsupportedOperationException("Trade commands not supported in Postgres mode");
    }

    public Connection createConnection() throws SQLException {
        return getConnection();
    }

    @Override
    public void close() {
    }
}
