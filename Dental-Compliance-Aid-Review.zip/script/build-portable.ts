import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "path";
import { build as viteBuild } from "vite";
import { rm, copyFile } from "fs/promises";
import { viteSingleFile } from "vite-plugin-singlefile";
import { metaImagesPlugin } from "../vite-plugin-meta-images";

async function buildPortable() {
  const rootDir = path.resolve(import.meta.dirname, "..");
  const clientRoot = path.resolve(rootDir, "client");
  const outDir = path.resolve(rootDir, "Dental-Compliance-Aid-PORTABLE");

  await rm(outDir, { recursive: true, force: true });

  await viteBuild({
    root: clientRoot,
    base: "./",
    plugins: [react(), tailwindcss(), metaImagesPlugin(), viteSingleFile()],
    css: {
      postcss: {
        plugins: [],
      },
    },
    resolve: {
      alias: {
        "@": path.resolve(rootDir, "client", "src"),
        "@shared": path.resolve(rootDir, "shared"),
        "@assets": path.resolve(rootDir, "attached_assets"),
      },
    },
    build: {
      outDir,
      emptyOutDir: true,
      assetsInlineLimit: 100_000_000,
      cssCodeSplit: false,
      rollupOptions: {
        output: {
          inlineDynamicImports: true,
        },
      },
    },
  });

  await copyFile(
    path.resolve(clientRoot, "public", "favicon.png"),
    path.resolve(outDir, "favicon.png"),
  );
  await copyFile(
    path.resolve(clientRoot, "public", "opengraph.jpg"),
    path.resolve(outDir, "opengraph.jpg"),
  );
}

buildPortable().catch((err) => {
  console.error(err);
  process.exit(1);
});
