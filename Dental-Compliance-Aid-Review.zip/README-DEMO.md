# Dental Compliance Aid - Demo Instructions

This folder contains the demo version of the Dental Compliance Aid portal.

## How to Run the Demo

### Prerequisites
You need **Node.js** installed on your computer.
1. Go to [nodejs.org](https://nodejs.org/)
2. Download and install the "LTS" version.

### Starting the App

**On Windows:**
1. Double-click the `demo-start.bat` file.
2. A black window will open (this is the server) - keep it open.
3. Your web browser should automatically open to the dashboard.

**On Mac:**
1. Right-click `demo-start.sh` and select "Open With" -> "Terminal".
   *(Or open Terminal, drag the file in, and press Enter)*
2. If it asks for permission, allow it.
3. Your web browser should automatically open.

### Accessing Manually
If the browser doesn't open automatically, open Chrome and type:
`http://localhost:5000`

### Stopping the App
Simply close the black terminal window.

---
**Note:** This is a local demo version. Any data you enter is saved only to your specific browser on this computer.
