I have researched the codebase and identified the `Layout.tsx` component as the place where the main content width is constrained.

I plan to modify `client/src/components/Layout.tsx` to dynamically adjust the maximum width of the main content area based on the sidebar's collapsed state.

**Plan:**

1.  **Modify `client/src/components/Layout.tsx`**:
    *   Locate the main content container `div` (currently with `max-w-6xl`).
    *   Update the `className` to conditionally apply a wider max-width (e.g., `max-w-[1600px]`) when `isCollapsed` is true.
    *   Preserve the original `max-w-6xl` when the sidebar is expanded.
    *   Ensure the transition is smooth using `transition-all`.

This change will allow the main content (including wide tables like Immunisation Records) to expand horizontally and utilize the extra space gained by collapsing the sidebar, rather than just re-centering.