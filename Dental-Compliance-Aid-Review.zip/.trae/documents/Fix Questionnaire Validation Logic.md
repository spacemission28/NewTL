I have identified the issue. The validation logic was checking for the generic field ID `steriliserBrand` (which is empty) instead of the specific dynamic ID `steriliserBrand_1` (which has your value).

I will fix this by making the validation logic smarter:
1.  **Dynamic Field Generation:** It will now check `steriliserCount` first.
2.  **Specific Targeting:** If you have 1 steriliser, it will explicitly look for `steriliserBrand_1` and `steriliserType_1`.
3.  **Legacy Exclusion:** It will ignore the generic `steriliserBrand` placeholder during validation, preventing the false "missing field" error.

This ensures that when you select a brand for "Steriliser 1", the system correctly recognizes it as answered.