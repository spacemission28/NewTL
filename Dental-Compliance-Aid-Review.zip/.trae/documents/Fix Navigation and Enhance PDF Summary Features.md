I will implement the requested changes to navigation, PDF features, and document saving.

**1. Fix Navigation (Back & Save)**
*   **Go Back:** I will ensure the "Go Back" arrow for "Required Affirmations" and "Review Log" explicitly navigates to the **IPC Submenu** (`ipc`) instead of the Main Dashboard.
*   **Save & Update:** I will modify the `handleSave` function so that saving changes in "Required Affirmations" or "Review Log" redirects the user to the **IPC Submenu**, rather than kicking them out to the Main Dashboard.

**2. PDF Summary Signature Upload**
*   **Interactive Box:** I will make the "Signature" box in the PDF Summary clickable.
*   **Upload & Display:** Clicking it will open a file dialog to upload an image (e.g., signature scan), which will then be displayed live in the box.

**3. PDF Footer Buttons & Functionality**
*   **New Buttons:** I will replace the "Official Compliance Record..." text with two buttons:
    *   **SAVE & DOWNLOAD PDF:** This will download the file to your computer *and* save a record of it to "All Documents".
    *   **PRINT PDF:** This will trigger the browser's print dialog.
*   **"All Documents" Integration:** I will update the "All Documents" page (`Reports.tsx`) to correctly categorize these saved PDF summaries (e.g., under "IPC Policy & Manual") instead of dumping them into "Snaps to File".

**Implementation Steps:**
1.  Modify `Dashboard.tsx` to adjust `activeMenu` transitions for Back and Save actions.
2.  Add signature upload state and logic to `Dashboard.tsx`.
3.  Replace the PDF footer text with the new buttons and implement the save/print handlers.
4.  Update `Reports.tsx` to read dynamic categories from storage, ensuring saved PDFs appear in their correct sections.