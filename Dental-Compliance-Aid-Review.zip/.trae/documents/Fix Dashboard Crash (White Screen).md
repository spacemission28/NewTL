I have identified the likely cause of the "blank screen" issue. It is a **runtime crash** caused by data corruption in `localStorage`, specifically where the application attempts to read properties from empty or invalid data rows (e.g., `null` values) in the new `cpdRows` structure.

This is crashing the application in two places:
1.  The `countRows` helper function (used for the dashboard tiles).
2.  The `cpdForPdf` calculation (used for the PDF generation logic).

We do **not** need to rollback the PDF logic (which would re-introduce incorrect columns). Instead, I will **harden** the code to safely handle invalid data without crashing.

### **Plan:**
1.  **Fix `countRows` Helper:**
    *   Add safety checks to ensure `rows` is an array and each `row` object exists before accessing properties.
2.  **Fix PDF Generation Logic:**
    *   Add safety checks to the `cpdForPdf` filter to skip null/undefined rows.
    *   Ensure the table rendering logic also checks for row existence.
3.  **Verify Data Loading:**
    *   Double-check that the `cpdRows` state initialization correctly handles all edge cases (already improved, but I will verify).

This will resolve the white screen and allow you to log in. I will execute these fixes immediately upon your confirmation.