# Guide: Deploying Dental Compliance Aid on Windows Server with SQLite

This guide is specific to deploying your application on **Windows Server 2019/2022**.

## 1. Prerequisites
- **OS:** Windows Server 2019 or 2022.
- **Access:** Administrator access via Remote Desktop Protocol (RDP).
- **Tools:** PowerShell.

## 2. Server Environment Setup

### Step 1: Install Node.js
1. Download the **LTS version** (e.g., v20.x) `.msi` installer from [nodejs.org](https://nodejs.org/).
2. Run the installer on the server. **Important:** Ensure "Add to PATH" is selected during installation.
3. Open PowerShell as Administrator and verify:
   ```powershell
   node -v
   npm -v
   ```

### Step 2: Install Git (Optional)
If you want to pull code directly from a repository:
1. Download "Git for Windows" from [git-scm.com](https://git-scm.com/).
2. Install with default settings.

## 3. Application Deployment

### Step 1: Transfer Files
1. Create a directory for your app, e.g., `C:\DentalApp`.
2. Copy your project files (excluding `node_modules`) to this folder. You can simply copy/paste over RDP or use Git clone.

### Step 2: Install Dependencies
Open PowerShell, navigate to your app folder, and install:
```powershell
cd C:\DentalApp
npm install --production
```

### Step 3: Database & Permissions (CRITICAL)
SQLite relies on file system permissions.
1. Ensure your `.env` points to a persistent path, e.g., `DATABASE_URL=file:./data/dental.db`.
2. Create the `data` folder inside `C:\DentalApp`.
3. **Grant Write Permissions:**
   *   Right-click the `data` folder -> **Properties** -> **Security**.
   *   Click **Edit** -> **Add**.
   *   Add the user account that will run the application (e.g., your Admin user, or `LocalService` if running as a service).
   *   **Check "Modify" and "Write" permissions.**
   *   *Failure to do this will result in "SQLITE_CANTOPEN" or "Read-only" errors.*

## 4. Process Management (Run as a Service)
We will use **PM2** to run the app as a background Windows Service, so it restarts automatically on reboot.

1. Install PM2 and the Windows startup plugin:
   ```powershell
   npm install -g pm2 pm2-windows-startup
   ```

2. Install the startup hook:
   ```powershell
   pm2-startup install
   ```

3. Start your application:
   ```powershell
   # Make sure you are in C:\DentalApp
   # Assuming dist/index.js is your built server entry point
   pm2 start dist/index.js --name "dental-app"
   pm2 save
   ```

## 5. Exposing to the Web

### Option A: Direct Port (Simplest for Dedicated Server)
If this server is dedicated to this one app:
1. Set `PORT=80` in your `.env` file.
2. Ensure no other service (like IIS) is using Port 80.
   *   To stop IIS if needed: `net stop W3SVC`
3. Configure **Windows Firewall**:
   *   Open "Windows Defender Firewall with Advanced Security".
   *   Inbound Rules -> New Rule -> Port -> TCP -> Specific Local Ports: 80 -> Allow the connection -> Name: "Node App HTTP".

### Option B: IIS Reverse Proxy (Standard for Windows Server)
If you want to use IIS (Internet Information Services) to manage the site:
1. **Install IIS Modules:**
   *   Download and install **URL Rewrite Module 2.1**.
   *   Download and install **Application Request Routing (ARR) 3.0**.
2. **Enable Proxy:**
   *   Open IIS Manager -> Server Node -> "Application Request Routing Cache" -> "Server Proxy Settings" -> Check "Enable proxy".
3. **Configure Site:**
   *   Create a new Website in IIS pointing to an empty folder (or your app folder).
   *   Use **URL Rewrite** to create a Reverse Proxy rule that forwards traffic from `YourSite` -> `localhost:3000`.

## 6. Backups (Task Scheduler)
Since your database is a single file (`dental.db`), backups are easy.

1. Create a PowerShell script `C:\DentalApp\backup.ps1`:
   ```powershell
   $source = "C:\DentalApp\data\dental.db"
   $destPath = "C:\Backups"
   if (!(Test-Path $destPath)) { New-Item -ItemType Directory -Path $destPath }
   $dest = "$destPath\dental_$(get-date -f yyyyMMdd).db"
   Copy-Item $source -Destination $dest
   ```

2. Open **Task Scheduler**:
   *   Create Basic Task -> "Daily Backup" -> Trigger: Daily at 3 AM.
   *   Action: Start a Program.
   *   Program/script: `powershell.exe`
   *   Add arguments: `-ExecutionPolicy Bypass -File "C:\DentalApp\backup.ps1"`

## 7. Troubleshooting Common Windows Issues
- **App crashes immediately:** Check logs with `pm2 logs`. Usually missing environment variables or path issues.
- **Database Locked:** Ensure you aren't opening the SQLite file with a viewer tool (like DB Browser for SQLite) while the app is trying to write to it.
- **Port In Use:** If you can't bind to port 80, open PowerShell: `netstat -ano | findstr :80` to see what PID is holding it.
