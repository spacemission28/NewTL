#!/bin/bash

echo "=================================================="
echo "   Dental Compliance Aid - Demo Launcher"
echo "=================================================="
echo ""
echo "Checking for Node.js..."

if ! command -v node &> /dev/null; then
    echo "Error: Node.js is not installed."
    echo "Please install Node.js from https://nodejs.org/"
    echo "Then run this script again."
    exit 1
fi

echo "Node.js found!"
echo ""
echo "Installing dependencies (this may take a minute)..."
npm install

if [ $? -ne 0 ]; then
    echo "Error: Failed to install dependencies."
    exit 1
fi

echo ""
echo "Starting the Demo Server..."
echo "Your browser should open automatically."
echo "If not, open Chrome and go to: http://localhost:4040"
echo ""
echo "Press Ctrl+C to stop the server."
echo ""

# Start the server and open the browser
# We use 'npm run dev' but modify it slightly to ensure it binds to localhost
PORT=4040 npm run dev &
PID=$!

# Wait a moment for server to start
sleep 5

# Open browser based on OS
if [[ "$OSTYPE" == "darwin"* ]]; then
    open "http://localhost:4040"
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    xdg-open "http://localhost:4040"
fi

wait $PID