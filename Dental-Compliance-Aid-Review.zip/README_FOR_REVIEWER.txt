DENTAL COMPLIANCE AID - REVIEW VERSION
========================================

Hi! This is the portable review version of the Dental Compliance Aid portal.
It allows you to test the full "Gap Analysis" and "Compliance Dashboard" features locally.

REQUIREMENTS
------------
- A computer (Windows, Mac, or Linux).
- Node.js installed (Download the "LTS" version from https://nodejs.org/ if you don't have it).

HOW TO RUN
----------

--- FOR WINDOWS USERS ---
1. Unzip this folder to your Desktop.
2. Open the folder "Dental-Compliance-Aid".
3. Double-click the file named "demo-start.bat".
   (It might just be named "demo-start" with a gear icon).
4. A black terminal window will open and install necessary files.
5. Once ready, it will automatically open your web browser to http://localhost:4040.

--- FOR MAC USERS ---
1. Unzip this folder to your Desktop.
2. Open the folder "Dental-Compliance-Aid".
3. Right-click the file "demo-start.sh" and select "Open With > Terminal".
   (Or drag the file into a Terminal window and press Enter).

FEATURES TO TEST
----------------
1. Gap Analysis Wizard (Tile: "AS 5369:2023 Gap Analysis")
   - Go through the 6 sections.
   - Try the "Save & Download PDF" button at the end.
   - Check the new "Patient Safety" section.

2. Compliance Summaries
   - Check "IPC Policy", "Steriliser PQ", etc.
   - Verify the PDF generation ("Save & Download PDF") works for each.

TROUBLESHOOTING
---------------
- If the browser doesn't open automatically, manually go to http://localhost:4040
- If the script closes immediately or fails, ensure you have installed Node.js first.
