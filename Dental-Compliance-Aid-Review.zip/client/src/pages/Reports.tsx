import { Layout } from "@/components/Layout";
import { useState, useEffect } from "react";
import { Download, ChevronRight, Folder, Edit2, Check, Trash2, Loader2 } from "lucide-react";
import { SECTIONS } from "@/components/GapAnalysisWizard";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

type Document = {
  name: string;
  date: string;
  category: string;
};

const staticDocuments: Document[] = [
  { name: "IPC Policy & Manual 2026", date: "Jan 12, 2026", category: "IPC Policy & Manual" },
  { name: "Practice Specific Protocol", date: "Jan 12, 2026", category: "IPC Policy & Manual" },
  { name: "DBA Readiness Report", date: "Jan 14, 2026", category: "DBA Affirmation Prep" },
  { name: "Evidence Folder Index", date: "Jan 14, 2026", category: "DBA Affirmation Prep" },
  { name: "Steriliser PQ Log", date: "Jan 15, 2026", category: "Steriliser PQ Validation" },
  { name: "Maintenance Certificate", date: "Jan 15, 2026", category: "Steriliser PQ Validation" },
  { name: "Handpiece Reprocessing Guide", date: "Jan 10, 2026", category: "Staff IPC Training & CPD" },
  { name: "AS 5369:2023 Gap Report", date: "Jan 11, 2026", category: "AS 5369:2023 Gap Analysis" },
];

const ALL_CATEGORIES = [
  "Snaps to File",
  "CPD Specific Snapshots",
  "IPC Policy & Manual",
  "DBA Affirmation Prep",
  "Steriliser PQ Validation",
  "Staff IPC Training & CPD",
  "AS 5369:2023 Gap Analysis"
];

export default function Reports() {
  const [selectedYear, setSelectedYear] = useState<number>(2026);
  const [documents, setDocuments] = useState<Document[]>([]);
  const [editingDoc, setEditingDoc] = useState<{ name: string; category: string; newName: string } | null>(null);

  useEffect(() => {
    // Load documents (defaults + snaps) and filter out deleted defaults
    try {
      // 1. Get deleted defaults
      const deletedDefaultsStr = localStorage.getItem("dentalcheck.deleted_docs");
      const deletedDefaults = deletedDefaultsStr ? JSON.parse(deletedDefaultsStr) : [];

      // 2. Filter static documents
      const activeDefaults = staticDocuments.filter(d => !deletedDefaults.includes(d.name));

      // 3. Get snaps and generated reports
      const snapsStr = localStorage.getItem("dentalcheck.snaps");
      let snapDocs: Document[] = [];
      if (snapsStr) {
        const snaps = JSON.parse(snapsStr);
        snapDocs = snaps.map((s: any) => ({
          name: s.name,
          date: s.date,
          // Use stored category if available, otherwise default to "Snaps to File"
          category: s.category || "Snaps to File"
        }));
      }

      setDocuments([...activeDefaults, ...snapDocs]);
    } catch (e) {
      console.error("Failed to load documents", e);
      setDocuments(staticDocuments); // Fallback
    }
  }, []);
  
  // Use ALL_CATEGORIES instead of deriving from documents
  const categories = ALL_CATEGORIES;

  const handleFileSnap = (docName: string, targetCategory: string) => {
    // In a real app, this would update the backend.
    // For now, we'll update local state and maybe localStorage if we want persistence of the move
    const updatedDocs = documents.map(d => {
      if (d.name === docName && d.category === "Snaps to File") {
        return { ...d, category: targetCategory };
      }
      return d;
    });
    setDocuments(updatedDocs);
    
    // Also update localStorage to reflect the move (remove from snaps list effectively)
    // Actually, we should probably keep it in snaps but mark it as filed? 
    // Or just let the UI state handle it for this session.
    // Let's remove it from "dentalcheck.snaps" to persist the "move"
    try {
        const snapsStr = localStorage.getItem("dentalcheck.snaps");
        if (snapsStr) {
            const snaps = JSON.parse(snapsStr);
            const filteredSnaps = snaps.filter((s: any) => s.name !== docName);
            localStorage.setItem("dentalcheck.snaps", JSON.stringify(filteredSnaps));
        }
    } catch (e) {
        console.error("Failed to update snaps storage", e);
    }
  };

  const handleRename = () => {
    if (!editingDoc) return;
    
    const { name, category, newName } = editingDoc;
    if (!newName.trim()) return;

    const updatedDocs = documents.map(d => {
      if (d.name === name && d.category === category) {
        return { ...d, name: newName.trim() };
      }
      return d;
    });
    setDocuments(updatedDocs);
    
    // Also update localStorage if it's a snap
    try {
        const snapsStr = localStorage.getItem("dentalcheck.snaps");
        if (snapsStr) {
            const snaps = JSON.parse(snapsStr);
            const updatedSnaps = snaps.map((s: any) => {
                if (s.name === name) {
                    return { ...s, name: newName.trim() };
                }
                return s;
            });
            localStorage.setItem("dentalcheck.snaps", JSON.stringify(updatedSnaps));
        }
    } catch (e) {
        console.error("Failed to update snaps name", e);
    }
    
    setEditingDoc(null);
  };

  const handleDownload = (doc: Document) => {
    // 1. Check if it's the Gap Analysis Report (Static or Generated)
    if (doc.category === "AS 5369:2023 Gap Analysis" || doc.name.includes("Gap Report")) {
      try {
        const savedData = localStorage.getItem("dentalcheck.gap_analysis");
        if (savedData) {
          const data = JSON.parse(savedData);
          
          // Generate real PDF report using jsPDF + autoTable (Headless generation)
          const doc = new jsPDF();
          
          // Header
          doc.setFontSize(20);
          doc.setTextColor(40, 40, 40);
          doc.text("Practice Accreditation Gap Analysis", 14, 22);
          
          doc.setFontSize(10);
          doc.setTextColor(100, 100, 100);
          doc.text(`Generated: ${new Date().toLocaleDateString()}`, 14, 28);
          doc.text("Standard: AS 5369:2023 & NSQHS", 14, 33);

          // Calculate Score
          let totalQuestions = 0;
          let score = 0;
          SECTIONS.forEach(sec => {
            sec.questions.forEach(q => {
              totalQuestions++;
              const ans = data[q.id]?.status;
              if (ans === "Yes" || ans === "NA") score++;
            });
          });
          const percent = totalQuestions > 0 ? Math.round((score / totalQuestions) * 100) : 0;

          // Score Box
          doc.setFillColor(240, 240, 240);
          doc.roundedRect(140, 15, 50, 25, 3, 3, 'F');
          doc.setFontSize(10);
          doc.setTextColor(100, 100, 100);
          doc.text("Compliance Score", 165, 22, { align: "center" });
          doc.setFontSize(24);
          if (percent >= 80) doc.setTextColor(0, 128, 0); // Green
          else if (percent >= 50) doc.setTextColor(255, 165, 0); // Orange
          else doc.setTextColor(255, 0, 0); // Red
          doc.text(`${percent}%`, 165, 33, { align: "center" });

          let yPos = 50;

          // Loop Sections
          SECTIONS.forEach((sec) => {
            // Section Title
            doc.setFontSize(14);
            doc.setTextColor(0, 0, 0);
            doc.text(sec.title, 14, yPos);
            yPos += 8;

            const tableBody = sec.questions.map(q => {
               const ans = data[q.id];
               return [
                 q.text,
                 q.clause,
                 ans?.status || "Not Answered",
                 ans?.notes || "-"
               ];
            });

            autoTable(doc, {
              startY: yPos,
              head: [['Requirement', 'Clause', 'Status', 'Notes']],
              body: tableBody,
              theme: 'grid',
              headStyles: { fillColor: [41, 128, 185], textColor: 255 },
              styles: { fontSize: 8, cellPadding: 3 },
              columnStyles: {
                0: { cellWidth: 80 },
                1: { cellWidth: 25 },
                2: { cellWidth: 25 },
                3: { cellWidth: 50 }
              },
              didParseCell: (data) => {
                 if (data.section === 'body' && data.column.index === 2) {
                     const status = data.cell.raw;
                     if (status === 'Yes') data.cell.styles.textColor = [0, 128, 0];
                     if (status === 'No') data.cell.styles.textColor = [255, 0, 0];
                     if (status === 'Partial') data.cell.styles.textColor = [255, 165, 0];
                 }
              }
            });

            yPos = (doc as any).lastAutoTable.finalY + 15;
            
            // Page break check (simple)
            if (yPos > 250) {
                doc.addPage();
                yPos = 20;
            }
          });

          doc.save("AS5369_Gap_Analysis_Report.pdf");
          return;
        }
      } catch (e) {
        console.error("Failed to generate PDF report", e);
      }
    }

    // Check if it's a generated report or snap (exists in dentalcheck.snaps)
    try {
        const snapsStr = localStorage.getItem("dentalcheck.snaps");
        if (snapsStr) {
            const snaps = JSON.parse(snapsStr);
            const snap = snaps.find((s: any) => s.name === doc.name);
            
            if (snap && snap.url) {
                // Determine extension based on data URL
                const isPdf = snap.url.startsWith('data:application/pdf');
                const isImage = snap.url.startsWith('data:image');
                const ext = isPdf ? '.pdf' : isImage ? '.jpg' : '.txt'; // Default fallback
                
                const link = document.createElement('a');
                link.href = snap.url;
                link.download = `${doc.name}${ext}`;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                return;
            }
        }
    } catch (e) {
        console.error("Failed to download snap", e);
    }

    // For static docs or if snap URL failed, create a dummy text file
    const element = document.createElement("a");
    const file = new Blob([`This is a placeholder content for document: ${doc.name}\nCategory: ${doc.category}\nDate: ${doc.date}`], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = `${doc.name}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleDelete = (docName: string, docCategory: string) => {
    if (!window.confirm(`Are you sure you want to delete "${docName}"?`)) {
      return;
    }

    const updatedDocs = documents.filter(d => !(d.name === docName && d.category === docCategory));
    setDocuments(updatedDocs);

    try {
        // If it is NOT one of the static default documents, it must be in "dentalcheck.snaps"
        // Even if category is "IPC Policy & Manual", if it's a generated PDF, it's stored in snaps.
        // We can check if it exists in staticDocuments to decide.
        const isStatic = staticDocuments.some(d => d.name === docName && d.category === docCategory);

        if (!isStatic) {
            // It's a snap or generated report
            const snapsStr = localStorage.getItem("dentalcheck.snaps");
            if (snapsStr) {
                const snaps = JSON.parse(snapsStr);
                // Filter by name AND category to be safe, or just name if unique enough.
                // Given our new unique naming, name should suffice, but let's be robust.
                const filteredSnaps = snaps.filter((s: any) => s.name !== docName);
                localStorage.setItem("dentalcheck.snaps", JSON.stringify(filteredSnaps));
            }
        } else {
            // It's a default static document
            const deletedDefaultsStr = localStorage.getItem("dentalcheck.deleted_docs");
            const deletedDefaults = deletedDefaultsStr ? JSON.parse(deletedDefaultsStr) : [];
            if (!deletedDefaults.includes(docName)) {
                deletedDefaults.push(docName);
                localStorage.setItem("dentalcheck.deleted_docs", JSON.stringify(deletedDefaults));
            }
        }
    } catch (e) {
        console.error("Failed to delete document", e);
    }
  };

  return (
    <Layout>
      <div className="w-full bg-card rounded-2xl border border-border p-8 shadow-sm mt-6">
        <header className="mb-8">
          <h2 className="text-2xl font-display font-bold text-foreground">All Documents</h2>
          <p className="text-sm text-muted-foreground mt-1">Practice compliance documentation repository</p>
        </header>

        <div className="flex gap-4 mb-10">
          {[2026, 2027].map(year => (
            <button
              key={year}
              onClick={() => setSelectedYear(year)}
              className={`flex items-center gap-3 px-8 py-5 rounded-xl border transition-all ${
                selectedYear === year
                  ? "bg-primary/5 border-primary text-primary shadow-sm"
                  : "bg-background border-border text-muted-foreground hover:border-primary/50"
              }`}
            >
              <Folder className={`w-5 h-5 ${selectedYear === year ? "text-primary" : "text-muted-foreground"}`} />
              <span className="font-bold text-lg">{year}</span>
            </button>
          ))}
        </div>

        <div className="space-y-12">
          {categories.map(category => (
            <div key={category} className="space-y-4">
              <div className="flex items-center gap-2 pb-2 border-b border-border">
                <ChevronRight className="w-4 h-4 text-primary" strokeWidth={3} />
                <h3 className="text-sm font-bold text-foreground/80 uppercase tracking-wider">{category}</h3>
              </div>
              
              <div className="overflow-hidden border border-border rounded-xl bg-background">
                <table className="w-full text-left border-collapse table-fixed">
                  <thead>
                    <tr className="bg-muted/30">
                      <th className="px-6 py-4 text-xs font-bold text-muted-foreground uppercase tracking-wider w-1/2">Document Name</th>
                      {category === "Snaps to File" ? (
                        <th className="px-6 py-4 text-xs font-bold text-muted-foreground uppercase tracking-wider w-1/4">File to...</th>
                      ) : (
                        <th className="px-6 py-4 text-xs font-bold text-muted-foreground uppercase tracking-wider w-1/4">Date Produced</th>
                      )}
                      <th className="px-6 py-4 text-xs font-bold text-muted-foreground uppercase tracking-wider text-center w-1/4">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {documents.filter(doc => doc.category === category).length === 0 ? (
                        <tr>
                            <td colSpan={3} className="px-6 py-8 text-center text-muted-foreground italic text-sm">
                                {category === "Snaps to File" ? "No new snaps. Use 'Document Snap' on mobile/sidebar to add." : "No documents in this category."}
                            </td>
                        </tr>
                    ) : (
                    documents
                      .filter(doc => doc.category === category)
                      .map((doc, idx) => (
                        <tr key={idx} className="hover:bg-muted/20 transition-colors group">
                          <td className="px-6 py-4 overflow-hidden">
                            <div className="flex items-center gap-3">
                              <FileText className="w-4 h-4 text-primary/60 shrink-0" />
                              {editingDoc?.name === doc.name && editingDoc?.category === doc.category ? (
                                <div className="flex items-center gap-2 flex-1 min-w-0">
                                  <input 
                                    type="text" 
                                    value={editingDoc.newName}
                                    onChange={(e) => setEditingDoc({ ...editingDoc, newName: e.target.value })}
                                    maxLength={20}
                                    className="flex-1 bg-background border border-primary rounded px-2 py-1 text-sm outline-none min-w-0"
                                    autoFocus
                                    onKeyDown={(e) => {
                                      if (e.key === "Enter") handleRename();
                                      if (e.key === "Escape") setEditingDoc(null);
                                    }}
                                  />
                                  <button onClick={handleRename} className="p-1 hover:bg-green-100 text-green-600 rounded-full">
                                    <Check className="w-4 h-4" />
                                  </button>
                                </div>
                              ) : (
                                <div className="flex items-center gap-2 flex-1 min-w-0 group/name">
                                  <span className="text-sm font-medium text-foreground truncate" title={doc.name}>
                                    {doc.name.length > 20 ? `${doc.name.substring(0, 20)}...` : doc.name}
                                  </span>
                                  <button 
                                    onClick={() => setEditingDoc({ name: doc.name, category: doc.category, newName: doc.name })}
                                    className="opacity-0 group-hover/name:opacity-100 p-1 hover:bg-primary/10 text-primary rounded-full transition-opacity"
                                  >
                                    <Edit2 className="w-3 h-3" />
                                  </button>
                                </div>
                              )}
                            </div>
                          </td>
                          {category === "Snaps to File" ? (
                            <td className="px-6 py-4">
                                <select 
                                    className="text-xs border border-border rounded px-2 py-1.5 bg-background text-foreground/80 outline-none focus:border-primary w-full max-w-[150px]"
                                    onChange={(e) => {
                                        if (e.target.value) {
                                            handleFileSnap(doc.name, e.target.value);
                                        }
                                    }}
                                    value=""
                                >
                                    <option value="">Select Folder...</option>
                                    {categories.filter(c => c !== "Snaps to File").map(c => (
                                        <option key={c} value={c}>{c}</option>
                                    ))}
                                </select>
                            </td>
                          ) : (
                            <td className="px-6 py-4 text-sm text-muted-foreground font-medium">
                              {doc.date}
                            </td>
                          )}
                          <td className="px-6 py-4">
                            <div className="flex items-center justify-center gap-2">
                            <button 
                              onClick={() => handleDownload(doc)}
                              className="p-2 rounded-lg hover:bg-primary/10 text-primary transition-all"
                            >
                              <Download className="w-4 h-4" />
                            </button>
                            <button 
                              onClick={() => handleDelete(doc.name, doc.category)}
                              className="p-2 rounded-lg hover:bg-red-50 text-red-500 transition-all"
                              title="Delete Document"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                            </div>
                          </td>
                        </tr>
                      )))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  );
}

function FileText(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
      <polyline points="14 2 14 8 20 8" />
      <line x1="16" x2="8" y1="13" y2="13" />
      <line x1="16" x2="8" y1="17" y2="17" />
      <line x1="10" x2="8" y1="9" y2="9" />
    </svg>
  );
}