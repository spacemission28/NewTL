import { Layout } from "@/components/Layout";
import { useState, useRef, useEffect } from "react";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Details() {
  const [saved, setSaved] = useState(false);
  const [formData, setFormData] = useState({
    practiceName: "",
    principalName: "",
    address: "",
    suburb: "",
    postcode: "",
    state: "",
    email: "",
  });
  const [unansweredFields, setUnansweredFields] = useState<string[]>([]);
  const scrollRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const requiredFields: (keyof typeof formData)[] = [
    "practiceName",
    "principalName",
    "address",
    "suburb",
    "postcode",
    "state",
    "email",
  ];

  useEffect(() => {
    try {
      const saved = localStorage.getItem("dentalcheck.details");
      if (saved) {
        const parsed = JSON.parse(saved) as Record<string, unknown>;
        setFormData(prev => {
          const next = { ...prev };
          requiredFields.forEach((k) => {
            if (typeof parsed[k] === "string") next[k] = parsed[k] as any;
          });
          return next;
        });
      }
    } catch (e) {
      console.error("Failed to load details", e);
    }
  }, []);

  const australianStates = [
    "New South Wales",
    "Victoria",
    "Queensland",
    "Western Australia",
    "South Australia",
    "Tasmania",
    "Australian Capital Territory",
    "Northern Territory"
  ];

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (unansweredFields.includes(field)) {
      setUnansweredFields(prev => prev.filter(f => f !== field));
    }
  };

  const handleSave = () => {
    const missing = requiredFields.filter(f => !String(formData[f] || "").trim());
    
    if (missing.length > 0) {
      setUnansweredFields(missing as string[]);
      alert("Please complete all the questions");
      
      const firstMissing = missing[0];
      scrollRefs.current[firstMissing as string]?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }

    setUnansweredFields([]);
    localStorage.setItem("dentalcheck.details", JSON.stringify(formData));
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <Layout>
      <div className="w-full bg-card rounded-2xl border border-border p-10 shadow-sm mt-6">
        <header className="mb-10 text-center">
          <h2 className="text-2xl font-display font-bold text-foreground">Your Details</h2>
          <p className="text-sm text-muted-foreground mt-2">Practice registration and identification information</p>
        </header>

        <div className="max-w-2xl mx-auto space-y-8">
          <div ref={el => { if (el) scrollRefs.current.practiceName = el; }} className="space-y-2">
            <div className="flex items-center gap-2">
              {unansweredFields.includes("practiceName") && <div className="w-1.5 h-1.5 rounded-full bg-red-500" />}
              <label className="text-sm font-medium text-foreground/70">Practice Name</label>
            </div>
            <input 
              type="text" 
              placeholder="e.g. Bright Smiles Dental"
              value={formData.practiceName}
              onChange={(e) => handleInputChange("practiceName", e.target.value)}
              className={cn(
                "w-full bg-background border rounded-md px-4 py-2.5 text-sm focus:ring-1 focus:ring-primary outline-none transition-all",
                unansweredFields.includes("practiceName") ? "border-red-500" : "border-input"
              )}
            />
          </div>

          <div ref={el => { if (el) scrollRefs.current.principalName = el; }} className="space-y-2">
            <div className="flex items-center gap-2">
              {unansweredFields.includes("principalName") && <div className="w-1.5 h-1.5 rounded-full bg-red-500" />}
              <label className="text-sm font-medium text-foreground/70">Name of Principal</label>
            </div>
            <input 
              type="text" 
              placeholder="e.g. Dr. Jane Smith"
              value={formData.principalName}
              onChange={(e) => handleInputChange("principalName", e.target.value)}
              className={cn(
                "w-full bg-background border rounded-md px-4 py-2.5 text-sm focus:ring-1 focus:ring-primary outline-none transition-all",
                unansweredFields.includes("principalName") ? "border-red-500" : "border-input"
              )}
            />
          </div>

          <div ref={el => { if (el) scrollRefs.current.address = el; }} className="space-y-2">
            <div className="flex items-center gap-2">
              {unansweredFields.includes("address") && <div className="w-1.5 h-1.5 rounded-full bg-red-500" />}
              <label className="text-sm font-medium text-foreground/70">Address of Practice</label>
            </div>
            <input 
              type="text" 
              placeholder="Start typing your Australian address..."
              value={formData.address}
              onChange={(e) => handleInputChange("address", e.target.value)}
              className={cn(
                "w-full bg-background border rounded-md px-4 py-2.5 text-sm focus:ring-1 focus:ring-primary outline-none transition-all",
                unansweredFields.includes("address") ? "border-red-500" : "border-input"
              )}
            />
            <p className="text-[10px] text-muted-foreground">Autofill powered by Australian address database</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div ref={el => { if (el) scrollRefs.current.suburb = el; }} className="space-y-2">
              <div className="flex items-center gap-2">
                {unansweredFields.includes("suburb") && <div className="w-1.5 h-1.5 rounded-full bg-red-500" />}
                <label className="text-sm font-medium text-foreground/70">Suburb</label>
              </div>
              <input 
                type="text" 
                placeholder="e.g. Surry Hills"
                value={formData.suburb}
                onChange={(e) => handleInputChange("suburb", e.target.value)}
                className={cn(
                  "w-full bg-background border rounded-md px-4 py-2.5 text-sm focus:ring-1 focus:ring-primary outline-none transition-all",
                  unansweredFields.includes("suburb") ? "border-red-500" : "border-input"
                )}
              />
            </div>
            <div ref={el => { if (el) scrollRefs.current.postcode = el; }} className="space-y-2">
              <div className="flex items-center gap-2">
                {unansweredFields.includes("postcode") && <div className="w-1.5 h-1.5 rounded-full bg-red-500" />}
                <label className="text-sm font-medium text-foreground/70">Postcode</label>
              </div>
              <input 
                type="text" 
                placeholder="e.g. 2010"
                value={formData.postcode}
                onChange={(e) => handleInputChange("postcode", e.target.value)}
                className={cn(
                  "w-full bg-background border rounded-md px-4 py-2.5 text-sm focus:ring-1 focus:ring-primary outline-none transition-all",
                  unansweredFields.includes("postcode") ? "border-red-500" : "border-input"
                )}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div ref={el => { if (el) scrollRefs.current.state = el; }} className="space-y-2">
              <div className="flex items-center gap-2">
                {unansweredFields.includes("state") && <div className="w-1.5 h-1.5 rounded-full bg-red-500" />}
                <label className="text-sm font-medium text-foreground/70">State & Territory</label>
              </div>
              <select 
                value={formData.state}
                onChange={(e) => handleInputChange("state", e.target.value)}
                className={cn(
                  "w-full bg-background border rounded-md px-4 py-2.5 text-sm focus:ring-1 focus:ring-primary outline-none transition-all",
                  unansweredFields.includes("state") ? "border-red-500" : "border-input"
                )}
              >
                <option value="">Select State...</option>
                {australianStates.map(state => (
                  <option key={state} value={state}>{state}</option>
                ))}
              </select>
            </div>
          </div>

          <div ref={el => { if (el) scrollRefs.current.email = el; }} className="space-y-2">
            <div className="flex items-center gap-2">
              {unansweredFields.includes("email") && <div className="w-1.5 h-1.5 rounded-full bg-red-500" />}
              <label className="text-sm font-medium text-foreground/70">Preferred Email Address for calendar/task notifications</label>
            </div>
            <input 
              type="email" 
              placeholder="e.g. principal@clinic.com.au"
              value={formData.email}
              onChange={(e) => handleInputChange("email", e.target.value)}
              className={cn(
                "w-full bg-background border rounded-md px-4 py-2.5 text-sm focus:ring-1 focus:ring-primary outline-none transition-all",
                unansweredFields.includes("email") ? "border-red-500" : "border-input"
              )}
            />
          </div>

          <div className="pt-8 flex flex-col items-center gap-4">
            <button 
              onClick={handleSave}
              className="bg-[#007AFF] text-white px-12 py-3 rounded-xl font-bold hover:opacity-90 transition-all shadow-lg min-w-[200px]"
            >
              Save changes
            </button>
            
            {saved && (
              <div className="flex items-center gap-2 px-6 py-2 rounded-full bg-green-100 text-green-700 border border-green-200 animate-in fade-in slide-in-from-top-2 duration-300">
                <Check className="w-4 h-4" />
                <span className="text-xs font-bold uppercase tracking-wider">Changes Saved</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
