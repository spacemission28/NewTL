import { useState, useEffect } from "react";
import { Layout } from "@/components/Layout";
import { Camera, Upload, X } from "lucide-react";
import { useLocation } from "wouter";

export default function DocumentSnap() {
  const [, setLocation] = useLocation();
  const [hasCamera, setHasCamera] = useState(false);

  useEffect(() => {
    // Check if camera is available (basic check)
    const canUseCamera =
      typeof (navigator as any)?.mediaDevices?.getUserMedia === "function";
    setHasCamera(canUseCamera);
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Create a mock "snapped" image URL
    const imageUrl = URL.createObjectURL(file);
    
    // Save to local storage for the Reports page to pick up
    try {
      const existingSnapsStr = localStorage.getItem("dentalcheck.snaps");
      const existingSnaps = existingSnapsStr ? JSON.parse(existingSnapsStr) : [];
      const newSnap = {
        id: Date.now().toString(),
        url: imageUrl,
        date: new Date().toLocaleDateString(),
        name: file.name // Use the actual file name
      };
      localStorage.setItem("dentalcheck.snaps", JSON.stringify([...existingSnaps, newSnap]));
      
      // Navigate to reports page
      alert("Document scanned and saved to 'Snaps to File'!");
      setLocation("/reports");
    } catch (err) {
      console.error("Failed to save snap", err);
      alert("Failed to save document");
    }
  };

  return (
    <Layout>
      <div className="flex flex-col items-center justify-center min-h-[60vh] p-4 text-center space-y-8 animate-in fade-in duration-500">
        <div className="bg-primary/10 p-6 rounded-full ring-4 ring-primary/20">
          <Camera className="w-16 h-16 text-primary" />
        </div>
        
        <div className="space-y-2 max-w-md">
          <h1 className="text-2xl font-bold tracking-tight">Document Snap</h1>
          <p className="text-muted-foreground">
            Take a photo of your certificate, receipt, or compliance document to add it to your records instantly.
          </p>
        </div>

        <div className="w-full max-w-sm space-y-4">
          <div className="relative group">
            <input
              type="file"
              accept="image/*,application/pdf"
              capture="environment"
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
              onChange={handleFileSelect}
            />
            <button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium h-14 rounded-xl shadow-lg shadow-primary/20 transition-all active:scale-95 flex items-center justify-center gap-3">
              <Camera className="w-5 h-5" />
              <span>{hasCamera ? "Take Photo" : "Upload Document"}</span>
            </button>
          </div>
          
          <div className="relative">
            <input
              type="file"
              accept="image/*,application/pdf"
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
              onChange={handleFileSelect}
            />
            <button className="w-full bg-secondary hover:bg-secondary/80 text-secondary-foreground font-medium h-12 rounded-xl transition-all active:scale-95 flex items-center justify-center gap-3">
              <Upload className="w-4 h-4" />
              <span>Upload from Gallery</span>
            </button>
          </div>

          <p className="text-xs text-muted-foreground pt-4">
            Supported formats: JPG, PNG, PDF
          </p>
        </div>
      </div>
    </Layout>
  );
}
