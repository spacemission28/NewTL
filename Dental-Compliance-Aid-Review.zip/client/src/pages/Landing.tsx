import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { ArrowRight, Activity, ShieldCheck } from "lucide-react";
// @ts-ignore
import clinicImg from "@assets/clinic_1768383184370.jpg";

export default function Landing() {
  const [, setLocation] = useLocation();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLocation("/dashboard");
  };

  return (
    <div className="h-screen flex flex-col md:flex-row bg-background font-sans overflow-hidden">
      {/* Left Panel - Branding & Form */}
      <div className="flex-1 flex flex-col justify-start pt-6 md:pt-8 px-8 sm:px-12 lg:px-24 bg-white dark:bg-card z-10 relative overflow-y-auto">
        <div className="w-full max-w-md mx-auto space-y-8 pb-12">
          
          <div className="flex items-center space-x-2">
            <div className="h-10 w-10 bg-primary/10 rounded-lg flex items-center justify-center text-primary">
              <Activity className="h-6 w-6" />
            </div>
            <span className="font-display font-bold text-2xl tracking-tight text-foreground">DentalCheck</span>
          </div>

          <div className="space-y-3">
            <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground leading-tight">
              Compliance made <span className="text-primary">effortless</span>.
            </h1>
            <p className="text-base text-muted-foreground">
              The intelligent platform for modern dental practices to manage IPC, DBA, Performance Qualification & CPD Record requirements.
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-5">
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-foreground">Email</label>
              <input 
                type="email" 
                placeholder="dr.reynolds@example.com"
                className="w-full px-4 py-2.5 rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                required
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-foreground">Password</label>
              <input 
                type="password" 
                placeholder="••••••••"
                className="w-full px-4 py-2.5 rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                required
              />
            </div>
            
            <button 
              type="submit"
              className="w-full bg-primary text-primary-foreground font-semibold py-3 rounded-lg hover:opacity-90 transition-opacity flex items-center justify-center group"
            >
              Sign In to Dashboard
              <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <div className="flex items-center justify-between text-sm">
              <a href="#" className="text-muted-foreground hover:text-foreground">Forgot password?</a>
            </div>
          </form>

          <div className="h-2" /> {/* Reduced dead space */}
        </div>
      </div>

      {/* Right Panel - Visual & Abstract */}
      <div className="hidden md:block flex-1 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/30 via-primary/5 to-white/80 z-10" />
        <img 
          src={clinicImg} 
          alt="Dental Clinic" 
          className="absolute inset-0 w-full h-full object-cover opacity-15 grayscale-[20%]"
        />
      </div>
    </div>
  );
}