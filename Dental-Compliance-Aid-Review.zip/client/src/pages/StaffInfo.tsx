import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { PlusCircle, MinusCircle, Users, Check } from "lucide-react";
import { Link } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Staff, InsertStaff } from "@shared/schema";
import { Layout } from "@/components/Layout";
import { cn } from "@/lib/utils";

export default function StaffInfo() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedRows, setSelectedRows] = useState<Set<string>>(new Set());
  
  // Local state for edits
  const [localStaff, setLocalStaff] = useState<Staff[]>([]);
  const [hasChanges, setHasChanges] = useState(false);
  const [saved, setSaved] = useState(false);

  // Fetch staff
  const { data: staffList, isLoading } = useQuery<Staff[]>({
    queryKey: ["/api/staff"],
  });

  // Sync local state when data loads
  useEffect(() => {
    if (staffList) {
      setLocalStaff(staffList);
    }
  }, [staffList]);

  // Update local state when query data changes (only if no unsaved changes to avoid overwriting)
  if (staffList && !hasChanges && JSON.stringify(staffList) !== JSON.stringify(localStaff)) {
    setLocalStaff(staffList);
  }

  // Create staff mutation
  const createMutation = useMutation({
    mutationFn: async (newStaff: InsertStaff) => {
      const res = await apiRequest("POST", "/api/staff", newStaff);
      return res.json();
    },
  });

  // Update staff mutation
  const updateMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<InsertStaff> }) => {
      const res = await apiRequest("PATCH", `/api/staff/${id}`, updates);
      return res.json();
    },
  });

  // Delete staff mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/staff/${id}`);
    },
  });

  const handleAddRow = () => {
    // For new rows, we create them immediately in backend to get an ID, 
    // OR we could use a temp ID. 
    // Given the requirement "dropdown menu is NOT provided unless Save Changes is pressed",
    // we should really keep everything local.
    // However, the previous implementation used direct DB calls.
    // To strictly follow the "Not provided unless saved" rule, let's use a temp ID strategy or just hold them.
    
    // Actually, simplest way to match the user's mental model:
    // 1. Add empty row to local state with a temp ID (e.g., "temp-" + Date.now())
    // 2. User edits.
    // 3. On Save, we loop through local state.
    //    - If ID starts with "temp-", POST to create.
    //    - If ID is real, PATCH to update.
    //    - If ID was in original list but not in local state, DELETE.
    
    const tempId = `temp-${Date.now()}`;
    const newRow: Staff = {
      id: tempId,
      name: "",
      role: "",
      email: "",
      startDate: "",
      notes: ""
    };
    setLocalStaff([...localStaff, newRow]);
    setHasChanges(true);
  };

  const handleRemoveRows = () => {
    const newLocalStaff = localStaff.filter(s => !selectedRows.has(s.id));
    setLocalStaff(newLocalStaff);
    setSelectedRows(new Set());
    setHasChanges(true);
  };

  const toggleRowSelection = (id: string) => {
    const newSelected = new Set(selectedRows);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedRows(newSelected);
  };

  const handleUpdate = (id: string, field: keyof InsertStaff, value: string) => {
    setLocalStaff(prev => prev.map(s => s.id === id ? { ...s, [field]: value } : s));
    setHasChanges(true);
  };

  const handleSaveChanges = async () => {
    try {
      // 1. Handle Deletions
      // Find IDs that were in the original staffList (from server) but are NOT in localStaff
      if (staffList) {
        const localIds = new Set(localStaff.map(s => s.id));
        const toDelete = staffList.filter(s => !localIds.has(s.id));
        await Promise.all(toDelete.map(s => deleteMutation.mutateAsync(s.id)));
      }

      // 2. Handle Creations and Updates
      await Promise.all(localStaff.map(async (staff) => {
        if (staff.id.startsWith("temp-")) {
          // Create new
          const { id, ...insertData } = staff;
          // We don't send the temp ID
          await createMutation.mutateAsync(insertData);
        } else {
          // Update existing
          // We could optimize by checking if it actually changed, but for now just send update
          const { id, ...updateData } = staff;
          await updateMutation.mutateAsync({ id, updates: updateData });
        }
      }));

      // 3. Refresh and Reset
      await queryClient.invalidateQueries({ queryKey: ["/api/staff"] });
      setHasChanges(false);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
      
    } catch (error) {
      console.error("Failed to save changes", error);
      toast({ title: "Error saving changes", variant: "destructive" });
    }
  };

  return (
    <Layout>
      <div className="w-full bg-card rounded-2xl border border-border p-10 shadow-sm mt-6">
        <header className="mb-10 text-center">
          <h2 className="text-2xl font-display font-bold text-foreground">Staff Info</h2>
          <p className="text-sm text-muted-foreground mt-2">Manage your staff details here. These records will be available in other registers.</p>
        </header>

        <div className="space-y-8">
          {/* Table Controls */}
          <div className="flex justify-end gap-2">
            <button onClick={handleAddRow} className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-xs font-bold shadow-sm hover:bg-primary/90 transition-colors">
              <PlusCircle className="w-4 h-4" /> ADD ROW
            </button>
            <button 
              onClick={handleRemoveRows} 
              disabled={selectedRows.size === 0}
              className="flex items-center gap-2 px-4 py-2 bg-muted text-foreground rounded-lg text-xs font-bold border border-border shadow-sm hover:bg-muted/80 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <MinusCircle className="w-4 h-4" /> REMOVE SELECTED ROW(S)
            </button>
          </div>

          {/* Staff Table */}
          <div className="bg-background rounded-xl border border-border shadow-inner overflow-x-auto">
            <table className="w-full border-collapse min-w-[800px]">
              <thead>
                <tr className="bg-muted/50 border-b border-border">
                  <th className="px-2 py-4 text-center border-r border-border w-10">
                    <input type="checkbox" className="rounded border-gray-300" disabled />
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border">Staff Name</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border">Role / Position</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border">Email</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-48">Start Date</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider">Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {isLoading && localStaff.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-muted-foreground">Loading staff records...</td>
                  </tr>
                ) : localStaff.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-muted-foreground">No staff records found. Click "ADD ROW" to start.</td>
                  </tr>
                ) : (
                  localStaff.map((staff) => (
                    <tr key={staff.id} className="hover:bg-muted/5">
                      <td className="text-center border-r border-border bg-muted/5">
                        <input 
                          type="checkbox" 
                          checked={selectedRows.has(staff.id)}
                          onChange={() => toggleRowSelection(staff.id)}
                          className="rounded border-gray-300 cursor-pointer"
                        />
                      </td>
                      <td className="border-r border-border h-full">
                        <input 
                          type="text"
                          value={staff.name} 
                          onChange={(e) => handleUpdate(staff.id, "name", e.target.value)}
                          className="w-full px-6 py-4 bg-transparent outline-none text-sm" 
                          placeholder="Enter Name" 
                        />
                      </td>
                      <td className="border-r border-border h-full">
                        <input 
                          type="text"
                          value={staff.role} 
                          onChange={(e) => handleUpdate(staff.id, "role", e.target.value)}
                          className="w-full px-6 py-4 bg-transparent outline-none text-sm" 
                          placeholder="Enter Role" 
                        />
                      </td>
                      <td className="border-r border-border h-full">
                        <input 
                          type="email"
                          value={staff.email || ""} 
                          onChange={(e) => handleUpdate(staff.id, "email", e.target.value)}
                          className="w-full px-6 py-4 bg-transparent outline-none text-sm" 
                          placeholder="Enter Email" 
                        />
                      </td>
                      <td className="border-r border-border h-full">
                        <input 
                          type="text"
                          value={staff.startDate || ""} 
                          onChange={(e) => handleUpdate(staff.id, "startDate", e.target.value)}
                          className="w-full px-6 py-4 bg-transparent outline-none text-sm" 
                          placeholder="DD/MM/YYYY" 
                        />
                      </td>
                      <td className="h-full">
                        <input 
                          type="text"
                          value={staff.notes || ""} 
                          onChange={(e) => handleUpdate(staff.id, "notes", e.target.value)}
                          className="w-full px-6 py-4 bg-transparent outline-none text-sm" 
                          placeholder="Optional notes..." 
                        />
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          <div className="flex flex-col items-center gap-4 pt-4">
            <button 
              onClick={handleSaveChanges}
              disabled={!hasChanges && !saved}
              className={cn(
                "bg-[#007AFF] text-white px-12 py-3 rounded-xl font-bold transition-all shadow-lg min-w-[200px] flex items-center justify-center gap-2",
                !hasChanges && !saved ? "opacity-50 cursor-not-allowed" : "hover:opacity-90"
              )}
            >
              Save Changes
            </button>
            
            {saved && (
              <div className="flex items-center gap-2 px-6 py-2 rounded-full bg-green-100 text-green-700 border border-green-200 animate-in fade-in slide-in-from-top-2 duration-300">
                <Check className="w-4 h-4" />
                <span className="text-xs font-bold uppercase tracking-wider">Changes Saved</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
