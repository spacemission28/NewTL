import { useState, useEffect } from "react";
import { Layout } from "@/components/Layout";
import { Camera, Upload, Check, ChevronUp, ChevronDown, X } from "lucide-react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";

export default function CPDSnap() {
  const [, setLocation] = useLocation();
  const [hasCamera, setHasCamera] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  
  // Form State
  const [provider, setProvider] = useState("");
  const [hours, setHours] = useState(1);
  const [type, setType] = useState("Clinical");

  useEffect(() => {
    // Check if camera is available (basic check)
    const canUseCamera =
      typeof (navigator as any)?.mediaDevices?.getUserMedia === "function";
    setHasCamera(canUseCamera);
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setSelectedFile(file);
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
  };

  const handleSave = () => {
    if (!selectedFile || !previewUrl) return;
    if (!provider.trim()) {
      alert("Please enter a provider name.");
      return;
    }

    try {
      // 1. Resize/Compress Image before saving
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        
        // Resize logic: Max dimension 1024px
        const MAX_DIM = 1024;
        if (width > MAX_DIM || height > MAX_DIM) {
          if (width > height) {
            height *= MAX_DIM / width;
            width = MAX_DIM;
          } else {
            width *= MAX_DIM / height;
            height = MAX_DIM;
          }
        }
        
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        
        ctx.drawImage(img, 0, 0, width, height);
        
        // Compress to JPEG with 0.7 quality
        const base64data = canvas.toDataURL('image/jpeg', 0.7);
        
        try {
            // Save to All Documents
            const existingSnapsStr = localStorage.getItem("dentalcheck.snaps");
            const existingSnaps = existingSnapsStr ? JSON.parse(existingSnapsStr) : [];
            const newSnap = {
              id: Date.now().toString(),
              url: base64data,
              date: new Date().toLocaleDateString(),
              name: `CPD Snap - ${provider} - ${new Date().toLocaleDateString()}`,
              category: "CPD Specific Snapshots"
            };
            localStorage.setItem("dentalcheck.snaps", JSON.stringify([...existingSnaps, newSnap]));

            // 2. Save Data to CPD Snap Log
            const existingLogsStr = localStorage.getItem("dentalcheck.cpd_snap_log");
            const existingLogs = existingLogsStr ? JSON.parse(existingLogsStr) : [];
            const newLog = {
              id: Date.now().toString(),
              date: new Date().toLocaleDateString(),
              provider,
              hours,
              type,
              imageId: newSnap.id
            };
            localStorage.setItem("dentalcheck.cpd_snap_log", JSON.stringify([...existingLogs, newLog]));

            alert("CPD Activity saved successfully!");
            setLocation("/dashboard");
        } catch (storageErr) {
            console.error("Storage full", storageErr);
            alert("Failed to save: Storage is full. Please delete old documents or snaps.");
        }
      };
      img.src = previewUrl; // Use the preview URL which is already a blob URL

    } catch (err) {
      console.error("Failed to save CPD snap", err);
      alert("Failed to save document.");
    }
  };

  const handleCancel = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    setProvider("");
    setHours(1);
    setType("Clinical");
  };

  if (previewUrl) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center min-h-[60vh] p-4 space-y-6 animate-in fade-in zoom-in-95 duration-300">
           <div className="w-full max-w-md bg-card border border-border rounded-2xl shadow-lg overflow-hidden">
             <div className="relative h-48 bg-muted/50 flex items-center justify-center overflow-hidden">
               <img src={previewUrl} alt="Preview" className="w-full h-full object-contain" />
               <button 
                 onClick={handleCancel}
                 className="absolute top-2 right-2 p-1 bg-black/50 text-white rounded-full hover:bg-black/70"
               >
                 <X className="w-5 h-5" />
               </button>
             </div>
             
             <div className="p-6 space-y-6">
               <div className="space-y-2">
                 <h2 className="text-xl font-bold">Log CPD Activity</h2>
                 <p className="text-xs text-muted-foreground">Confirm details for this record.</p>
               </div>

               {/* Provider */}
               <div className="space-y-1">
                 <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Provider / Topic</label>
                 <input
                   type="text"
                   value={provider}
                   onChange={(e) => setProvider(e.target.value)}
                   placeholder="e.g. ADA NSW - Infection Control"
                   className="w-full p-3 rounded-xl border border-border bg-background focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                 />
               </div>

               {/* Hours */}
               <div className="space-y-1">
                 <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Hours</label>
                 <div className="flex items-center gap-3">
                   <div className="flex-1 p-3 rounded-xl border border-border bg-background font-mono text-lg font-bold text-center">
                     {hours.toFixed(1)}
                   </div>
                   <div className="flex flex-col gap-1">
                     <button 
                       onClick={() => setHours(h => h + 0.5)}
                       className="p-1 rounded-md bg-primary/10 text-primary hover:bg-primary/20 active:scale-95"
                     >
                       <ChevronUp className="w-4 h-4" />
                     </button>
                     <button 
                       onClick={() => setHours(h => Math.max(0.5, h - 0.5))}
                       className="p-1 rounded-md bg-primary/10 text-primary hover:bg-primary/20 active:scale-95"
                     >
                       <ChevronDown className="w-4 h-4" />
                     </button>
                   </div>
                 </div>
               </div>

               {/* Type */}
               <div className="space-y-1">
                 <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Type</label>
                 <select
                   value={type}
                   onChange={(e) => setType(e.target.value)}
                   className="w-full p-3 rounded-xl border border-border bg-background focus:ring-2 focus:ring-primary/20 outline-none transition-all appearance-none"
                 >
                   <option value="Clinical CPD">Clinical CPD</option>
                   <option value="Scientific CPD">Scientific CPD</option>
                   <option value="Other CPD">Other CPD</option>

                 </select>
               </div>

               <button 
                 onClick={handleSave}
                 className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold h-12 rounded-xl shadow-lg shadow-primary/20 transition-all active:scale-95 flex items-center justify-center gap-2 mt-4"
               >
                 <Check className="w-5 h-5" />
                 <span>Save Record</span>
               </button>
             </div>
           </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="flex flex-col items-center justify-center min-h-[60vh] p-4 text-center space-y-8 animate-in fade-in duration-500">
        <div className="bg-primary/10 p-6 rounded-full ring-4 ring-primary/20">
          <Camera className="w-16 h-16 text-primary" />
        </div>
        
        <div className="space-y-2 max-w-md">
          <h1 className="text-2xl font-bold tracking-tight">CPD Log Snap</h1>
          <p className="text-muted-foreground">
            Take a photo of a CPD certificate or Article or QR/Bar code. We'll file it in All Documents and add it to your log.
          </p>
        </div>

        <div className="w-full max-w-sm space-y-4">
          <div className="relative group">
            <input
              type="file"
              accept="image/*,application/pdf"
              capture="environment"
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
              onChange={handleFileSelect}
            />
            <button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium h-14 rounded-xl shadow-lg shadow-primary/20 transition-all active:scale-95 flex items-center justify-center gap-3">
              <Camera className="w-5 h-5" />
              <span>{hasCamera ? "Take Photo" : "Upload Document"}</span>
            </button>
          </div>
          
          <div className="relative">
            <input
              type="file"
              accept="image/*,application/pdf"
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
              onChange={handleFileSelect}
            />
            <button className="w-full bg-secondary hover:bg-secondary/80 text-secondary-foreground font-medium h-12 rounded-xl transition-all active:scale-95 flex items-center justify-center gap-3">
              <Upload className="w-4 h-4" />
              <span>Upload from Gallery</span>
            </button>
          </div>

          <p className="text-xs text-muted-foreground pt-4">
            Supported formats: JPG, PNG, PDF
          </p>
        </div>
      </div>
    </Layout>
  );
}
