import { Layout } from "@/components/Layout";
import autoTable from "jspdf-autotable";
import { ComplianceScore } from "@/components/ComplianceScore";
import { TaskTable } from "@/components/TaskTable";
import { GapAnalysisWizard, SECTIONS as GapSections } from "@/components/GapAnalysisWizard";
import { useQuery } from "@tanstack/react-query";
import type { Staff } from "@shared/schema";
import {
  ShieldCheck,
  Users,
  Stethoscope,
  AlertTriangle,
  FileText,
  CheckCircle2,
  Cog,
  Search,
  Plus,
  Check,
  ExternalLink,
  ChevronLeft,
  ArrowLeft,
  MinusCircle,
  PlusCircle,
  Upload,
  Download,
  BookOpen,
  GraduationCap,
  Syringe,
  RefreshCw,
  AlertCircle,
  Camera,
  Activity,
  X,
  QrCode
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import { cn } from "@/lib/utils";
import { Link, useLocation, useRoute } from "wouter";

const tiles = [
  {
    id: "cpd_breakdown",
    title: "CPD Log / Breakdown",
    desc: "Track & Analyze CPD",
    icon: BookOpen,
  },
  {
    id: "ipc",
    title: "IPC Policy & Manual",
    desc: "Updated annually to ADA 5th ed. & AS 5369:2023",
    icon: FileText,
  },
  {
    id: "affirmation",
    title: "DBA Affirmation",
    desc: "Readiness report & evidence folder ready",
    icon: CheckCircle2,
  },
  {
    id: "steriliser",
    title: "Steriliser PQ Validation",
    desc: "AS 5369:2023 compliant • Coordinated & reviewed",
    icon: Cog,
  },
  {
    id: "training",
    title: "Staff IPC Training",
    desc: "Module to complete",
    icon: Users,
  },
  {
    id: "gap",
    title: "AS 5369:2023 Gap Analysis",
    desc: "Ongoing alignment • Progress tracked",
    icon: Search,
  },
];

const ipcAffirmations = [
  {
    topic: "Standard precautions",
    items: [
      "Hand hygiene performed before and after patient contact, after glove removal, after touching surfaces",
      "Alcohol-based hand rub available at every operatory entry and in sterilising area",
      "PPE (gloves, masks, protective eyewear, gowns/aprons) worn as per risk assessment",
      "Respiratory hygiene / cough etiquette promoted in waiting room"
    ]
  },
  {
    topic: "Sharps safety",
    items: [
      "Single-handed recapping or approved safety-engineered devices used",
      "Sharps containers located at point of use, never overfilled, correctly labelled"
    ]
  },
  {
    topic: "Waste management",
    items: [
      "Clinical waste segregated and disposed in yellow bags/containers",
      "Cytotoxic waste (if applicable) in purple containers",
      "Pharmaceutical waste returned via approved scheme"
    ]
  },
  {
    topic: "Spill management",
    items: [
      "Spill kit available and staff trained in use",
      "Procedure for blood / body substance spills documented and followed"
    ]
  },
  {
    topic: "Environmental cleaning",
    items: [
      "Dedicated cleaning products for clinical and non-clinical areas",
      "Surfaces cleaned between patients and at end of session",
      "Floors cleaned daily and when visibly soiled"
    ]
  },
  {
    topic: "Reprocessing of reusable instruments (AS 5369:2023)",
    items: [
      "Dirty-to-clean one-way flow maintained",
      "Instruments cleaned before sterilisation (ultrasonic + manual if needed)",
      "Steriliser performance qualification (PQ) performed annually by qualified technician",
      "Daily Bowie-Dick/air removal test (vacuum sterilisers)",
      "Chemical indicators used per load",
      "Biological indicators used as per validation protocol",
      "Batch labelling and record-keeping for every sterilised load"
    ]
  },
  {
    topic: "Immunisation & health monitoring",
    items: [
      "All clinical staff vaccinated against hepatitis B (or have documented immunity)",
      "Staff with blood-borne viruses follow CDNA guidelines",
      "Annual review of staff immunisation status"
    ]
  },
  {
    topic: "Training & competency",
    items: [
      "All staff receive initial and annual IPC training",
      "Training records maintained for every team member",
      "New staff orientation includes IPC module"
    ]
  },
  {
    topic: "Documentation & review",
    items: [
      "This manual reviewed and updated at least annually",
      "Version control and change log maintained",
      "Practice-specific risk assessment completed"
    ]
  },
  {
    topic: "Other universal must-haves",
    items: [
      "Legionella risk management plan for waterlines (if applicable)",
      "Radiation safety officer appointed (if X-ray equipment used)",
      "Emergency procedures documented (medical emergency, fire, evacuation)"
    ]
  }
];

import { useIsMobile } from "@/hooks/use-mobile";

export default function Dashboard() {
  const isMobile = useIsMobile();
  const { data: staffList } = useQuery<Staff[]>({ 
    queryKey: ["/api/staff"],
  });
  const [location, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [activeMenu, setActiveMenu] = useState<
    "main" | "ipc" | "questionnaire" | "dba_sub" | "dba_affirmation" | "dba_templates" | "ipc_affirmations" | "review_log" | "pdf_summary" | "steriliser_pq" | "steriliser_pq_log" | "staff_training" | "staff_training_register" | "cpd_logs" | "immunisation_records" | "gap_analysis" | "mobile_upload" | "search_results" | "cpd_breakdown"
  >(() => {
    // Check for query param (more reliable than localStorage for navigation)
    if (typeof window !== "undefined") {
        const search = window.location.search;
        const params = new URLSearchParams(search);
        if (params.get("mobile_scan") === "true") {
            return "mobile_upload";
        }
    }
    return "main";
  });
  const [activeTemplate, setActiveTemplate] = useState<"cpd" | "recency" | "pii">("recency");
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [notes, setNotes] = useState<Record<string, string>>({});
  const [showSaved, setShowSaved] = useState(false);
  const [unansweredFields, setUnansweredFields] = useState<string[]>([]);
  const [complianceScore, setComplianceScore] = useState(87);
  const [gapAnalysisScore, setGapAnalysisScore] = useState(() => {
    try {
      const saved = localStorage.getItem("dentalcheck.gap_score");
      return saved ? parseInt(saved, 10) : 0;
    } catch {
      return 0;
    }
  });
  const scrollRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const [finalAffirmationChecked, setFinalAffirmationChecked] = useState(false);
  const [errorOnCheckbox, setErrorOnCheckbox] = useState(false);
  const [summaryType, setSummaryType] = useState<"ipc" | "dba" | "steriliser" | "staff">("ipc");

  const [pdfDentistName, setPdfDentistName] = useState("");
  const [pdfPracticeName, setPdfPracticeName] = useState(() => {
    try {
      const saved = localStorage.getItem("dentalcheck.details");
      return saved ? JSON.parse(saved).practiceName || "" : "";
    } catch {
      return "";
    }
  });
  const [pdfDate, setPdfDate] = useState(() => new Date().toLocaleDateString("en-AU", { day: "2-digit", month: "short", year: "numeric" }));
  const [currentYear, setCurrentYear] = useState(() => new Date().getFullYear());
  const [nextYear, setNextYear] = useState(() => new Date().getFullYear() + 1);
  const floatingPanelRef = useRef<HTMLElement | null>(null);
  const floatingHeadingRef = useRef<HTMLElement | null>(null);
  const [floatingBackPos, setFloatingBackPos] = useState<{ left: number; top: number; size: "sm" | "lg"; variant: "muted" | "zinc" } | null>(null);

  // Steriliser PQ State
  const [steriliserPQRows, setSteriliserPQRows] = useState(() => {
    try {
      const saved = localStorage.getItem("dentalcheck.steriliser_pq");
      const parsed = saved ? JSON.parse(saved) : null;
      return Array.isArray(parsed) ? parsed : [{ date: "", technician: "", equipmentId: "", notes: "", certAttached: "" }];
    } catch {
      return [{ date: "", technician: "", equipmentId: "", notes: "", certAttached: "" }];
    }
  });

  // Row Selection State
  const [selectedReviewRows, setSelectedReviewRows] = useState<Set<number>>(new Set());
  const [selectedStaffTrainingRows, setSelectedStaffTrainingRows] = useState<Set<number>>(new Set());
  const [selectedCpdLogRows, setSelectedCpdLogRows] = useState<Set<number>>(new Set());
  const [selectedImmunisationRows, setSelectedImmunisationRows] = useState<Set<number>>(new Set());
  const [selectedSteriliserPQRows, setSelectedSteriliserPQRows] = useState<Set<number>>(new Set());
  const [selectedCpdRows, setSelectedCpdRows] = useState<Set<number>>(new Set());
  const [selectedRecencyRows, setSelectedRecencyRows] = useState<Set<number>>(new Set());

  // Generic Toggle Selection Handler
  const toggleRowSelection = (index: number, selectionSet: Set<number>, setSelection: (s: Set<number>) => void) => {
    const newSet = new Set(selectionSet);
    if (newSet.has(index)) {
      newSet.delete(index);
    } else {
      newSet.add(index);
    }
    setSelection(newSet);
  };

  // Generic Remove Selected Rows Handler
  const removeSelectedRows = (
    rows: any[], 
    setRows: (r: any[]) => void, 
    selectionSet: Set<number>, 
    setSelection: (s: Set<number>) => void
  ) => {
    if (selectionSet.size === 0) return;
    
    const newRows = rows.filter((_, index) => !selectionSet.has(index));
    // If all rows deleted, keep at least one empty row
    if (newRows.length === 0) {
      // Create a fresh empty row based on the structure of the first row (or default)
      // For simplicity, we can just reset to initial state logic or keep one empty
      // But to avoid complexity with type inference, we'll just check the type of row
      // For now, let's just clear. The "Add Row" function usually knows the structure.
      // Actually, we should probably keep the structure.
      // Let's rely on the fact that we filter. If length is 0, we might want to add one back.
      // We'll handle empty array gracefully or re-add a blank row if needed in specific handlers.
    }
    
    setRows(newRows);
    setSelection(new Set());
  };
  const [reviewRows, setReviewRows] = useState([
    { version: "1.0", date: `14 Jan ${currentYear}`, reviewedAgainst: "ADA Guidelines 5th Ed. (member version) + AS 5369:2023", changes: "Updated waterline management references; steriliser PQ frequency adjusted", reviewedBy: "[Name]" },
    { version: "", date: "", reviewedAgainst: "", changes: "", reviewedBy: "" },
    { version: "", date: "", reviewedAgainst: "", changes: "", reviewedBy: "" },
  ]);
  const [reviewAffirmation, setReviewAffirmation] = useState({
    name: "",
    date: ""
  });

  // Staff Training Register State
  const [staffTrainingRows, setStaffTrainingRows] = useState(() => {
    try {
      const saved = localStorage.getItem("dentalcheck.staff_training_register");
      const parsed = saved ? JSON.parse(saved) : null;
      return Array.isArray(parsed) ? parsed : [{ name: "", email: "", role: "", date: "", topic: "", provider: "", nextDue: "", evidenceUploaded: "" }];
    } catch {
      return [{ name: "", email: "", role: "", date: "", topic: "", provider: "", nextDue: "", evidenceUploaded: "" }];
    }
  });
  const [staffTrainingAffirmation, setStaffTrainingAffirmation] = useState({
    name: "",
    date: ""
  });

  // CPD Logs State
  const [cpdLogRows, setCpdLogRows] = useState(() => {
    try {
      const saved = localStorage.getItem("dentalcheck.cpd_logs");
      const parsed = saved ? JSON.parse(saved) : null;
      return Array.isArray(parsed) ? parsed : [{ practitioner: "", topic: "", date: "", provider: "", totalHours: "", ipcHours: "", type: "", certHeld: "No", notes: "" }];
    } catch {
      return [{ practitioner: "", topic: "", date: "", provider: "", totalHours: "", ipcHours: "", type: "", certHeld: "No", notes: "" }];
    }
  });
  const [cpdAffirmation, setCpdAffirmation] = useState({
    name: "",
    date: ""
  });

  // Immunisation Records State
  const [immunisationRows, setImmunisationRows] = useState(() => {
    try {
      const saved = localStorage.getItem("dentalcheck.immunisation_records");
      const parsed = saved ? JSON.parse(saved) : null;
      return Array.isArray(parsed) ? parsed : [{ staffMember: "", vaccine: "", courseCompletionDate: "", serologyResult: "", serologyDate: "", boosterNeeded: "", evidenceHeld: "", nextReviewDate: "", evidenceUploaded: "" }];
    } catch {
      return [{ staffMember: "", vaccine: "", courseCompletionDate: "", serologyResult: "", serologyDate: "", boosterNeeded: "", evidenceHeld: "", nextReviewDate: "", evidenceUploaded: "" }];
    }
  });
  const [immunisationAffirmation, setImmunisationAffirmation] = useState({
    name: "",
    date: ""
  });

  // DBA Affirmation State (Owner Name & Date)
  const [dbaAffirmation, setDbaAffirmation] = useState({
    name: "",
    date: ""
  });

  // Template States
  const [cpdRows, setCpdRows] = useState(() => {
    try {
      const saved = localStorage.getItem("dentalcheck.cpd_breakdown");
      const parsed = saved ? JSON.parse(saved) : null;
      return Array.isArray(parsed) ? parsed : [{ date: "", provider: "", hours: "", type: "", snapImage: "", notes: "" }];
    } catch {
      return [{ date: "", provider: "", hours: "", type: "", snapImage: "", notes: "" }];
    }
  });

  // Effect to ingest CPD Snaps
  useEffect(() => {
    try {
      const snapLogStr = localStorage.getItem("dentalcheck.cpd_snap_log");
      if (snapLogStr) {
        const snapLogs = JSON.parse(snapLogStr);
        if (Array.isArray(snapLogs) && snapLogs.length > 0) {
          // Get all snaps to resolve images
          const snapsStr = localStorage.getItem("dentalcheck.snaps");
          const snaps = snapsStr ? JSON.parse(snapsStr) : [];
          const safeSnaps = Array.isArray(snaps) ? snaps : [];
          
          const newRows = snapLogs.map((log: any) => {
            const snap = safeSnaps.find((s: any) => s.id === log.imageId);
            return {
              date: log.date || "",
              provider: log.provider || "", 
              hours: log.hours || "",
              type: log.type || "",
              snapImage: snap ? snap.url : "",
              notes: "" 
            };
          });

          setCpdRows((prev: any[]) => {
            const safePrev = Array.isArray(prev) ? prev : [];
            const cleanPrev = (safePrev.length === 1 && !safePrev[0].date && !safePrev[0].provider) ? [] : safePrev;
            const updated = [...cleanPrev, ...newRows];
            localStorage.setItem("dentalcheck.cpd_breakdown", JSON.stringify(updated));
            return updated;
          });

          localStorage.removeItem("dentalcheck.cpd_snap_log");
        }
      }
    } catch (e) {
      console.error("Failed to ingest CPD snaps", e);
    }
  }, []);

  const [recencyRows, setRecencyRows] = useState([{ period: "", location: "", hours: "", supervisor: "" }]);

  const [piiTracker, setPiiTracker] = useState({ insurer: "", policyNumber: "", expiryDate: "", coverageLimits: "" });
  
  const [uploadModalState, setUploadModalState] = useState<{ isOpen: boolean; section: 'steriliser' | 'staff' | 'immunisation' | 'cpd' | null; rowIndex: number } | null>(null);

  // Validation States for DBA Templates
  const [cpdErrors, setCpdErrors] = useState<Set<number>>(new Set());
  const [recencyErrors, setRecencyErrors] = useState<Set<number>>(new Set());
  const [piiErrors, setPiiErrors] = useState<string[]>([]);
  const [showTemplateError, setShowTemplateError] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  // PDF Signature State
  const [signatureDataUrl, setSignatureDataUrl] = useState<string | null>(null);
  const [signatureFileName, setSignatureFileName] = useState<string | null>(null);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const signatureInputRef = useRef<HTMLInputElement>(null);

  const handleSignatureUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setSignatureFileName(file.name);
    
    const reader = new FileReader();
    reader.onload = (event) => {
        if (event.target?.result) {
            setSignatureDataUrl(event.target.result as string);
        }
    };
    reader.readAsDataURL(file);
  };
  
  const handleSavePdf = async () => {
    try {
      setIsGeneratingPdf(true);

      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      // --- Helper Functions ---
      const addHeader = (title: string, subTitle: string) => {
        // Logo or Brand Name
        doc.setFontSize(22);
        doc.setTextColor(40, 40, 40);
        doc.text("Dental Compliance Aid", 14, 20);

        // Report Title
        doc.setFontSize(16);
        doc.setTextColor(0, 51, 102); // Dark Blue
        doc.text(title, 14, 30);

        // Sub Title / Practice Info
        doc.setFontSize(10);
        doc.setTextColor(100, 100, 100);
        const practiceInfo = `${pdfPracticeName || "My Dental Practice"} | Generated: ${pdfDate}`;
        doc.text(practiceInfo, 14, 36);
        
        // Line Separator
        doc.setDrawColor(200, 200, 200);
        doc.line(14, 40, 196, 40);
        
        return 45; // Return Y position for next content
      };

      const addSectionTitle = (title: string, y: number) => {
        doc.setFontSize(12);
        doc.setTextColor(0, 0, 0);
        doc.setFont("helvetica", "bold");
        doc.text(title, 14, y);
        doc.setFont("helvetica", "normal");
        return y + 6;
      };

      const addAffirmationBlock = (affirmation: { name: string; date: string }, y: number) => {
        doc.setFillColor(240, 248, 255); // AliceBlue
        doc.setDrawColor(100, 149, 237); // CornflowerBlue
        doc.roundedRect(14, y, 182, 25, 3, 3, 'FD');
        
        doc.setFontSize(10);
        doc.setTextColor(0, 51, 102);
        doc.setFont("helvetica", "bold");
        doc.text("AFFIRMATION STATEMENT", 19, y + 8);
        
        doc.setFontSize(9);
        doc.setTextColor(50, 50, 50);
        doc.setFont("helvetica", "italic");
        
        const text = `I, ${affirmation.name || "[Name]"}, affirm this review on ${affirmation.date || "[Date]"}.`;
        
        // Split text to fit
        const splitText = doc.splitTextToSize(text, 170);
        doc.text(splitText, 19, y + 14);
        
        return y + 35;
      };

      let finalName = "";
      let category = "";

      // --- IPC POLICY SUMMARY ---
      if (summaryType === "ipc") {
        let y = addHeader("IPC Policy & Manual Summary", "Annual Review & Compliance Check");
        finalName = `IPC-Policy-Summary-${new Date().toLocaleDateString().replace(/\//g, '-')}`;
        category = "IPC Policy & Manual";

        // 1. Review Log
        y = addSectionTitle("1. Manual Review & Change Log", y);
        
        autoTable(doc, {
          startY: y,
          head: [['Date', 'Section Reviewed', 'Change Description', 'Reviewer']],
          body: reviewRows.map(r => [r.date, r.reviewedAgainst, r.changes, r.reviewedBy]),
          theme: 'striped',
          headStyles: { fillColor: [41, 128, 185] },
          styles: { fontSize: 9 },
        });
        y = (doc as any).lastAutoTable.finalY + 10;

        // 2. Review Affirmation
        y = addAffirmationBlock(reviewAffirmation, y);

        // 3. IPC Affirmations Checklist
        y = addSectionTitle("2. IPC Compliance Checklist", y);
        
        // Flatten the grouped affirmations
        const checklistBody: any[] = [];
        ipcAffirmations.forEach(group => {
            // Group Header Row
            checklistBody.push([{ content: group.topic, colSpan: 2, styles: { fillColor: [220, 220, 220], fontStyle: 'bold' } }]);
            
            group.items.forEach(item => {
                const answer = (answers as any)[item]?.status || "Not Checked";
                checklistBody.push([item, answer]);
            });
        });

        autoTable(doc, {
            startY: y,
            head: [['Requirement / Standard', 'Status']],
            body: checklistBody,
            theme: 'grid',
            headStyles: { fillColor: [41, 128, 185] },
            columnStyles: {
                0: { cellWidth: 140 },
                1: { cellWidth: 40, halign: 'center' }
            },
            didParseCell: (data) => {
                if (data.section === 'body' && data.column.index === 1) {
                    if (data.cell.raw === 'Compliant') data.cell.styles.textColor = [0, 128, 0];
                    if (data.cell.raw === 'Non-Compliant') data.cell.styles.textColor = [255, 0, 0];
                }
            }
        });
      }

      // --- STERILISER PQ SUMMARY ---
      else if (summaryType === "steriliser") {
        let y = addHeader("Steriliser PQ Validation Summary", "Annual Performance Qualification Log");
        finalName = `Steriliser-PQ-Summary-${new Date().toLocaleDateString().replace(/\//g, '-')}`;
        category = "Steriliser PQ Validation";

        autoTable(doc, {
            startY: y,
            head: [['Date', 'Technician / Validator', 'Equipment ID', 'Notes / Result', 'Certificate']],
            body: steriliserPQRows.map(r => [r.date, r.techName, r.equipmentId, r.notes, r.certAttached]),
            theme: 'striped',
            headStyles: { fillColor: [46, 204, 113] }, // Green for Steriliser
            styles: { fontSize: 9 },
            columnStyles: {
                3: { cellWidth: 60 }
            }
        });
      }

      // --- STAFF TRAINING SUMMARY ---
      else if (summaryType === "staff") {
        let y = addHeader("Staff Training & Immunisation Summary", "IPC Training & Health Safety");
        finalName = `Staff-Training-Summary-${new Date().toLocaleDateString().replace(/\//g, '-')}`;
        category = "Staff IPC Training & CPD";

        // 1. Staff Training Register
        y = addSectionTitle("1. Staff Training Register", y);
        autoTable(doc, {
            startY: y,
            head: [['Staff Name', 'Role', 'Induction Date', 'Training Module', 'Competency Assessed By']],
            body: staffTrainingRows.map(r => [r.name, r.role, r.inductionDate, r.module, r.assessedBy]),
            theme: 'striped',
            headStyles: { fillColor: [155, 89, 182] }, // Purple
            styles: { fontSize: 9 }
        });
        y = (doc as any).lastAutoTable.finalY + 10;
        
        y = addAffirmationBlock(staffTrainingAffirmation, y);

        // 2. CPD Logs
        y = addSectionTitle("2. CPD Logs (Infection Control)", y);
        autoTable(doc, {
            startY: y,
            head: [['Staff Name', 'Activity / Course', 'Date', 'Provider', 'Hours']],
            body: cpdLogRows.map(r => [r.staffName || r.practitioner, r.activity || r.topic, r.date, r.provider, r.hours || r.totalHours]),
            theme: 'striped',
            headStyles: { fillColor: [155, 89, 182] },
            styles: { fontSize: 9 }
        });
        y = (doc as any).lastAutoTable.finalY + 10;
        
        y = addAffirmationBlock(cpdAffirmation, y);

        // 3. Immunisation Records
        doc.addPage();
        y = 20; // Reset Y for new page
        y = addSectionTitle("3. Immunisation Records", y);
        
        autoTable(doc, {
            startY: y,
            head: [['Staff Member', 'Vaccine', 'Completed', 'Serology Result', 'Review Date']],
            body: immunisationRows.map(r => [r.staffMember, r.vaccine, r.courseCompletionDate, r.serologyResult, r.nextReviewDate]),
            theme: 'striped',
            headStyles: { fillColor: [155, 89, 182] },
            styles: { fontSize: 9 }
        });
        y = (doc as any).lastAutoTable.finalY + 10;

        y = addAffirmationBlock(immunisationAffirmation, y);
      }

      // --- DBA AFFIRMATIONS SUMMARY ---
      else {
        let y = addHeader("DBA Affirmations Summary", "Registration Renewal & Compliance");
        finalName = `DBA-Affirmation-Summary-${new Date().toLocaleDateString().replace(/\//g, '-')}`;
        category = "DBA Affirmation Prep";

        // 1. Renewal Affirmations
        y = addSectionTitle("1. Registration Renewal Affirmations", y);
        
        // We need to reconstruct the DBA affirmations list since it's derived in render
        const dbaSections = [
             { id: "crim", title: "Criminal History", text: "I have not been charged with or convicted of..." },
             { id: "eng", title: "English Language", text: "I continue to meet the English language skills..." },
             { id: "pii", title: "Professional Indemnity Insurance", text: "I hold appropriate professional indemnity insurance..." },
             { id: "cpd", title: "Continuing Professional Development", text: "I have met the CPD requirements..." },
             { id: "rec", title: "Recency of Practice", text: "I have met the recency of practice requirements..." }
        ];

        const affirmationBody = dbaSections.map(sec => {
            const ans = (answers as any)[sec.id]?.status === "True" ? "AFFIRMED" : "NOT AFFIRMED";
            return [sec.title, sec.text, ans];
        });

        autoTable(doc, {
            startY: y,
            head: [['Requirement', 'Statement', 'Status']],
            body: affirmationBody,
            theme: 'grid',
            headStyles: { fillColor: [243, 156, 18] }, // Orange
            styles: { fontSize: 9 },
            columnStyles: {
                0: { cellWidth: 40, fontStyle: 'bold' },
                1: { cellWidth: 110 },
                2: { cellWidth: 30, halign: 'center', fontStyle: 'bold' }
            },
            didParseCell: (data) => {
                 if (data.section === 'body' && data.column.index === 2) {
                     if (data.cell.raw === 'AFFIRMED') data.cell.styles.textColor = [0, 128, 0];
                     else data.cell.styles.textColor = [255, 0, 0];
                 }
            }
        });
        y = (doc as any).lastAutoTable.finalY + 10;

        // 2. Recency Log
        y = addSectionTitle("2. Recency of Practice Log", y);
        autoTable(doc, {
            startY: y,
            head: [['Year', 'Clinical Hours', 'Role / Scope', 'Verified By']],
            body: recencyRows.map(r => [r.period, r.hours, r.location, r.supervisor]),
            theme: 'striped',
            headStyles: { fillColor: [243, 156, 18] },
            styles: { fontSize: 9 }
        });
        
        // 3. PII Tracker
        y = (doc as any).lastAutoTable.finalY + 10;
        y = addSectionTitle("3. Professional Indemnity Insurance", y);
        autoTable(doc, {
            startY: y,
            head: [['Insurer', 'Policy Number', 'Expiry Date', 'Coverage Amount']],
            body: [[piiTracker.insurer, piiTracker.policyNumber, piiTracker.expiryDate, piiTracker.coverageLimits]],
            theme: 'plain',
            styles: { fontSize: 10 },
            columnStyles: { 0: { fontStyle: 'bold' } }
        });
      }

      // --- SAVE & STORE ---
      const pdfDataUrl = doc.output('datauristring');
      
      // Save to LocalStorage
      const newReport = {
          id: Date.now().toString(),
          name: finalName,
          date: new Date().toLocaleDateString(),
          category: category,
          type: "generated_pdf",
          url: pdfDataUrl
      };

      try {
          const snapsStr = localStorage.getItem("dentalcheck.snaps");
          let snaps = snapsStr ? JSON.parse(snapsStr) : [];
          snaps = snaps.filter((s: any) => s.name !== finalName);
          localStorage.setItem("dentalcheck.snaps", JSON.stringify([...snaps, newReport]));
      } catch (e) {
          console.error("Storage quota exceeded", e);
      }

      doc.save(`${finalName}.pdf`);

    } catch (e) {
      console.error("Failed to generate PDF", e);
      alert(`Failed to generate PDF: ${e instanceof Error ? e.message : "Unknown error"}`);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const handleUploadComplete = (name: string, type: 'desktop' | 'snap') => {
    if (!uploadModalState) return;
    const { section, rowIndex } = uploadModalState;
    const uploadText = type === 'snap' ? `Uploaded (Snap: ${name})` : `Uploaded (${name})`;

    if (section === 'steriliser') {
      const nr = [...steriliserPQRows];
      nr[rowIndex].certAttached = uploadText;
      setSteriliserPQRows(nr);
    } else if (section === 'staff') {
      const nr = [...staffTrainingRows];
      nr[rowIndex].evidenceUploaded = uploadText;
      setStaffTrainingRows(nr);
    } else if (section === 'immunisation') {
      const nr = [...immunisationRows];
      nr[rowIndex].evidenceUploaded = uploadText;
      setImmunisationRows(nr);
    } else if (section === 'cpd') {
      const nr = [...cpdRows];
      nr[rowIndex].certAttached = uploadText;
      setCpdRows(nr);
    }

    setUploadModalState(null);
  };
  
  const clinicProfileQuestions = [
    { id: "steriliserCount", label: "Number of sterilisers" },
    { id: "steriliserBrand", label: "What Brand of Steriliser" },
    { id: "steriliserType", label: "What Type of Steriliser" },
    { id: "sinkCount", label: "Number of sinks in Steri Room" },
    { id: "oneWayFlow", label: "One-way flow physical separation (Dirty to Clean)" },
    { id: "handpiecePolicy", label: "Handpiece Reprocessing Policy" },
    { id: "staffDentists", label: "Number of Dentists" },
    { id: "staffHygienists", label: "Number of Hygienists / OHTs" },
    { id: "staffAssistants", label: "Number of Dental Assistants" },
    { id: "staffAdmin", label: "Number of Admin / Reception Staff" },
    { id: "hepBImmunity", label: "All clinical staff have evidence of Hep B immunity" },
  ];

  const requiredFields = clinicProfileQuestions.map(q => q.id);

  const dbaFields = ["pii", "recency", "cpd", "ipc_affirm", "fitness"];

  // Renewal Tasks Calculation
  const renewalTasks = useMemo(() => {
    // 1. IPC Policy & Manual
    const totalIPC = ipcAffirmations.reduce((acc, group) => acc + group.items.length, 0);
    const confirmedIPC = Object.keys(answers).filter(k => k.startsWith("ipc_aff_") && answers[k] === "AFFIRMED").length;
    const progressIPC = totalIPC > 0 ? Math.round((confirmedIPC / totalIPC) * 100) : 0;

    // 2. Specific to your Clinic (Questionnaire)
    const totalClinic = requiredFields.length;
    const confirmedClinic = requiredFields.filter(f => answers[f]).length;
    const progressClinic = totalClinic > 0 ? Math.round((confirmedClinic / totalClinic) * 100) : 0;

    // 3. Required Affirmations (DBA Affirmations)
    const totalDBA = dbaFields.length;
    const confirmedDBA = dbaFields.filter(f => answers[f]).length;
    const progressDBA = totalDBA > 0 ? Math.round((confirmedDBA / totalDBA) * 100) : 0;

    // Helper to count non-empty rows
    const countRows = (rows: any[], keysToCheck: string[]) => {
      if (!Array.isArray(rows)) return 0;
      return rows.filter(r => r && keysToCheck.every(k => r[k] && String(r[k]).trim() !== "")).length;
    };

    const reviewLogCount = countRows(reviewRows, ["version", "date", "reviewedAgainst", "changes", "reviewedBy"]);
    // For DBA Templates, we check Recency (PII is separate)
    const recencyTemplateCount = countRows(recencyRows, ["period", "location", "hours"]);
    const dbaTemplatesCount = recencyTemplateCount;
    
    // PII Certificate Logic
    const isPiiComplete = piiTracker.insurer && piiTracker.policyNumber && piiTracker.expiryDate && piiTracker.coverageLimits;

    // Steriliser PQ Logic
    const steriliserCount = countRows(steriliserPQRows, ["date", "technician", "equipmentId", "notes"]);
    const isSteriliserComplete = steriliserCount > 0; // Considered complete if at least one valid record exists

    const staffTrainingCount = countRows(staffTrainingRows, ["name", "role", "date", "topic"]);
    const immunisationCount = countRows(immunisationRows, ["staffMember", "vaccine", "courseCompletionDate"]);
    
    // CPD Breakdown Logic (New)
    const cpdBreakdownCount = countRows(cpdRows, ["date", "provider", "hours", "type"]);

    return [
      { id: "h_cpd", title: "CPD Log / Breakdown", type: "heading" as const },
      { id: "cpd_log", title: "CPD Log", category: "CPD Compliance", status: `${cpdBreakdownCount} entries` },

      // 1. IPC Policy & Manual
      { id: "h_ipc", title: "IPC Policy & Manual", type: "heading" as const },
      { id: "clinic_specific", title: "Specific to your Clinic", category: "Practice Details", progress: progressClinic },
      { id: "ipc_affirm_task", title: "Required Affirmations", category: "Documentation", progress: progressIPC },
      { id: "review_log", title: "Review / Change Log Summary", category: "Documentation", status: `${reviewLogCount} entries` },

      // 2. DBA Affirmation
      { id: "h_dba", title: "DBA Affirmation", type: "heading" as const },
      { id: "dba_affirm_task", title: "Registration Renewal Affirmation", category: "DBA Compliance", progress: progressDBA },
      { id: "pii_cert", title: "PII Certificate Tracker", category: "Insurance", status: isPiiComplete ? "COMPLETE" : "INCOMPLETE" },
      { id: "dba_templates", title: "Practise Recency", category: "AHPRA", status: `${dbaTemplatesCount} entries` },

      // 3. Steriliser PQ Validation
      { id: "h_steriliser", title: "Steriliser PQ Validation", type: "heading" as const },
      { id: "steriliser", title: "Steriliser PQ Validation", category: "Equipment", status: isSteriliserComplete ? "COMPLETE" : "INCOMPLETE" },

      // 4. Staff IPC Training & CPD
      { id: "h_training", title: "Staff IPC Training & CPD", type: "heading" as const },
      { id: "staff_training", title: "Staff Training Register", category: "Staff", status: `${staffTrainingCount} entries` },
      { id: "immunisation", title: "Immunisation Records", category: "Staff", status: `${immunisationCount} entries` },
      
      // 5. Gap Analysis
      { id: "h_gap", title: "AS 5369:2023 Gap Analysis", type: "heading" as const },
      { id: "gap_analysis", title: "Self-Assessment", category: "Gap Analysis", progress: gapAnalysisScore },
    ];
  }, [answers, gapAnalysisScore, reviewRows, cpdRows, recencyRows, piiTracker, steriliserPQRows, staffTrainingRows, cpdLogRows, immunisationRows]);

  useEffect(() => {
    const handleMobileScanEvent = () => setActiveMenu("mobile_upload");
    window.addEventListener("dashboard-mobile-scan", handleMobileScanEvent);
    
    // Clean up query param if present
    if (typeof window !== "undefined") {
        const search = window.location.search;
        const params = new URLSearchParams(search);
        if (params.get("mobile_scan") === "true") {
            // Remove the query param without reloading
            const newUrl = window.location.pathname;
            window.history.replaceState({}, document.title, newUrl);
        }
    }
    
    return () => {
      window.removeEventListener("dashboard-mobile-scan", handleMobileScanEvent);
    };
  }, []);

  useEffect(() => {
    // Reset save state and checkbox when navigating away or switching tabs within templates
    setFinalAffirmationChecked(false);
    setShowSaved(false);
    setUnansweredFields([]);
    setErrorOnCheckbox(false);
    setShowTemplateError(false);
    setCpdErrors(new Set());
    setRecencyErrors(new Set());
    setPiiErrors([]);
    
    window.scrollTo(0, 0);

    const main = document.querySelector(".app-main") as HTMLElement | null;
    if (main) {
      main.scrollTo({ top: 0, left: 0, behavior: "auto" });
    }
  }, [activeMenu, activeTemplate]);

  useEffect(() => {
    // No-op for staff
  }, [location]);

  useEffect(() => {
    try {
      const savedDetails = localStorage.getItem("dentalcheck.details");
      if (!savedDetails) return;
      const parsed = JSON.parse(savedDetails);
      if (!parsed || typeof parsed !== "object") return;
      if (typeof parsed.principalName === "string") setPdfDentistName(parsed.principalName);
      if (typeof parsed.practiceName === "string") setPdfPracticeName(parsed.practiceName);
    } catch {
      return;
    }
  }, []);

  useLayoutEffect(() => {
    if (activeMenu === "pdf_summary") {
      document.body.classList.add("printing-summary");
      return;
    }
    document.body.classList.remove("printing-summary");
  }, [activeMenu]);

  const floatingBackConfig = useMemo(() => {
    if (activeMenu === "ipc") return { onClick: () => setActiveMenu("main"), align: "panel_top" as const, variant: "muted" as const, size: "sm" as const };
    if (activeMenu === "dba_sub") return { onClick: () => setActiveMenu("main"), align: "panel_top" as const, variant: "muted" as const, size: "sm" as const };
    if (activeMenu === "questionnaire") return { onClick: () => setActiveMenu("ipc"), align: "heading_center" as const, variant: "muted" as const, size: "sm" as const };
    if (activeMenu === "ipc_affirmations") return { onClick: () => setActiveMenu("ipc"), align: "heading_center" as const, variant: "muted" as const, size: "sm" as const };
    if (activeMenu === "review_log") return { onClick: () => setActiveMenu("ipc"), align: "heading_center" as const, variant: "muted" as const, size: "sm" as const };
    if (activeMenu === "dba_templates") return { onClick: () => setActiveMenu("dba_sub"), align: "heading_center" as const, variant: "muted" as const, size: "sm" as const };
    if (activeMenu === "dba_affirmation") return { onClick: () => setActiveMenu("dba_sub"), align: "heading_center" as const, variant: "muted" as const, size: "sm" as const };
    if (activeMenu === "steriliser_pq") return { onClick: () => setActiveMenu("main"), align: "panel_top" as const, variant: "muted" as const, size: "sm" as const };
    if (activeMenu === "steriliser_pq_log") return { onClick: () => setActiveMenu("steriliser_pq"), align: "heading_center" as const, variant: "muted" as const, size: "sm" as const };
    if (activeMenu === "staff_training") return { onClick: () => setActiveMenu("main"), align: "panel_top" as const, variant: "muted" as const, size: "sm" as const };
    if (activeMenu === "staff_training_register") return { onClick: () => setActiveMenu("staff_training"), align: "heading_center" as const, variant: "muted" as const, size: "sm" as const };
    if (activeMenu === "cpd_logs") return { onClick: () => setActiveMenu("staff_training"), align: "heading_center" as const, variant: "muted" as const, size: "sm" as const };
    if (activeMenu === "immunisation_records") return { onClick: () => setActiveMenu("staff_training"), align: "heading_center" as const, variant: "muted" as const, size: "sm" as const };
    if (activeMenu === "cpd_breakdown") return { onClick: () => setActiveMenu("main"), align: "heading_center" as const, variant: "muted" as const, size: "sm" as const };
    if (activeMenu === "pdf_summary") return { onClick: () => setActiveMenu(summaryType === "ipc" ? "ipc" : summaryType === "dba" ? "dba_sub" : summaryType === "staff" ? "staff_training" : "steriliser_pq"), align: "heading_center" as const, variant: "zinc" as const, size: "lg" as const };
    return null;
  }, [activeMenu, summaryType]);

  // Disable floating back button on mobile, we'll render a static one
  useLayoutEffect(() => {
    if (isMobile || !floatingBackConfig) {
      setFloatingBackPos(null);
      return;
    }

    const selectorByMenu: Partial<Record<typeof activeMenu, string>> = {
      ipc: "[data-floating-panel='ipc']",
      dba_sub: "[data-floating-panel='dba_sub']",
      questionnaire: "[data-floating-panel='questionnaire']",
      ipc_affirmations: "[data-floating-panel='ipc_affirmations']",
      review_log: "[data-floating-panel='review_log']",
      dba_templates: "[data-floating-panel='dba_templates']",
      dba_affirmation: "[data-floating-panel='dba_affirmation']",
      steriliser_pq: "[data-floating-panel='steriliser_pq']",
      steriliser_pq_log: "[data-floating-panel='steriliser_pq_log']",
      staff_training: "[data-floating-panel='staff_training']",
      staff_training_register: "[data-floating-panel='staff_training_register']",
      cpd_logs: "[data-floating-panel='cpd_logs']",
      immunisation_records: "[data-floating-panel='immunisation_records']",
      pdf_summary: "[data-floating-panel='pdf_summary']",
      gap_analysis: "[data-floating-panel='gap_analysis']",
      cpd_breakdown: "[data-floating-panel='cpd_breakdown']",
    };

    let raf: number | null = null;
    let stop = false;
    const disposers: Array<() => void> = [];

    const getPanel = () => {
      const selector = selectorByMenu[activeMenu];
      const queried = selector ? (document.querySelector(selector) as HTMLElement | null) : null;
      if (queried) return queried;

      const refEl = floatingPanelRef.current;
      if (refEl && refEl.isConnected && refEl.dataset.floatingPanel === activeMenu) return refEl;
      return null;
    };

    const getHeading = () =>
      (floatingHeadingRef.current && floatingHeadingRef.current.isConnected)
        ? floatingHeadingRef.current
        : (document.querySelector("[data-floating-heading='1']") as HTMLElement | null);

    const buttonPx = floatingBackConfig.size === "lg" ? 40 : 36;

    const measure = (panel: HTMLElement) => {
      const panelRect = panel.getBoundingClientRect();
      let top = panelRect.top;

      const style = window.getComputedStyle(panel);
      const computedPaddingLeft = parseFloat(style.paddingLeft || "0") || 0;
      const firstTile = panel.querySelector("[data-floating-first-tile='1']") as HTMLElement | null;

      const isSubMenu = activeMenu === "ipc" || activeMenu === "dba_sub" || activeMenu === "staff_training" || activeMenu === "steriliser_pq";
      const tileGapPx = isSubMenu ? 18 : 6;
      const nudgeLeftPx = 0;

      const appMain = document.querySelector(".app-main") as HTMLElement | null;
      const appMainLeft = appMain?.getBoundingClientRect().left;
      const leftEdge = isSubMenu && typeof appMainLeft === "number" ? appMainLeft : panelRect.left;
      const minLeft = leftEdge + 6;

      let rawLeft: number;
      let maxLeftBeforeContent: number;
      if (firstTile) {
        const tileRect = firstTile.getBoundingClientRect();
        const gutterWidth = Math.max(0, tileRect.left - leftEdge);
        rawLeft = leftEdge + gutterWidth / 2 - buttonPx / 2 - nudgeLeftPx;
        maxLeftBeforeContent = tileRect.left - buttonPx - tileGapPx;
      } else {
        rawLeft = leftEdge + computedPaddingLeft / 2 - buttonPx / 2 - nudgeLeftPx;
        maxLeftBeforeContent = leftEdge + Math.max(0, computedPaddingLeft - buttonPx - 6);
      }

      const maxLeft = Math.max(maxLeftBeforeContent, minLeft);
      const left = Math.round(Math.min(Math.max(rawLeft, minLeft), maxLeft));

      if (floatingBackConfig.align === "heading_center") {
        const heading = getHeading();
        const appHeader = document.querySelector("header") as HTMLElement | null;
        const headerRect = appHeader?.getBoundingClientRect();
        const minTop = Math.round((headerRect?.bottom ?? 0) + 16);
        if (heading) {
          const headingRect = heading.getBoundingClientRect();
          const desiredTop = headingRect.top + (headingRect.height - buttonPx) / 2;
          top = Math.max(desiredTop, minTop);
        } else {
          top = Math.max(top, minTop);
        }
      } else {
        const appHeader = document.querySelector("header") as HTMLElement | null;
        const headerRect = appHeader?.getBoundingClientRect();
        const minTop = Math.round((headerRect?.bottom ?? 0) + 16);
        top = Math.max(top, minTop);
      }

      setFloatingBackPos({
        left,
        top: Math.round(top),
        size: floatingBackConfig.size,
        variant: floatingBackConfig.variant,
      });
    };

    const attachListeners = (panel: HTMLElement) => {
      const onScroll = () => {
        if (stop) return;
        if (raf) cancelAnimationFrame(raf);
        raf = requestAnimationFrame(() => measure(panel));
      };

      const onResize = () => {
        if (stop) return;
        if (raf) cancelAnimationFrame(raf);
        raf = requestAnimationFrame(() => measure(panel));
      };

      window.addEventListener("scroll", onScroll, { passive: true });
      window.addEventListener("resize", onResize);
      disposers.push(() => window.removeEventListener("scroll", onScroll));
      disposers.push(() => window.removeEventListener("resize", onResize));

      const main = document.querySelector(".app-main") as HTMLElement | null;
      if (main) {
        main.addEventListener("scroll", onScroll, { passive: true });
        disposers.push(() => main.removeEventListener("scroll", onScroll));
      }

      const ro = new ResizeObserver(onResize);
      ro.observe(panel);
      const heading = getHeading();
      if (heading) ro.observe(heading);
      disposers.push(() => ro.disconnect());

      // Polling to handle initial layout animation (e.g. framer motion entry)
      // This fixes the issue where the back button is initially misplaced because
      // the element is still animating into its final position.
      let animationFrameCount = 0;
      const animateMeasure = () => {
        if (stop) return;
        measure(panel);
        if (animationFrameCount < 60) { // Poll for ~1 second (60 frames)
          animationFrameCount++;
          raf = requestAnimationFrame(animateMeasure);
        }
      };
      animateMeasure();
    };

    const tryInit = (attempt: number) => {
      if (stop) return;
      const panel = getPanel();
      if (!panel) {
        setFloatingBackPos(null);
        if (attempt < 90) {
          raf = requestAnimationFrame(() => tryInit(attempt + 1));
        }
        return;
      }

      attachListeners(panel);
      raf = requestAnimationFrame(() => measure(panel));
    };

    tryInit(0);

    return () => {
      stop = true;
      if (raf) cancelAnimationFrame(raf);
      disposers.forEach((d) => d());
    };
  }, [floatingBackConfig]);

  useEffect(() => {
    const handleReset = () => {
      setActiveMenu("main");
      setTimeout(() => {
        window.scrollTo(0, 0);
        document.documentElement.scrollTop = 0;
        document.body.scrollTop = 0;
      }, 0);
    };
    window.addEventListener('dashboard-reset', handleReset);
    return () => window.removeEventListener('dashboard-reset', handleReset);
  }, []);

  useEffect(() => {
    const handlePopState = () => {
      if (window.location.pathname === "/dashboard") {
        setActiveMenu("main");
      }
    };

    const handleDashboardReset = () => {
      setActiveMenu("main");
    };

    const handleDashboardNavigation = (e: CustomEvent<{ target: string }>) => {
      // Cast e.detail.target to the allowed types if possible, or just use string
      // We need to ensure the target is one of the valid activeMenu values
      const target = e.detail.target;
      if (target) {
        setActiveMenu(target as any);
      }
    };

    const handleDashboardSearch = (e: CustomEvent<{ query: string }>) => {
      const query = e.detail.query;
      setSearchQuery(query);
      setActiveMenu("search_results");
    };

    window.addEventListener('popstate', handlePopState);
    window.addEventListener('dashboard-reset', handleDashboardReset);
    window.addEventListener('dashboard-navigation', handleDashboardNavigation as EventListener);
    window.addEventListener('dashboard-search', handleDashboardSearch as EventListener);
    
    // Check on mount
    handlePopState();

    return () => {
      window.removeEventListener('popstate', handlePopState);
      window.removeEventListener('dashboard-reset', handleDashboardReset);
      window.removeEventListener('dashboard-navigation', handleDashboardNavigation as EventListener);
      window.removeEventListener('dashboard-search', handleDashboardSearch as EventListener);
    };
  }, []);

  const handleDashboardClick = () => {
    setActiveMenu("main");
    window.scrollTo(0, 0);
  };

  const handleSelect = (id: string, value: string) => {
    // If the value is "AFFIRM" (meaning the user is trying to revert from "AFFIRMED"),
    // check if the manual has been locked/saved.
    if (value === "AFFIRM") {
      // If we are in IPC affirmations and the user has checked the final approval box,
      // prevent them from reverting.
      const isIPCApproved = localStorage.getItem("ipc_manual_approved") === "true";
      
      if (id.startsWith("ipc_aff_") && (finalAffirmationChecked || isIPCApproved)) {
        alert("You cannot revert an affirmation after approving the manual. Uncheck the approval box first if you need to make changes.");
        return;
      }
    }
    
    // Check if we are modifying a DBA field that is locked
    if (dbaFields.includes(id)) {
      // Remove lock check to allow editing
      // const isDBAApproved = localStorage.getItem("dba_manual_approved") === "true";
      // if (isDBAApproved) {
      //    alert("You cannot revert an affirmation after approving the summary. Please contact support or reset if needed.");
      //    return;
      // }
    }

    setAnswers((prev) => {
      const currentValue = prev[id];

      // Toggle logic for Questionnaire (Clinic Profile & Procedures)
      // Any field in requiredFields except sterilisers (which are handled dynamically now)
      // Actually, all selection buttons in the questionnaire should be toggleable.
      if (requiredFields.includes(id) || id.startsWith("steriliserType_")) {
        if (value === currentValue) {
           return { ...prev, [id]: "" };
        }
      }

      // Toggle logic for DBA: If incoming is "AFFIRM" or "NOT_READY" and matches current, toggle off (clear it)
      if (dbaFields.includes(id)) {
        // If clicking the same button again, clear the selection
        if (value === currentValue) {
           return { ...prev, [id]: "" };
        }
      }
      
      // Toggle logic for IPC: If current value is "AFFIRMED" and new value is "AFFIRMED", set to "AFFIRM" (toggle off)
      if (id.startsWith("ipc_aff_")) {
        if (value === "AFFIRMED" && currentValue === "AFFIRMED") {
           return { ...prev, [id]: "AFFIRM" };
        }
      }
      
      return { ...prev, [id]: value };
    });

    if (unansweredFields.includes(id)) {
      setUnansweredFields(prev => prev.filter(f => f !== id));
    }
    
    // If we are un-affirming, and the final checkbox is checked, we should probably uncheck it
    // because the validation is no longer met.
    const isReverting = value === "AFFIRM" || value === "" || (answers[id] === "AFFIRMED" && value === "AFFIRMED") || (answers[id] === "NOT_READY" && value === "NOT_READY");
    
    if (isReverting) {
       if (finalAffirmationChecked) {
          setFinalAffirmationChecked(false);
          // Also clear the persistent approval flag if they modify it
          localStorage.removeItem("ipc_manual_approved");
          localStorage.removeItem("dba_manual_approved");
       }
       // Also check persistent storage
       if (localStorage.getItem("ipc_manual_approved") === "true" && id.startsWith("ipc_aff_")) {
          localStorage.removeItem("ipc_manual_approved");
          setFinalAffirmationChecked(false);
       }
       if (localStorage.getItem("dba_manual_approved") === "true" && dbaFields.includes(id)) {
          // Remove lock on revert
          localStorage.removeItem("dba_manual_approved");
          setFinalAffirmationChecked(false);
       }
    }
  };

  const handleNoteChange = (id: string, value: string) => {
    setNotes(prev => ({ ...prev, [id]: value }));
  };

  const validateIPC = () => {
    const totalItems = ipcAffirmations.reduce((acc, group) => acc + group.items.length, 0);
    const confirmedKeys = Object.keys(answers).filter(k => k.startsWith("ipc_aff_") && answers[k] === "AFFIRMED");
    
    if (confirmedKeys.length < totalItems) {
      alert("Please affirm every dot point before approving the manual");
      const missingFields: string[] = [];
      let firstMissing: string | null = null;

      for (let g = 0; g < ipcAffirmations.length; g++) {
        for (let i = 0; i < ipcAffirmations[g].items.length; i++) {
          const fieldId = `ipc_aff_${g}_${i}`;
          if (answers[fieldId] !== "AFFIRMED") {
            missingFields.push(fieldId);
            if (!firstMissing) firstMissing = fieldId;
          }
        }
      }
      setUnansweredFields(missingFields);
      if (firstMissing) {
        scrollRefs.current[firstMissing]?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      return false;
    }
    return true;
  };

  const validateDBA = () => {
    const missing = dbaFields.filter(f => !answers[f]);
    if (missing.length > 0) {
      setUnansweredFields(missing);
      alert("Please complete all the affirmations (select 'Affirm' for each section)");
      const firstMissing = missing[0];
      scrollRefs.current[firstMissing]?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return false;
    }
    return true;
  };

  const handleIPCCheckboxChange = (checked: boolean) => {
    if (checked) {
      const isValid = validateIPC();
      if (!isValid) {
        setErrorOnCheckbox(true);
        setFinalAffirmationChecked(false);
        return;
      }
      setErrorOnCheckbox(false);
      setFinalAffirmationChecked(true);
    } else {
      setFinalAffirmationChecked(false);
      setErrorOnCheckbox(false);
    }
  };

  const handleDBACheckboxChange = (checked: boolean) => {
    if (checked) {
      const isValid = validateDBA();
      if (!isValid) {
        setErrorOnCheckbox(true);
        setFinalAffirmationChecked(false);
        return;
      }
      setErrorOnCheckbox(false);
      setFinalAffirmationChecked(true);
    } else {
      setFinalAffirmationChecked(false);
      setErrorOnCheckbox(false);
    }
  };

  const handleMobileScan = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Create a mock "snapped" image URL
    const imageUrl = URL.createObjectURL(file);
    
    // Save to local storage for the Reports page to pick up
    try {
      const existingSnapsStr = localStorage.getItem("dentalcheck.snaps");
      const existingSnaps = existingSnapsStr ? JSON.parse(existingSnapsStr) : [];
      const newSnap = {
        id: Date.now().toString(),
        url: imageUrl,
        date: new Date().toLocaleDateString(),
        name: `Snap ${existingSnaps.length + 1}`
      };
      localStorage.setItem("dentalcheck.snaps", JSON.stringify([...existingSnaps, newSnap]));
      
      // Navigate to reports page
      alert("Document scanned and saved to 'Snaps to File'!");
      setLocation("/reports");
    } catch (err) {
      console.error("Failed to save snap", err);
      alert("Failed to save document");
    }
  };

  const handleSave = () => {
    // Function to restore deleted documents
    const restoreDocument = (docName: string) => {
        try {
            const deletedDefaultsStr = localStorage.getItem("dentalcheck.deleted_docs");
            if (deletedDefaultsStr) {
                const deletedDefaults = JSON.parse(deletedDefaultsStr);
                const updatedDeleted = deletedDefaults.filter((name: string) => name !== docName);
                if (updatedDeleted.length !== deletedDefaults.length) {
                    localStorage.setItem("dentalcheck.deleted_docs", JSON.stringify(updatedDeleted));
                }
            }
        } catch (e) {
            console.error("Failed to restore document", e);
        }
    };

    if (activeMenu === "questionnaire") {
      // Create a dynamic list of required fields based on the answers
      let dynamicRequired = requiredFields.filter(f => 
          f !== "steriliserBrand" && 
          f !== "steriliserType" && 
          f !== "steriliserBrand_1" && // Filter out legacy/potential duplicates just in case
          f !== "steriliserType_1"
      );

      // Add dynamic steriliser fields based on count
      const count = parseInt(answers.steriliserCount) || 0;
      const safeCount = count > 4 ? 4 : count; // Cap at 4 matching UI

      if (safeCount > 0) {
          for (let i = 1; i <= safeCount; i++) {
              dynamicRequired.push(`steriliserBrand_${i}`);
              dynamicRequired.push(`steriliserType_${i}`);
          }
      }

      // Validate against the dynamic list
      const missing = dynamicRequired.filter(f => !answers[f] || answers[f].trim() === "");

      if (missing.length > 0) {
        setUnansweredFields(missing);
        alert("Please complete all the questions");
        const firstMissing = missing[0];
        scrollRefs.current[firstMissing]?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
      }
    }

    if (activeMenu === "dba_affirmation") {
      const isValid = validateDBA();
      if (!isValid) return;
      
      if (!finalAffirmationChecked) {
        setErrorOnCheckbox(true);
        alert("Please check the affirmation box");
        scrollRefs.current.finalAffirmation?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
      }
      
      // Check if Owner Name and Date are filled
      // These fields are inside 'reviewAffirmation' state (used in UI)
      if (!reviewAffirmation.name || !reviewAffirmation.date) {
        alert("Please fill in the Practice Owner / Principal Dentist name and Date of Latest Review.");
        return;
      }
      
      // Set persistent approval flag for DBA
      localStorage.setItem("dba_manual_approved", "true");
      
      // Restore default DBA documents if they were deleted
      restoreDocument("DBA Readiness Report");
      restoreDocument("Evidence Folder Index");
    }

    if (activeMenu === "cpd_breakdown") {
      setShowTemplateError(false);
      // Validate CPD Rows
      const errors = new Set<number>();
      
      // 1. Check if table is empty (0 rows)
      if (cpdRows.length === 0) {
          alert("You must have at least one entry in the CPD Log.");
          return;
      }

      cpdRows.forEach((row: any, idx: number) => {
        // Check if row is empty or incomplete
        const isEmpty = !row.date && !row.provider && !row.hours;
        // Notes are OPTIONAL
        const isComplete = row.date && row.provider && row.hours;
        
        if (!isEmpty && !isComplete) {
           errors.add(idx);
        }
        if (cpdRows.length === 1 && isEmpty) {
           errors.add(idx);
        }
      });
      
      const allEmpty = cpdRows.every((row: any) => !row.date && !row.provider && !row.hours);
      if (allEmpty) {
           cpdRows.forEach((_: any, idx: number) => errors.add(idx));
      }

      if (errors.size > 0) {
        setCpdErrors(errors);
        setShowTemplateError(true);
        alert("Please complete all fields in the CPD Log.");
        return;
      }
      setCpdErrors(new Set());
      
      // SAVE
      localStorage.setItem("dentalcheck.cpd_breakdown", JSON.stringify(cpdRows));
      setShowSaved(true);
    }

    if (activeMenu === "dba_templates") {
      setShowTemplateError(false);
      
      if (activeTemplate === "recency") {
        const errors = new Set<number>();
        recencyRows.forEach((row, idx) => {
          const isEmpty = !row.period && !row.location && !row.hours;
          const isComplete = row.period && row.location && row.hours; // supervisor optional? assume required if not optional
          
          if (!isEmpty && !isComplete) {
            errors.add(idx);
          }
          if (recencyRows.length === 1 && isEmpty) {
            errors.add(idx);
          }
        });
        
        if (errors.size > 0) {
          setRecencyErrors(errors);
          setShowTemplateError(true);
          alert("Please complete all fields in the Recency Evidence Summary.");
          return;
        }
        setRecencyErrors(new Set());
      }
      
      if (activeTemplate === "pii") {
        const errors: string[] = [];
        if (!piiTracker.insurer) errors.push("insurer");
        if (!piiTracker.policyNumber) errors.push("policyNumber");
        if (!piiTracker.expiryDate) errors.push("expiryDate");
        if (!piiTracker.coverageLimits) errors.push("coverageLimits");
        
        if (errors.length > 0) {
          setPiiErrors(errors);
          setShowTemplateError(true);
          alert("Please fill in all fields in the PII Certificate Tracker.");
          return;
        }
        setPiiErrors([]);
      }
    }

    if (activeMenu === "ipc_affirmations") {
      const isValid = validateIPC();
      if (!isValid) return;

      if (!finalAffirmationChecked) {
        setErrorOnCheckbox(true);
        alert("Please check the approval box");
        scrollRefs.current.officialApproval?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
      }
      
      // Persist the lock state so we know the manual was approved
      // We can use a special key in 'answers' or a separate state if we want persistence across sessions.
      // For now, let's just assume the user means "while I'm in this session".
      // But wait, if they save, they go back to the main menu.
      // If they come back, 'finalAffirmationChecked' is reset to false in useEffect? No.
      // Actually, 'finalAffirmationChecked' is reset to false in the setTimeout below.
      
      // The requirement says: "It is only prevented ... if both ... checkbox is checked AND 'Save ...' is clicked"
      // This implies a persistent "Approved" state.
      // Let's set a persistent flag.
      localStorage.setItem("ipc_manual_approved", "true");
      
      // Restore default IPC documents if they were deleted
      restoreDocument("IPC Policy & Manual 2026");
      restoreDocument("Practice Specific Protocol");
    }

    setUnansweredFields([]);
    setErrorOnCheckbox(false);
    setShowSaved(true);
    
        // Validate Review Log
      if (activeMenu === "review_log") {
        // Filter out empty rows
        const validRows = reviewRows.filter(r => r.version || r.date || r.reviewedAgainst || r.changes || r.reviewedBy);
        if (validRows.length === 0) {
            alert("You must have at least one entry in the Review Log before saving.");
            return;
        }
        // Save the valid rows (or all if we want to keep empty ones, but usually we filter)
        // Let's filter to be clean
        setReviewRows(validRows);
        localStorage.setItem("dentalcheck.review_log", JSON.stringify(validRows));
      }
      
      // Auto-navigate ONLY for sections that are not exceptions
      if (activeMenu !== "ipc_affirmations" && activeMenu !== "review_log" && activeMenu !== "dba_templates" && activeMenu !== "questionnaire" && activeMenu !== "dba_affirmation" && activeMenu !== "cpd_breakdown") {
         setTimeout(() => {
           setActiveMenu("main");
         }, 2000);
      }
      
      const newScore = Math.min(100, complianceScore + 2);
      setComplianceScore(newScore);
      setShowSaved(true);
      
    // End of handleSave
  };

  const addReviewRow = () => {
    setReviewRows([...reviewRows, { version: "", date: "", reviewedAgainst: "", changes: "", reviewedBy: "" }]);
  };

  const removeReviewRow = () => {
    if (selectedReviewRows.size > 0) {
      removeSelectedRows(reviewRows, setReviewRows, selectedReviewRows, setSelectedReviewRows);
    } else if (reviewRows.length > 1) {
       // Fallback to old behavior if nothing selected (optional, or just do nothing)
       setReviewRows(reviewRows.slice(0, -1));
    }
  };

  const updateReviewRow = (index: number, field: string, value: string) => {
    const newRows = [...reviewRows];
    (newRows[index] as any)[field] = value;
    setReviewRows(newRows);
  };

  // Staff Training Register Handlers
  const addStaffTrainingRow = () => setStaffTrainingRows([...staffTrainingRows, { name: "", email: "", role: "", date: "", topic: "", provider: "", nextDue: "", evidenceUploaded: "" }]);
  const removeStaffTrainingRow = () => {
    if (selectedStaffTrainingRows.size > 0) {
      removeSelectedRows(staffTrainingRows, setStaffTrainingRows, selectedStaffTrainingRows, setSelectedStaffTrainingRows);
    } else if (staffTrainingRows.length > 1) {
      setStaffTrainingRows(staffTrainingRows.slice(0, -1));
    }
  };
  const updateStaffTrainingRow = (index: number, field: string, value: string) => {
    const newRows = [...staffTrainingRows];
    (newRows[index] as any)[field] = value;
    setStaffTrainingRows(newRows);
  };
  const handleSaveStaffTraining = (navigateBack: boolean = true) => {
    // Validation
    const isEmpty = staffTrainingRows.length === 0;
    const errors = staffTrainingRows.some((row: any) => !row.name || !row.date || !row.topic || !row.provider);
    
    if (isEmpty) {
        alert("You must have at least one entry in the Staff Training Register.");
        return;
    }
    
    if (errors) {
        alert("Please fill in all required fields (Name, Date, Topic, Provider) for each entry.");
        return;
    }

    localStorage.setItem("dentalcheck.staff_training_register", JSON.stringify(staffTrainingRows));
    setShowSaved(true);
  };

  // CPD Log Handlers
  const addCpdLogRow = () => setCpdLogRows([...cpdLogRows, { practitioner: "", topic: "", date: "", provider: "", totalHours: "", ipcHours: "", type: "", certHeld: "No", notes: "" }]);
  const removeCpdLogRow = () => {
    if (selectedCpdLogRows.size > 0) {
      removeSelectedRows(cpdLogRows, setCpdLogRows, selectedCpdLogRows, setSelectedCpdLogRows);
    } else if (cpdLogRows.length > 1) {
      setCpdLogRows(cpdLogRows.slice(0, -1));
    }
  };
  const updateCpdLogRow = (index: number, field: string, value: string) => {
    const newRows = [...cpdLogRows];
    (newRows[index] as any)[field] = value;
    setCpdLogRows(newRows);
  };
  const handleSaveCpdLogs = (navigateBack: boolean = true) => {
    // Validation
    const errors = cpdLogRows.some((row: any) => !row.practitioner || !row.date || !row.topic || !row.provider || !row.totalHours);
    if (errors) {
        alert("Please fill in all required fields (Practitioner, Date, Topic, Provider, Hours) for each entry.");
        return;
    }

    localStorage.setItem("dentalcheck.cpd_logs", JSON.stringify(cpdLogRows));
    setShowSaved(true);
  };

  // Immunisation Records Handlers
  const addImmunisationRow = () => setImmunisationRows([...immunisationRows, { staffMember: "", vaccine: "", courseCompletionDate: "", serologyResult: "", serologyDate: "", boosterNeeded: "", evidenceHeld: "", nextReviewDate: "", evidenceUploaded: "" }]);
  const removeImmunisationRow = () => {
    if (selectedImmunisationRows.size > 0) {
      removeSelectedRows(immunisationRows, setImmunisationRows, selectedImmunisationRows, setSelectedImmunisationRows);
    } else if (immunisationRows.length > 1) {
      setImmunisationRows(immunisationRows.slice(0, -1));
    }
  };
  const updateImmunisationRow = (index: number, field: string, value: string) => {
    const newRows = [...immunisationRows];
    (newRows[index] as any)[field] = value;
    setImmunisationRows(newRows);
  };
  const handleSaveImmunisation = (navigateBack: boolean = true) => {
    // Validation
    const isEmpty = immunisationRows.length === 0;
    const errors = immunisationRows.some((row: any) => !row.staffMember || !row.vaccine || !row.courseCompletionDate || !row.evidenceHeld);
    
    if (isEmpty) {
        alert("You must have at least one entry in the Immunisation Records.");
        return;
    }
    
    if (errors) {
        alert("Please fill in all required fields (Staff Member, Vaccine, Date, Evidence Held) for each entry.");
        return;
    }

    localStorage.setItem("dentalcheck.immunisation_records", JSON.stringify(immunisationRows));
    setShowSaved(true);
  };

  const addCpdRow = () => setCpdRows([...cpdRows, { date: "", activity: "", provider: "", hours: "", type: "", certAttached: "", notes: "" }]);
  const removeCpdRow = () => {
    if (selectedCpdRows.size > 0) {
      removeSelectedRows(cpdRows, setCpdRows, selectedCpdRows, setSelectedCpdRows);
    } else if (cpdRows.length > 1) {
      setCpdRows(cpdRows.slice(0, -1));
    }
  };
  const addRecencyRow = () => setRecencyRows([...recencyRows, { period: "", location: "", hours: "", supervisor: "" }]);
  const removeRecencyRow = () => {
    if (selectedRecencyRows.size > 0) {
      removeSelectedRows(recencyRows, setRecencyRows, selectedRecencyRows, setSelectedRecencyRows);
    } else if (recencyRows.length > 1) {
      setRecencyRows(recencyRows.slice(0, -1));
    }
  };

  // Steriliser PQ Handlers
  const addSteriliserRow = () => setSteriliserPQRows([...steriliserPQRows, { date: "", technician: "", equipmentId: "", notes: "", certAttached: "" }]);
  const removeSteriliserRow = () => {
    if (selectedSteriliserPQRows.size > 0) {
      removeSelectedRows(steriliserPQRows, setSteriliserPQRows, selectedSteriliserPQRows, setSelectedSteriliserPQRows);
    } else if (steriliserPQRows.length > 1) {
      setSteriliserPQRows(steriliserPQRows.slice(0, -1));
    }
  };
  
  const handleSaveSteriliser = (navigateBack: boolean = true) => {
    // Validation
    const isEmpty = steriliserPQRows.length === 0;
    const errors = steriliserPQRows.some((row: any) => !row.date || !row.technician || !row.equipmentId);
    
    if (isEmpty) {
        alert("You must have at least one entry in the Steriliser PQ Log.");
        return;
    }
    
    if (errors) {
        alert("Please fill in all required fields (Date, Technician, Equipment ID) for each entry.");
        return;
    }

    localStorage.setItem("dentalcheck.steriliser_pq", JSON.stringify(steriliserPQRows));
    
    // Also update documents list if there are certificates attached (mock logic)
    // In a real app, this would be handled by the upload function returning a URL/ID
    const newDocs: any[] = [];
    steriliserPQRows.forEach((row: any, idx: number) => {
      if (row.certAttached === "Uploaded") {
        newDocs.push({
          name: `Steriliser PQ Cert - ${row.date || "Undated"}`,
          date: new Date().toLocaleDateString("en-AU", { day: "2-digit", month: "short", year: "numeric" }),
          category: "Steriliser PQ Validation"
        });
      }
    });

    if (newDocs.length > 0) {
      try {
        const existingDocsStr = localStorage.getItem("dentalcheck.documents");
        const existingDocs = existingDocsStr ? JSON.parse(existingDocsStr) : [];
        // Simple merge (duplicates allowed for demo simplicity)
        localStorage.setItem("dentalcheck.documents", JSON.stringify([...existingDocs, ...newDocs]));
      } catch (e) {
        console.error("Failed to update documents", e);
      }
    }

    setShowSaved(true);
  };

  // Calculations
  const safeCpdRows = Array.isArray(cpdRows) ? cpdRows : [];
  const totalHours = safeCpdRows.reduce((acc: number, row: any) => acc + (parseFloat(row?.hours) || 0), 0);
  const infectionControlHours = safeCpdRows
    .filter((r: any) => String(r?.type || "").toLowerCase().includes("infection"))
    .reduce((acc: number, row: any) => acc + (parseFloat(row?.hours) || 0), 0);
  const cprHours = safeCpdRows
    .filter((r: any) => String(r?.type || "").toLowerCase().includes("cpr"))
    .reduce((acc: number, row: any) => acc + (parseFloat(row?.hours) || 0), 0);

  const safeCpdLogRows = Array.isArray(cpdLogRows) ? cpdLogRows : [];
  const cpdLogTotalHours = safeCpdLogRows.reduce((acc: number, row: any) => acc + (parseFloat(row?.totalHours) || 0), 0);
  const cpdLogIpcHours = safeCpdLogRows.reduce((acc: number, row: any) => acc + (parseFloat(row?.ipcHours) || 0), 0);

  if (isMobile) {
    return (
      <Layout onDashboardClick={handleDashboardClick}>
        <div className="flex flex-col items-center justify-center min-h-[80vh] space-y-8 px-4 relative">
          <div className="flex items-center mb-8">
            <Activity className="h-12 w-12 text-primary mr-3" />
            <span className="font-display font-bold text-3xl text-foreground tracking-tight">
              DentalCheck
            </span>
          </div>

          <div className="w-full max-w-sm space-y-6 relative">
            {/* Document Snap Button */}
            <label className="block w-full cursor-pointer relative group">
              <div className="bg-card hover:bg-accent/5 border-2 border-primary/20 hover:border-primary/50 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center text-center transition-all shadow-sm active:scale-95">
                <div className="bg-primary/10 p-4 rounded-full mb-4">
                  <Camera className="h-10 w-10 text-primary" />
                </div>
                <h2 className="text-xl font-bold text-foreground mb-2">Document Snap</h2>
                <p className="text-sm text-muted-foreground">Capture & Upload</p>
                <input 
                  type="file" 
                  accept="image/*" 
                  capture="environment"
                  className="hidden" 
                  onChange={handleMobileScan}
                />
              </div>
            </label>

            {/* CPD Log Snap Button */}
            <Link href="/cpd-snap">
              <a className="block w-full relative group mb-6 mt-6">
                <div className="bg-blue-50 dark:bg-blue-900/10 hover:bg-blue-100 dark:hover:bg-blue-900/20 border-2 border-blue-200 dark:border-blue-800 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center text-center transition-all shadow-sm active:scale-95">
                  <div className="bg-blue-100 dark:bg-blue-800/30 p-4 rounded-full mb-4">
                    <QrCode className="h-10 w-10 text-blue-600 dark:text-blue-400" />
                  </div>
                  <h2 className="text-xl font-bold text-blue-900 dark:text-blue-100 mb-2">CPD Log Snap</h2>
                  <p className="text-sm text-blue-700 dark:text-blue-300">Log Activities</p>
                </div>
              </a>
            </Link>

            {/* All Documents Button */}
            <Link href="/reports">
              <a className="block w-full relative group">
                <div className="bg-card hover:bg-accent/5 border border-border hover:border-primary/50 rounded-2xl p-8 flex flex-col items-center justify-center text-center transition-all shadow-sm active:scale-95">
                  <div className="bg-primary/10 p-4 rounded-full mb-4">
                    <FileText className="h-10 w-10 text-primary" />
                  </div>
                  <h2 className="text-xl font-bold text-foreground mb-2">All Documents</h2>
                  <p className="text-sm text-muted-foreground">View & Manage Files</p>
                </div>
              </a>
            </Link>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout onDashboardClick={handleDashboardClick}>
      <div className="flex flex-col space-y-8 pt-6">
        {/* Mobile Static Back Button */}
        {isMobile && floatingBackConfig && (
           <button
             onClick={floatingBackConfig.onClick}
             className="flex items-center text-sm font-medium text-muted-foreground hover:text-foreground mb-4"
           >
             <ChevronLeft className="w-4 h-4 mr-1" />
             Back
           </button>
        )}

        {floatingBackConfig && floatingBackPos && (
          <button
            onClick={floatingBackConfig.onClick}
            className={cn(
              "no-print fixed z-50 p-2 rounded-full transition-colors",
              floatingBackPos.variant === "zinc"
                ? "text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800"
                : "text-muted-foreground hover:bg-muted"
            )}
            style={{ left: floatingBackPos.left, top: floatingBackPos.top }}
            title="Back"
          >
            <ArrowLeft className={cn(floatingBackPos.size === "lg" ? "w-6 h-6" : "w-5 h-5")} />
          </button>
        )}
        <AnimatePresence mode="wait">
          {activeMenu === "main" ? (
            <motion.div
              key="main-menu"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-8"
            >
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
                {tiles.map((tile, index) => (
                  <motion.div
                    key={tile.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    whileHover={{
                      y: -8,
                      scale: 1.02,
                      boxShadow: "0 15px 30px -5px rgb(0 0 0 / 0.1)",
                    }}
                    onClick={() => {
                      if (tile.id === "cpd_breakdown") setActiveMenu("cpd_breakdown");
                      if (tile.id === "ipc") setActiveMenu("ipc");
                      if (tile.id === "affirmation") setActiveMenu("dba_sub");
                      if (tile.id === "steriliser") setActiveMenu("steriliser_pq");
                      if (tile.id === "training") setActiveMenu("staff_training");
                      if (tile.id === "gap") setActiveMenu("gap_analysis");
                    }}
                    className="group cursor-pointer bg-card rounded-xl border border-border p-5 flex flex-col items-center justify-center text-center shadow-sm transition-all duration-200"
                  >
                    <div className="mb-3 p-3 rounded-lg bg-primary/5 group-hover:bg-primary/10 transition-colors">
                      <tile.icon className="h-7 w-7 text-primary" />
                    </div>
                    <h2 className="text-primary font-display font-bold text-sm leading-tight mb-2">
                      {tile.title}
                    </h2>
                    <p className="text-[10px] text-muted-foreground leading-snug">
                      {tile.desc}
                    </p>
                  </motion.div>
                ))}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                  <TaskTable tasks={renewalTasks} />
                </div>
                <div className="space-y-6">
                  {/* DBA Renewal Deadline Tile */}
                  <div className="bg-blue-50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-800 p-5 rounded-xl">
                    <h4 className="font-semibold text-blue-900 dark:text-blue-100 mb-2 flex items-center text-sm">
                      <ShieldCheck className="w-4 h-4 mr-2" />
                      DBA Renewal Deadline
                    </h4>
                    <p className="text-xs text-blue-700 dark:text-blue-300 leading-relaxed">
                      Your annual Dental Board of Australia (DBA) practitioner registration (through the AHPRA portal) is due <strong>30th November 2026</strong>. Note that Late renewal (1 December – 31 December) incurs a late fee, and after 31 December your registration lapses (practitioner cannot practise until reinstated).
                    </p>
                  </div>

                  {/* AS 5369:2023 Deadline Tile */}
                  <div className="bg-amber-50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-800 p-5 rounded-xl">
                    <h4 className="font-semibold text-amber-900 dark:text-amber-100 mb-2 flex items-center text-sm">
                      <AlertTriangle className="w-4 h-4 mr-2" />
                      AS 5369:2023 Deadline
                    </h4>
                    <p className="text-xs text-amber-800 dark:text-amber-300 leading-relaxed">
                      The <strong>June 30, 2026</strong>, deadline for completing and documenting a AS 5369:2023 Gap Analysis applies specifically to dental practices (not individual dentists) that are pursuing or maintaining accreditation under NSQHS Standards, which incorporate AS 5369:2023 for reprocessing compliance.
                    </p>
                    <p className="text-xs text-amber-800 dark:text-amber-300 leading-relaxed mt-2">
                      Small, independent dental practices (e.g., sole trader clinics) are not required to be accredited under NSQHS or conduct a formal gap analysis by this date — compliance is enforced at the practitioner level via DBA registration renewals. However, all dental practitioners must ensure their practice aligns with AS 5369:2023 in daily operations, as non-compliance can trigger DBA investigations or conditions on individual registration.
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          ) : activeMenu === "ipc" ? (
            <motion.div
              key="ipc-menu"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div
                className="w-full"
                data-floating-panel="ipc"
                ref={(el) => {
                  if (!el) return;
                  floatingPanelRef.current = el;
                  floatingHeadingRef.current = null;
                }}
              >
                <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 pl-0 md:pl-12">
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  whileHover={{
                    y: -8,
                    scale: 1.02,
                    boxShadow: "0 15px 30px -5px rgb(0 0 0 / 0.1)",
                  }}
                  onClick={() => setActiveMenu("questionnaire")}
                  className="group cursor-pointer bg-card rounded-xl border border-border p-5 flex flex-col items-center justify-center text-center shadow-sm transition-all duration-200"
                  data-floating-first-tile="1"
                >
                  <div className="mb-3 p-3 rounded-lg bg-primary/5 group-hover:bg-primary/10 transition-colors">
                    <Plus className="h-7 w-7 text-primary" strokeWidth={1.8} />
                  </div>
                  <h2 className="text-primary font-display font-bold text-sm leading-tight mb-2">
                    Specific to your clinic
                  </h2>
                  <p className="text-[10px] text-muted-foreground leading-snug">
                    Steriliser, Reprocessing area, Instruments, staff etc
                  </p>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  whileHover={{
                    y: -8,
                    scale: 1.02,
                    boxShadow: "0 15px 30px -5px rgb(0 0 0 / 0.1)",
                  }}
                  onClick={() => setActiveMenu("ipc_affirmations")}
                  className="group cursor-pointer bg-card rounded-xl border border-border p-5 flex flex-col items-center justify-center text-center shadow-sm transition-all duration-200"
                >
                  <div className="mb-3 p-3 rounded-lg bg-primary/5 group-hover:bg-primary/10 transition-colors">
                    <Plus className="h-7 w-7 text-primary" strokeWidth={1.8} />
                  </div>
                  <h2 className="text-primary font-display font-bold text-sm leading-tight mb-2">
                    Required Affirmations
                  </h2>
                  <p className="text-[10px] text-muted-foreground leading-snug">
                    Mandatory regulatory compliance checks
                  </p>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  whileHover={{
                    y: -8,
                    scale: 1.02,
                    boxShadow: "0 15px 30px -5px rgb(0 0 0 / 0.1)",
                  }}
                  onClick={() => setActiveMenu("review_log")}
                  className="group cursor-pointer bg-card rounded-xl border border-border p-5 flex flex-col items-center justify-center text-center shadow-sm transition-all duration-200"
                >
                  <div className="mb-3 p-3 rounded-lg bg-primary/5 group-hover:bg-primary/10 transition-colors">
                    <FileText className="h-7 w-7 text-primary" strokeWidth={1.8} />
                  </div>
                  <h2 className="text-primary font-display font-bold text-sm leading-tight mb-2">
                    Review Log / Change Summary
                  </h2>
                  <p className="text-[10px] text-muted-foreground leading-snug">
                    Track updates and manual revisions
                  </p>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  whileHover={{
                    y: -8,
                    scale: 1.02,
                    boxShadow: "0 15px 30px -5px rgb(0 0 0 / 0.1)",
                  }}
                  onClick={() => { setSummaryType("ipc"); setActiveMenu("pdf_summary"); }}
                  className="group cursor-pointer bg-card rounded-xl border border-border p-5 flex flex-col items-center justify-center text-center shadow-sm transition-all duration-200"
                >
                  <div className="mb-3 p-3 rounded-lg bg-primary/5 group-hover:bg-primary/10 transition-colors">
                    <Download className="h-7 w-7 text-primary" strokeWidth={1.8} />
                  </div>
                  <h2 className="text-primary font-display font-bold text-sm leading-tight mb-2">
                    FULL PDF SUMMARY
                  </h2>
                  <p className="text-[10px] text-muted-foreground leading-snug">
                    ONLY available when all requirements have been completed
                  </p>
                </motion.div>
                </div>
              </div>
            </motion.div>
          ) : activeMenu === "staff_training" ? (
            <motion.div
              key="staff_training"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div
                className="w-full"
                data-floating-panel="staff_training"
                ref={(el) => {
                  if (!el) return;
                  floatingPanelRef.current = el;
                  floatingHeadingRef.current = null;
                }}
              >
                <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 pl-0 md:pl-12">
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    whileHover={{
                      y: -8,
                      scale: 1.02,
                      boxShadow: "0 15px 30px -5px rgb(0 0 0 / 0.1)",
                    }}
                    onClick={() => setActiveMenu("staff_training_register")}
                    className="group cursor-pointer bg-card rounded-xl border border-border p-5 flex flex-col items-center justify-center text-center shadow-sm transition-all duration-200"
                    data-floating-first-tile="1"
                  >
                    <div className="mb-3 p-3 rounded-lg bg-primary/5 group-hover:bg-primary/10 transition-colors">
                      <BookOpen className="h-7 w-7 text-primary" strokeWidth={1.8} />
                    </div>
                    <h2 className="text-primary font-display font-bold text-sm leading-tight mb-2">
                      Staff Training Register
                    </h2>
                    <p className="text-[10px] text-muted-foreground leading-snug">
                      Log attendance & topics
                    </p>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    whileHover={{
                      y: -8,
                      scale: 1.02,
                      boxShadow: "0 15px 30px -5px rgb(0 0 0 / 0.1)",
                    }}
                    onClick={() => setActiveMenu("immunisation_records")}
                    className="group cursor-pointer bg-card rounded-xl border border-border p-5 flex flex-col items-center justify-center text-center shadow-sm transition-all duration-200"
                  >
                    <div className="mb-3 p-3 rounded-lg bg-primary/5 group-hover:bg-primary/10 transition-colors">
                      <Syringe className="h-7 w-7 text-primary" strokeWidth={1.8} />
                    </div>
                    <h2 className="text-primary font-display font-bold text-sm leading-tight mb-2">
                      Immunisation Records
                    </h2>
                    <p className="text-[10px] text-muted-foreground leading-snug">
                      Summary & status
                    </p>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    whileHover={{
                      y: -8,
                      scale: 1.02,
                      boxShadow: "0 15px 30px -5px rgb(0 0 0 / 0.1)",
                    }}
                    onClick={() => {
                      setSummaryType("staff");
                      setActiveMenu("pdf_summary");
                    }}
                    className="group cursor-pointer bg-card rounded-xl border border-border p-5 flex flex-col items-center justify-center text-center shadow-sm transition-all duration-200"
                  >
                    <div className="mb-3 p-3 rounded-lg bg-primary/5 group-hover:bg-primary/10 transition-colors">
                      <FileText className="h-7 w-7 text-primary" strokeWidth={1.8} />
                    </div>
                    <h2 className="text-primary font-display font-bold text-sm leading-tight mb-2">
                      FULL PDF SUMMARY
                    </h2>
                    <p className="text-[10px] text-muted-foreground leading-snug">
                      Download validation summary
                    </p>
                  </motion.div>
                </div>
              </div>
            </motion.div>
          ) : activeMenu === "staff_training_register" ? (
            <motion.div
              key="staff_training_register"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="w-full bg-card rounded-2xl border border-border p-10 shadow-sm relative"
              data-floating-panel="staff_training_register"
              ref={(el) => {
                if (!el) return;
                floatingPanelRef.current = el;
              }}
            >
              <div className="flex justify-between items-center mb-10">
                <div className="flex-1 text-center">
                  <h2
                    className="text-2xl font-display font-bold text-foreground"
                    data-floating-heading="1"
                    ref={(el) => {
                      if (!el) return;
                      floatingHeadingRef.current = el;
                    }}
                  >
                    Staff Training Register
                  </h2>
                  <h3 className="text-[10px] font-bold text-primary uppercase tracking-widest mt-2">
                    Infection Prevention & Control (IPC)
                  </h3>
                </div>
              </div>

              <div className="max-w-6xl mx-auto space-y-8">
                {/* Preface Section */}
                <div className="bg-blue-50/50 p-6 rounded-xl border border-blue-100 space-y-4 text-sm text-blue-900 leading-relaxed">
                  <div>
                    <strong className="block text-blue-700 uppercase text-xs tracking-wider mb-1">Purpose</strong>
                    <p>
                      This register records all infection prevention and control (IPC) training provided to staff at {pdfPracticeName ? <strong>{pdfPracticeName}</strong> : <span className="text-red-500 font-bold">[Please fill in the clinic name in 'Your Details']</span>}. It demonstrates compliance with:
                    </p>
                    <ul className="list-disc pl-5 mt-1 space-y-1">
                      <li>Dental Board of Australia (DBA) requirements for ongoing professional competency</li>
                      <li>ADA Guidelines for Infection Prevention and Control, 5th Edition (Section H – Training & Competency)</li>
                      <li>NHMRC Australian Guidelines for the Prevention and Control of Infection in Healthcare (Section 3 – Standard Precautions & Staff Education)</li>
                    </ul>
                  </div>
                  
                  <div>
                    <strong className="block text-blue-700 uppercase text-xs tracking-wider mb-1">Key Principles</strong>
                    <ul className="list-disc pl-5 mt-1 space-y-1">
                      <li>All clinical and non-clinical staff receive initial IPC training upon commencement and annual refreshers.</li>
                      <li>Training covers (at minimum): hand hygiene, PPE, sharps safety, waste management, spills, environmental cleaning, and reprocessing (where relevant).</li>
                      <li>Records are reviewed annually as part of the IPC manual review process.</li>
                      <li>Certificates, sign-in sheets, or acknowledgments are retained in staff files (digital or physical).</li>
                      <li>The practice owner / IPC lead ensures this register is maintained and reviewed.</li>
                    </ul>
                  </div>
                </div>

                {/* Table Controls */}
                <div className="flex justify-end gap-2">
                  <button onClick={addStaffTrainingRow} className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-xs font-bold shadow-sm"><PlusCircle className="w-4 h-4" /> ADD ROW</button>
                  <button onClick={removeStaffTrainingRow} className="flex items-center gap-2 px-4 py-2 bg-muted text-foreground rounded-lg text-xs font-bold border border-border shadow-sm"><MinusCircle className="w-4 h-4" /> REMOVE SELECTED ROW(S)</button>
                </div>

                {/* Training Table */}
                <div className="bg-background rounded-xl border border-border shadow-inner overflow-x-auto">
                  <table className="w-full border-collapse min-w-[800px]">
                    <thead>
                      <tr className="bg-muted/50 border-b border-border">
                        <th className="px-2 py-4 text-center border-r border-border w-10">
                          <input type="checkbox" className="rounded border-gray-300" disabled />
                        </th>
                        <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-48">Name</th>
                        <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-48">Email</th>
                        <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-32">Role</th>
                        <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-32">Date</th>
                        <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border">Topic(s)</th>
                        <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border">Provider / Method</th>
                        <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-32">Next Due</th>
                        <th className="px-6 py-4 text-center text-xs font-bold text-foreground/70 uppercase tracking-wider w-40">Evidence</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {staffTrainingRows.map((row: any, idx: number) => {
                         // Overdue Logic
                         let statusColor = "";
                         if (row.nextDue) {
                           // Attempt to parse DD/MM/YYYY
                           const parts = row.nextDue.split("/");
                           if (parts.length === 3) {
                             const due = new Date(`${parts[2]}-${parts[1]}-${parts[0]}`); // YYYY-MM-DD
                             const today = new Date();
                             const diffTime = due.getTime() - today.getTime();
                             const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

                             if (diffDays < 0) statusColor = "bg-red-50 text-red-900"; // Overdue
                             else if (diffDays < 30) statusColor = "bg-amber-50 text-amber-900"; // Due soon
                           }
                         }

                         return (
                        <tr key={idx} className={`hover:bg-muted/5 ${statusColor}`}>
                          <td className="text-center border-r border-border bg-muted/5">
                            <input 
                              type="checkbox" 
                              checked={selectedStaffTrainingRows.has(idx)}
                              onChange={() => toggleRowSelection(idx, selectedStaffTrainingRows, setSelectedStaffTrainingRows)}
                              className="rounded border-gray-300"
                            />
                          </td>
                          <td className="border-r border-border h-full">
                            {staffList && staffList.length > 0 ? (
                              <select
                                value={row.name}
                                onChange={(e) => {
                                  const selectedStaff = staffList.find(s => s.name === e.target.value);
                                  const nr = [...staffTrainingRows];
                                  nr[idx].name = e.target.value;
                                  if (selectedStaff) {
                                    nr[idx].role = selectedStaff.role || "";
                                    nr[idx].email = selectedStaff.email || "";
                                  }
                                  setStaffTrainingRows(nr);
                                }}
                                className="w-full px-6 py-4 bg-transparent outline-none text-sm appearance-none cursor-pointer"
                              >
                                <option value="">Select Staff</option>
                                {staffList.map((s) => (
                                  <option key={s.id} value={s.name}>
                                    {s.name}
                                  </option>
                                ))}
                              </select>
                            ) : (
                              <textarea rows={1} value={row.name} onChange={(e) => updateStaffTrainingRow(idx, "name", e.target.value)} className="w-full px-6 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="Staff Name" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} />
                            )}
                          </td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.email} onChange={(e) => updateStaffTrainingRow(idx, "email", e.target.value)} className="w-full px-6 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="email@example.com" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.role} onChange={(e) => updateStaffTrainingRow(idx, "role", e.target.value)} className="w-full px-6 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="Role" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.date} onChange={(e) => updateStaffTrainingRow(idx, "date", e.target.value)} className="w-full px-6 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="DD/MM/YYYY" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.topic} onChange={(e) => updateStaffTrainingRow(idx, "topic", e.target.value)} className="w-full px-6 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="e.g. Hand Hygiene, PPE" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.provider} onChange={(e) => updateStaffTrainingRow(idx, "provider", e.target.value)} className="w-full px-6 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="e.g. In-house" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.nextDue} onChange={(e) => updateStaffTrainingRow(idx, "nextDue", e.target.value)} className="w-full px-6 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="DD/MM/YYYY" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="text-center h-full align-middle p-2">
                            <button 
                              onClick={() => {
                                if (row.evidenceUploaded) {
                                  const nr = [...staffTrainingRows];
                                  nr[idx].evidenceUploaded = "";
                                  setStaffTrainingRows(nr);
                                } else {
                                  setUploadModalState({ isOpen: true, section: 'staff', rowIndex: idx });
                                }
                              }}
                              className={cn(
                                "flex items-center gap-2 px-3 py-1.5 rounded-lg text-[10px] font-bold border mx-auto transition-all",
                                row.evidenceUploaded 
                                  ? "bg-green-100 text-green-700 border-green-200" 
                                  : "bg-muted hover:bg-muted/80 text-foreground border-border"
                              )}
                            >
                              <Upload className="w-3 h-3" /> 
                              {row.evidenceUploaded ? "UPLOADED" : "UPLOAD"}
                            </button>
                          </td>
                        </tr>
                      );
                      })}
                    </tbody>
                  </table>
                </div>

                {/* Affirmation Section */}
                <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-6 space-y-4 mt-8">
                  <h3 className="text-sm font-bold text-zinc-700 uppercase tracking-wider border-b border-zinc-200 pb-2">Affirmation</h3>
                  <p className="text-sm text-zinc-600 italic">
                    I confirm that the training recorded in this register is accurate and has been delivered as stated.
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Practice Owner / IPC Lead</label>
                      <input 
                        type="text" 
                        value={staffTrainingAffirmation.name} 
                        onChange={(e) => setStaffTrainingAffirmation({...staffTrainingAffirmation, name: e.target.value})}
                        className="w-full bg-white border border-zinc-300 rounded-md px-3 py-2 text-sm outline-none focus:border-primary"
                        placeholder="Name..."
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Date</label>
                      <input 
                        type="text" 
                        value={staffTrainingAffirmation.date} 
                        onChange={(e) => setStaffTrainingAffirmation({...staffTrainingAffirmation, date: e.target.value})}
                        className="w-full bg-white border border-zinc-300 rounded-md px-3 py-2 text-sm outline-none focus:border-primary"
                        placeholder="DD/MM/YYYY"
                      />
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-col items-center gap-4 pt-4">
                  <div className="flex gap-4">
                    <button 
                      onClick={() => handleSaveStaffTraining(true)} 
                      className="bg-primary text-primary-foreground px-8 py-3 rounded-xl font-bold hover:opacity-90 shadow-lg"
                    >
                      Save Data
                    </button>
                    {/* Placeholder for future PDF generation if needed, explicitly requested to be similar to Review Log which has save */}
                  </div>
                  
                  {showSaved && (
                    <div className="flex items-center gap-2 px-6 py-2 rounded-full bg-green-100 text-green-700 border border-green-200 animate-in fade-in slide-in-from-top-2 duration-300">
                      <Check className="w-4 h-4" />
                      <span className="text-xs font-bold uppercase tracking-wider">Saved Successfully</span>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          ) : activeMenu === "cpd_logs" ? (
            <motion.div
              key="cpd_logs"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="w-full bg-card rounded-2xl border border-border p-10 shadow-sm relative overflow-x-auto"
              data-floating-panel="cpd_logs"
              ref={(el) => {
                if (!el) return;
                floatingPanelRef.current = el;
              }}
            >
              <div className="flex justify-between items-center mb-10">
                <div className="flex-1 text-center">
                  <h2
                    className="text-2xl font-display font-bold text-foreground"
                    data-floating-heading="1"
                    ref={(el) => {
                      if (!el) return;
                      floatingHeadingRef.current = el;
                    }}
                  >
                    CPD Logs
                  </h2>
                  <h3 className="text-[10px] font-bold text-primary uppercase tracking-widest mt-2">
                    Continuing Professional Development
                  </h3>
                </div>
              </div>

              <div className="min-w-[1200px] space-y-8">
                {/* Preface Section */}
                <div className="bg-blue-50/50 p-6 rounded-xl border border-blue-100 space-y-4 text-sm text-blue-900 leading-relaxed">
                  <div>
                    <strong className="block text-blue-700 uppercase text-xs tracking-wider mb-1">Purpose</strong>
                    <p>
                      This log records continuing professional development (CPD) activities completed by registered dental practitioners at {pdfPracticeName ? <strong>{pdfPracticeName}</strong> : <span className="text-red-500 font-bold">[Please fill in the clinic name in 'Your Details']</span>}. It demonstrates compliance with:
                    </p>
                    <ul className="list-disc pl-5 mt-1 space-y-1">
                      <li>Dental Board of Australia (DBA) Registration Standard: Continuing Professional Development</li>
                      <li>Minimum 60 hours over 3 years (average 10 hours per year)</li>
                      <li>Mandatory CPD requirements including infection prevention and control (IPC), CPR/first aid, and radiation safety (where applicable)</li>
                      <li>ADA Guidelines for Infection Prevention and Control, 5th Edition (ongoing IPC education emphasis)</li>
                    </ul>
                  </div>
                  
                  <div>
                    <strong className="block text-blue-700 uppercase text-xs tracking-wider mb-1">Key Principles</strong>
                    <ul className="list-disc pl-5 mt-1 space-y-1">
                      <li>All registered practitioners must complete at least 60 hours of CPD over the current 3-year cycle (current cycle: [e.g., {currentYear}–{currentYear + 2}]).</li>
                      <li>IPC-focused CPD is tracked separately to demonstrate ongoing competency in infection prevention (recommended minimum 10–20 hours per cycle).</li>
                      <li>Records include certificates, attendance sheets, or verification of completion.</li>
                      <li>This log is reviewed annually as part of the IPC manual and overall compliance process.</li>
                    </ul>
                  </div>
                </div>

                {/* Table Controls */}
                <div className="flex justify-end gap-2">
                  <button onClick={addCpdLogRow} className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-xs font-bold shadow-sm"><PlusCircle className="w-4 h-4" /> ADD ROW</button>
                  <button onClick={removeCpdLogRow} className="flex items-center gap-2 px-4 py-2 bg-muted text-foreground rounded-lg text-xs font-bold border border-border shadow-sm"><MinusCircle className="w-4 h-4" /> REMOVE SELECTED ROW(S)</button>
                </div>

                {/* CPD Logs Table */}
                <div className="bg-background rounded-xl border border-border shadow-inner overflow-hidden">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-muted/50 border-b border-border">
                        <th className="px-2 py-4 text-center border-r border-border w-10">
                          <input type="checkbox" className="rounded border-gray-300" disabled />
                        </th>
                        <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-48">Practitioner Name & Reg No.</th>
                        <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border">CPD Activity / Topic</th>
                        <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-32">Date Completed</th>
                        <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border">Provider / Source</th>
                        <th className="px-6 py-4 text-center text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-24">Total Hours</th>
                        <th className="px-6 py-4 text-center text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-24">IPC Hours</th>
                        <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-32">Type</th>
                        <th className="px-6 py-4 text-center text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-24">Cert Held</th>
                        <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider">Notes / Category</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {cpdLogRows.map((row: any, idx: number) => (
                        <tr key={idx} className="hover:bg-muted/5">
                          <td className="text-center border-r border-border bg-muted/5">
                            <input 
                              type="checkbox" 
                              checked={selectedCpdLogRows.has(idx)}
                              onChange={() => toggleRowSelection(idx, selectedCpdLogRows, setSelectedCpdLogRows)}
                              className="rounded border-gray-300"
                            />
                          </td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.practitioner} onChange={(e) => updateCpdLogRow(idx, "practitioner", e.target.value)} className="w-full px-6 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="Name (Reg No.)" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.topic} onChange={(e) => updateCpdLogRow(idx, "topic", e.target.value)} className="w-full px-6 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="Description" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.date} onChange={(e) => updateCpdLogRow(idx, "date", e.target.value)} className="w-full px-6 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="DD/MM/YYYY" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.provider} onChange={(e) => updateCpdLogRow(idx, "provider", e.target.value)} className="w-full px-6 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="Provider" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="border-r border-border h-full"><input type="number" step="0.5" value={row.totalHours} onChange={(e) => updateCpdLogRow(idx, "totalHours", e.target.value)} className="w-full px-2 py-4 bg-transparent outline-none text-sm text-center" placeholder="0" /></td>
                          <td className="border-r border-border h-full"><input type="number" step="0.5" value={row.ipcHours} onChange={(e) => updateCpdLogRow(idx, "ipcHours", e.target.value)} className="w-full px-2 py-4 bg-transparent outline-none text-sm text-center" placeholder="0" /></td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.type} onChange={(e) => updateCpdLogRow(idx, "type", e.target.value)} className="w-full px-6 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="Clinical/Non-clinical" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="border-r border-border h-full">
                            <select 
                              value={row.certHeld} 
                              onChange={(e) => updateCpdLogRow(idx, "certHeld", e.target.value)}
                              className="w-full px-2 py-4 bg-transparent outline-none text-sm text-center cursor-pointer appearance-none"
                            >
                              <option>Yes</option>
                              <option>No</option>
                            </select>
                          </td>
                          <td className="h-full"><textarea rows={1} value={row.notes} onChange={(e) => updateCpdLogRow(idx, "notes", e.target.value)} className="w-full px-6 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="Notes..." onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                        </tr>
                      ))}
                      {/* Running Total Row */}
                      <tr className="bg-muted/30 font-bold border-t border-border">
                        <td colSpan={4} className="px-6 py-4 text-right text-xs uppercase tracking-wider border-r border-border">Total Recorded Hours</td>
                        <td className="px-2 py-4 text-center text-sm border-r border-border">{cpdLogTotalHours}</td>
                        <td className="px-2 py-4 text-center text-sm border-r border-border">{cpdLogIpcHours}</td>
                        <td colSpan={3}></td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {/* Affirmation Section */}
                <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-6 space-y-4 mt-8">
                  <h3 className="text-sm font-bold text-zinc-700 uppercase tracking-wider border-b border-zinc-200 pb-2">Affirmation</h3>
                  <p className="text-sm text-zinc-600 italic">
                    I confirm that the CPD recorded in this log is accurate, verifiable, and meets DBA standards.
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Practice Owner / Principal Dentist</label>
                      <input 
                        type="text" 
                        value={cpdAffirmation.name} 
                        onChange={(e) => setCpdAffirmation({...cpdAffirmation, name: e.target.value})}
                        className="w-full bg-white border border-zinc-300 rounded-md px-3 py-2 text-sm outline-none focus:border-primary"
                        placeholder="Name..."
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Date</label>
                      <input 
                        type="text" 
                        value={cpdAffirmation.date} 
                        onChange={(e) => setCpdAffirmation({...cpdAffirmation, date: e.target.value})}
                        className="w-full bg-white border border-zinc-300 rounded-md px-3 py-2 text-sm outline-none focus:border-primary"
                        placeholder="DD/MM/YYYY"
                      />
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-col items-center gap-4 pt-4">
                  <div className="flex gap-4">
                    <button 
                      onClick={() => handleSaveCpdLogs(true)} 
                      className="bg-primary text-primary-foreground px-8 py-3 rounded-xl font-bold hover:opacity-90 shadow-lg"
                    >
                      Save Data
                    </button>
                  </div>
                  
                  {showSaved && (
                    <div className="flex items-center gap-2 px-6 py-2 rounded-full bg-green-100 text-green-700 border border-green-200 animate-in fade-in slide-in-from-top-2 duration-300">
                      <Check className="w-4 h-4" />
                      <span className="text-xs font-bold uppercase tracking-wider">Saved Successfully</span>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          ) : activeMenu === "immunisation_records" ? (
            <motion.div
              key="immunisation_records"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="w-full bg-card rounded-2xl border border-border p-10 shadow-sm relative overflow-x-auto"
              data-floating-panel="immunisation_records"
              ref={(el) => {
                if (!el) return;
                floatingPanelRef.current = el;
              }}
            >
              <div className="flex justify-between items-center mb-10">
                <div className="flex-1 text-center">
                  <h2
                    className="text-2xl font-display font-bold text-foreground"
                    data-floating-heading="1"
                    ref={(el) => {
                      if (!el) return;
                      floatingHeadingRef.current = el;
                    }}
                  >
                    Immunisation Records
                  </h2>
                  <h3 className="text-[10px] font-bold text-primary uppercase tracking-widest mt-2">
                    Staff Health & Safety
                  </h3>
                </div>
              </div>

              <div className="min-w-[1200px] space-y-8">
                {/* Preface Section */}
                <div className="bg-blue-50/50 p-6 rounded-xl border border-blue-100 space-y-4 text-sm text-blue-900 leading-relaxed">
                  <div>
                    <strong className="block text-blue-700 uppercase text-xs tracking-wider mb-1">Purpose</strong>
                    <p>
                      This summary records the immunisation status of all clinical and non-clinical staff at {pdfPracticeName ? <strong>{pdfPracticeName}</strong> : <span className="text-red-500 font-bold">[Clinic Name]</span>} who are at occupational risk of exposure to bloodborne viruses or other vaccine-preventable diseases. It demonstrates compliance with:
                    </p>
                    <ul className="list-disc pl-5 mt-1 space-y-1">
                      <li>Australian Immunisation Handbook (current edition, {currentYear} update) – recommendations for healthcare workers</li>
                      <li>ADA Guidelines for Infection Prevention and Control, 5th Edition (Section G – Immunisation & Health Monitoring)</li>
                      <li>Dental Board of Australia (DBA) expectations for staff health and safety</li>
                    </ul>
                  </div>
                  
                  <div>
                    <strong className="block text-blue-700 uppercase text-xs tracking-wider mb-1">Key Principles</strong>
                    <ul className="list-disc pl-5 mt-1 space-y-1">
                      <li>All clinical staff must be vaccinated against hepatitis B (or have documented immunity via serology).</li>
                      <li>It is recommended but not mandatory for non-clinical staff who may have incidental exposure (e.g., reception, cleaning, waste handling). Each practise must maintain a safe working environment and manage risks to staff and patients. So it is up to the practise to determine which non-clinical staff are required to be immunised against hepatitis B.</li>
                      <li>Other recommended vaccines for healthcare workers (e.g., MMR, varicella, dTpa/pertussis) are recorded where relevant.</li>
                      <li>Post-vaccination serological testing (anti-HBs) is performed 4–8 weeks after completion of the hepatitis B course for staff at risk.</li>
                      <li>Records are reviewed annually as part of the IPC manual review process.</li>
                      <li>Original vaccination certificates and serology reports are retained in individual staff files (digital or physical).</li>
                    </ul>
                  </div>
                </div>

                {/* Table Controls */}
                <div className="flex justify-end gap-2">
                  <button onClick={addImmunisationRow} className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-xs font-bold shadow-sm"><PlusCircle className="w-4 h-4" /> ADD ROW</button>
                  <button onClick={removeImmunisationRow} className="flex items-center gap-2 px-4 py-2 bg-muted text-foreground rounded-lg text-xs font-bold border border-border shadow-sm"><MinusCircle className="w-4 h-4" /> REMOVE SELECTED ROW(S)</button>
                </div>

                {/* Immunisation Table */}
                <div className="bg-background rounded-xl border border-border shadow-inner overflow-hidden">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-muted/50 border-b border-border">
                        <th className="px-2 py-4 text-center border-r border-border w-10">
                          <input type="checkbox" className="rounded border-gray-300" disabled />
                        </th>
                        <th className="px-4 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-40">Staff Member</th>
                        <th className="px-4 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-32">Vaccine</th>
                        <th className="px-4 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border">Course Completion Date</th>
                        <th className="px-4 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border">Serology Result (anti-HBs)</th>
                        <th className="px-4 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-32">Serology Date</th>
                        <th className="px-4 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-24">Booster Needed?</th>
                        <th className="px-4 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-24">Evidence Held (Y/N)</th>
                        <th className="px-4 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-32">Next Review Date</th>
                        <th className="px-4 py-4 text-center text-xs font-bold text-foreground/70 uppercase tracking-wider w-40">Evidence/Certificate Upload</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {immunisationRows.map((row: any, idx: number) => (
                        <tr key={idx} className="hover:bg-muted/5">
                          <td className="text-center border-r border-border bg-muted/5">
                            <input 
                              type="checkbox" 
                              checked={selectedImmunisationRows.has(idx)}
                              onChange={() => toggleRowSelection(idx, selectedImmunisationRows, setSelectedImmunisationRows)}
                              className="rounded border-gray-300"
                            />
                          </td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.staffMember} onChange={(e) => updateImmunisationRow(idx, "staffMember", e.target.value)} className="w-full px-4 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="Dr. Jane Smith" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.vaccine} onChange={(e) => updateImmunisationRow(idx, "vaccine", e.target.value)} className="w-full px-4 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="Hepatitis B" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.courseCompletionDate} onChange={(e) => updateImmunisationRow(idx, "courseCompletionDate", e.target.value)} className="w-full px-4 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="Completed 2018" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.serologyResult} onChange={(e) => updateImmunisationRow(idx, "serologyResult", e.target.value)} className="w-full px-4 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="≥10 mIU/mL (immune)" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.serologyDate} onChange={(e) => updateImmunisationRow(idx, "serologyDate", e.target.value)} className="w-full px-4 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="15/3/2018" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.boosterNeeded} onChange={(e) => updateImmunisationRow(idx, "boosterNeeded", e.target.value)} className="w-full px-4 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="No" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.evidenceHeld} onChange={(e) => updateImmunisationRow(idx, "evidenceHeld", e.target.value)} className="w-full px-4 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="Y" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.nextReviewDate} onChange={(e) => updateImmunisationRow(idx, "nextReviewDate", e.target.value)} className="w-full px-4 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="Jan-27" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="text-center h-full align-middle p-2">
                            <button 
                              onClick={() => {
                                if (row.evidenceUploaded) {
                                  const nr = [...immunisationRows];
                                  nr[idx].evidenceUploaded = "";
                                  setImmunisationRows(nr);
                                } else {
                                  setUploadModalState({ isOpen: true, section: 'immunisation', rowIndex: idx });
                                }
                              }}
                              className={cn(
                                "flex items-center gap-2 px-3 py-1.5 rounded-lg text-[10px] font-bold border mx-auto transition-all",
                                row.evidenceUploaded 
                                  ? "bg-green-100 text-green-700 border-green-200" 
                                  : "bg-muted hover:bg-muted/80 text-foreground border-border"
                              )}
                            >
                              <Upload className="w-3 h-3" /> 
                              {row.evidenceUploaded ? "UPLOADED" : "UPLOAD"}
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Affirmation Section */}
                <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-6 space-y-4 mt-8">
                  <h3 className="text-sm font-bold text-zinc-700 uppercase tracking-wider border-b border-zinc-200 pb-2">Affirmation</h3>
                  <p className="text-sm text-zinc-600 italic">
                    I confirm that the immunisation records summarised in this table are accurate, up to date, and held on file.
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Practice Owner / IPC Lead</label>
                      <input 
                        type="text" 
                        value={immunisationAffirmation.name} 
                        onChange={(e) => setImmunisationAffirmation({...immunisationAffirmation, name: e.target.value})}
                        className="w-full bg-white border border-zinc-300 rounded-md px-3 py-2 text-sm outline-none focus:border-primary"
                        placeholder="Name..."
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Date of Latest Review</label>
                      <input 
                        type="text" 
                        value={immunisationAffirmation.date} 
                        onChange={(e) => setImmunisationAffirmation({...immunisationAffirmation, date: e.target.value})}
                        className="w-full bg-white border border-zinc-300 rounded-md px-3 py-2 text-sm outline-none focus:border-primary"
                        placeholder="DD/MM/YYYY"
                      />
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-col items-center gap-4 pt-4">
                  <div className="flex gap-4">
                    <button 
                      onClick={() => handleSaveImmunisation(true)} 
                      className="bg-primary text-primary-foreground px-8 py-3 rounded-xl font-bold hover:opacity-90 shadow-lg"
                    >
                      Save Data
                    </button>
                  </div>
                  
                  {showSaved && (
                    <div className="flex items-center gap-2 px-6 py-2 rounded-full bg-green-100 text-green-700 border border-green-200 animate-in fade-in slide-in-from-top-2 duration-300">
                      <Check className="w-4 h-4" />
                      <span className="text-xs font-bold uppercase tracking-wider">Saved Successfully</span>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          ) : activeMenu === "dba_sub" ? (
            <motion.div
              key="dba_sub"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div
                className="w-full"
                data-floating-panel="dba_sub"
                ref={(el) => {
                  if (!el) return;
                  floatingPanelRef.current = el;
                  floatingHeadingRef.current = null;
                }}
              >
                <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 pl-12">
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  whileHover={{
                    y: -8,
                    scale: 1.02,
                    boxShadow: "0 15px 30px -5px rgb(0 0 0 / 0.1)",
                  }}
                  onClick={() => setActiveMenu("dba_affirmation")}
                  className="group cursor-pointer bg-card rounded-xl border border-border p-5 flex flex-col items-center justify-center text-center shadow-sm transition-all duration-200"
                  data-floating-first-tile="1"
                >
                  <div className="mb-3 p-3 rounded-lg bg-primary/5 group-hover:bg-primary/10 transition-colors">
                    <Plus className="h-7 w-7 text-primary" strokeWidth={1.8} />
                  </div>
                  <h2 className="text-primary font-display font-bold text-sm leading-tight mb-2">
                    Registration Renewal Affirmation
                  </h2>
                  <p className="text-[10px] text-muted-foreground leading-snug">
                    DBA/AHPRA renewal readiness checklist
                  </p>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  whileHover={{
                    y: -8,
                    scale: 1.02,
                    boxShadow: "0 15px 30px -5px rgb(0 0 0 / 0.1)",
                  }}
                  onClick={() => setActiveMenu("dba_templates")}
                  className="group cursor-pointer bg-card rounded-xl border border-border p-5 flex flex-col items-center justify-center text-center shadow-sm transition-all duration-200"
                >
                  <div className="mb-3 p-3 rounded-lg bg-primary/5 group-hover:bg-primary/10 transition-colors">
                    <FileText className="h-7 w-7 text-primary" strokeWidth={1.8} />
                  </div>
                  <h2 className="text-primary font-display font-bold text-sm leading-tight mb-2">
                    DBA Templates
                  </h2>
                  <p className="text-[10px] text-muted-foreground leading-snug">
                    Practise Records / Recency Evidence Summary
                  </p>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  whileHover={{
                    y: -8,
                    scale: 1.02,
                    boxShadow: "0 15px 30px -5px rgb(0 0 0 / 0.1)",
                  }}
                  onClick={() => { setSummaryType("dba"); setActiveMenu("pdf_summary"); }}
                  className="group cursor-pointer bg-card rounded-xl border border-border p-5 flex flex-col items-center justify-center text-center shadow-sm transition-all duration-200"
                >
                  <div className="mb-3 p-3 rounded-lg bg-primary/5 group-hover:bg-primary/10 transition-colors">
                    <Download className="h-7 w-7 text-primary" strokeWidth={1.8} />
                  </div>
                  <h2 className="text-primary font-display font-bold text-sm leading-tight mb-2">
                    FULL PDF SUMMARY
                  </h2>
                  <p className="text-[10px] text-muted-foreground leading-snug">
                    ONLY available when all requirements have been completed
                  </p>
                </motion.div>
                </div>
              </div>
            </motion.div>
          ) : activeMenu === "pdf_summary" ? (
            <motion.div
              id="pdf-summary-content"
              key="pdf_summary"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="pdf-page w-full max-w-5xl mx-auto bg-white dark:bg-zinc-900 rounded-2xl border-2 border-zinc-200 dark:border-zinc-800 shadow-2xl p-16 relative overflow-hidden"
              data-floating-panel="pdf_summary"
              ref={(el) => {
                if (!el) return;
                floatingPanelRef.current = el;
              }}
            >
              {(() => {
                const ipcRows = ipcAffirmations.flatMap((group, groupIdx) =>
                  group.items.map((requirement, itemIdx) => {
                    const fieldId = `ipc_aff_${groupIdx}_${itemIdx}`;
                    
                    // Logic to check readiness:
                    // 1. Check individual field in answers
                    // 2. OR check global "ipc_manual_approved" flag from localStorage (set when they click Save in affirmations)
                    // 3. OR check if they have completed the questionnaire (since this overlaps)
                    
                    // But specifically for "IPC Policy & Manual Affirmations", we use the "ipc_affirmations" section state.
                    // The 'answers' object is live state.
                    
                    // If the user has saved the IPC affirmations, we expect 'answers' to be populated?
                    // Or maybe we rely on the localStorage "ipc_manual_approved" to assume all are done?
                    
                    // Let's use a robust check:
                    // If "ipc_manual_approved" is true, we consider ALL ipc affirmations as "Ready"
                    // UNLESS we specifically have a "false" value in answers (unlikely if bulk approved)
                    
                    const isGloballyApproved = localStorage.getItem("ipc_manual_approved") === "true";
                    const isIndividuallyAffirmed = answers[fieldId] === "AFFIRMED";
                    
                    return {
                      section: group.topic,
                      requirement,
                      ready: isGloballyApproved || isIndividuallyAffirmed,
                    };
                  })
                );

                const dbaAffirmationSections = [
                  {
                    id: "pii",
                    number: "1",
                    title: "Professional Indemnity Insurance (PII)",
                    bullets: [
                      "Affirm that you have current PII that meets DBA requirements (minimum $5–10 million per claim / $15–20 million annual aggregate).",
                      "Cover includes civil liability for dental practice.",
                      "Run-off cover arranged if ceasing practice.",
                    ],
                    evidence: "Certificate of currency (dated within last 12 months).",
                    ready: answers.pii === "Affirm",
                    note: notes.pii,
                  },
                  {
                    id: "recency",
                    number: "2",
                    title: "Recency of Practice",
                    bullets: [
                      "Affirm that you have practised dentistry within the last 3 years (or met requirements via CPD/supervised practice).",
                      "If not, declare remedial training/conditions.",
                    ],
                    evidence: "CPD log, employment letters, or practice records.",
                    ready: answers.recency === "Affirm",
                    note: notes.recency,
                  },
                  {
                    id: "cpd",
                    number: "3",
                    title: "Continuing Professional Development (CPD)",
                    bullets: [
                      "Affirm completion of at least 60 hours of CPD over the 3-year cycle (min 10 hours/year average).",
                      "Includes mandatory: 10 hrs Infection Control, 4 hrs CPR, 4 hrs Radiation Safety.",
                    ],
                    evidence: "CPD log/portfolio with certificates, hours breakdown.",
                    ready: answers.cpd === "Affirm",
                    note: notes.cpd,
                  },
                  {
                    id: "ipc_affirm",
                    number: "4",
                    title: "Infection Prevention and Control",
                    bullets: [
                      "Affirm current, customised IPC systems in place (manual reviewed annually).",
                      "Staff trained, reprocessing compliant with AS 5369:2023.",
                    ],
                    evidence: "Completed IPC affirmation checklist + review log.",
                    ready: answers.ipc_affirm === "Affirm",
                    note: notes.ipc_affirm,
                  },
                  {
                    id: "fitness",
                    number: "5",
                    title: "Fitness to Practise / Health / Criminal History",
                    bullets: [
                      "Affirm no changes to health that impair safe practice.",
                      "Affirm no criminal history relevant to practice.",
                      "Affirm no notifications, conditions, or investigations since last renewal.",
                    ],
                    evidence: "None required unless declaring.",
                    ready: answers.fitness === "Affirm",
                    note: notes.fitness,
                  },
                ];

                const cpdForPdf = Array.isArray(cpdRows) ? cpdRows.filter((r: any) =>
                  r && [r.date, r.provider, r.hours, r.type, r.notes].some((v) => (v || "").toString().trim().length > 0)
                ) : [];

                const recencyForPdf = Array.isArray(recencyRows) ? recencyRows.filter((r) =>
                  r && [r.period, r.location, r.hours, r.supervisor].some((v) => (v || "").toString().trim().length > 0)
                ) : [];

                return (
                  <div className="space-y-10">
                    <div className="flex justify-between items-start border-b-4 border-primary pb-6">
                      <div>
                        <h1
                          className="text-3xl md:text-4xl font-display font-black text-zinc-900 dark:text-zinc-100 uppercase tracking-normal"
                          data-floating-heading="1"
                          ref={(el) => {
                            if (!el) return;
                            floatingHeadingRef.current = el;
                          }}
                        >
                          <span>FULL</span>
                          <span className="mx-2">PDF</span>
                          <span>SUMMARY</span>
                        </h1>
                        <p className="text-zinc-500 font-bold mt-3 text-base md:text-lg">
                          {summaryType === "ipc" ? "IPC Policy & Manual" : summaryType === "steriliser" ? "Steriliser PQ Validation" : summaryType === "staff" ? "Staff Training & Immunisation" : "DBA Affirmations"}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-zinc-400 text-xs font-mono">{pdfDate}</p>
                      </div>
                    </div>

                    <div className="avoid-break grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="space-y-2">
                        <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">Dentist's Name</p>
                        <input
                          value={pdfDentistName}
                          readOnly
                          className="w-full bg-transparent border-b border-zinc-300 dark:border-zinc-700 px-0 py-2 text-sm font-semibold text-zinc-900 dark:text-zinc-100 outline-none"
                          placeholder="Fill out 'Your Details'"
                        />
                      </div>
                      <div className="space-y-2">
                        <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">Practice Name</p>
                        <input
                          value={pdfPracticeName}
                          readOnly
                          className="w-full bg-transparent border-b border-zinc-300 dark:border-zinc-700 px-0 py-2 text-sm font-semibold text-zinc-900 dark:text-zinc-100 outline-none"
                          placeholder="Fill out 'Your Details'"
                        />
                      </div>
                      <div className="space-y-2">
                        <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">Date</p>
                        <input
                          value={pdfDate}
                          onChange={(e) => setPdfDate(e.target.value)}
                          className="no-print w-full bg-transparent border-b border-zinc-300 dark:border-zinc-700 px-0 py-2 text-sm font-semibold text-zinc-900 dark:text-zinc-100 outline-none"
                          placeholder="DD MMM YYYY"
                        />
                      </div>
                    </div>

                    {summaryType === "ipc" ? (
                      <div className="space-y-4">
                        <div className="bg-zinc-50 dark:bg-zinc-800/50 p-4 rounded-xl border border-zinc-200 dark:border-zinc-800 space-y-3">
                          <h3 className="text-xs font-black text-zinc-500 uppercase tracking-widest border-b border-zinc-200 dark:border-zinc-700 pb-2">Review Log / Change Summary</h3>
                          <div className="space-y-3">
                            {/* Preface for Review Log */}
                            <div className="text-[10px] text-zinc-500 space-y-2 border-b border-zinc-200 dark:border-zinc-700 pb-3 mb-3">
                              <p><strong>Purpose:</strong> This log records each review of the Infection Prevention and Control Manual against the most current standards (DBA, ADA 5th Ed, AS 5369:2023).</p>
                              <p><strong>Key Principles:</strong> Annual review required; updates actioned; forms part of compliance evidence.</p>
                            </div>
                            
                            <table className="w-full border-collapse mb-4">
                              <thead>
                                <tr className="bg-zinc-100 dark:bg-zinc-800 border-b border-zinc-200 dark:border-zinc-700">
                                  <th className="px-2 py-1 text-left text-[10px] font-bold text-zinc-500 uppercase">Version</th>
                                  <th className="px-2 py-1 text-left text-[10px] font-bold text-zinc-500 uppercase">Date</th>
                                  <th className="px-2 py-1 text-left text-[10px] font-bold text-zinc-500 uppercase">Reviewed Against</th>
                                  <th className="px-2 py-1 text-left text-[10px] font-bold text-zinc-500 uppercase">Changes</th>
                                  <th className="px-2 py-1 text-left text-[10px] font-bold text-zinc-500 uppercase">Reviewed By</th>
                                </tr>
                              </thead>
                              <tbody>
                                {reviewRows.filter(r => r.version || r.date).map((row, idx) => (
                                  <tr key={idx} className="border-b border-zinc-100 dark:border-zinc-800 last:border-b-0">
                                    <td className="px-2 py-1 text-[10px] align-top">{row.version}</td>
                                    <td className="px-2 py-1 text-[10px] align-top">{row.date}</td>
                                    <td className="px-2 py-1 text-[10px] align-top">{row.reviewedAgainst}</td>
                                    <td className="px-2 py-1 text-[10px] align-top">{row.changes}</td>
                                    <td className="px-2 py-1 text-[10px] align-top">{row.reviewedBy}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>

                            <div className="avoid-break flex justify-between items-end pt-2">
                              <div className="text-[10px]">
                                <p className="text-zinc-500">I confirm that I have personally reviewed the current manual against the latest standards and that the entries in this log are accurate.</p>
                              </div>
                              <div className="text-right">
                                <p className="text-[10px] font-bold text-zinc-900">{reviewAffirmation.name}</p>
                                <p className="text-[10px] text-zinc-500">{reviewAffirmation.date}</p>
                              </div>
                            </div>
                          </div>
                        </div>

                        <h3 className="text-xs font-black text-zinc-500 uppercase tracking-widest border-b border-zinc-100 dark:border-zinc-800 pb-2">IPC Policy & Manual Affirmations</h3>
                        <div className="border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden">
                          <table className="w-full border-collapse">
                            <thead>
                              <tr className="bg-zinc-50 dark:bg-zinc-800/50 border-b border-zinc-200 dark:border-zinc-800">
                                <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800 w-48">Section</th>
                                <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800">Requirement</th>
                                <th className="px-4 py-3 text-center text-[10px] font-bold text-zinc-500 uppercase tracking-widest w-36">Status</th>
                              </tr>
                            </thead>
                            <tbody>
                              {ipcRows.map((row: any, idx: number) => (
                                <tr key={idx} className="border-b border-zinc-100 dark:border-zinc-800 last:border-b-0">
                                  <td className="px-4 py-3 text-xs text-zinc-700 dark:text-zinc-300 align-top border-r border-zinc-100 dark:border-zinc-800">{row.section}</td>
                                  <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top border-r border-zinc-100 dark:border-zinc-800">{row.requirement}</td>
                                  <td className="px-4 py-3 text-xs align-middle text-center">
                                    <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-800">
                                      {row.ready ? "READY" : "NEEDS ATTENTION"}
                                    </span>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    ) : summaryType === "steriliser" ? (
                      <div className="space-y-4">
                        <h3 className="text-xs font-black text-zinc-500 uppercase tracking-widest border-b border-zinc-100 dark:border-zinc-800 pb-2">Steriliser Performance Qualification (PQ) Log</h3>
                        <div className="bg-zinc-50 dark:bg-zinc-800/50 p-3 mb-4 rounded-xl border border-zinc-200 dark:border-zinc-800 text-[10px] text-zinc-600 space-y-2">
                          <p><strong>Requirement (AS 5369:2023 & ADA Guidelines 5th Edition Section F):</strong> You are required to verify sterilisation efficacy annually, or immediately after purchasing or installing a new steriliser. This record documents that a qualified steriliser technician has performed and certified the Performance Qualification (PQ) in accordance with AS 5369:2023.</p>
                          <p><strong>Note:</strong> Batch monitoring records are separate and must be kept in daily logbook.</p>
                        </div>
                        <div className="border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden">
                          <table className="w-full border-collapse">
                            <thead>
                              <tr className="bg-zinc-50 dark:bg-zinc-800/50 border-b border-zinc-200 dark:border-zinc-800">
                                <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800 w-32">Date</th>
                                <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800">Technician</th>
                                <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800">Equipment / NATA</th>
                                <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Notes</th>
                              </tr>
                            </thead>
                            <tbody>
                              {steriliserPQRows.map((row: any, idx: number) => (
                                <tr key={idx} className="border-b border-zinc-100 dark:border-zinc-800 last:border-b-0">
                                  <td className="px-4 py-3 text-xs text-zinc-700 dark:text-zinc-300 align-top border-r border-zinc-100 dark:border-zinc-800">{row.date}</td>
                                  <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top border-r border-zinc-100 dark:border-zinc-800">{row.technician}</td>
                                  <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top border-r border-zinc-100 dark:border-zinc-800">{row.equipmentId}</td>
                                  <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top">{row.notes}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    ) : summaryType === "staff" ? (
                      <div className="space-y-4">
                          <h3 className="text-xs font-black text-zinc-500 uppercase tracking-widest border-b border-zinc-100 dark:border-zinc-800 pb-2">Staff Training Register</h3>
                          
                          {/* Staff Training Preface */}
                          <div className="bg-zinc-50 dark:bg-zinc-800/50 p-3 mb-4 rounded-xl border border-zinc-200 dark:border-zinc-800 text-[10px] text-zinc-600 space-y-2">
                            <p><strong>Purpose:</strong> This register records all infection prevention and control (IPC) training provided to staff. It demonstrates compliance with DBA requirements, ADA Guidelines 5th Ed., and NHMRC Guidelines.</p>
                            <p><strong>Affirmation:</strong> I confirm that the training recorded in this register is accurate and has been delivered as stated.</p>
                            <div className="flex gap-4 pt-1">
                              <p><strong>Practice Owner / IPC Lead:</strong> {staffTrainingAffirmation.name || "____________"}</p>
                              <p><strong>Date:</strong> {staffTrainingAffirmation.date || "____________"}</p>
                            </div>
                          </div>

                          <div className="border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden mb-8">
                            <table className="w-full border-collapse">
                              <thead>
                                <tr className="bg-zinc-50 dark:bg-zinc-800/50 border-b border-zinc-200 dark:border-zinc-800">
                                  <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800 w-48">Name</th>
                                  <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800 w-32">Date</th>
                                  <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800">Topic(s)</th>
                                  <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Provider / Method</th>
                                </tr>
                              </thead>
                              <tbody>
                                {staffTrainingRows.map((row: any, idx: number) => (
                                  <tr key={idx} className="border-b border-zinc-100 dark:border-zinc-800 last:border-b-0">
                                    <td className="px-4 py-3 text-xs text-zinc-700 dark:text-zinc-300 align-top border-r border-zinc-100 dark:border-zinc-800">{row.name}</td>
                                    <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top border-r border-zinc-100 dark:border-zinc-800">{row.date}</td>
                                    <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top border-r border-zinc-100 dark:border-zinc-800">{row.topic}</td>
                                    <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top">{row.provider}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>

                          <h3 className="text-xs font-black text-zinc-500 uppercase tracking-widest border-b border-zinc-100 dark:border-zinc-800 pb-2">CPD Logs</h3>
                          
                          {/* CPD Preface */}
                          <div className="bg-zinc-50 dark:bg-zinc-800/50 p-3 mb-4 rounded-xl border border-zinc-200 dark:border-zinc-800 text-[10px] text-zinc-600 space-y-2">
                            <p><strong>Purpose:</strong> This log records continuing professional development (CPD) activities completed by registered dental practitioners. It demonstrates compliance with DBA Registration Standard: Continuing Professional Development.</p>
                            <p><strong>Affirmation:</strong> I confirm that the CPD recorded in this log is accurate, verifiable, and meets DBA standards.</p>
                            <div className="flex gap-4 pt-1">
                              <p><strong>Practice Owner / Principal Dentist:</strong> {cpdAffirmation.name || "____________"}</p>
                              <p><strong>Date:</strong> {cpdAffirmation.date || "____________"}</p>
                            </div>
                          </div>

                          <div className="border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden mb-8">
                            <table className="w-full border-collapse">
                              <thead>
                                <tr className="bg-zinc-50 dark:bg-zinc-800/50 border-b border-zinc-200 dark:border-zinc-800">
                                  <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800 w-40">Practitioner</th>
                                  <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800">Topic</th>
                                  <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800 w-24">Date</th>
                                  <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800">Provider</th>
                                  <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800 w-16">Total Hrs</th>
                                  <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800 w-16">IPC Hrs</th>
                                  <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800 w-20">Cert (Y/N)</th>
                                </tr>
                              </thead>
                              <tbody>
                                {cpdLogRows.map((row: any, idx: number) => (
                                  <tr key={idx} className="border-b border-zinc-100 dark:border-zinc-800 last:border-b-0">
                                    <td className="px-4 py-3 text-xs text-zinc-700 dark:text-zinc-300 align-top border-r border-zinc-100 dark:border-zinc-800">{row.practitioner}</td>
                                    <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top border-r border-zinc-100 dark:border-zinc-800">{row.topic}</td>
                                    <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top border-r border-zinc-100 dark:border-zinc-800">{row.date}</td>
                                    <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top border-r border-zinc-100 dark:border-zinc-800">{row.provider}</td>
                                    <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top border-r border-zinc-100 dark:border-zinc-800">{row.totalHours}</td>
                                    <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top border-r border-zinc-100 dark:border-zinc-800">{row.ipcHours}</td>
                                    <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top border-r border-zinc-100 dark:border-zinc-800">{row.certHeld}</td>
                                  </tr>
                                ))}
                                <tr className="bg-zinc-50 dark:bg-zinc-800/50 font-bold border-t border-zinc-200 dark:border-zinc-800">
                                  <td colSpan={4} className="px-4 py-3 text-right text-[10px] uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800">Total Recorded Hours</td>
                                  <td className="px-4 py-3 text-xs border-r border-zinc-200 dark:border-zinc-800">{cpdLogTotalHours}</td>
                                  <td className="px-4 py-3 text-xs border-r border-zinc-200 dark:border-zinc-800">{cpdLogIpcHours}</td>
                                  <td className="px-4 py-3"></td>
                                </tr>
                              </tbody>
                            </table>
                          </div>

                          <h3 className="text-xs font-black text-zinc-500 uppercase tracking-widest border-b border-zinc-100 dark:border-zinc-800 pb-2">Immunisation Records</h3>
                          
                          {/* Immunisation Preface */}
                          <div className="bg-zinc-50 dark:bg-zinc-800/50 p-3 mb-4 rounded-xl border border-zinc-200 dark:border-zinc-800 text-[10px] text-zinc-600 space-y-2">
                            <p><strong>Purpose:</strong> This summary records the immunisation status of all clinical and non-clinical staff at {pdfPracticeName || "[Clinic Name]"} who are at occupational risk of exposure to bloodborne viruses or other vaccine-preventable diseases.</p>
                            <p><strong>Affirmation:</strong> I confirm that the immunisation records summarised in this table are accurate, up to date, and held on file.</p>
                            <div className="flex gap-4 pt-1">
                              <p><strong>Practice Owner / IPC Lead:</strong> {immunisationAffirmation.name || "____________"}</p>
                              <p><strong>Date:</strong> {immunisationAffirmation.date || "____________"}</p>
                            </div>
                          </div>

                          <div className="border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden">
                            <table className="w-full border-collapse">
                              <thead>
                                <tr className="bg-zinc-50 dark:bg-zinc-800/50 border-b border-zinc-200 dark:border-zinc-800">
                                  <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800 w-32">Staff Member</th>
                                  <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800 w-24">Vaccine</th>
                                  <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800">Course Date</th>
                                  <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800">Serology Result</th>
                                  <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800 w-24">Booster?</th>
                                  <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800 w-16">Evid.</th>
                                  <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest w-24">Review</th>
                                </tr>
                              </thead>
                              <tbody>
                                {immunisationRows.map((row: any, idx: number) => (
                                  <tr key={idx} className="border-b border-zinc-100 dark:border-zinc-800 last:border-b-0">
                                    <td className="px-4 py-3 text-xs text-zinc-700 dark:text-zinc-300 align-top border-r border-zinc-100 dark:border-zinc-800">{row.staffMember}</td>
                                    <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top border-r border-zinc-100 dark:border-zinc-800">{row.vaccine}</td>
                                    <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top border-r border-zinc-100 dark:border-zinc-800">{row.courseCompletionDate}</td>
                                    <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top border-r border-zinc-100 dark:border-zinc-800">{row.serologyResult}</td>
                                    <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top border-r border-zinc-100 dark:border-zinc-800">{row.boosterNeeded}</td>
                                    <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top border-r border-zinc-100 dark:border-zinc-800">{row.evidenceHeld}</td>
                                    <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top">{row.nextReviewDate}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      ) : (
                      <div className="space-y-10">
                        <div className="space-y-4">
                          <h3 className="text-xs font-black text-zinc-500 uppercase tracking-widest border-b border-zinc-100 dark:border-zinc-800 pb-2">Registration Renewal Affirmation</h3>
                          <div className="space-y-4">
                            {dbaAffirmationSections.map((sec) => (
                              <div key={sec.id} className="border border-zinc-200 dark:border-zinc-800 rounded-xl p-5 space-y-3">
                                <div className="flex items-start justify-between gap-6">
                                  <p className="text-sm font-black text-zinc-900 dark:text-zinc-100">
                                    {sec.number}. {sec.title}
                                  </p>
                                  <span className="shrink-0 text-[10px] font-bold uppercase tracking-wider text-zinc-800">
                                    {sec.ready ? "AFFIRMED" : "NEEDS ATTENTION"}
                                  </span>
                                </div>

                                <ul className="list-disc pl-5 space-y-1 text-xs text-zinc-800 dark:text-zinc-200">
                                  {sec.bullets.map((b: string, i: number) => (
                                    <li key={i}>{b}</li>
                                  ))}
                                </ul>

                                <p className="text-xs text-zinc-700 dark:text-zinc-300">
                                  <span className="font-bold">Evidence:</span> {sec.evidence}
                                </p>

                                {typeof sec.note === "string" && sec.note.trim().length > 0 && (
                                  <p className="text-xs text-zinc-700 dark:text-zinc-300">
                                    <span className="font-bold">Notes:</span> {sec.note}
                                  </p>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>

                        <div className="space-y-4">
                          <h3 className="text-xs font-black text-zinc-500 uppercase tracking-widest border-b border-zinc-100 dark:border-zinc-800 pb-2">DBA Templates</h3>

                          <div className="bg-blue-50/50 p-4 rounded-xl border border-blue-100 mb-4">
                            <div className="flex gap-3">
                              <AlertCircle className="w-5 h-5 text-blue-600 shrink-0" />
                              <div className="space-y-2">
                                <p className="text-xs text-blue-800 font-medium leading-relaxed">
                                  <strong>AHPRA Reminder:</strong> Remember to log your personal CPD hours (including IPC-focused hours) directly in the AHPRA portal during renewal. Use your CPD log in this portal to prepare your hours breakdown.
                                </p>
                                <div className="flex items-center gap-2">
                                  <input 
                                    type="checkbox" 
                                    id="ahpra_logged" 
                                    className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
                                  />
                                  <label htmlFor="ahpra_logged" className="text-xs text-blue-900 font-bold cursor-pointer">
                                    I have logged my CPD (including IPC hours) in the AHPRA renewal form
                                  </label>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Preface Section */}
                          <div className="bg-blue-50/50 p-6 rounded-xl border border-blue-100 space-y-4 text-sm text-blue-900 leading-relaxed mb-4">
                            <div>
                              <strong className="block text-blue-700 uppercase text-xs tracking-wider mb-1">Purpose</strong>
                              <p>
                                This log records continuing professional development (CPD) activities completed by registered dental practitioners at {pdfPracticeName ? <strong>{pdfPracticeName}</strong> : <span className="text-red-500 font-bold">[Please fill in the clinic name in 'Your Details']</span>}. It demonstrates compliance with:
                              </p>
                              <ul className="list-disc pl-5 mt-1 space-y-1">
                                <li>Dental Board of Australia (DBA) Registration Standard: Continuing Professional Development</li>
                                <li>Minimum 60 hours over 3 years (average 10 hours per year)</li>
                                <li>Mandatory CPD requirements including infection prevention and control (IPC), CPR/first aid, and radiation safety (where applicable)</li>
                                <li>ADA Guidelines for Infection Prevention and Control, 5th Edition (ongoing IPC education emphasis)</li>
                              </ul>
                            </div>
                            
                            <div>
                              <strong className="block text-blue-700 uppercase text-xs tracking-wider mb-1">Key Principles</strong>
                              <ul className="list-disc pl-5 mt-1 space-y-1">
                                <li>All registered practitioners must complete at least 60 hours of CPD over the current 3-year cycle (current cycle: [e.g., {currentYear}–{currentYear + 2}]).</li>
                                <li>IPC-focused CPD is tracked separately to demonstrate ongoing competency in infection prevention (recommended minimum 10–20 hours per cycle).</li>
                                <li>Records include certificates, attendance sheets, or verification of completion.</li>
                                <li>This log is reviewed annually as part of the IPC manual and overall compliance process.</li>
                              </ul>
                            </div>
                          </div>

                          <div className="border border-zinc-200 dark:border-zinc-800 rounded-xl p-5 space-y-4">
                            <div className="flex items-start justify-between gap-6">
                              <p className="text-sm font-black text-zinc-900 dark:text-zinc-100">CPD Log / Hours Breakdown</p>
                              <div className="text-right">
                                <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">Total Hours</p>
                                <p className="text-sm font-black text-zinc-900 dark:text-zinc-100">{totalHours}</p>
                              </div>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                              <div>
                                <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">Infection Control</p>
                                <p className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">{infectionControlHours}</p>
                              </div>
                              <div>
                                <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">CPR</p>
                                <p className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">{cprHours}</p>
                              </div>
                              <div>
                                <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">Other</p>
                                <p className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">{Math.max(0, totalHours - infectionControlHours - cprHours)}</p>
                              </div>
                            </div>

                            {cpdForPdf.length === 0 ? (
                              <p className="text-xs text-zinc-500">No CPD entries recorded.</p>
                            ) : (
                              <div className="border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden">
                                <table className="w-full border-collapse">
                                  <thead>
                                    <tr className="bg-zinc-50 dark:bg-zinc-800/50 border-b border-zinc-200 dark:border-zinc-800">
                                      <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800 w-28">Date</th>
                                      <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800">Provider / Topic</th>
                                      <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800 w-20">Hours</th>
                                      <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800 w-32">Type</th>
                                      <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Notes</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {cpdForPdf.map((r: any, idx) => (
                                      <tr key={idx} className="border-b border-zinc-100 dark:border-zinc-800 last:border-b-0">
                                        <td className="px-4 py-3 text-xs text-zinc-700 dark:text-zinc-300 align-top border-r border-zinc-100 dark:border-zinc-800">{r.date || ""}</td>
                                        <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top border-r border-zinc-100 dark:border-zinc-800">{r.provider || ""}</td>
                                        <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top border-r border-zinc-100 dark:border-zinc-800">{r.hours || ""}</td>
                                        <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top border-r border-zinc-100 dark:border-zinc-800">{r.type || ""}</td>
                                        <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top">{r.notes || ""}</td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            )}
                          </div>

                          <div className="border border-zinc-200 dark:border-zinc-800 rounded-xl p-5 space-y-4">
                            <p className="text-sm font-black text-zinc-900 dark:text-zinc-100">Practice Records / Recency Evidence Summary</p>
                            {recencyForPdf.length === 0 ? (
                              <p className="text-xs text-zinc-500">No recency entries recorded.</p>
                            ) : (
                              <div className="border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden">
                                <table className="w-full border-collapse">
                                  <thead>
                                    <tr className="bg-zinc-50 dark:bg-zinc-800/50 border-b border-zinc-200 dark:border-zinc-800">
                                      <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800">Period</th>
                                      <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800">Location</th>
                                      <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest border-r border-zinc-200 dark:border-zinc-800 w-28">Hours/week</th>
                                      <th className="px-4 py-3 text-left text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Supervisor</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {recencyForPdf.map((r, idx) => (
                                      <tr key={idx} className="border-b border-zinc-100 dark:border-zinc-800 last:border-b-0">
                                        <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top border-r border-zinc-100 dark:border-zinc-800">{r.period || ""}</td>
                                        <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top border-r border-zinc-100 dark:border-zinc-800">{r.location || ""}</td>
                                        <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top border-r border-zinc-100 dark:border-zinc-800">{r.hours || ""}</td>
                                        <td className="px-4 py-3 text-xs text-zinc-800 dark:text-zinc-200 align-top">{r.supervisor || ""}</td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    )}

                    <div className="avoid-break space-y-6 pt-6 border-t border-zinc-100 dark:border-zinc-800 break-inside-avoid page-break-inside-avoid" data-pdf-keep-together="true">
                      <p className="text-sm text-zinc-800 dark:text-zinc-200 font-medium">
                        I have reviewed all requirements and am prepared to affirm compliance on renewal.
                      </p>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div className="space-y-2">
                          <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">Signature (Write)</p>
                          <div className="h-24 border border-zinc-300 dark:border-zinc-700 rounded-lg" />
                        </div>

                        <div className="space-y-2">
                          <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">Signature (Upload)</p>
                          <div 
                              className="cursor-pointer"
                              onClick={() => signatureInputRef.current?.click()}
                          >
                              {signatureDataUrl ? (
                                <div className="border border-zinc-300 dark:border-zinc-700 rounded-lg p-3 bg-white dark:bg-zinc-900">
                                  <img src={signatureDataUrl} alt={signatureFileName || "Signature"} className="max-h-24 object-contain" />
                                </div>
                              ) : (
                                <div className="h-24 border border-dashed border-zinc-300 dark:border-zinc-700 rounded-lg flex items-center justify-center text-xs text-zinc-400 hover:bg-zinc-50 dark:hover:bg-zinc-800 transition-colors">
                                  Click to upload signature image
                                </div>
                              )}
                          </div>
                          <input
                            ref={signatureInputRef}
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={handleSignatureUpload}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="avoid-break flex justify-between items-center pt-6 border-t border-zinc-100 dark:border-zinc-800 no-print">
                      <div className="flex gap-4 items-center">
                        {/* Removed Official Compliance Record text as requested */}
                      </div>
                      <div className="flex gap-4">
                          <button
                            onClick={handleSavePdf}
                            disabled={isGeneratingPdf}
                            className="bg-primary text-primary-foreground px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:opacity-90 transition-all shadow-lg text-xs md:text-sm disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            {isGeneratingPdf ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                            {isGeneratingPdf ? "GENERATING PDF..." : "SAVE & DOWNLOAD PDF"}
                          </button>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </motion.div>
          ) : activeMenu === "mobile_upload" ? (
             <div className="w-full bg-card rounded-2xl border border-border p-8 shadow-sm relative h-full flex flex-col justify-center pt-12">
                <header className="mb-6 text-center relative">
                   <button 
                      onClick={() => setActiveMenu("main")}
                      className="absolute top-1/2 left-0 -translate-y-1/2 p-2 text-muted-foreground hover:text-foreground hover:bg-muted/50 rounded-full transition-all"
                   >
                      <ArrowLeft className="w-8 h-8" />
                   </button>
                   <h2 className="text-xl font-display font-bold text-foreground">Document Snap</h2>
                   <p className="text-xs text-muted-foreground mt-1 max-w-xs mx-auto">Snap & upload certs/receipts directly</p>
                </header>
                
                <div className="max-w-md mx-auto w-full">
                   <label className="flex flex-col items-center justify-center w-full h-72 border-2 border-primary/50 border-dashed rounded-3xl cursor-pointer bg-muted/30 hover:bg-primary/5 transition-colors">
                      <div className="flex flex-col items-center justify-center">
                         <Camera className="w-20 h-20 text-primary mb-6" strokeWidth={1.5} />
                         <p className="mb-2 text-xl font-bold text-foreground">Tap to take a photo</p>
                         <p className="text-sm text-muted-foreground">or select from library</p>
                      </div>
                      <input type="file" className="hidden" accept="image/*" capture="environment" onChange={handleMobileScan} />
                   </label>
                </div>
             </div>
          ) : activeMenu === "search_results" ? (
            <motion.div
              key="search_results"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="w-full bg-card rounded-2xl border border-border p-10 shadow-sm relative"
            >
              <header className="mb-10 text-center relative">
                <button 
                  onClick={() => {
                    setActiveMenu("main");
                    setSearchQuery("");
                  }}
                  className="absolute top-1/2 left-0 -translate-y-1/2 p-2 text-muted-foreground hover:text-foreground hover:bg-muted/50 rounded-full transition-all"
                >
                  <ArrowLeft className="w-8 h-8" />
                </button>
                <h2 className="text-2xl font-display font-bold text-foreground">
                  Search Results
                </h2>
                <p className="text-sm text-muted-foreground mt-2">
                  Results for "<span className="font-semibold text-primary">{searchQuery}</span>"
                </p>
              </header>

              <div className="max-w-4xl mx-auto space-y-8">
                {/* 1. Menu Tiles (Navigation) */}
                <section>
                  <h3 className="text-xs font-bold text-foreground/50 uppercase tracking-wider mb-4 pb-2 border-b border-border">
                    Menu Items
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {(() => {
                      const filteredTiles = tiles.filter(tile => 
                        (tile.title || "").toLowerCase().includes(searchQuery.toLowerCase()) || 
                        (tile.desc || "").toLowerCase().includes(searchQuery.toLowerCase())
                      );
                      
                      const showUpload = ("document snap".includes(searchQuery.toLowerCase()) || "upload".includes(searchQuery.toLowerCase()));
                      
                      if (filteredTiles.length === 0 && !showUpload) {
                        return <p className="text-sm text-muted-foreground italic col-span-full">No matching menu items.</p>;
                      }

                      return (
                        <>
                          {filteredTiles.map(tile => (
                            <div 
                              key={tile.id}
                              onClick={() => {
                                if (tile.id === "ipc") setActiveMenu("ipc");
                                if (tile.id === "affirmation") setActiveMenu("dba_sub");
                                if (tile.id === "steriliser") setActiveMenu("steriliser_pq");
                                if (tile.id === "training") setActiveMenu("staff_training");
                                if (tile.id === "gap") setActiveMenu("gap_analysis");
                              }}
                              className="cursor-pointer bg-card hover:bg-accent/5 border border-border hover:border-primary/50 p-4 rounded-xl transition-all flex items-center gap-4"
                            >
                              <div className="p-2 bg-primary/10 rounded-lg">
                                <tile.icon className="h-5 w-5 text-primary" />
                              </div>
                              <div>
                                <h4 className="font-bold text-sm text-foreground">{tile.title}</h4>
                                <p className="text-xs text-muted-foreground">{tile.desc}</p>
                              </div>
                            </div>
                          ))}
                          {/* Add manual matches for sub-menus if needed */}
                          {showUpload && (
                             <div 
                              onClick={() => setActiveMenu("mobile_upload")}
                              className="cursor-pointer bg-card hover:bg-accent/5 border border-border hover:border-primary/50 p-4 rounded-xl transition-all flex items-center gap-4"
                            >
                              <div className="p-2 bg-primary/10 rounded-lg">
                                <Camera className="h-5 w-5 text-primary" />
                              </div>
                              <div>
                                <h4 className="font-bold text-sm text-foreground">Document Snap</h4>
                                <p className="text-xs text-muted-foreground">Capture & Upload</p>
                              </div>
                            </div>
                          )}
                        </>
                      );
                    })()}
                  </div>
                </section>

                {/* 2. Tasks */}
                <section>
                  <h3 className="text-xs font-bold text-foreground/50 uppercase tracking-wider mb-4 pb-2 border-b border-border">
                    Tasks
                  </h3>
                  <div className="space-y-3">
                    {(() => {
                      const filteredTasks = renewalTasks.filter(task => {
                        // Safety check
                        if (!task) return false;
                        // Skip headings
                        if ((task as any).type === "heading") return false;
                        
                        const title = task.title || "";
                        const category = (task as any).category || "";
                        
                        return title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                               category.toLowerCase().includes(searchQuery.toLowerCase());
                      });

                      if (filteredTasks.length === 0) {
                        return <p className="text-sm text-muted-foreground italic">No matching tasks found.</p>;
                      }

                      return filteredTasks.map(task => {
                        // Determine status/color
                        const t = task as any;
                        let statusColor = "bg-amber-500";
                        let statusText = "";
                        
                        if (typeof t.progress === "number") {
                           if (t.progress === 100) statusColor = "bg-green-500";
                           else if (t.progress > 0) statusColor = "bg-blue-500";
                           statusText = `${t.progress}%`;
                        } else if (typeof t.status === "string") {
                           if (t.status === "COMPLETE" || t.status === "Completed") statusColor = "bg-green-500";
                           else if (t.status === "INCOMPLETE") statusColor = "bg-red-500";
                           statusText = t.status;
                        }

                        return (
                          <div 
                            key={task.id} 
                            onClick={() => {
                              // Navigation logic based on task ID
                              if (task.id === "clinic_specific") setActiveMenu("questionnaire");
                              if (task.id === "ipc_affirm_task") setActiveMenu("ipc_affirmations");
                              if (task.id === "review_log") setActiveMenu("review_log");
                              if (task.id === "dba_affirm_task") setActiveMenu("dba_affirmation");
                              if (task.id === "pii_cert") setActiveMenu("dba_templates");
                              if (task.id === "dba_templates") setActiveMenu("dba_templates");
                              if (task.id === "steriliser") setActiveMenu("steriliser_pq");
                              if (task.id === "staff_training") setActiveMenu("staff_training_register");
                              if (task.id === "immunisation") setActiveMenu("immunisation_records");
                              if (task.id === "cpd_logs_task") setActiveMenu("cpd_logs");
                              if (task.id === "gap_analysis") setActiveMenu("gap_analysis");
                            }}
                            className="bg-card border border-border hover:border-primary/50 cursor-pointer p-4 rounded-xl flex justify-between items-center transition-all"
                          >
                            <div className="flex items-center gap-3">
                              <div className={cn("w-2 h-2 rounded-full", statusColor)} />
                              <div>
                                <h4 className="font-bold text-sm text-foreground">{task.title}</h4>
                                <p className="text-xs text-muted-foreground">{(task as any).category}</p>
                              </div>
                            </div>
                            <span className="text-xs font-mono bg-muted px-2 py-1 rounded">{statusText}</span>
                          </div>
                        );
                      });
                    })()}
                  </div>
                </section>

                {/* 3. Affirmations / Content */}
                <section>
                  <h3 className="text-xs font-bold text-foreground/50 uppercase tracking-wider mb-4 pb-2 border-b border-border">
                    Content & Requirements
                  </h3>
                  <div className="space-y-3">
                    {(() => {
                      // 1. IPC Affirmations
                      const ipcMatches = ipcAffirmations.flatMap(group => 
                        group.items
                          .filter(item => (item || "").toLowerCase().includes(searchQuery.toLowerCase()))
                          .map((item, idx) => ({ type: 'ipc', group, item, idx }))
                      );

                      // 2. Clinic Profile Questions
                      const profileMatches = clinicProfileQuestions
                        .filter(q => (q.label || "").toLowerCase().includes(searchQuery.toLowerCase()))
                        .map(q => ({ type: 'profile', item: q.label, id: q.id }));

                      // 3. DBA Affirmations
                      const dbaMatches = [
                        { title: "Professional Indemnity Insurance (PII)", desc: "Affirm that you have current PII that meets DBA requirements.", id: "pii" },
                        { title: "Recency of Practice", desc: "Affirm that you have practised dentistry within the last 3 years.", id: "recency" },
                        { title: "Continuing Professional Development (CPD)", desc: "Affirm completion of at least 60 hours of CPD over the 3-year cycle.", id: "cpd" },
                        { title: "Infection Prevention and Control", desc: "Affirm current, customised IPC systems in place.", id: "ipc_affirm" },
                        { title: "Fitness to Practise / Health / Criminal History", desc: "Affirm no changes to health or criminal history.", id: "fitness" },
                      ].filter(item => item.title.toLowerCase().includes(searchQuery.toLowerCase()) || item.desc.toLowerCase().includes(searchQuery.toLowerCase()))
                       .map(item => ({ type: 'dba', ...item }));

                      // 4. Gap Analysis
                      const gapMatches = GapSections.flatMap(sec => 
                        sec.questions.filter(q => q.text.toLowerCase().includes(searchQuery.toLowerCase()) || q.guidance.toLowerCase().includes(searchQuery.toLowerCase()))
                        .map(q => ({ type: 'gap', section: sec.title, question: q.text, guidance: q.guidance }))
                      );

                      // 5. Static Content (Steriliser, Logs, etc.)
                      const staticMatches = [
                        { title: "Steriliser PQ Validation", desc: "Performance Qualification (PQ) conducted annually by qualified technician.", target: "steriliser_pq" },
                        { title: "Staff Training Register", desc: "Record of staff IPC training, dates, and evidence.", target: "staff_training_register" },
                        { title: "CPD Logs", desc: "Track continuing professional development hours and certificates.", target: "cpd_logs" },
                        { title: "Immunisation Records", desc: "Staff vaccination status and serology records.", target: "immunisation_records" },
                        { title: "Review Log", desc: "Log of manual reviews and changes.", target: "review_log" },
                      ].filter(item => item.title.toLowerCase().includes(searchQuery.toLowerCase()) || item.desc.toLowerCase().includes(searchQuery.toLowerCase()))
                       .map(item => ({ type: 'static', ...item }));

                      // 6. Passages & Prefaces
                      const passageMatches = [
                         // CPD Template
                         { 
                           title: "CPD Log Purpose", 
                           text: "This log records continuing professional development (CPD) activities completed by registered dental practitioners. It demonstrates compliance with Dental Board of Australia (DBA) Registration Standard.", 
                           target: "dba_templates", 
                           subTarget: "cpd" 
                         },
                         { 
                           title: "CPD Key Principles", 
                           text: "All registered practitioners must complete at least 60 hours of CPD over the current 3-year cycle. IPC-focused CPD is tracked separately.", 
                           target: "dba_templates", 
                           subTarget: "cpd" 
                         },
                         // PII Template
                         {
                           title: "PII Action Item",
                           text: "PII certificates must be updated annually. Ensure your policy meets the minimum aggregate requirements before renewing registration.",
                           target: "dba_templates",
                           subTarget: "pii"
                         },
                         // Recency Template
                         {
                           title: "Recency Employment Log",
                           text: "Log of employment period, location, hours per week, and supervisor details to demonstrate recency of practice.",
                           target: "dba_templates",
                           subTarget: "recency"
                         },
                         // DBA Affirmation Guidance
                         {
                           title: "DBA Renewal Guidance",
                           text: "Guidance Note: This tool is a preparation aid only. Always refer to the current AHPRA/DBA renewal form.",
                           target: "dba_affirmation"
                         },
                         // Mobile Upload
                         {
                           title: "Document Snap",
                           text: "Tap to take a photo or select from library. Snap & upload certs/receipts directly.",
                           target: "mobile_upload"
                         },
                         // Gap Analysis Intro (from Wizard)
                         {
                           title: "Gap Analysis Disclaimer",
                           text: "A formal, documented gap analysis against AS 5369:2023 is NOT mandatory for most dental practices. It is only required if your practice is pursuing or maintaining accreditation.",
                           target: "gap_analysis"
                         }
                      ].filter(p => p.title.toLowerCase().includes(searchQuery.toLowerCase()) || p.text.toLowerCase().includes(searchQuery.toLowerCase()))
                       .map(p => ({ type: 'passage', ...p }));

                      const allMatches = [...ipcMatches, ...profileMatches, ...dbaMatches, ...gapMatches, ...staticMatches, ...passageMatches];

                      if (allMatches.length === 0) {
                        return <p className="text-sm text-muted-foreground italic">No matching content found.</p>;
                      }

                      return allMatches.map((match: any, i) => {
                         if (match.type === 'ipc') {
                            return (
                              <div key={`ipc-${match.group.topic}-${match.idx}-${i}`} 
                                   onClick={() => setActiveMenu("ipc_affirmations")}
                                   className="cursor-pointer bg-card hover:bg-accent/5 border border-border hover:border-primary/50 p-4 rounded-xl transition-all"
                              >
                                <p className="text-xs font-bold text-primary mb-1">{match.group.topic} (IPC Manual)</p>
                                <p className="text-sm text-foreground">{match.item}</p>
                              </div>
                            );
                         } else if (match.type === 'profile') {
                            return (
                              <div key={`profile-${match.id}-${i}`} 
                                   onClick={() => setActiveMenu("questionnaire")}
                                   className="cursor-pointer bg-card hover:bg-accent/5 border border-border hover:border-primary/50 p-4 rounded-xl transition-all"
                              >
                                <p className="text-xs font-bold text-primary mb-1">Clinic Profile & Procedures</p>
                                <p className="text-sm text-foreground">{match.item}</p>
                              </div>
                            );
                         } else if (match.type === 'dba') {
                            return (
                              <div key={`dba-${match.id}-${i}`} 
                                   onClick={() => setActiveMenu("dba_affirmation")}
                                   className="cursor-pointer bg-card hover:bg-accent/5 border border-border hover:border-primary/50 p-4 rounded-xl transition-all"
                              >
                                <p className="text-xs font-bold text-primary mb-1">DBA Affirmation</p>
                                <p className="font-bold text-sm text-foreground">{match.title}</p>
                                <p className="text-xs text-muted-foreground">{match.desc}</p>
                              </div>
                            );
                         } else if (match.type === 'gap') {
                            return (
                              <div key={`gap-${i}`} 
                                   onClick={() => setActiveMenu("gap_analysis")}
                                   className="cursor-pointer bg-card hover:bg-accent/5 border border-border hover:border-primary/50 p-4 rounded-xl transition-all"
                              >
                                <p className="text-xs font-bold text-primary mb-1">Gap Analysis: {match.section}</p>
                                <p className="font-bold text-sm text-foreground">{match.question}</p>
                                <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{match.guidance}</p>
                              </div>
                            );
                         } else if (match.type === 'static') {
                            return (
                              <div key={`static-${i}`} 
                                   onClick={() => setActiveMenu(match.target)}
                                   className="cursor-pointer bg-card hover:bg-accent/5 border border-border hover:border-primary/50 p-4 rounded-xl transition-all"
                              >
                                <p className="text-xs font-bold text-primary mb-1">Section</p>
                                <p className="font-bold text-sm text-foreground">{match.title}</p>
                                <p className="text-xs text-muted-foreground">{match.desc}</p>
                              </div>
                            );
                         } else if (match.type === 'passage') {
                            return (
                              <div key={`passage-${i}`} 
                                   onClick={() => {
                                      setActiveMenu(match.target);
                                      if (match.subTarget) setActiveTemplate(match.subTarget);
                                   }}
                                   className="cursor-pointer bg-card hover:bg-accent/5 border border-border hover:border-primary/50 p-4 rounded-xl transition-all"
                              >
                                <p className="text-xs font-bold text-primary mb-1">Information / Passage</p>
                                <p className="font-bold text-sm text-foreground">{match.title}</p>
                                <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{match.text}</p>
                              </div>
                            );
                         }
                         return null;
                      });
                    })()}
                  </div>
                </section>
              </div>
            </motion.div>
          ) : activeMenu === "cpd_breakdown" ? (
            <motion.div
              key="cpd_breakdown"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="w-full bg-card rounded-2xl border border-border p-10 shadow-sm relative"
            >
              <header className="mb-8 text-center relative">
                <button
                  onClick={() => setActiveMenu("main")}
                  className="absolute left-0 top-1/2 -translate-y-1/2 p-2 hover:bg-muted rounded-full transition-colors"
                  aria-label="Go back"
                >
                  <ArrowLeft className="w-6 h-6 text-muted-foreground" />
                </button>
                <h2 className="text-2xl font-display font-bold text-foreground">
                  CPD Log / Hours Breakdown Template
                </h2>
                <p className="text-muted-foreground mt-2">
                  Compliance templates and logs for DBA registration standards
                </p>
              </header>

              {previewImage && (
                <div 
                    className="fixed inset-0 z-[9999] bg-black/80 flex items-center justify-center p-4 animate-in fade-in duration-200"
                    onClick={() => setPreviewImage(null)}
                >
                    <div className="relative max-w-4xl max-h-[90vh] bg-background rounded-xl overflow-hidden shadow-2xl">
                        <button 
                            onClick={() => setPreviewImage(null)}
                            className="absolute top-2 right-2 p-2 bg-black/50 text-white rounded-full hover:bg-black/70 transition-colors z-10"
                        >
                            <X className="w-5 h-5" />
                        </button>
                        <img 
                            src={previewImage} 
                            alt="Snap Preview" 
                            className="w-full h-full object-contain"
                            onClick={(e) => e.stopPropagation()} 
                        />
                    </div>
                </div>
              )}

              <div className="max-w-6xl mx-auto space-y-6">
                      {/* Preface Section */}
                      <div className="bg-blue-50/50 p-6 rounded-xl border border-blue-100 space-y-4 text-sm text-blue-900 leading-relaxed">
                        <div>
                          <strong className="block text-blue-700 uppercase text-xs tracking-wider mb-1">Purpose</strong>
                          <p>
                            This log records continuing professional development (CPD) activities completed by registered dental practitioners.
                          </p>
                          <ul className="list-disc pl-5 mt-1 space-y-1">
                            <li>Dental Board of Australia (DBA) Registration Standard: Continuing Professional Development</li>
                            <li>Minimum 60 hours over 3 years (average 10 hours per year)</li>
                            <li>Mandatory CPD requirements including infection prevention and control (IPC), CPR/first aid, and radiation safety (where applicable)</li>
                            <li>ADA Guidelines for Infection Prevention and Control, 5th Edition (ongoing IPC education emphasis)</li>
                          </ul>
                        </div>
                        
                        <div>
                          <strong className="block text-blue-700 uppercase text-xs tracking-wider mb-1">Key Principles</strong>
                          <ul className="list-disc pl-5 mt-1 space-y-1">
                            <li>All registered practitioners must complete at least 60 hours of CPD over the current 3-year cycle.</li>
                            <li>IPC-focused CPD is tracked separately to demonstrate ongoing competency in infection prevention (recommended minimum 10–20 hours per cycle).</li>
                            <li>Records include certificates, attendance sheets, or verification of completion.</li>
                          </ul>
                        </div>
                      </div>

                      <div className="flex justify-between items-center bg-muted/30 p-4 rounded-xl border border-border/50 mb-6">
                        <div className="flex gap-6">
                          <div className="text-center">
                            <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Total Hours</p>
                            <p className="text-xl font-bold text-primary">{totalHours}</p>
                          </div>
                          <div className="text-center">
                            <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Infection Control (min 10)</p>
                            <p className={cn("text-xl font-bold", infectionControlHours >= 10 ? "text-green-600" : "text-red-500")}>{infectionControlHours}</p>
                          </div>
                          <div className="text-center">
                            <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">CPR (min 4)</p>
                            <p className={cn("text-xl font-bold", cprHours >= 4 ? "text-green-600" : "text-red-500")}>{cprHours}</p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <button onClick={addCpdRow} className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-xs font-bold hover:opacity-90 transition-all shadow-sm">
                            <PlusCircle className="w-4 h-4" /> ADD ROW
                          </button>
                          <button onClick={removeCpdRow} className="flex items-center gap-2 px-4 py-2 bg-muted text-foreground rounded-lg text-xs font-bold hover:bg-muted/80 transition-all border border-border shadow-sm">
                            <MinusCircle className="w-4 h-4" /> REMOVE SELECTED ROW(S)
                          </button>
                        </div>
                      </div>

                      <div className={cn("bg-background rounded-xl border shadow-inner overflow-hidden", cpdErrors.size > 0 ? "border-red-500 ring-2 ring-red-100" : "border-border")}>
                        <table className="w-full border-collapse">
                          <thead>
                            <tr className="bg-muted/50 border-b border-border">
                              <th className="px-2 py-4 text-center border-r border-border w-10">
                                <input type="checkbox" className="rounded border-gray-300" disabled />
                              </th>
                              <th className="px-4 py-4 text-left text-[10px] font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-32">Date</th>
                              <th className="px-4 py-4 text-left text-[10px] font-bold text-foreground/70 uppercase tracking-wider border-r border-border">Provider / Topic</th>
                              <th className="px-4 py-4 text-left text-[10px] font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-20">Hours</th>
                              <th className="px-4 py-4 text-left text-[10px] font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-40">Type</th>
                              <th className="px-4 py-4 text-left text-[10px] font-bold text-foreground/70 uppercase tracking-wider">Snap Preview</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-border">
                            {Array.isArray(cpdRows) && cpdRows.map((row: any, idx: number) => {
                              if (!row) return null;
                              return (
                              <tr key={idx} className={cn("hover:bg-muted/5", cpdErrors.has(idx) && "bg-red-50/50")}>
                                <td className="text-center border-r border-border bg-muted/5">
                                  <input 
                                    type="checkbox" 
                                    checked={selectedCpdRows.has(idx)}
                                    onChange={() => toggleRowSelection(idx, selectedCpdRows, setSelectedCpdRows)}
                                    className="rounded border-gray-300"
                                  />
                                </td>
                                <td className="border-r border-border h-full"><textarea rows={1} value={row.date} onChange={(e) => { const nr = [...cpdRows]; nr[idx].date = e.target.value; setCpdRows(nr); }} className="w-full px-4 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="14 Jan 2026" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                                <td className="border-r border-border h-full"><textarea rows={1} value={row.provider} onChange={(e) => { const nr = [...cpdRows]; nr[idx].provider = e.target.value; setCpdRows(nr); }} className="w-full px-4 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="ADA" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                                <td className="border-r border-border text-center"><input type="number" value={row.hours} onChange={(e) => {
                                  const nr = [...cpdRows];
                                  nr[idx].hours = e.target.value;
                                  setCpdRows(nr);
                                }} className="w-full px-4 py-4 bg-transparent outline-none text-sm text-center" /></td>
                                <td className="border-r border-border">
                                  <select value={row.type} className="w-full px-4 py-4 bg-transparent outline-none text-sm" onChange={(e) => {
                                    const nr = [...cpdRows];
                                    nr[idx].type = e.target.value;
                                    setCpdRows(nr);
                                  }}>
                                    <option value="">Select...</option>
                                    <option value="Clinical CPD">Clinical CPD</option>
                                    <option value="Scientific CPD">Scientific CPD</option>
                                    <option value="Other CPD">Other CPD</option>

                                  </select>
                                </td>
                                <td className="h-full">
                                    {row.snapImage ? (
                                        <div 
                                            className="p-2 cursor-pointer hover:opacity-80 transition-opacity"
                                            onClick={() => setPreviewImage(row.snapImage)}
                                        >
                                            <img src={row.snapImage} alt="Snap" className="h-16 w-auto object-cover rounded border border-border" />
                                        </div>
                                    ) : (
                                        <span className="text-xs text-muted-foreground px-4 py-4 block">No snap</span>
                                    )}
                                </td>
                              </tr>
                            );
                            })}
                          </tbody>
                        </table>
                      </div>
                      <div className="flex flex-col items-center justify-center pt-8 gap-4">
                        <button onClick={handleSave} className="bg-primary text-primary-foreground px-12 py-3 rounded-xl font-bold hover:opacity-90 transition-all shadow-lg flex items-center gap-2">
                          Save Annual Summary Sheet
                        </button>
                        {showSaved && (
                          <div className="flex items-center gap-2 px-6 py-2 rounded-full bg-green-100 text-green-700 border border-green-200 animate-in fade-in slide-in-from-top-2 duration-300">
                            <Check className="w-4 h-4" />
                            <span className="text-xs font-bold uppercase tracking-wider">Changes Saved</span>
                          </div>
                        )}
                      </div>
              </div>
            </motion.div>
          ) : activeMenu === "dba_templates" ? (
            <motion.div
              key="dba_templates"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="w-full bg-card rounded-2xl border border-border p-10 shadow-sm relative"
              data-floating-panel="dba_templates"
              ref={(el) => {
                if (!el) return;
                floatingPanelRef.current = el;
              }}
            >
              <header className="mb-8 text-center">
                <h2 
                  className="text-2xl font-display font-bold text-foreground"
                  data-floating-heading="1"
                  ref={(el) => {
                    if (!el) return;
                    floatingHeadingRef.current = el;
                  }}
                >
                  Practise Records / PII
                </h2>
                <p className="text-muted-foreground mt-2">
                  Compliance templates and logs for DBA registration standards
                </p>
              </header>

              <div className="flex justify-center mb-12">
                <div
                  className="inline-flex bg-muted/50 p-1 rounded-xl border border-border"
                >
                  {[
                    { id: "recency", label: "Practice Records / Recency Evidence Summary" },
                    { id: "pii", label: "PII Certificate Tracker" },
                  ].map((btn) => (
                    <button
                      key={btn.id}
                      onClick={() => setActiveTemplate(btn.id as any)}
                      className={cn(
                        "px-6 py-2.5 text-xs font-bold rounded-lg transition-all",
                        activeTemplate === btn.id
                          ? "bg-background text-primary shadow-sm ring-1 ring-border"
                          : "text-muted-foreground hover:text-foreground"
                      )}
                    >
                      {btn.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="max-w-6xl mx-auto">
                <AnimatePresence mode="wait">
                  {activeTemplate === "recency" && (
                    <motion.div key="recency" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-4">
                      <div className="space-y-4">
                        <h4 className="text-sm font-bold text-foreground/80 border-b border-border pb-2 uppercase tracking-wider">Employment Log</h4>
                        
                        <div className="flex justify-end gap-2">
                          <button onClick={addRecencyRow} className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-xs font-bold shadow-sm"><PlusCircle className="w-4 h-4" /> ADD ROW</button>
                          <button onClick={removeRecencyRow} className="flex items-center gap-2 px-4 py-2 bg-muted text-foreground rounded-lg text-xs font-bold border border-border shadow-sm"><MinusCircle className="w-4 h-4" /> REMOVE SELECTED ROW(S)</button>
                        </div>

                        <div className={cn("bg-background rounded-xl border shadow-inner overflow-hidden", recencyErrors.size > 0 ? "border-red-500 ring-2 ring-red-100" : "border-border")}>
                          <table className="w-full border-collapse">
                            <thead>
                              <tr className="bg-muted/50 border-b border-border">
                                <th className="px-2 py-4 text-center border-r border-border w-10">
                                  <input type="checkbox" className="rounded border-gray-300" disabled />
                                </th>
                                <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border">Period</th>
                                <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border">Location</th>
                                <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border">Hours per week</th>
                                <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider">Supervisor (if applicable)</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-border">
                              {recencyRows.map((row, idx) => (
                                <tr key={idx} className={cn("hover:bg-muted/5", recencyErrors.has(idx) && "bg-red-50/50")}>
                                  <td className="text-center border-r border-border bg-muted/5">
                                    <input 
                                      type="checkbox" 
                                      checked={selectedRecencyRows.has(idx)}
                                      onChange={() => toggleRowSelection(idx, selectedRecencyRows, setSelectedRecencyRows)}
                                      className="rounded border-gray-300"
                                    />
                                  </td>
                                  <td className="border-r border-border h-full"><textarea rows={1} value={row.period} onChange={(e) => { const nr = [...recencyRows]; nr[idx].period = e.target.value; setRecencyRows(nr); }} className="w-full px-6 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                                  <td className="border-r border-border h-full"><textarea rows={1} value={row.location} onChange={(e) => { const nr = [...recencyRows]; nr[idx].location = e.target.value; setRecencyRows(nr); }} className="w-full px-6 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                                  <td className="border-r border-border h-full"><textarea rows={1} value={row.hours} onChange={(e) => { const nr = [...recencyRows]; nr[idx].hours = e.target.value; setRecencyRows(nr); }} className="w-full px-6 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                                  <td className="h-full"><textarea rows={1} value={row.supervisor} onChange={(e) => { const nr = [...recencyRows]; nr[idx].supervisor = e.target.value; setRecencyRows(nr); }} className="w-full px-6 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>

                      <div className="flex flex-col items-center gap-4 pt-4">
                        <button className="flex items-center gap-2 px-8 py-3 bg-muted hover:bg-muted/80 text-foreground rounded-xl text-xs font-bold border border-border transition-all shadow-sm">
                          <Upload className="w-4 h-4" /> PROOF OF OWNERSHIP
                        </button>

                        <div className="flex items-start gap-3 p-4 bg-primary/5 rounded-2xl border border-primary/10 max-w-2xl">
                          <input type="checkbox" id="recency_decl" className="mt-1 w-5 h-5 rounded border-border text-primary shrink-0" />
                          <label htmlFor="recency_decl" className="text-xs text-foreground/80 leading-relaxed font-medium">I declare that I have met the DBA recency of practice requirements for the 2026 renewal cycle and hold evidence to support this declaration.</label>
                        </div>

                        <button onClick={handleSave} className="bg-primary text-primary-foreground px-12 py-3 rounded-xl font-bold hover:opacity-90 shadow-lg">Save Annual Summary Sheet</button>
                        {showSaved && (
                          <div className="flex items-center gap-2 px-6 py-2 rounded-full bg-green-100 text-green-700 border border-green-200 animate-in fade-in slide-in-from-top-2 duration-300">
                            <Check className="w-4 h-4" />
                            <span className="text-xs font-bold uppercase tracking-wider">Changes Saved</span>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  )}

                  {activeTemplate === "pii" && (
                    <motion.div key="pii" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-8 max-w-4xl mx-auto">
                      <div className="bg-card rounded-2xl border border-border p-8 shadow-sm space-y-6">
                        <div className="flex items-start gap-4 p-4 bg-blue-50/50 rounded-xl border border-blue-100">
                          <AlertTriangle className="w-5 h-5 text-blue-600 mt-0.5" />
                          <p className="text-xs text-blue-800 leading-relaxed font-medium">Action Item: PII certificates must be updated annually. Ensure your policy meets the minimum aggregate requirements before renewing registration.</p>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="space-y-2">
                            <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Insurer</label>
                            <input
                              type="text"
                              value={piiTracker.insurer}
                              onChange={(e) => setPiiTracker(prev => ({ ...prev, insurer: e.target.value }))}
                              className={cn("w-full bg-background border border-border p-3 rounded-lg text-sm", piiErrors.includes("insurer") && "border-red-500 ring-2 ring-red-100")}
                              placeholder="e.g. Guild Insurance"
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Policy Number</label>
                            <input
                              type="text"
                              value={piiTracker.policyNumber}
                              onChange={(e) => setPiiTracker(prev => ({ ...prev, policyNumber: e.target.value }))}
                              className={cn("w-full bg-background border border-border p-3 rounded-lg text-sm", piiErrors.includes("policyNumber") && "border-red-500 ring-2 ring-red-100")}
                              placeholder="XXXX-XXXX-XXXX"
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Expiry Date</label>
                            <input
                              type="text"
                              value={piiTracker.expiryDate}
                              onChange={(e) => setPiiTracker(prev => ({ ...prev, expiryDate: e.target.value }))}
                              className={cn("w-full bg-background border border-border p-3 rounded-lg text-sm", piiErrors.includes("expiryDate") && "border-red-500 ring-2 ring-red-100")}
                              placeholder="31 Dec 2026"
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Coverage Limits</label>
                            <input
                              type="text"
                              value={piiTracker.coverageLimits}
                              onChange={(e) => setPiiTracker(prev => ({ ...prev, coverageLimits: e.target.value }))}
                              className={cn("w-full bg-background border border-border p-3 rounded-lg text-sm", piiErrors.includes("coverageLimits") && "border-red-500 ring-2 ring-red-100")}
                              placeholder="e.g. $20M Aggregate"
                            />
                          </div>
                        </div>
                        <div className="pt-6 border-t border-border flex flex-col items-center justify-center gap-4">
                          <button onClick={handleSave} className="bg-primary text-primary-foreground px-12 py-3 rounded-xl font-bold hover:opacity-90 shadow-lg">Update PII Tracker</button>
                          {showSaved && (
                            <div className="flex items-center gap-2 px-6 py-2 rounded-full bg-green-100 text-green-700 border border-green-200 animate-in fade-in slide-in-from-top-2 duration-300">
                              <Check className="w-4 h-4" />
                              <span className="text-xs font-bold uppercase tracking-wider">Changes Saved</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          ) : activeMenu === "steriliser_pq" ? (
            <motion.div
              key="steriliser_pq"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div
                className="w-full"
                data-floating-panel="steriliser_pq"
                ref={(el) => {
                  if (!el) return;
                  floatingPanelRef.current = el;
                  floatingHeadingRef.current = null;
                }}
              >
                <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 pl-12">
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    whileHover={{
                      y: -8,
                      scale: 1.02,
                      boxShadow: "0 15px 30px -5px rgb(0 0 0 / 0.1)",
                    }}
                    onClick={() => setActiveMenu("steriliser_pq_log")}
                    className="group cursor-pointer bg-card rounded-xl border border-border p-5 flex flex-col items-center justify-center text-center shadow-sm transition-all duration-200"
                    data-floating-first-tile="1"
                  >
                    <div className="mb-3 p-3 rounded-lg bg-primary/5 group-hover:bg-primary/10 transition-colors">
                      <Cog className="h-7 w-7 text-primary" strokeWidth={1.8} />
                    </div>
                    <h2 className="text-primary font-display font-bold text-sm leading-tight mb-2">
                      Performance Qualification & Technician Reporting
                    </h2>
                    <p className="text-[10px] text-muted-foreground leading-snug">
                      Log annual validation records
                    </p>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 }}
                    whileHover={{
                      y: -8,
                      scale: 1.02,
                      boxShadow: "0 15px 30px -5px rgb(0 0 0 / 0.1)",
                    }}
                    onClick={() => {
                      handleSaveSteriliser(false);
                      setSummaryType("steriliser");
                      setActiveMenu("pdf_summary");
                    }}
                    className="group cursor-pointer bg-card rounded-xl border border-border p-5 flex flex-col items-center justify-center text-center shadow-sm transition-all duration-200"
                  >
                    <div className="mb-3 p-3 rounded-lg bg-primary/5 group-hover:bg-primary/10 transition-colors">
                      <FileText className="h-7 w-7 text-primary" strokeWidth={1.8} />
                    </div>
                    <h2 className="text-primary font-display font-bold text-sm leading-tight mb-2">
                      FULL PDF SUMMARY
                    </h2>
                    <p className="text-[10px] text-muted-foreground leading-snug">
                      Download validation summary
                    </p>
                  </motion.div>
                </div>
              </div>
            </motion.div>
          ) : activeMenu === "gap_analysis" ? (
            <motion.div
              key="gap-analysis"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="w-full bg-card rounded-2xl border border-border p-10 shadow-sm relative"
              data-floating-panel="gap_analysis"
              ref={(el) => {
                if (!el) return;
                floatingPanelRef.current = el;
              }}
            >
              <GapAnalysisWizard 
                onComplete={(score) => setGapAnalysisScore(score)}
                onClose={() => setActiveMenu("main")}
              />
            </motion.div>
          ) : activeMenu === "steriliser_pq_log" ? (
            <motion.div
              key="steriliser_pq_log"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="w-full bg-card rounded-2xl border border-border p-10 shadow-sm relative"
              data-floating-panel="steriliser_pq_log"
              ref={(el) => {
                if (!el) return;
                floatingPanelRef.current = el;
              }}
            >
              <div className="flex justify-between items-center mb-10">
                <div className="flex-1 text-center">
                  <h2
                    className="text-2xl font-display font-bold text-foreground"
                    data-floating-heading="1"
                    ref={(el) => {
                      if (!el) return;
                      floatingHeadingRef.current = el;
                    }}
                  >
                    Steriliser Annual Validation (PQ)
                  </h2>
                  <h3 className="text-[10px] font-bold text-primary uppercase tracking-widest mt-2">
                    Performance Qualification & Technician Reporting
                  </h3>
                </div>
              </div>

              <div className="max-w-6xl mx-auto space-y-8">
                <div className="bg-blue-50/50 p-6 rounded-xl border border-blue-100 space-y-2">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                    <div className="text-sm text-blue-800 leading-relaxed font-medium">
                      <p>
                        <strong>Requirement (AS 5369:2023 & ADA Guidelines 5th Edition Section F):</strong> You are required to verify sterilisation efficacy annually, or immediately after purchasing or installing a new steriliser. This record documents that a qualified steriliser technician has performed and certified the Performance Qualification (PQ) in accordance with AS 5369:2023.
                      </p>
                      <div className="mt-3 text-xs text-blue-700">
                        <strong className="block text-blue-800 uppercase text-[10px] tracking-widest mb-1">IMPORTANT NOTE:</strong>
                        <p className="leading-relaxed">Batch monitoring records (daily/weekly chemical, biological, and physical indicators) are <strong>separate</strong> from this annual validation report and must be maintained in your daily steriliser logbook.</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end gap-2">
                  <button onClick={addSteriliserRow} className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-xs font-bold shadow-sm"><PlusCircle className="w-4 h-4" /> ADD ROW</button>
                  <button onClick={removeSteriliserRow} className="flex items-center gap-2 px-4 py-2 bg-muted text-foreground rounded-lg text-xs font-bold border border-border shadow-sm"><MinusCircle className="w-4 h-4" /> REMOVE SELECTED ROW(S)</button>
                </div>

                <div className="bg-background rounded-xl border border-border shadow-inner overflow-hidden">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-muted/50 border-b border-border">
                        <th className="px-2 py-4 text-center border-r border-border w-10">
                          <input type="checkbox" className="rounded border-gray-300" disabled />
                        </th>
                        <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-32">Date</th>
                        <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border">Technician Details</th>
                        <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border">Equipment ID / NATA Proof</th>
                        <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border">Notes</th>
                        <th className="px-6 py-4 text-center text-xs font-bold text-foreground/70 uppercase tracking-wider w-40">Certificate</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {steriliserPQRows.map((row: any, idx: number) => (
                        <tr key={idx} className="hover:bg-muted/5">
                          <td className="text-center border-r border-border bg-muted/5">
                            <input 
                              type="checkbox" 
                              checked={selectedSteriliserPQRows.has(idx)}
                              onChange={() => toggleRowSelection(idx, selectedSteriliserPQRows, setSelectedSteriliserPQRows)}
                              className="rounded border-gray-300"
                            />
                          </td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.date} onChange={(e) => { const nr = [...steriliserPQRows]; nr[idx].date = e.target.value; setSteriliserPQRows(nr); }} className="w-full px-6 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="DD/MM/YYYY" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.technician} onChange={(e) => { const nr = [...steriliserPQRows]; nr[idx].technician = e.target.value; setSteriliserPQRows(nr); }} className="w-full px-6 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="Name / Company" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.equipmentId} onChange={(e) => { const nr = [...steriliserPQRows]; nr[idx].equipmentId = e.target.value; setSteriliserPQRows(nr); }} className="w-full px-6 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="ID / Cert #" onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="border-r border-border h-full"><textarea rows={1} value={row.notes} onChange={(e) => { const nr = [...steriliserPQRows]; nr[idx].notes = e.target.value; setSteriliserPQRows(nr); }} className="w-full px-6 py-4 bg-transparent outline-none text-sm resize-none overflow-hidden h-full" placeholder="Compliance notes..." onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }} /></td>
                          <td className="text-center h-full align-middle p-2">
                            <button 
                              onClick={() => {
                                if (row.certAttached) {
                                  const nr = [...steriliserPQRows];
                                  nr[idx].certAttached = "";
                                  setSteriliserPQRows(nr);
                                } else {
                                  setUploadModalState({ isOpen: true, section: 'steriliser', rowIndex: idx });
                                }
                              }}
                              className={cn(
                                "flex items-center gap-2 px-3 py-1.5 rounded-lg text-[10px] font-bold border mx-auto transition-all",
                                row.certAttached 
                                  ? "bg-green-100 text-green-700 border-green-200" 
                                  : "bg-muted hover:bg-muted/80 text-foreground border-border"
                              )}
                            >
                              <Upload className="w-3 h-3" /> 
                              {row.certAttached ? "UPLOADED" : "UPLOAD"}
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="flex flex-col items-center gap-4 pt-4">
                  <div className="flex gap-4">
                    <button 
                      onClick={() => handleSaveSteriliser(true)} 
                      className="bg-primary text-primary-foreground px-8 py-3 rounded-xl font-bold hover:opacity-90 shadow-lg"
                    >
                      Save Data
                    </button>

                  </div>
                  
                  {showSaved && (
                    <div className="flex items-center gap-2 px-6 py-2 rounded-full bg-green-100 text-green-700 border border-green-200 animate-in fade-in slide-in-from-top-2 duration-300">
                      <Check className="w-4 h-4" />
                      <span className="text-xs font-bold uppercase tracking-wider">Saved Successfully</span>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          ) : activeMenu === "dba_affirmation" ? (
            <motion.div
              key="dba_affirmation"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="w-full bg-card rounded-2xl border border-border p-10 shadow-sm relative"
              data-floating-panel="dba_affirmation"
              ref={(el) => {
                if (!el) return;
                floatingPanelRef.current = el;
              }}
            >
              <header className="mb-6 text-center">
                <h2
                  className="text-2xl font-display font-bold text-foreground"
                  data-floating-heading="1"
                  ref={(el) => {
                    if (!el) return;
                    floatingHeadingRef.current = el;
                  }}
                >
                  DBA Registration Renewal Affirmation
                </h2>
                <h3 className="text-[10px] font-bold text-primary uppercase tracking-widest mt-2">
                    Interactive Readiness Checklist ({nextYear} DBA/AHPRA)
                  </h3>
                </header>



              <div className="max-w-5xl mx-auto mb-10 p-6 bg-blue-50/50 rounded-xl border border-blue-100 flex flex-col gap-4">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                  <p className="text-xs text-blue-800 leading-relaxed font-medium">
                    Guidance Note: This tool is a preparation aid only. Always refer to the current AHPRA/DBA renewal form.
                  </p>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    { label: "AHPRA Portal", href: "https://www.ahpra.gov.au/Login.aspx" },
                    { label: "Code of Conduct", href: "https://www.dentalboard.gov.au/Codes-Guidelines/Policies-Codes-Guidelines/Code-of-conduct.aspx" },
                    { label: "Advertising Guidelines", href: "https://www.dentalboard.gov.au/Codes-Guidelines/Advertising-a-regulated-health-service/Guidelines-for-advertising-regulated-health-services.aspx" },
                    { label: "PII Levels", href: "https://www.dentalboard.gov.au/documents/default.aspx?record=WD10%2F84&dbid=AP&chksum=eyOZIh6%2F01m2pktsPUEJRw%3D%3D" },
                  ].map(link => (
                    <a key={link.label} href={link.href} target="_blank" rel="noopener noreferrer" className="text-[10px] text-primary flex items-center gap-1 hover:underline">
                      <ExternalLink className="w-3 h-3" />
                      {link.label}
                    </a>
                  ))}
                </div>
              </div>

              <div className="space-y-12 max-w-5xl mx-auto">
                <AffirmationSection
                  number="1"
                  title="Professional Indemnity Insurance (PII)"
                  bullets={[
                    "Affirm that you have current PII that meets DBA requirements (minimum $5–10 million per claim / $15–20 million annual aggregate).",
                    "Cover includes civil liability for dental practice.",
                    "Run-off cover arranged if ceasing practice."
                  ]}
                  evidence="Certificate of currency (dated within last 12 months)."
                  id="pii"
                  answers={answers}
                  notes={notes}
                  onSelect={handleSelect}
                  onNoteChange={handleNoteChange}
                  isError={unansweredFields.includes("pii")}
                  scrollRef={el => { if (el) scrollRefs.current.pii = el; }}
                />

                <AffirmationSection
                  number="2"
                  title="Recency of Practice"
                  bullets={[
                    "Affirm that you have practised dentistry within the last 3 years (or met requirements via CPD/supervised practice).",
                    "If not, declare remedial training/conditions."
                  ]}
                  evidence="CPD log, employment letters, or practice records."
                  id="recency"
                  answers={answers}
                  notes={notes}
                  onSelect={handleSelect}
                  onNoteChange={handleNoteChange}
                  isError={unansweredFields.includes("recency")}
                  scrollRef={el => { if (el) scrollRefs.current.recency = el; }}
                />

                <AffirmationSection
                  number="3"
                  title="Continuing Professional Development (CPD)"
                  bullets={[
                    "Affirm completion of at least 60 hours of CPD over the 3-year cycle (min 10 hours/year average).",
                    "Includes mandatory: 10 hrs Infection Control, 4 hrs CPR, 4 hrs Radiation Safety."
                  ]}
                  evidence="CPD log/portfolio with certificates, hours breakdown."
                  id="cpd"
                  answers={answers}
                  notes={notes}
                  onSelect={handleSelect}
                  onNoteChange={handleNoteChange}
                  isError={unansweredFields.includes("cpd")}
                  scrollRef={el => { if (el) scrollRefs.current.cpd = el; }}
                />

                <AffirmationSection
                  number="4"
                  title="Infection Prevention and Control"
                  bullets={[
                    "Affirm current, customised IPC systems in place (manual reviewed annually).",
                    "Staff trained, reprocessing compliant with AS 5369:2023."
                  ]}
                  evidence="Completed IPC affirmation checklist + review log."
                  id="ipc_affirm"
                  answers={answers}
                  notes={notes}
                  onSelect={handleSelect}
                  onNoteChange={handleNoteChange}
                  isError={unansweredFields.includes("ipc_affirm")}
                  scrollRef={el => { if (el) scrollRefs.current.ipc_affirm = el; }}
                />

                <AffirmationSection
                  number="5"
                  title="Fitness to Practise / Health / Criminal History"
                  bullets={[
                    "Affirm no changes to health that impair safe practice.",
                    "Affirm no criminal history relevant to practice.",
                    "Affirm no notifications, conditions, or investigations since last renewal."
                  ]}
                  evidence="None required unless declaring."
                  id="fitness"
                  answers={answers}
                  notes={notes}
                  onSelect={handleSelect}
                  onNoteChange={handleNoteChange}
                  isError={unansweredFields.includes("fitness")}
                  scrollRef={el => { if (el) scrollRefs.current.fitness = el; }}
                />

                <div ref={el => { if (el) scrollRefs.current.finalAffirmation = el; }} className="pt-8 border-t border-border">
                  <div className={cn(
                    "flex items-start gap-4 p-8 rounded-2xl border transition-all shadow-sm",
                    errorOnCheckbox ? "bg-red-50 border-red-500 ring-4 ring-red-100/50" : "bg-primary/5 border-primary/10"
                  )}>
                    <input 
                      type="checkbox" 
                      id="final_affirmation"
                      checked={finalAffirmationChecked}
                      onChange={(e) => handleDBACheckboxChange(e.target.checked)}
                      className={cn(
                        "mt-1.5 w-5 h-5 rounded text-primary focus:ring-primary transition-all cursor-pointer",
                        errorOnCheckbox ? "border-red-500 ring-2 ring-red-200" : "border-primary/20"
                      )}
                    />
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-2">
                        {errorOnCheckbox && <div className="w-1.5 h-1.5 rounded-full bg-red-500 shrink-0 animate-pulse" />}
                        <label htmlFor="final_affirmation" className="text-base font-bold leading-relaxed text-foreground/90 cursor-pointer">
                          I affirm that all information provided is accurate and that I am ready to submit my {nextYear} DBA/AHPRA renewal application.
                        </label>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        All sections above must be affirmed before checking this box.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Affirmation Section */}
              <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-6 space-y-4 mt-8 max-w-6xl mx-auto">
                <h3 className="text-sm font-bold text-zinc-700 uppercase tracking-wider border-b border-zinc-200 pb-2">Affirmation</h3>
                <p className="text-sm text-zinc-600 italic">
                  I confirm that I have personally reviewed the current manual against the latest standards and that the entries in this log are accurate.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Practice Owner / Principal Dentist</label>
                    <input 
                      type="text" 
                      value={reviewAffirmation.name} 
                      onChange={(e) => setReviewAffirmation({...reviewAffirmation, name: e.target.value})}
                      className="w-full bg-white border border-zinc-300 rounded-md px-3 py-2 text-sm outline-none focus:border-primary"
                      placeholder="Name..."
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Date of Latest Review</label>
                    <input 
                      type="text" 
                      value={reviewAffirmation.date} 
                      onChange={(e) => setReviewAffirmation({...reviewAffirmation, date: e.target.value})}
                      className="w-full bg-white border border-zinc-300 rounded-md px-3 py-2 text-sm outline-none focus:border-primary"
                      placeholder="DD/MM/YYYY"
                    />
                  </div>
                </div>
              </div>

              <div className="mt-12 flex flex-col items-center gap-4">
                <button
                  onClick={handleSave}
                  className="bg-primary text-primary-foreground px-12 py-3 rounded-xl font-bold hover:opacity-90 transition-all shadow-lg flex items-center gap-2"
                >
                  <FileText className="w-5 h-5" /> Save Overall Readiness Summary
                </button>
                
                {showSaved && (
                  <div className="flex items-center gap-2 px-6 py-2 rounded-full bg-green-100 text-green-700 border border-green-200 animate-in fade-in slide-in-from-top-2 duration-300">
                    <Check className="w-4 h-4" />
                    <span className="text-xs font-bold uppercase tracking-wider">Affirmations Recorded</span>
                  </div>
                )}
              </div>
            </motion.div>
          ) : activeMenu === "ipc_affirmations" ? (
            <motion.div
              key="ipc_affirmations"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="w-full bg-card rounded-2xl border border-border p-10 shadow-sm relative"
              data-floating-panel="ipc_affirmations"
              ref={(el) => {
                if (!el) return;
                floatingPanelRef.current = el;
              }}
            >
              <header className="mb-10 text-center">
                <h2
                  className="text-2xl font-display font-bold text-foreground"
                  data-floating-heading="1"
                  ref={(el) => {
                    if (!el) return;
                    floatingHeadingRef.current = el;
                  }}
                >
                  IPC Policy & Manual Affirmations
                </h2>
                <h3 className="text-[10px] font-bold text-primary uppercase tracking-widest mt-2">
                  Standard precautions & universal requirements
                </h3>
              </header>

              <div className="space-y-8 max-w-5xl mx-auto">
                {ipcAffirmations.map((group, groupIdx) => (
                  <div key={groupIdx} className="space-y-4">
                    <h4 className="text-xs font-bold text-foreground/50 uppercase tracking-widest border-b border-border pb-2">
                      {group.topic}
                    </h4>
                    <div className="grid grid-cols-1 gap-3">
                      {group.items.map((item, itemIdx) => {
                        const fieldId = `ipc_aff_${groupIdx}_${itemIdx}`;
                        const isMissing = unansweredFields.includes(fieldId);
                        return (
                          <div 
                            key={itemIdx} 
                            ref={el => { if (el) scrollRefs.current[fieldId] = el; }}
                            className={cn(
                              "flex items-center justify-between p-4 rounded-xl border transition-all group shadow-sm",
                              isMissing ? "bg-red-50 border-red-500 ring-2 ring-red-100 shadow-md" : "bg-muted/20 border-border/40 hover:bg-muted/30"
                            )}
                          >
                            <div className="flex items-center gap-2 pr-4">
                              {isMissing && <div className="w-1.5 h-1.5 rounded-full bg-red-500 shrink-0 animate-pulse" />}
                              <span className="text-sm text-foreground/80 leading-relaxed">{item}</span>
                            </div>
                            <button
                              onClick={() => handleSelect(fieldId, "AFFIRMED")}
                              className={cn(
                                "shrink-0 px-4 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all",
                                answers[fieldId] === "AFFIRMED"
                                  ? "bg-[#007AFF] text-white shadow-sm"
                                  : isMissing ? "bg-white text-red-500 border-red-500" : "bg-background text-muted-foreground border border-border group-hover:border-[#007AFF]/30"
                              )}
                            >
                              {answers[fieldId] === "AFFIRMED" ? "AFFIRMED" : "AFFIRM"}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}

                <div ref={el => { if (el) scrollRefs.current.officialApproval = el; }} className="pt-12 border-t border-border mt-12">
                  <div className={cn(
                    "flex items-start gap-4 p-8 rounded-2xl border shadow-inner transition-all",
                    errorOnCheckbox ? "bg-red-50 border-red-500 ring-4 ring-red-100/50" : "bg-primary/5 border-primary/10"
                  )}>
                    <input 
                      type="checkbox" 
                      id="official_ipc_approval"
                      checked={finalAffirmationChecked}
                      onChange={(e) => handleIPCCheckboxChange(e.target.checked)}
                      className={cn(
                        "mt-1.5 w-6 h-6 rounded text-primary focus:ring-primary transition-all cursor-pointer",
                        errorOnCheckbox ? "border-red-500 ring-2 ring-red-200" : "border-primary/20"
                      )}
                    />
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        {errorOnCheckbox && <div className="w-1.5 h-1.5 rounded-full bg-red-500 shrink-0 animate-pulse" />}
                        <label htmlFor="official_ipc_approval" className="text-base font-bold text-foreground/90 leading-relaxed cursor-pointer">
                          I approve this version as our official IPC manual
                        </label>
                      </div>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        By checking this box, you confirm that this manual has been reviewed and adopted as the practice standard.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-12 flex flex-col items-center gap-4">
                <button
                  onClick={handleSave}
                  className="bg-primary text-primary-foreground px-12 py-4 rounded-xl font-bold hover:opacity-90 transition-all shadow-xl hover:scale-[1.02] active:scale-[0.98]"
                >
                  Save and Update Manual
                </button>
                
                {showSaved && (
                  <div className="flex items-center gap-2 px-6 py-2 rounded-full bg-green-100 text-green-700 border border-green-200 animate-in fade-in slide-in-from-top-2 duration-300">
                    <Check className="w-4 h-4" />
                    <span className="text-xs font-bold uppercase tracking-wider">IPC Manual Updated</span>
                  </div>
                )}
              </div>
            </motion.div>
          ) : activeMenu === "review_log" ? (
            <motion.div
              key="review_log"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="w-full bg-card rounded-2xl border border-border p-10 shadow-sm relative"
              data-floating-panel="review_log"
              ref={(el) => {
                if (!el) return;
                floatingPanelRef.current = el;
              }}
            >
              <div className="flex justify-between items-center mb-10">
                <div className="flex-1 text-center">
                  <h2
                    className="text-2xl font-display font-bold text-foreground"
                    data-floating-heading="1"
                    ref={(el) => {
                      if (!el) return;
                      floatingHeadingRef.current = el;
                    }}
                  >
                    Review Log / Change Summary
                  </h2>
                  <h3 className="text-[10px] font-bold text-primary uppercase tracking-widest mt-2">
                    IPC Policy & Manual Revisions
                  </h3>
                </div>
              </div>

              <div className="max-w-6xl mx-auto space-y-6">
                {/* Preface Section */}
                <div className="bg-blue-50/50 p-6 rounded-xl border border-blue-100 space-y-4 text-sm text-blue-900 leading-relaxed">
                  <div>
                    <strong className="block text-blue-700 uppercase text-xs tracking-wider mb-1">Purpose</strong>
                    <p>
                      This log records each review of the Infection Prevention and Control Manual against the most current standards. It demonstrates ongoing due diligence and currency in line with:
                    </p>
                    <ul className="list-disc pl-5 mt-1 space-y-1">
                      <li>Dental Board of Australia (DBA) requirements for maintaining contemporary knowledge and systems</li>
                      <li>ADA Guidelines for Infection Prevention and Control, 5th Edition (including all blue-highlighted changes in the member version)</li>
                      <li>AS 5369:2023 Reprocessing of reusable medical devices in health service organisations</li>
                    </ul>
                  </div>
                  
                  <div>
                    <strong className="block text-blue-700 uppercase text-xs tracking-wider mb-1">Key Principles</strong>
                    <ul className="list-disc pl-5 mt-1 space-y-1">
                      <li>The manual must be reviewed at least annually, or sooner if there are significant updates to the ADA Guidelines, AS 5369:2023, NHMRC AICG, or DBA expectations.</li>
                      <li>Reviews should specifically consider any <strong>blue-highlighted changes</strong> in the latest ADA member version.</li>
                      <li>Any required updates (universal or practice-specific) are noted here and actioned.</li>
                      <li>This log forms part of the evidence of compliance for DBA registration renewal and practice audits.</li>
                    </ul>
                  </div>
                </div>

                <div className="flex justify-between items-center p-4 bg-muted/30 rounded-xl border border-border/50">
                  <p className="text-sm text-foreground/70 leading-relaxed">
                    If this is your first year using our portal, you must update this manually, otherwise, 
                    <button 
                      className="mx-2 px-3 py-1 rounded bg-muted text-muted-foreground text-xs font-bold cursor-not-allowed opacity-50 border border-border"
                      title="This script will compare current vs previous year data and auto-generate a summary PDF once historical data is available."
                      disabled
                    >
                      CLICK HERE
                    </button>
                  </p>
                  <div className="flex gap-2">
                    <button 
                      onClick={addReviewRow}
                      className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-xs font-bold hover:opacity-90 transition-all shadow-sm"
                    >
                      <PlusCircle className="w-4 h-4" />
                      ADD ROW
                    </button>
                    <button 
                      onClick={removeReviewRow}
                      className="flex items-center gap-2 px-4 py-2 bg-muted text-foreground rounded-lg text-xs font-bold hover:bg-muted/80 transition-all border border-border shadow-sm"
                    >
                      <MinusCircle className="w-4 h-4" />
                      REMOVE SELECTED ROW(S)
                    </button>
                  </div>
                </div>

                <div className="bg-background rounded-xl border border-border shadow-inner overflow-hidden">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-muted/50 border-b border-border">
                        <th className="px-2 py-4 text-center border-r border-border w-10">
                          <input type="checkbox" className="rounded border-gray-300" disabled />
                        </th>
                        <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-24">Version</th>
                        <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border w-40">Date</th>
                        <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border">Reviewed against</th>
                        <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider border-r border-border">Key changes noted / actions taken</th>
                        <th className="px-6 py-4 text-left text-xs font-bold text-foreground/70 uppercase tracking-wider">Reviewed by</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {reviewRows.map((row, idx) => (
                        <tr key={idx} className="hover:bg-muted/10 transition-colors">
                          <td className="text-center border-r border-border bg-muted/5">
                            <input 
                              type="checkbox" 
                              checked={selectedReviewRows.has(idx)}
                              onChange={() => toggleRowSelection(idx, selectedReviewRows, setSelectedReviewRows)}
                              className="rounded border-gray-300"
                            />
                          </td>
                          <td className="border-r border-border h-full">
                            <textarea 
                              rows={1}
                              value={row.version} 
                              onChange={(e) => updateReviewRow(idx, "version", e.target.value)}
                              onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }}
                              className="w-full px-6 py-4 bg-transparent outline-none text-sm text-foreground/80 font-medium resize-none overflow-hidden h-full" 
                              placeholder="e.g. 1.0"
                            />
                          </td>
                          <td className="border-r border-border h-full">
                            <textarea 
                              rows={1}
                              value={row.date} 
                              onChange={(e) => updateReviewRow(idx, "date", e.target.value)}
                              onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }}
                              className="w-full px-6 py-4 bg-transparent outline-none text-sm text-foreground/80 resize-none overflow-hidden h-full" 
                              placeholder="e.g. 14 Jan 2026"
                            />
                          </td>
                          <td className="border-r border-border h-full">
                            <textarea 
                              rows={1}
                              value={row.reviewedAgainst} 
                              onChange={(e) => updateReviewRow(idx, "reviewedAgainst", e.target.value)}
                              onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }}
                              className="w-full px-6 py-4 bg-transparent outline-none text-sm text-foreground/80 resize-none overflow-hidden h-full" 
                              placeholder="Record standards reviewed..."
                            />
                          </td>
                          <td className="border-r border-border h-full">
                            <textarea 
                              rows={1}
                              value={row.changes} 
                              onChange={(e) => updateReviewRow(idx, "changes", e.target.value)}
                              onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }}
                              className="w-full px-6 py-4 bg-transparent outline-none text-sm text-foreground/80 resize-none overflow-hidden h-full" 
                              placeholder="Detail modifications made..."
                            />
                          </td>
                          <td className="h-full">
                            <textarea 
                              rows={1}
                              value={row.reviewedBy} 
                              onChange={(e) => updateReviewRow(idx, "reviewedBy", e.target.value)}
                              onInput={(e) => { e.currentTarget.style.height = 'auto'; e.currentTarget.style.height = e.currentTarget.scrollHeight + 'px'; }}
                              className="w-full px-6 py-4 bg-transparent outline-none text-sm text-foreground/80 resize-none overflow-hidden h-full" 
                              placeholder="Enter name"
                            />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="mt-12 flex flex-col items-center gap-4">
                <button
                  onClick={handleSave}
                  className="bg-primary text-primary-foreground px-12 py-3 rounded-xl font-bold hover:opacity-90 transition-all shadow-lg"
                >
                  Save Changes
                </button>
                
                {showSaved && (
                  <div className="flex items-center gap-2 px-6 py-2 rounded-full bg-green-100 text-green-700 border border-green-200 animate-in fade-in slide-in-from-top-2 duration-300">
                    <Check className="w-4 h-4" />
                    <span className="text-xs font-bold uppercase tracking-wider">Changes Saved</span>
                  </div>
                )}
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="questionnaire"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="w-full bg-card rounded-2xl border border-border p-10 shadow-sm relative"
              data-floating-panel="questionnaire"
              ref={(el) => {
                if (!el) return;
                floatingPanelRef.current = el;
              }}
            >
              <header className="mb-10 text-center">
                <h2
                  className="text-2xl font-display font-bold text-foreground"
                  data-floating-heading="1"
                  ref={(el) => {
                    if (!el) return;
                    floatingHeadingRef.current = el;
                  }}
                >
                  Clinic Profile & Procedures
                </h2>
                <h3 className="text-[10px] font-bold text-primary uppercase tracking-widest mt-2">
                  Please answer the questions below
                </h3>
              </header>

              <div className="space-y-12 max-w-5xl mx-auto">
                <section>
                  <h4 className="text-[10px] font-bold text-foreground/50 uppercase tracking-wider mb-6 pb-2 border-b border-border">
                    1. Steriliser Details
                  </h4>
                  <div className="space-y-6 max-w-5xl mx-auto">
                    <div ref={el => { if (el) scrollRefs.current.steriliserCount = el; }}>
                      <QuestionRow
                        label="Number of sterilisers"
                        options={["1", "2", "3", "4"]}
                        value={answers.steriliserCount}
                        onSelect={(v) => handleSelect("steriliserCount", v)}
                        isError={unansweredFields.includes("steriliserCount")}
                      />
                    </div>

                    {/* Dynamic Steriliser Brand & Type Inputs */}
                    {(() => {
                      const count = parseInt(answers.steriliserCount) || 0;
                      // "4+" logic removed, max is 4 via UI options, but we keep safe check
                      const safeCount = count > 4 ? 4 : count;
                      
                      if (safeCount > 0) {
                        return Array.from({ length: safeCount }).map((_, i) => {
                          const index = i + 1;
                          const brandKey = `steriliserBrand_${index}`;
                          const typeKey = `steriliserType_${index}`;
                          
                          const currentBrand = answers[brandKey] || (index === 1 ? answers.steriliserBrand : "") || "";
                          const currentType = answers[typeKey] || (index === 1 ? answers.steriliserType : "") || "";

                          return (
                            <div key={index} className="space-y-6 border-t border-border/50 pt-6 mt-6 first:border-0 first:pt-0 first:mt-0">
                              {safeCount > 1 && (
                                <h5 className="text-xs font-bold text-primary uppercase tracking-wider mb-2">Steriliser {index}</h5>
                              )}
                              
                              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 py-2">
                                <div className="flex items-center gap-2">
                                  {unansweredFields.includes(brandKey) && <div className="w-1.5 h-1.5 rounded-full bg-red-500" />}
                                  <span className="text-sm font-medium text-foreground/70">
                                    What Brand of Steriliser {safeCount > 1 ? index : ""}
                                  </span>
                                </div>
                                <div className="md:w-1/2">
                                  <select 
                                    className={cn(
                                      "w-full bg-background border rounded-md px-3 py-2 text-sm text-center focus:ring-1 focus:ring-primary outline-none transition-all",
                                      unansweredFields.includes(brandKey) ? "border-red-500 ring-2 ring-red-100" : "border-input"
                                    )}
                                    value={currentBrand}
                                    onChange={(e) => handleSelect(brandKey, e.target.value)}
                                  >
                                    <option value="" className="text-center">Select brand...</option>
                                    <option>Melag</option>
                                    <option>W&H</option>
                                    <option>Mocom</option>
                                    <option>SciCan (Statim)</option>
                                    <option>NSK</option>
                                    <option>ProMedCo</option>
                                    <option>Runyes</option>
                                    <option>Pureclave</option>
                                    <option>Siltex</option>
                                    <option>Ajax Dental</option>
                                    <option>Midmark</option>
                                    <option>Getinge</option>
                                    <option>Tuttnauer</option>
                                    <option>Other</option>
                                  </select>
                                </div>
                              </div>

                              <div>
                                <QuestionRow
                                  label={`What Type of Steriliser ${safeCount > 1 ? index : ""}`}
                                  options={["Class B", "Class S", "Class N"]}
                                  value={currentType}
                                  onSelect={(v) => handleSelect(typeKey, v)}
                                  isError={unansweredFields.includes(typeKey)}
                                />
                              </div>
                            </div>
                          );
                        });
                      }
                      
                      return null;
                    })()}
                  </div>
                </section>

                <section>
                  <h4 className="text-[10px] font-bold text-foreground/50 uppercase tracking-wider mb-6 pb-2 border-b border-border">
                    2. Reprocessing Area Layout
                  </h4>
                  <div className="space-y-6 max-w-5xl mx-auto">
                    <div ref={el => { if (el) scrollRefs.current.sinkCount = el; }}>
                      <QuestionRow
                        label="Number of dedicated sinks"
                        options={["1", "2", "3+"]}
                        value={answers.sinkCount}
                        onSelect={(v) => handleSelect("sinkCount", v)}
                        isError={unansweredFields.includes("sinkCount")}
                      />
                    </div>
                    <div ref={el => { if (el) scrollRefs.current.oneWayFlow = el; }}>
                      <QuestionRow
                        label="One-way flow physical separation?"
                        options={["Yes", "No"]}
                        value={answers.oneWayFlow}
                        onSelect={(v) => handleSelect("oneWayFlow", v)}
                        isError={unansweredFields.includes("oneWayFlow")}
                        tooltip={
                          <InfoTooltip 
                            className="w-[500px]"
                            content={
                            <ul className="list-disc pl-3 space-y-2">
                              <li><strong>AS 5369:2023 (Section 5.6 – Facility design and layout)</strong></li>
                              <li>Dirty instruments should never go back to the clean/sterile side (the process should flow in one direction only).</li>
                              <li><strong>Physical separation</strong> = Separate zones for dirty and clean work (e.g., two sinks, separate benches, or a physical divider like a splash guard/wall).</li>
                              <li>In small dental clinics, a single room is acceptable if there's clear separation (e.g., dirty sink on one side, clean packing on the other) and no overlap (no dirty instruments placed on clean benches).</li>
                              <li>You need a simple floor plan/diagram of the sterilising area showing dirty → clean flow and separation (hand-drawn or photo is fine).</li>
                              <li>Photos of the setup (dirty sink separate from clean bench/steriliser).</li>
                              <li>Written procedure in your IPC manual: "All instruments follow a one-way flow from dirty to clean zones; physical separation maintained via dedicated benches and sinks."</li>
                              <li>
                                Staff acknowledgment (signed training record): "I understand and follow one-way flow." 
                                <span className="block mt-1">
                                   <span className="text-primary underline cursor-pointer hover:text-primary/80" onClick={() => setActiveMenu("staff_training_register")}>Staff Training Register</span>
                                </span>
                              </li>
                            </ul>
                          } />
                        }
                      />
                    </div>
                  </div>
                </section>

                <section>
                  <h4 className="text-[10px] font-bold text-foreground/50 uppercase tracking-wider mb-6 pb-2 border-b border-border">
                    3. Handpiece Policy
                  </h4>
                  <div className="space-y-6 max-w-5xl mx-auto">
                    <div ref={el => { if (el) scrollRefs.current.handpiecePolicy = el; }}>
                      <QuestionRow
                        label="Reprocessing approach"
                        options={["Reprocessed", "Single-use", "Mix"]}
                        value={answers.handpiecePolicy}
                        onSelect={(v) => handleSelect("handpiecePolicy", v)}
                        isError={unansweredFields.includes("handpiecePolicy")}
                      />
                    </div>
                  </div>
                </section>

                <section>
                  <h4 className="text-[10px] font-bold text-foreground/50 uppercase tracking-wider mb-6 pb-2 border-b border-border">
                    4. Staff Numbers
                  </h4>
                  <div className="space-y-6 max-w-5xl mx-auto">
                    <div ref={el => { if (el) scrollRefs.current.staffDentists = el; }}>
                      <QuestionRow
                        label="Registered Dentists"
                        options={["1-2", "3-5", "6-10", "11+"]}
                        value={answers.staffDentists}
                        onSelect={(v) => handleSelect("staffDentists", v)}
                        isError={unansweredFields.includes("staffDentists")}
                      />
                    </div>
                    <div ref={el => { if (el) scrollRefs.current.staffHygienists = el; }}>
                      <QuestionRow
                        label="OHT / Hygienists"
                        options={["1-2", "3-5", "6-10", "11+"]}
                        value={answers.staffHygienists}
                        onSelect={(v) => handleSelect("staffHygienists", v)}
                        isError={unansweredFields.includes("staffHygienists")}
                      />
                    </div>
                    <div ref={el => { if (el) scrollRefs.current.staffAssistants = el; }}>
                      <QuestionRow
                        label="Dental Assistants"
                        options={["1-2", "3-5", "6-10", "11+"]}
                        value={answers.staffAssistants}
                        onSelect={(v) => handleSelect("staffAssistants", v)}
                        isError={unansweredFields.includes("staffAssistants")}
                      />
                    </div>
                    <div ref={el => { if (el) scrollRefs.current.staffAdmin = el; }}>
                      <QuestionRow
                        label="Admin / Reception"
                        options={["1-2", "3-5", "6-10", "11+"]}
                        value={answers.staffAdmin}
                        onSelect={(v) => handleSelect("staffAdmin", v)}
                        isError={unansweredFields.includes("staffAdmin")}
                      />
                    </div>
                  </div>
                </section>

                <section>
                  <h4 className="text-[10px] font-bold text-foreground/50 uppercase tracking-wider mb-6 pb-2 border-b border-border">
                    5. Immunisation Status
                  </h4>
                  <div className="space-y-6 max-w-5xl mx-auto">
                    <div ref={el => { if (el) scrollRefs.current.hepBImmunity = el; }}>
                      <QuestionRow
                        label="Hep B Immunity Documented?"
                        options={["Yes", "No", "Partial"]}
                        value={answers.hepBImmunity}
                        onSelect={(v) => handleSelect("hepBImmunity", v)}
                        isError={unansweredFields.includes("hepBImmunity")}
                        tooltip={
                          <InfoTooltip content={
                            <span>
                              See <span className="text-primary underline cursor-pointer hover:text-primary/80" onClick={() => setActiveMenu("immunisation_records")}>'Immunisation Records'</span> in 'Staff IPC Training' for more information.
                            </span>
                          } />
                        }
                      />
                    </div>
                  </div>
                </section>
              </div>

              <div className="mt-8 flex flex-col items-center gap-4">
                <button
                  onClick={handleSave}
                  className="bg-primary text-primary-foreground px-12 py-3 rounded-xl font-bold hover:opacity-90 transition-all shadow-lg"
                >
                  Save Changes
                </button>
                
                {showSaved && (
                  <div className="flex items-center gap-2 px-6 py-2 rounded-full bg-green-100 text-green-700 border border-green-200 animate-in fade-in slide-in-from-top-2 duration-300">
                    <Check className="w-4 h-4" />
                    <span className="text-xs font-bold uppercase tracking-wider">Changes Saved</span>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      <UploadChoiceModal 
        isOpen={!!uploadModalState?.isOpen} 
        onClose={() => setUploadModalState(null)} 
        onUpload={handleUploadComplete} 
      />
    </Layout>
  );
}

function AffirmationSection({
  number,
  title,
  bullets,
  evidence,
  id,
  answers,
  notes,
  onSelect,
  onNoteChange,
  isError,
  scrollRef,
}: {
  number: string;
  title: string;
  bullets: string[];
  evidence: string;
  id: string;
  answers: Record<string, string>;
  notes: Record<string, string>;
  onSelect: (id: string, v: string) => void;
  onNoteChange: (id: string, v: string) => void;
  isError?: boolean;
  scrollRef?: (instance: HTMLDivElement | null) => void;
}) {
  return (
    <section ref={scrollRef}>
      <h4 className="text-[10px] font-bold text-foreground/50 uppercase tracking-wider mb-6 pb-2 border-b border-border">
        {number}. {title}
      </h4>
      <div className="space-y-6">
        <div className="space-y-3">
          {bullets.map((bullet, i) => (
            <div key={i} className="flex items-start gap-3">
              <div className="w-1.5 h-1.5 rounded-full bg-primary/40 mt-1.5 shrink-0" />
              <p className="text-sm text-foreground/70 leading-relaxed">{bullet}</p>
            </div>
          ))}
        </div>
        
        <div className={cn(
          "flex flex-col gap-6 p-6 rounded-2xl border transition-all shadow-sm",
          isError ? "bg-red-50 border-red-500 ring-2 ring-red-100" : "bg-muted/30 border-border/50"
        )}>
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <input 
                type="checkbox" 
                id={`evidence_${id}`}
                className="mt-1 w-4 h-4 rounded border-border text-primary focus:ring-primary"
              />
              <div>
                <div className="flex items-center gap-2">
                  {isError && <div className="w-1.5 h-1.5 rounded-full bg-red-500 shrink-0 animate-pulse" />}
                  <label htmlFor={`evidence_${id}`} className="text-sm font-semibold text-foreground/80">
                    Evidence to have ready:
                  </label>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">{evidence}</p>
              </div>
            </div>
            <div className={cn(
              "flex border rounded-lg overflow-hidden divide-x shadow-sm bg-background w-full md:w-auto min-w-[200px]",
              isError ? "border-red-500 divide-red-500 ring-1 ring-red-500" : "border-border divide-border"
            )}>
              {["Affirm", "Not Ready"].map((opt) => (
                <button
                  key={opt}
                  onClick={() => onSelect(id, opt)}
                  className={cn(
                    "flex-1 px-5 py-2.5 text-xs font-semibold transition-all text-center",
                    answers[id] === opt
                      ? opt === "Affirm" ? "bg-primary text-white" : "bg-red-500 text-white"
                      : "bg-background text-foreground/40 hover:bg-muted",
                  )}
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">
              Notes / Action required
            </label>
            <textarea 
              value={notes[id] || ""}
              onChange={(e) => onNoteChange(id, e.target.value)}
              placeholder="Record any follow-up tasks or verification notes here..."
              className="w-full bg-background border border-border/50 rounded-lg p-3 text-sm focus:ring-1 focus:ring-primary outline-none transition-all min-h-[80px] resize-none"
            />
          </div>
        </div>
      </div>
    </section>
  );
}

function InfoTooltip({ content, className }: { content: React.ReactNode; className?: string }) {
  const [open, setOpen] = useState(false);
  
  return (
    <div className="relative inline-flex items-center ml-2 align-middle">
      <button 
        onClick={(e) => { e.stopPropagation(); setOpen(!open); }}
        className="w-4 h-4 rounded-full bg-primary text-primary-foreground flex items-center justify-center hover:opacity-90 transition-all shadow-sm focus:outline-none"
        aria-label="More information"
      >
        <span className="text-[10px] font-bold leading-none">?</span>
      </button>
      
      {open && (
        <div className={cn(
          "absolute left-full top-1/2 -translate-y-1/2 ml-3 p-3 rounded-xl bg-zinc-100 dark:bg-zinc-800 border border-border/50 shadow-xl z-50 text-xs text-foreground/80 leading-relaxed text-left",
          className || "w-64"
        )}>
           {content}
           <div className="absolute right-full top-1/2 -translate-y-1/2 border-8 border-transparent border-r-zinc-100 dark:border-r-zinc-800" />
        </div>
      )}
    </div>
  );
}

function QuestionRow({
  label,
  options,
  value,
  onSelect,
  isError,
  tooltip,
}: {
  label: string;
  options: string[];
  value?: string;
  onSelect: (v: string) => void;
  isError?: boolean;
  tooltip?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 py-2">
      <div className="flex items-center gap-2">
        {isError && <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />}
        <span className="text-sm font-medium text-foreground/70 flex items-center">
          {label}
          {tooltip}
        </span>
      </div>
      <div className={cn(
        "flex border rounded-lg overflow-hidden divide-x divide-border shadow-sm w-full md:w-1/2 transition-all",
        isError ? "border-red-500 ring-2 ring-red-100" : "border-border"
      )}>
        {options.map((opt) => (
          <button
            key={opt}
            onClick={() => onSelect(opt)}
            className={cn(
              "flex-1 px-5 py-1.5 text-xs font-semibold transition-all text-center",
              value === opt
                ? "bg-[#007AFF] text-white"
                : "bg-background text-foreground/40 hover:bg-muted",
            )}
          >
            {opt}
          </button>
        ))}
      </div>
    </div>
  );
}

function UploadChoiceModal({ isOpen, onClose, onUpload }: { isOpen: boolean; onClose: () => void; onUpload: (name: string, type: 'desktop' | 'snap') => void }) {
  const [activeTab, setActiveTab] = useState<"desktop" | "snaps">("snaps");
  const [snaps, setSnaps] = useState<any[]>([]);

  useEffect(() => {
    if (isOpen) {
      const s = localStorage.getItem("dentalcheck.snaps");
      if (s) {
        try {
          setSnaps(JSON.parse(s));
        } catch (e) {
          console.error("Failed to parse snaps", e);
          setSnaps([]);
        }
      } else {
        setSnaps([]);
      }
      setActiveTab("snaps");
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="bg-white dark:bg-zinc-900 w-full max-w-lg rounded-xl shadow-2xl overflow-hidden border border-zinc-200 dark:border-zinc-800 animate-in fade-in zoom-in-95 duration-200">
        <div className="p-4 border-b border-zinc-100 dark:border-zinc-800 relative">
          <h3 className="font-bold text-lg text-foreground text-center">Upload Document</h3>
          <button onClick={onClose} className="absolute right-4 top-1/2 -translate-y-1/2 p-1 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-full transition-colors text-foreground">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-4">
          <div className="flex gap-2 mb-4 bg-zinc-100 dark:bg-zinc-800 p-1 rounded-lg">
            <button 
              onClick={() => setActiveTab("snaps")}
              className={cn(
                "flex-1 py-2 text-sm font-medium rounded-md transition-all",
                activeTab === "snaps" 
                  ? "bg-white dark:bg-zinc-700 shadow-sm text-primary" 
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              All Documents
            </button>
            <button 
              onClick={() => setActiveTab("desktop")}
              className={cn(
                "flex-1 py-2 text-sm font-medium rounded-md transition-all",
                activeTab === "desktop" 
                  ? "bg-white dark:bg-zinc-700 shadow-sm text-primary" 
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              Upload from Desktop
            </button>
          </div>

          {activeTab === "snaps" ? (
             <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
               {snaps.length === 0 ? (
                 <div className="text-center py-12 flex flex-col items-center gap-3 text-muted-foreground">
                   <div className="w-12 h-12 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center">
                     <FileText className="w-6 h-6 text-zinc-300" />
                   </div>
                   <p className="text-sm">No documents found in Document Snap.</p>
                   <p className="text-xs max-w-[200px] mx-auto opacity-70">Use the mobile scan feature to add documents here.</p>
                 </div>
               ) : (
                 snaps.map((snap: any) => (
                   <div 
                     key={snap.id} 
                     onClick={() => onUpload(snap.name, 'snap')} 
                     className="flex items-center gap-3 p-3 rounded-lg border border-zinc-100 dark:border-zinc-800 hover:border-primary/50 hover:bg-primary/5 cursor-pointer transition-all group bg-card"
                   >
                     <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                       <FileText className="w-5 h-5" />
                     </div>
                     <div className="flex-1 min-w-0">
                       <p className="text-sm font-medium text-foreground truncate">{snap.name}</p>
                       <p className="text-xs text-muted-foreground">{snap.date}</p>
                     </div>
                     <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                        <span className="text-xs font-bold text-primary bg-primary/10 px-2 py-1 rounded-full">Select</span>
                     </div>
                   </div>
                 ))
               )}
             </div>
          ) : (
            <div className="py-12 text-center border-2 border-dashed border-zinc-200 dark:border-zinc-800 rounded-xl hover:border-primary/50 hover:bg-primary/5 transition-all cursor-pointer relative group">
               <input 
                 type="file" 
                 className="absolute inset-0 opacity-0 cursor-pointer z-10" 
                 onChange={(e) => {
                    if (e.target.files?.[0]) {
                      onUpload(e.target.files[0].name, 'desktop');
                    }
                 }}
               />
               <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                 <Upload className="w-8 h-8 text-muted-foreground group-hover:text-primary transition-colors" />
               </div>
               <p className="text-sm font-medium text-foreground">Click to upload from desktop</p>
               <p className="text-xs text-muted-foreground mt-1">PDF, JPG, PNG supported</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
