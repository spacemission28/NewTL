import { useState } from "react";
import { Sidebar } from "./Sidebar";
import { Bell, Search, Menu, GraduationCap, Users, FileText, Camera, LayoutDashboard, QrCode } from "lucide-react";
import { cn } from "@/lib/utils";
import { useIsMobile } from "@/hooks/use-mobile";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export function Layout({ children, onDashboardClick }: { children: React.ReactNode, onDashboardClick?: () => void }) {
  const isMobile = useIsMobile();
  const [isCollapsed, setIsCollapsed] = useState(() => {
    const saved = localStorage.getItem("sidebar_collapsed");
    return saved ? JSON.parse(saved) : false;
  });
  const [searchQuery, setSearchQuery] = useState("");

  const handleSetIsCollapsed = (value: boolean) => {
    setIsCollapsed(value);
    localStorage.setItem("sidebar_collapsed", JSON.stringify(value));
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      // Dispatch a custom event for the Dashboard to handle
      window.dispatchEvent(new CustomEvent('dashboard-search', { 
        detail: { query: searchQuery } 
      }));
    }
  };

  return (
    <div className="flex h-screen bg-background font-sans overflow-hidden">
      {!isMobile && (
        <Sidebar 
          isCollapsed={isCollapsed} 
          setIsCollapsed={handleSetIsCollapsed} 
          onDashboardClick={onDashboardClick} 
        />
      )}
      <div className="flex flex-1 flex-col overflow-hidden transition-all duration-300 ease-in-out">
        <header className="flex h-16 items-center justify-between border-b border-border bg-card px-4 md:px-6 shadow-sm z-10">
          <div className="flex items-center w-full">
            {isMobile && (
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="mr-4 shrink-0">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="p-0 w-[100px] border-r-0">
                  <div className="flex h-full flex-col bg-sidebar border-r border-sidebar-border items-center">
                    <div className="flex h-16 items-center justify-center border-b border-sidebar-border w-full">
                       <span className="font-display font-bold text-lg text-sidebar-foreground tracking-tight">
                         DC
                       </span>
                    </div>
                    <div className="flex-1 overflow-y-auto py-6">
                      <nav className="space-y-4 px-3 flex flex-col items-center">
                        <Link href="/dashboard">
                          <a className="flex items-center justify-center p-4 rounded-xl text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground transition-all hover:scale-110" title="Dashboard">
                            <LayoutDashboard className="h-8 w-8" />
                          </a>
                        </Link>
                        <Link href="/details">
                          <a className="flex items-center justify-center p-4 rounded-xl text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground transition-all hover:scale-110">
                            <GraduationCap className="h-8 w-8" />
                          </a>
                        </Link>
                        <Link href="/staff-info">
                          <a className="flex items-center justify-center p-4 rounded-xl text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground transition-all hover:scale-110">
                            <Users className="h-8 w-8" />
                          </a>
                        </Link>
                         <Link href="/reports">
                          <a className="flex items-center justify-center p-4 rounded-xl text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground transition-all hover:scale-110">
                            <FileText className="h-8 w-8" />
                          </a>
                        </Link>
                        <Link href="/document-snap">
                          <a className="flex items-center justify-center p-4 rounded-xl text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground transition-all hover:scale-110">
                            <Camera className="h-8 w-8" />
                          </a>
                        </Link>
                        <Link href="/cpd-snap">
                          <a className="flex items-center justify-center p-4 rounded-xl text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground transition-all hover:scale-110" title="CPD Log Snap">
                            <QrCode className="h-8 w-8" />
                          </a>
                        </Link>
                      </nav>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            )}
            <div className="relative w-full">
              <form onSubmit={handleSearch} className="w-full">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search..."
                  className="w-full h-9 rounded-md border border-input bg-background text-sm shadow-sm transition-colors focus:outline-none focus:ring-1 focus:ring-ring pl-[35px] pr-4"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </form>
            </div>
          </div>
        </header>
        <main className="app-main flex-1 overflow-auto bg-background/50">
          <div className={cn(
            "mx-auto p-4 md:p-8 pt-0 space-y-8 transition-all duration-300 ease-in-out",
            isCollapsed ? "max-w-[1600px]" : "max-w-6xl"
          )}>
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
