import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  ChevronRight, 
  ChevronLeft, 
  CheckCircle2, 
  AlertTriangle, 
  Info, 
  Save, 
  AlertCircle,
  ArrowRight,
  Download,
  X,
  Loader2
} from "lucide-react";
import { cn } from "@/lib/utils";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";

// --- Types ---

type AnswerStatus = "Yes" | "No" | "Partial" | "NA" | "";

interface Question {
  id: string;
  text: string;
  clause: string;
  guidance: string;
  defaultRisk: "High" | "Medium" | "Low";
}

interface Section {
  id: string;
  title: string;
  description: string;
  questions: Question[];
}

interface GapAnalysisData {
  [questionId: string]: {
    status: AnswerStatus;
    notes: string;
    risk?: "High" | "Medium" | "Low"; // User can override or confirmed default
  };
}

// --- Data: AS 5369:2023 Checklist ---

export const SECTIONS: Section[] = [
  {
    id: "governance",
    title: "1. Governance & Risk Management",
    description: "Management responsibility, risk assessment frameworks, and policy documentation.",
    questions: [
      {
        id: "gov_1",
        text: "Has a formal risk management framework been established for all reprocessing activities?",
        clause: "Section 2",
        guidance: "You must identify risks (e.g., sharps, chemical exposure, infection transmission) and document controls. This replaces simple 'policies' with a risk-based approach.",
        defaultRisk: "High"
      },
      {
        id: "gov_2",
        text: "Is there a designated person responsible for reprocessing (Infection Control Coordinator)?",
        clause: "Clause 2.2",
        guidance: "A specific staff member must be appointed and their duties defined in writing.",
        defaultRisk: "Medium"
      },
      {
        id: "gov_3",
        text: "Are all reprocessing policies updated to reference AS 5369:2023?",
        clause: "Section 2",
        guidance: "Review your manual. References to AS/NZS 4815 or 4187 should be replaced with AS 5369:2023 where applicable.",
        defaultRisk: "Medium"
      }
    ]
  },
  {
    id: "facility",
    title: "2. Facility Design & Environment",
    description: "Workflow, segregation of clean/dirty areas, and environmental controls.",
    questions: [
      {
        id: "fac_1",
        text: "Is there clear physical or spatial separation between dirty (cleaning) and clean (packaging/sterilisation) areas?",
        clause: "Section 3",
        guidance: "One-way flow from dirty to clean is mandatory to prevent cross-contamination. If physical barriers aren't possible, strict procedural separation must be validated.",
        defaultRisk: "High"
      },
      {
        id: "fac_2",
        text: "Is there a dedicated hand hygiene sink in the reprocessing area (separate from instrument washing sinks)?",
        clause: "Clause 3.3",
        guidance: "A dedicated hand wash basin with non-touch taps is required in the reprocessing area.",
        defaultRisk: "High"
      },
      {
        id: "fac_3",
        text: "Are reprocessing sinks designed to minimize splashing and of adequate size?",
        clause: "Clause 3.4",
        guidance: "Sinks should be deep enough to immerse instruments fully. Splashing poses an infection risk.",
        defaultRisk: "Low"
      }
    ]
  },
  {
    id: "cleaning",
    title: "3. Cleaning & Disinfection",
    description: "Manual and mechanical cleaning processes and monitoring.",
    questions: [
      {
        id: "clean_1",
        text: "Is water quality for reprocessing monitored and recorded?",
        clause: "Section 6",
        guidance: "Final rinse water quality must be compatible with the process. Water hardness and chloride levels can affect instruments and steriliser function.",
        defaultRisk: "Medium"
      },
      {
        id: "clean_2",
        text: "If using an Ultrasonic Cleaner, is a performance test (e.g., foil test or commercial indicator) conducted daily/weekly?",
        clause: "Section 6",
        guidance: "Daily operational checks and periodic performance tests are required to ensure cavitation is effective.",
        defaultRisk: "High"
      },
      {
        id: "clean_3",
        text: "Are brushes and cleaning aids inspected daily and replaced/disinfected?",
        clause: "Section 6",
        guidance: "Cleaning equipment itself can be a source of contamination if not maintained.",
        defaultRisk: "Medium"
      }
    ]
  },
  {
    id: "packaging",
    title: "4. Packaging & Sterilisation",
    description: "SBS (Sterile Barrier Systems), loading, and steriliser operation.",
    questions: [
      {
        id: "pack_1",
        text: "Are instrument packs labelled with a batch number that links to the patient?",
        clause: "Section 7",
        guidance: "Traceability to the patient is a key requirement. Batch control identification must be on every pack.",
        defaultRisk: "High"
      },
      {
        id: "pack_2",
        text: "Is a Chemical Indicator (Class 1) used on the outside of every pack (or internal if viewable)?",
        clause: "Section 7",
        guidance: "External indicators distinguish processed from unprocessed items.",
        defaultRisk: "High"
      },
      {
        id: "pack_3",
        text: "Are sterilisers loaded according to manufacturer instructions (no overloading)?",
        clause: "Section 7",
        guidance: "Overloading compromises steam penetration and drying.",
        defaultRisk: "Medium"
      }
    ]
  },
  {
    id: "validation",
    title: "5. Validation (IQ/OQ/PQ)",
    description: "Equipment validation and performance qualification.",
    questions: [
      {
        id: "val_1",
        text: "Has annual Performance Qualification (PQ) been conducted by a qualified technician?",
        clause: "Section 8 & 9",
        guidance: "PQ is mandatory annually. It validates that the steriliser works effectively for YOUR specific loads (reference loads).",
        defaultRisk: "High"
      },
      {
        id: "val_2",
        text: "Do you have a validation report that defines your 'Reference Loads' (Product Families)?",
        clause: "Section 9",
        guidance: "You must define what you sterilise (e.g., 'Solid Hollow', 'Porous'). The PQ must test these specific families.",
        defaultRisk: "High"
      }
    ]
  },
  {
    id: "patient_safety_consumers",
    title: "6. Patient Safety & Consumer Engagement",
    description: "Standards 2, 4, 5 & 6: Partnering with patients, medication safety, and clinical communication.",
    questions: [
      {
        id: "cons_1",
        text: "Does the practice have a formal mechanism to collect and act on patient feedback (e.g., annual satisfaction surveys)?",
        clause: "NSQHS Standard 2",
        guidance: "Evidence: Summary reports of survey results and meeting minutes showing where changes were made based on feedback.",
        defaultRisk: "Medium"
      },
      {
        id: "cons_2",
        text: "Is the Australian Charter of Healthcare Rights clearly displayed in the waiting area and understood by all staff?",
        clause: "NSQHS Standard 2",
        guidance: "Auditors will look for the poster and may ask staff how they support patient rights (e.g., privacy/informed consent).",
        defaultRisk: "Low"
      },
      {
        id: "med_1",
        text: "Is there a documented monthly check of the Medical Emergency Drug Kit (expiry dates and contents)?",
        clause: "NSQHS Standard 4",
        guidance: "Keep a logbook with the kit showing the date checked and the signature of the responsible staff member.",
        defaultRisk: "High"
      },
      {
        id: "med_2",
        text: "Are patient allergies and current medications confirmed and documented at every clinical appointment?",
        clause: "NSQHS Standard 4",
        guidance: "The clinical record must show a 'date last updated' for medical history at each visit, not just once a year.",
        defaultRisk: "High"
      },
      {
        id: "id_1",
        text: "Does the clinical team use three approved patient identifiers (Name, DOB, Address) before starting any treatment?",
        clause: "NSQHS Standard 5",
        guidance: "This is a core audit requirement. Staff should ask the patient to state these, rather than reading them out for the patient to confirm.",
        defaultRisk: "High"
      },
      {
        id: "id_2",
        text: "Is a 'Time Out' or surgical safety checklist used and recorded for all invasive procedures (extractions, implants)?",
        clause: "NSQHS Standard 5",
        guidance: "Evidence: A 'check-box' in the clinical notes confirming the correct patient, site, and procedure were verified before starting.",
        defaultRisk: "Medium"
      },
      {
        id: "comm_1",
        text: "Is there a standardized protocol for clinical handover between staff (e.g., using the ISBAR framework)?",
        clause: "NSQHS Standard 6",
        guidance: "ISBAR = Identification, Situation, Background, Assessment, Recommendation. You need a written policy describing this process.",
        defaultRisk: "Medium"
      }
    ]
  }
];

// --- Component ---

interface GapAnalysisWizardProps {
  onComplete: (score: number) => void;
  onClose: () => void;
}

export function GapAnalysisWizard({ onComplete, onClose }: GapAnalysisWizardProps) {
  const [currentStep, setCurrentStep] = useState(0); // 0 to SECTIONS.length - 1
  const [showReport, setShowReport] = useState(false);
  const [dismissedWarnings, setDismissedWarnings] = useState<string[]>([]);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [data, setData] = useState<GapAnalysisData>(() => {
    try {
      const saved = localStorage.getItem("dentalcheck.gap_analysis");
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });
  
  const activeSection = SECTIONS[currentStep];

  // Calculate stats
  const stats = useMemo(() => {
    let totalQuestions = 0;
    let completed = 0;
    let gaps = 0;
    let score = 0;

    SECTIONS.forEach(sec => {
      sec.questions.forEach(q => {
        totalQuestions++;
        const ans = data[q.id]?.status;
        if (ans) completed++;
        if (ans === "Yes" || ans === "NA") score++;
        if (ans === "No" || ans === "Partial") gaps++;
      });
    });

    const percent = totalQuestions > 0 ? Math.round((score / totalQuestions) * 100) : 0;
    return { totalQuestions, completed, gaps, score, percent };
  }, [data]);

  // Save to local storage whenever data changes
  const saveData = (newData: GapAnalysisData) => {
    localStorage.setItem("dentalcheck.gap_analysis", JSON.stringify(newData));
    setData(newData);
  };

  const handleAnswer = (qId: string, status: AnswerStatus) => {
    const newData = {
      ...data,
      [qId]: { ...data[qId], status }
    };
    saveData(newData);
  };

  const handleNote = (qId: string, note: string) => {
    const newData = {
      ...data,
      [qId]: { ...data[qId], notes: note }
    };
    saveData(newData);
  };

  const nextStep = () => {
    if (currentStep < SECTIONS.length - 1) {
      setCurrentStep(prev => prev + 1);
      window.scrollTo(0, 0);
    } else {
      setShowReport(true);
      onComplete(stats.percent);
      // Also save the score
      localStorage.setItem("dentalcheck.gap_score", stats.percent.toString());
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
      window.scrollTo(0, 0);
    }
  };

  // --- Logic Checks ---
  const activeWarnings = useMemo(() => {
    const warnings: { id: string; title: string; message: string }[] = [];
    
    // Check 1: Phantom Validation (Validation Section)
    if (data["val_1"]?.status === "Yes" && data["val_2"]?.status === "No") {
      warnings.push({
        id: "phantom_validation",
        title: "Contradiction Detected: Phantom Validation",
        message: "You have marked PQ as complete, but 'Reference Loads' as missing. A technician cannot perform a valid PQ without first defining your reference loads. Please review."
      });
    }

    // Check 2: Paperwork Paradox (Governance Section)
    if (data["gov_3"]?.status === "Yes" && data["gov_1"]?.status === "No") {
      warnings.push({
        id: "paperwork_paradox",
        title: "Contradiction Detected: Policy Gaps",
        message: "You indicated your policies are updated to AS 5369, but you lack a Risk Management Framework. Since the Standard requires this framework, your policies may still be non-compliant."
      });
    }

    // Check 3: Unidentified Surgery (Patient Safety Section)
    if (data["id_2"]?.status === "Yes" && data["id_1"]?.status === "No") {
      warnings.push({
        id: "unidentified_surgery",
        title: "Contradiction Detected: Safety Check Flaw",
        message: "You are conducting 'Time Outs' but not using the 3 Approved Identifiers. A valid Time Out requires checking these specific identifiers. Please check your protocol."
      });
    }

    // Check 4: Safe but Unknown (Governance Section)
    if (data["gov_1"]?.status === "Yes" && data["gov_2"]?.status === "No") {
      warnings.push({
        id: "safe_unknown",
        title: "Contradiction Detected: Accountability Gap",
        message: "You have a Risk Framework but no Designated Person (ICC). A framework requires an accountable person to function effectively."
      });
    }

    return warnings.filter(w => !dismissedWarnings.includes(w.id));
  }, [data, dismissedWarnings]);

  const handleDownloadSnapshot = async () => {
    try {
      setIsGeneratingPdf(true);

      // Allow UI to update
      await new Promise(resolve => setTimeout(resolve, 100));
      
      // Generate real PDF report using jsPDF + autoTable
      const doc = new jsPDF();
      
      // Header
      doc.setFontSize(20);
      doc.setTextColor(40, 40, 40);
      doc.text("Practice Accreditation Gap Analysis", 14, 22);
      
      doc.setFontSize(10);
      doc.setTextColor(100, 100, 100);
      doc.text(`Generated: ${new Date().toLocaleDateString()}`, 14, 28);
      doc.text("Standard: AS 5369:2023 & NSQHS", 14, 33);

      // Score Box
      doc.setFillColor(240, 240, 240);
      doc.roundedRect(140, 15, 50, 25, 3, 3, 'F');
      doc.setFontSize(10);
      doc.setTextColor(100, 100, 100);
      doc.text("Compliance Score", 165, 22, { align: "center" });
      doc.setFontSize(24);
      if (stats.percent >= 80) doc.setTextColor(0, 128, 0); // Green
      else if (stats.percent >= 50) doc.setTextColor(255, 165, 0); // Orange
      else doc.setTextColor(255, 0, 0); // Red
      doc.text(`${stats.percent}%`, 165, 33, { align: "center" });

      let yPos = 50;

      // Loop Sections
      SECTIONS.forEach((sec) => {
        // Section Title
        doc.setFontSize(14);
        doc.setTextColor(0, 0, 0);
        doc.text(sec.title, 14, yPos);
        yPos += 8;

        const tableBody = sec.questions.map(q => {
            const ans = data[q.id];
            return [
              q.text,
              q.clause,
              ans?.status || "Not Answered",
              ans?.notes || "-"
            ];
        });

        autoTable(doc, {
          startY: yPos,
          head: [['Requirement', 'Clause', 'Status', 'Notes']],
          body: tableBody,
          theme: 'grid',
          headStyles: { fillColor: [41, 128, 185], textColor: 255 },
          styles: { fontSize: 8, cellPadding: 3 },
          columnStyles: {
            0: { cellWidth: 80 },
            1: { cellWidth: 25 },
            2: { cellWidth: 25 },
            3: { cellWidth: 50 }
          },
          didParseCell: (data) => {
              if (data.section === 'body' && data.column.index === 2) {
                  const status = data.cell.raw;
                  if (status === 'Yes') data.cell.styles.textColor = [0, 128, 0];
                  if (status === 'No') data.cell.styles.textColor = [255, 0, 0];
                  if (status === 'Partial') data.cell.styles.textColor = [255, 165, 0];
              }
          }
        });

        yPos = (doc as any).lastAutoTable.finalY + 15;
        
        // Page break check (simple)
        if (yPos > 250) {
            doc.addPage();
            yPos = 20;
        }
      });

      doc.save(`Gap-Analysis-Report-${new Date().toISOString().split('T')[0]}.pdf`);
      
      // Also call onClose to exit after a short delay
      setTimeout(onClose, 1000);
      
    } catch (error) {
      console.error("PDF Generation failed:", error);
      alert("Failed to generate PDF. Please try using the Print -> Save as PDF option instead.");
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  if (showReport) {
    // --- Report View ---
    const gapList = SECTIONS.flatMap(sec => 
      sec.questions
        .filter(q => data[q.id]?.status === "No" || data[q.id]?.status === "Partial")
        .map(q => ({ ...q, section: sec.title, status: data[q.id]?.status, notes: data[q.id]?.notes }))
    );

    return (
      <div id="gap-analysis-report" className="max-w-5xl mx-auto space-y-8 animate-in fade-in duration-500">
        <div className="flex items-center justify-between mb-8">
            <button onClick={() => setShowReport(false)} className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
                <ChevronLeft className="w-4 h-4" /> Back to Assessment
            </button>
            <div className="flex gap-4">
                <button 
                  onClick={handleDownloadSnapshot} 
                  disabled={isGeneratingPdf}
                  className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:opacity-90 transition-colors disabled:opacity-50 disabled:cursor-wait"
                >
                    {isGeneratingPdf ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                    {isGeneratingPdf ? "Generating..." : "Save & Download PDF"}
                </button>
            </div>
        </div>
        
        {/* Disclaimer / Guidance */}
        <div className="bg-blue-50/50 border border-blue-100 p-4 rounded-xl flex items-start gap-3">
             <Info className="w-5 h-5 text-blue-600 mt-0.5 shrink-0" />
             <div className="text-sm text-blue-800">
                 <p className="font-bold mb-1">Important Guidance</p>
                 <p className="mb-2">This tool is a self-assessment aid to help identify gaps against AS 5369:2023 and NSQHS Standards. It does not constitute a formal validation or legal advice.</p>
                 <div className="flex flex-wrap gap-4 mt-2">
                     <a href="https://www.ada.org.au" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline text-xs font-bold flex items-center gap-1">
                        <ArrowRight className="w-3 h-3" /> ADA Member Portal
                     </a>
                     <a href="https://www.standards.org.au" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline text-xs font-bold flex items-center gap-1">
                        <ArrowRight className="w-3 h-3" /> Standards Australia (AS 5369:2023)
                     </a>
                 </div>
             </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Score Card */}
            <div className="bg-card rounded-xl border border-border p-6 shadow-sm flex flex-col items-center justify-center text-center">
                <h3 className="text-muted-foreground font-medium uppercase tracking-wider text-xs mb-2">Compliance Score</h3>
                <div className={cn("text-5xl font-bold mb-2", 
                    stats.percent >= 80 ? "text-green-600" : 
                    stats.percent >= 50 ? "text-amber-500" : "text-red-500"
                )}>
                    {stats.percent}%
                </div>
                <p className="text-xs text-muted-foreground">Aligned with AS 5369:2023 & NSQHS</p>
            </div>
            
            {/* Summary Stats */}
            <div className="md:col-span-2 bg-card rounded-xl border border-border p-6 shadow-sm grid grid-cols-3 gap-4">
                <div className="text-center p-4 bg-red-50 rounded-lg border border-red-100">
                    <div className="text-2xl font-bold text-red-600 mb-1">{gapList.filter(g => g.defaultRisk === "High").length}</div>
                    <div className="text-xs font-bold text-red-800 uppercase">High Risk Gaps</div>
                </div>
                <div className="text-center p-4 bg-amber-50 rounded-lg border border-amber-100">
                    <div className="text-2xl font-bold text-amber-600 mb-1">{gapList.length}</div>
                    <div className="text-xs font-bold text-amber-800 uppercase">Total Gaps Identified</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg border border-green-100">
                    <div className="text-2xl font-bold text-green-600 mb-1">{stats.completed} / {stats.totalQuestions}</div>
                    <div className="text-xs font-bold text-green-800 uppercase">Questions Answered</div>
                </div>
            </div>
        </div>

        {/* Action Plan */}
        <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
            <div className="p-6 border-b border-border bg-muted/30">
                <h3 className="font-display font-bold text-lg flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-amber-500" />
                    Priority Action Plan
                </h3>
                <p className="text-sm text-muted-foreground mt-1">Based on your identified gaps against AS 5369:2023 & NSQHS</p>
            </div>
            {gapList.length === 0 ? (
                <div className="p-12 text-center text-muted-foreground">
                    <CheckCircle2 className="w-12 h-12 text-green-500 mx-auto mb-4" />
                    <p className="font-medium">No gaps identified!</p>
                    <p className="text-sm">Great job aligning with the new standard.</p>
                </div>
            ) : (
                <table className="w-full text-sm text-left">
                    <thead className="bg-muted/50 text-muted-foreground font-medium border-b border-border">
                        <tr>
                            <th className="px-6 py-4 w-24">Risk</th>
                            <th className="px-6 py-4">Gap / Requirement</th>
                            <th className="px-6 py-4 w-40">Standard Ref</th>
                            <th className="px-6 py-4 w-1/3">Your Notes</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                        {gapList.sort((a, b) => (a.defaultRisk === "High" ? -1 : 1)).map((gap) => (
                            <tr key={gap.id} className="hover:bg-muted/5">
                                <td className="px-6 py-4">
                                    <span className={cn(
                                        "px-2 py-1 rounded-full text-[10px] font-bold uppercase border",
                                        gap.defaultRisk === "High" ? "bg-red-100 text-red-700 border-red-200" :
                                        gap.defaultRisk === "Medium" ? "bg-amber-100 text-amber-700 border-amber-200" :
                                        "bg-blue-100 text-blue-700 border-blue-200"
                                    )}>
                                        {gap.defaultRisk}
                                    </span>
                                </td>
                                <td className="px-6 py-4">
                                    <div className="font-medium text-foreground mb-1">{gap.text}</div>
                                    <div className="text-xs text-muted-foreground">{gap.guidance}</div>
                                </td>
                                <td className="px-6 py-4 font-mono text-xs text-muted-foreground">{gap.clause}</td>
                                <td className="px-6 py-4 italic text-muted-foreground">{gap.notes || "No notes added"}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
      </div>
    );
  }

  // --- Wizard Step View ---

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in slide-in-from-right-4 duration-500">
      
      {/* Preface / Important Note */}
      {currentStep === 0 && (
        <div className="bg-blue-50/50 p-6 rounded-xl border border-blue-100 space-y-2 mb-8">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
            <div className="text-sm text-blue-800 leading-relaxed font-medium">
              <p>
                <strong className="block text-blue-900 mb-1">IMPORTANT NOTE</strong>
                A formal, documented gap analysis against AS 5369:2023 & NSQHS is <strong>NOT mandatory</strong> for most dental practices.
              </p>
              <p className="mt-2">
                It is only required if your practice is pursuing or maintaining accreditation under the <strong>National Safety and Quality Health Service (NSQHS) Standards</strong> (e.g., through QIP or HDAA), which incorporate AS 5369:2023 for reprocessing compliance.
              </p>
              <p className="mt-2">
                For non-accredited practices, ongoing risk-based compliance with the standards is still expected under DBA and ADA requirements. This tool is provided as a helpful self-assessment aid to support best practice and audit preparedness.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Header / Progress */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-display font-bold text-primary mb-1">Practice Accreditation Gap Analysis</h2>
          <p className="text-sm text-muted-foreground">Self-Assessment Tool • Step {currentStep + 1} of {SECTIONS.length}</p>
        </div>
        <div className="text-right">
             <div className="text-sm font-bold text-primary mb-1">{Math.round(((currentStep) / SECTIONS.length) * 100)}% Complete</div>
             <div className="w-32 h-2 bg-secondary rounded-full overflow-hidden">
                <div className="h-full bg-primary transition-all duration-500" style={{ width: `${((currentStep) / SECTIONS.length) * 100}%` }} />
             </div>
        </div>
      </div>

      {/* Section Card */}
      <div className="bg-card rounded-2xl border border-border shadow-sm overflow-hidden">
        <div className="bg-muted/30 border-b border-border p-6">
            <h3 className="text-xl font-bold text-foreground">{activeSection.title}</h3>
            <p className="text-sm text-muted-foreground mt-1">{activeSection.description}</p>
        </div>
        
        {/* Active Logic Warnings */}
        <AnimatePresence>
          {activeWarnings.map(warning => (
            <motion.div
              key={warning.id}
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="bg-amber-50 border-b border-amber-200"
            >
              <div className="p-4 flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <h4 className="text-sm font-bold text-amber-900 mb-1">{warning.title}</h4>
                  <p className="text-sm text-amber-800 leading-relaxed">{warning.message}</p>
                </div>
                <button 
                  onClick={() => setDismissedWarnings(prev => [...prev, warning.id])}
                  className="text-amber-600 hover:text-amber-800 transition-colors p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        <div className="divide-y divide-border">
            {activeSection.questions.map((q) => (
                <div key={q.id} className="p-6 hover:bg-muted/5 transition-colors">
                    <div className="flex items-start gap-4 mb-4">
                        <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                                <span className="px-2 py-0.5 rounded bg-secondary text-secondary-foreground text-[10px] font-bold uppercase">{q.clause}</span>
                                {q.defaultRisk === "High" && (
                                    <span className="flex items-center gap-1 text-[10px] font-bold text-red-600 bg-red-50 px-2 py-0.5 rounded border border-red-100">
                                        <AlertCircle className="w-3 h-3" /> HIGH RISK
                                    </span>
                                )}
                            </div>
                            <h4 className="font-medium text-foreground text-base mb-2 leading-relaxed">{q.text}</h4>
                            
                            <div className="flex items-start gap-2 p-3 bg-blue-50/50 rounded-lg border border-blue-100 text-sm text-blue-800">
                                <Info className="w-4 h-4 shrink-0 mt-0.5" />
                                <p className="text-xs leading-relaxed">{q.guidance}</p>
                            </div>
                        </div>

                        <div className="shrink-0 w-48 space-y-2">
                            <label className="text-[10px] font-bold uppercase text-muted-foreground tracking-wider">Compliance Status</label>
                            <select 
                                value={data[q.id]?.status || ""}
                                onChange={(e) => handleAnswer(q.id, e.target.value as AnswerStatus)}
                                className={cn(
                                    "w-full p-2.5 rounded-lg border text-sm font-medium outline-none focus:ring-2 focus:ring-primary/20 transition-all",
                                    data[q.id]?.status === "Yes" ? "bg-green-50 border-green-200 text-green-700" :
                                    data[q.id]?.status === "No" ? "bg-red-50 border-red-200 text-red-700" :
                                    data[q.id]?.status === "Partial" ? "bg-amber-50 border-amber-200 text-amber-700" :
                                    data[q.id]?.status === "NA" ? "bg-gray-50 border-gray-200 text-gray-600" :
                                    "bg-background border-border"
                                )}
                            >
                                <option value="">Select...</option>
                                <option value="Yes">Yes (Compliant)</option>
                                <option value="Partial">Partial</option>
                                <option value="No">No (Gap)</option>
                                <option value="NA">N/A</option>
                            </select>
                        </div>
                    </div>
                    
                    {/* Notes Field - Expand if answered */}
                    {data[q.id]?.status && (
                        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} className="pl-4 border-l-2 border-border ml-1">
                             <label className="text-[10px] font-bold uppercase text-muted-foreground tracking-wider mb-1 block">Evidence / Action Notes</label>
                             <textarea 
                                value={data[q.id]?.notes || ""}
                                onChange={(e) => handleNote(q.id, e.target.value)}
                                placeholder="Describe your evidence or action plan..."
                                className="w-full bg-muted/20 border border-border rounded-lg p-3 text-sm focus:bg-background outline-none transition-colors min-h-[80px] resize-y"
                             />
                        </motion.div>
                    )}
                </div>
            ))}
        </div>

        {/* Navigation */}
        <div className="p-6 bg-muted/30 border-t border-border flex justify-between items-center">
            <button 
                onClick={prevStep}
                disabled={currentStep === 0}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold text-sm disabled:opacity-50 disabled:cursor-not-allowed hover:bg-background transition-colors"
            >
                <ChevronLeft className="w-4 h-4" /> Previous
            </button>
            
            <div className="flex gap-2">
                <button 
                    onClick={onClose}
                    className="px-6 py-2.5 rounded-xl font-bold text-sm text-muted-foreground hover:bg-background transition-colors"
                >
                    Save & Exit
                </button>
                <button 
                    onClick={nextStep}
                    className="flex items-center gap-2 px-8 py-2.5 bg-primary text-primary-foreground rounded-xl font-bold text-sm shadow-lg hover:opacity-90 transition-all"
                >
                    {currentStep === SECTIONS.length - 1 ? "View Report" : "Next Section"}
                    <ArrowRight className="w-4 h-4" />
                </button>
            </div>
        </div>
      </div>
    </div>
  );
}