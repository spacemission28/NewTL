import { CheckCircle2, AlertCircle, Clock, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export interface Task {
  id: string;
  title: string;
  category?: string;
  progress?: number;
  status?: "INCOMPLETE" | "COMPLETE" | string;
  type?: "task" | "heading";
}

const defaultTasks: Task[] = [
  { id: "1", title: "Infection Control Manual Review", category: "Infection Control", progress: 65 },
];

interface TaskTableProps {
  tasks?: Task[];
}

export function TaskTable({ tasks = defaultTasks }: TaskTableProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <>
      <div className={cn(
        "bg-card rounded-xl border border-border shadow-sm overflow-hidden flex flex-col h-full transition-all duration-500",
        isExpanded ? "fixed inset-4 z-50 m-auto max-w-6xl max-h-[80vh]" : "relative"
      )}>
        <div className="p-6 border-b border-border flex justify-between items-center bg-card">
          <div>
            <h3 className="font-display font-semibold text-lg">Renewal Countdown</h3>
            <p className="text-sm text-muted-foreground">Track your compliance progress</p>
          </div>
          <button 
            onClick={() => setIsExpanded(!isExpanded)}
            className="text-sm font-medium text-primary hover:text-primary/80 transition-colors"
          >
            {isExpanded ? "Close" : "View All"}
          </button>
        </div>
        <div className="overflow-x-auto flex-1 bg-card">
          <table className="w-full text-sm text-left">
            <thead className="bg-muted/50 text-muted-foreground font-medium sticky top-0 z-10">
              <tr>
                <th className="px-3 md:px-6 py-3">Task</th>
                <th className="hidden md:table-cell px-6 py-3">Category</th>
                <th className="px-3 md:px-6 py-3 w-48">Percentage Complete</th>
                <th className="px-3 md:px-6 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {tasks.map((task) => {
                if (task.type === "heading") {
                  return (
                    <tr key={task.id} className="bg-muted/30">
                      <td colSpan={4} className="px-3 md:px-6 py-3 font-bold text-sm text-foreground uppercase tracking-wider border-y border-border/50">
                        {task.title}
                      </td>
                    </tr>
                  );
                }
                
                return (
                <tr key={task.id} className="hover:bg-muted/20 transition-colors group">
                  <td className="px-3 md:px-6 py-4 font-medium text-foreground pl-7 md:pl-10 relative">
                    <div className="absolute left-2 md:left-6 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-muted-foreground/40" />
                    {task.title}
                  </td>
                  <td className="hidden md:table-cell px-6 py-4 text-muted-foreground">{task.category}</td>
                  <td className="px-3 md:px-6 py-4">
                    {task.status === "INCOMPLETE" ? (
                      <span className="text-xs font-bold text-amber-600 bg-amber-50 dark:bg-amber-900/20 dark:text-amber-400 px-2 py-1 rounded border border-amber-200 dark:border-amber-800">
                        INCOMPLETE
                      </span>
                    ) : task.status === "COMPLETE" ? (
                      <span className="text-xs font-bold text-green-600 bg-green-50 dark:bg-green-900/20 dark:text-green-400 px-2 py-1 rounded border border-green-200 dark:border-green-800">
                        COMPLETE
                      </span>
                    ) : task.status ? (
                      <span className="text-xs font-bold text-blue-600 bg-blue-50 dark:bg-blue-900/20 dark:text-blue-400 px-2 py-1 rounded border border-blue-200 dark:border-blue-800">
                        {task.status}
                      </span>
                    ) : (
                      <div className="flex items-center gap-3">
                        <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                          <div 
                            className={cn(
                              "h-full rounded-full transition-all duration-500",
                              (task.progress || 0) === 100 ? "bg-green-500" :
                              (task.progress || 0) >= 50 ? "bg-primary" :
                              "bg-amber-500"
                            )}
                            style={{ width: `${task.progress || 0}%` }}
                          />
                        </div>
                        <span className="text-xs font-medium w-9 text-right">{task.progress || 0}%</span>
                      </div>
                    )}
                  </td>
                  <td className="px-3 md:px-6 py-4 text-right">
                    <button className="text-primary opacity-0 group-hover:opacity-100 transition-opacity">
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* Backdrop for expanded state */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsExpanded(false)}
            className="fixed inset-0 bg-black/50 z-40 backdrop-blur-sm"
          />
        )}
      </AnimatePresence>
    </>
  );
}