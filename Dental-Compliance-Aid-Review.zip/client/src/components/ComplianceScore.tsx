import { CircularProgressbarWithChildren, buildStyles } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';
import { motion } from "framer-motion";

interface ComplianceScoreProps {
  score: number;
  label: string;
}

export function ComplianceScore({ score, label }: ComplianceScoreProps) {
  // Determine color based on score
  const getColor = (s: number) => {
    if (s >= 90) return "hsl(150, 60%, 45%)"; // Success
    if (s >= 70) return "hsl(35, 90%, 50%)"; // Warning
    return "hsl(0, 84%, 60%)"; // Danger
  };

  return (
    <div className="bg-card rounded-xl border border-border shadow-sm p-6 flex flex-col items-center justify-center">
      <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-4">{label}</h3>
      <div className="w-40 h-40">
        <CircularProgressbarWithChildren
          value={score}
          styles={buildStyles({
            pathColor: getColor(score),
            trailColor: "hsl(210, 20%, 90%)",
            strokeLinecap: "round",
            pathTransitionDuration: 1.5,
          })}
        >
          <div className="flex flex-col items-center justify-center text-center">
            <span className="text-4xl font-display font-bold text-foreground">
              {score}%
            </span>
            <span className="text-xs text-muted-foreground font-medium mt-1">
              Compliant
            </span>
          </div>
        </CircularProgressbarWithChildren>
      </div>
      <div className="mt-6 w-full grid grid-cols-2 gap-4 text-center">
        <div className="p-3 bg-secondary/50 rounded-lg">
          <div className="text-xs text-muted-foreground">Last Audit</div>
          <div className="font-semibold text-sm">Oct 12, 2025</div>
        </div>
        <div className="p-3 bg-secondary/50 rounded-lg">
          <div className="text-xs text-muted-foreground">Next Due</div>
          <div className="font-semibold text-sm">Jan 20, 2026</div>
        </div>
      </div>
    </div>
  );
}