import { 
  GraduationCap, 
  FileText, 
  LayoutDashboard,
  Activity,
  PanelLeftClose,
  PanelLeft,
  Camera,
  Users,
  QrCode
} from "lucide-react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

interface SidebarProps {
  isCollapsed: boolean;
  setIsCollapsed: (value: boolean) => void;
  onDashboardClick?: () => void;
  hideCollapseButton?: boolean;
}

export function Sidebar({ isCollapsed, setIsCollapsed, onDashboardClick, hideCollapseButton }: SidebarProps) {
  const [location, setLocation] = useLocation();

  const navItems = [
    { icon: LayoutDashboard, label: "Dashboard", href: "/dashboard" },
    { icon: GraduationCap, label: "Your Details", href: "/details" },
    { icon: Users, label: "Staff Info", href: "/staff-info" },
    { icon: FileText, label: "All Documents", href: "/reports" },
  ];

  const handleNavClick = (href: string) => {
    // Navigate to dashboard and reset state
    if (href === "/dashboard") {
      // Force immediate scroll to top
      window.scrollTo(0, 0);
      document.documentElement.scrollTop = 0;
      document.body.scrollTop = 0;

      const main = document.querySelector(".app-main") as HTMLElement | null;
      if (main) {
        main.scrollTo({ top: 0, left: 0, behavior: "auto" });
      }
      
      // Dispatch reset event for Dashboard component state
      window.dispatchEvent(new CustomEvent('dashboard-reset'));
      
      if (onDashboardClick) {
        onDashboardClick();
      }
    } else {
        // For other links, if on mobile/overlay mode, close the sidebar
        if (onDashboardClick) {
            onDashboardClick();
        }
    }
  };

  const handleSnapClick = () => {
      // Navigate to the dedicated Document Snap page
      setLocation("/document-snap");
  };

  const handleCPDSnapClick = () => {
      setLocation("/cpd-snap");
  };

  return (
    <div 
      className={cn(
        "app-sidebar flex h-full flex-col bg-sidebar border-r border-sidebar-border transition-all duration-300 ease-in-out",
        isCollapsed ? "w-16" : "w-56"
      )}
    >
      <div className="flex h-16 items-center justify-between px-4 border-b border-sidebar-border">
        {!isCollapsed && (
          <div className="flex items-center">
            <Activity className="h-6 w-6 text-primary mr-2" />
            <span className="font-display font-bold text-lg text-sidebar-foreground tracking-tight whitespace-nowrap">
              DentalCheck
            </span>
          </div>
        )}
        {isCollapsed && <Activity className="h-6 w-6 text-primary mx-auto" />}
        {!hideCollapseButton && (
          <button 
            onClick={() => setIsCollapsed(!isCollapsed)}
            className={cn(
              "p-1.5 rounded-md hover:bg-sidebar-accent transition-colors",
              isCollapsed ? "mx-auto" : "ml-2"
            )}
          >
            {isCollapsed ? <PanelLeft className="h-5 w-5 text-sidebar-foreground/70" /> : <PanelLeftClose className="h-5 w-5 text-sidebar-foreground/70" />}
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto py-6 flex flex-col">
        <nav className="space-y-1 px-3">
          {/* Dashboard Icon - Always visible, but special handling for mobile to ensure it's top */}
          <Link href="/dashboard">
              <a
                  onClick={() => handleNavClick("/dashboard")}
                  className={cn(
                      "flex items-center px-3 py-3 text-sm font-medium rounded-md transition-colors",
                      location === "/dashboard" || location === "/"
                          ? "bg-sidebar-accent text-sidebar-primary shadow-sm"
                          : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground",
                      isCollapsed && "justify-center px-0",
                      // On desktop, we hide this specific instance if we want to rely on the loop, 
                      // BUT to be safe and ensure it's ALWAYS there and ALWAYS top, let's just keep it here 
                      // and remove it from the navItems loop completely.
                  )}
                  title={isCollapsed ? "Dashboard" : ""}
              >
                  <LayoutDashboard
                      className={cn(
                          "h-5 w-5 flex-shrink-0 transition-colors",
                          !isCollapsed && "mr-3",
                          location === "/dashboard" || location === "/" ? "text-sidebar-primary" : "text-sidebar-foreground/50"
                      )}
                  />
                  {!isCollapsed && <span className="whitespace-nowrap">Dashboard</span>}
              </a>
          </Link>

          {navItems.map((item) => {
            // Skip Dashboard since we manually rendered it at the top
            if (item.href === "/dashboard") return null;

            const isActive = location === item.href || (item.href === "/dashboard" && location === "/");
            return (
              <Link key={item.href} href={item.href}>
                <a
                  onClick={() => handleNavClick(item.href)}
                  className={cn(
                    "flex items-center px-3 py-3 text-sm font-medium rounded-md transition-colors",
                    isActive
                      ? "bg-sidebar-accent text-sidebar-primary shadow-sm"
                      : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground",
                    isCollapsed && "justify-center px-0"
                  )}
                  title={isCollapsed ? item.label : ""}
                >
                  <item.icon
                    className={cn(
                      "h-5 w-5 flex-shrink-0 transition-colors",
                      !isCollapsed && "mr-3",
                      isActive ? "text-sidebar-primary" : "text-sidebar-foreground/50"
                    )}
                  />
                  {!isCollapsed && <span className="whitespace-nowrap">{item.label}</span>}
                </a>
              </Link>
            );
          })}
        </nav>

        {/* Document Snap Tile */}
        <div className="px-3 pb-2 mt-auto space-y-2">
            <button
                onClick={handleSnapClick}
                className={cn(
                    "bg-primary/10 hover:bg-primary/20 border border-primary/20 rounded-xl flex flex-col items-center justify-center text-center transition-all group w-full",
                    isCollapsed ? "p-2 aspect-square" : "p-3 h-28"
                )}
                title="Document Snap"
            >
                <Camera className={cn("text-primary group-hover:scale-110 transition-transform", isCollapsed ? "h-6 w-6 mb-0" : "h-8 w-8 mb-2")} strokeWidth={1.5} />
                {!isCollapsed && (
                    <>
                        <span className="text-primary font-bold text-xs block mb-0.5">Document Snap</span>
                        <span className="text-[9px] text-primary/70 leading-tight block">General Uploads</span>
                    </>
                )}
            </button>

            <button
                onClick={handleCPDSnapClick}
                className={cn(
                    "bg-blue-50 hover:bg-blue-100 border border-blue-200 dark:bg-blue-900/20 dark:hover:bg-blue-900/30 dark:border-blue-800 rounded-xl flex flex-col items-center justify-center text-center transition-all group w-full",
                    isCollapsed ? "p-2 aspect-square" : "p-3 h-28"
                )}
                title="CPD Log Snap"
            >
                <QrCode className={cn("text-blue-600 dark:text-blue-400 group-hover:scale-110 transition-transform", isCollapsed ? "h-6 w-6 mb-0" : "h-8 w-8 mb-2")} strokeWidth={1.5} />
                {!isCollapsed && (
                    <>
                        <span className="text-blue-700 dark:text-blue-300 font-bold text-xs block mb-0.5">CPD Log Snap</span>
                        <span className="text-[9px] text-blue-600/70 dark:text-blue-400/70 leading-tight block">Log Activities</span>
                    </>
                )}
            </button>
        </div>
      </div>

      <div className="p-4 border-t border-sidebar-border">
        <div className={cn(
          "flex items-center p-2 rounded-md bg-sidebar-accent/30",
          isCollapsed && "justify-center p-1"
        )}>
          <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs shrink-0">
            DR
          </div>
          {!isCollapsed && (
            <div className="ml-3 overflow-hidden">
              <p className="text-sm font-medium text-sidebar-foreground truncate">Dr. Reynolds</p>
              <p className="text-xs text-sidebar-foreground/50 truncate">Admin</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
