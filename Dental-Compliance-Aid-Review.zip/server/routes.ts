import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertStaffSchema } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // put application routes here
  // prefix all routes with /api

  // use storage to perform CRUD operations on the storage interface
  // e.g. storage.insertUser(user) or storage.getUserByUsername(username)

  app.get("/api/staff", async (req, res) => {
    const staff = await storage.getStaffList();
    res.json(staff);
  });

  app.post("/api/staff", async (req, res) => {
    const result = insertStaffSchema.safeParse(req.body);
    if (!result.success) {
      res.status(400).json(result.error);
      return;
    }
    const staff = await storage.createStaff(result.data);
    res.json(staff);
  });

  app.patch("/api/staff/:id", async (req, res) => {
    const result = insertStaffSchema.partial().safeParse(req.body);
    if (!result.success) {
      res.status(400).json(result.error);
      return;
    }
    const staff = await storage.updateStaff(req.params.id, result.data);
    if (!staff) {
      res.status(404).json({ message: "Staff not found" });
      return;
    }
    res.json(staff);
  });

  app.delete("/api/staff/:id", async (req, res) => {
    await storage.deleteStaff(req.params.id);
    res.status(204).end();
  });

  return httpServer;
}
