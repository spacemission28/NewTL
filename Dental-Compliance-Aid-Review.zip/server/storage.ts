import { type User, type InsertUser, type Staff, type InsertStaff } from "@shared/schema";
import { randomUUID } from "crypto";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getStaffList(): Promise<Staff[]>;
  createStaff(staff: InsertStaff): Promise<Staff>;
  updateStaff(id: string, updates: Partial<InsertStaff>): Promise<Staff | undefined>;
  deleteStaff(id: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private staff: Map<string, Staff>;

  constructor() {
    this.users = new Map();
    this.staff = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getStaffList(): Promise<Staff[]> {
    return Array.from(this.staff.values());
  }

  async createStaff(insertStaff: InsertStaff): Promise<Staff> {
    const id = randomUUID();
    const staff: Staff = { 
      ...insertStaff, 
      id,
      email: insertStaff.email ?? null,
      startDate: insertStaff.startDate ?? null,
      notes: insertStaff.notes ?? null
    };
    this.staff.set(id, staff);
    return staff;
  }

  async updateStaff(id: string, updates: Partial<InsertStaff>): Promise<Staff | undefined> {
    const existing = this.staff.get(id);
    if (!existing) return undefined;
    const updated = { 
      ...existing, 
      ...updates,
      email: updates.email !== undefined ? updates.email : existing.email,
      startDate: updates.startDate !== undefined ? updates.startDate : existing.startDate,
      notes: updates.notes !== undefined ? updates.notes : existing.notes
    };
    this.staff.set(id, updated);
    return updated;
  }

  async deleteStaff(id: string): Promise<void> {
    this.staff.delete(id);
  }
}

export const storage = new MemStorage();
