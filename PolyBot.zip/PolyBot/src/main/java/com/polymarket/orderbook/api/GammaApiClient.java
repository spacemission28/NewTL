package com.polymarket.orderbook.api;

import com.polymarket.orderbook.config.AppConfig;
import com.polymarket.orderbook.model.Event;
import com.polymarket.orderbook.model.Market;
import com.polymarket.orderbook.model.Series;
import com.polymarket.orderbook.util.JsonUtil;
import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.ParseException;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.apache.hc.core5.util.Timeout;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;

import java.io.IOException;
import java.math.BigDecimal;

public class GammaApiClient {

    private static final Logger logger = LoggerFactory.getLogger(GammaApiClient.class);
    private final String baseUrl;
    private final CloseableHttpClient httpClient;
    private final ObjectMapper objectMapper;

    public GammaApiClient() {
        this.baseUrl = AppConfig.getInstance().getGammaApiUrl();
        this.objectMapper = new ObjectMapper();

        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(Timeout.ofSeconds(10))
                .setConnectionRequestTimeout(Timeout.ofSeconds(10))
                .setResponseTimeout(Timeout.ofSeconds(30))
                .build();

        this.httpClient = HttpClients.custom()
                .setDefaultRequestConfig(requestConfig)
                .build();

        logger.info("GammaApiClient initialized with 10s connect timeout and 30s response timeout");
    }

    private void addBrowserHeaders(HttpGet request) {
        request.setHeader("Accept", "application/json");
        request.setHeader("Accept-Language", "en-US,en;q=0.9");
        request.setHeader("Accept-Encoding", "gzip, deflate, br");
        request.setHeader("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
        request.setHeader("sec-ch-ua", "\"Not_A Brand\";v=\"8\", \"Chromium\";v=\"120\", \"Google Chrome\";v=\"120\"");
        request.setHeader("sec-ch-ua-mobile", "?0");
        request.setHeader("sec-ch-ua-platform", "\"macOS\"");
        request.setHeader("sec-fetch-dest", "empty");
        request.setHeader("sec-fetch-mode", "cors");
        request.setHeader("sec-fetch-site", "cross-site");
        request.setHeader("Connection", "keep-alive");
    }

    public Market getMarketBySlug(String slug) throws IOException, ParseException {
        String url = String.format("%s/markets?slug=%s", baseUrl, slug);
        logger.info("Fetching market data for slug: {}", slug);

        HttpGet request = new HttpGet(url);
        addBrowserHeaders(request);

        try (CloseableHttpResponse response = httpClient.execute(request)) {
            int statusCode = response.getCode();
            String responseBody = EntityUtils.toString(response.getEntity());

            if (statusCode != 200) {
                logger.error("Failed to fetch market. Status: {}, Body: {}", statusCode, responseBody);
                throw new IOException("Failed to fetch market: " + statusCode);
            }

            logger.info("Market response received, length: {} bytes", responseBody.length());
            logger.debug("Market response body: {}", responseBody);

            Market[] markets = null;
            try {
                markets = JsonUtil.fromJson(responseBody, Market[].class);
            } catch (Exception e) {
                logger.error("Failed to parse market JSON response", e);
                logger.error("Response body: {}", responseBody);
                throw new IOException("Failed to parse market response: " + e.getMessage(), e);
            }

            if (markets == null || markets.length == 0) {
                logger.error("No markets found in response for slug: {}", slug);
                throw new IOException("No market found for slug: " + slug);
            }

            Market market = markets[0];
            logger.info("Successfully fetched market: {} (token IDs: {})",
                    market.getQuestion(), market.getClobTokenIds());

            return market;
        }
    }

    public Event getEventBySlug(String slug) throws IOException, ParseException {
        String url = String.format("%s/events?slug=%s", baseUrl, slug);
        logger.info("Fetching event data for slug: {}", slug);

        HttpGet request = new HttpGet(url);
        addBrowserHeaders(request);

        try (CloseableHttpResponse response = httpClient.execute(request)) {
            int statusCode = response.getCode();
            String responseBody = EntityUtils.toString(response.getEntity());

            if (statusCode != 200) {
                logger.error("Failed to fetch event. Status: {}, Body: {}", statusCode, responseBody);
                throw new IOException("Failed to fetch event: " + statusCode);
            }

            logger.debug("Event response body: {}", responseBody);

            Event[] events = null;
            try {
                events = JsonUtil.fromJson(responseBody, Event[].class);
            } catch (Exception e) {
                logger.error("Failed to parse event JSON response", e);
                throw new IOException("Failed to parse event response: " + e.getMessage(), e);
            }

            if (events == null || events.length == 0) {
                logger.error("No events found in response for slug: {}", slug);
                throw new IOException("No event found for slug: " + slug);
            }

            Event event = events[0];
            logger.info("Successfully fetched event: {} with {} markets",
                    event.getTitle(), event.getMarkets() != null ? event.getMarkets().size() : 0);

            return event;
        }
    }

    public Series getSeriesBySlug(String slug) throws IOException, ParseException {
        String normalizedSlug = slug.replace("btc-updown-", "btc-up-or-down-");
        String url = String.format("%s/series?slug=%s", baseUrl, normalizedSlug);
        logger.info("Fetching series data for slug: {}", normalizedSlug);

        HttpGet request = new HttpGet(url);
        addBrowserHeaders(request);

        try (CloseableHttpResponse response = httpClient.execute(request)) {
            int statusCode = response.getCode();
            String responseBody = EntityUtils.toString(response.getEntity());

            if (statusCode != 200) {
                logger.error("Failed to fetch series. Status: {}, Body: {}", statusCode, responseBody);
                throw new IOException("Failed to fetch series: " + statusCode);
            }

            logger.debug("Series response body: {}", responseBody);

            Series[] seriesArray = null;
            try {
                seriesArray = JsonUtil.fromJson(responseBody, Series[].class);
            } catch (Exception e) {
                logger.error("Failed to parse series JSON response", e);
                throw new IOException("Failed to parse series response: " + e.getMessage(), e);
            }

            if (seriesArray == null || seriesArray.length == 0) {
                logger.error("No series found in response for slug: {}", normalizedSlug);
                throw new IOException("No series found for slug: " + normalizedSlug);
            }

            Series series = seriesArray[0];
            logger.info("Successfully fetched series: {} with {} events",
                    series.getTitle(), series.getEvents() != null ? series.getEvents().size() : 0);

            return series;
        }
    }

    public Market resolveSlugToMarket(String slug) throws IOException, ParseException {
        logger.info("Resolving slug to market: {}", slug);

        try {
            Market market = getMarketBySlug(slug);
            logger.info("Resolved as market slug: {}", market.getQuestion());
            return market;
        } catch (IOException e) {
            logger.info("Not a market slug, trying as event slug...");
        }

        try {
            Event event = getEventBySlug(slug);
            Market market = event.getActiveMarket();

            if (market != null) {
                logger.info("Found market in event: {}, now fetching full market details by slug", market.getQuestion());

                String marketSlug = market.getSlug();
                if (marketSlug != null) {
                    Market fullMarket = getMarketBySlug(marketSlug);
                    logger.info("Resolved via event to market: {}", fullMarket.getQuestion());
                    return fullMarket;
                }
            }
        } catch (IOException e) {
            logger.info("Not an event slug, trying as series slug...");
        }

        Series series = getSeriesBySlug(slug);
        Event currentEvent = series.getCurrentEvent();

        if (currentEvent == null) {
            throw new IOException("No active event found in series: " + slug);
        }

        logger.info("Found current event in series: {}", currentEvent.getTitle());

        String eventSlug = currentEvent.getSlug();
        if (eventSlug == null) {
            throw new IOException("Current event has no slug: " + slug);
        }

        logger.info("Fetching full event details for: {}", eventSlug);
        Event fullEvent = getEventBySlug(eventSlug);
        Market market = fullEvent.getActiveMarket();

        if (market == null) {
            throw new IOException("No active market found in event: " + eventSlug);
        }

        logger.info("Found market in event: {}, now fetching full market details by slug", market.getQuestion());

        String marketSlug = market.getSlug();
        if (marketSlug == null) {
            throw new IOException("Market has no slug in event: " + eventSlug);
        }

        Market fullMarket = getMarketBySlug(marketSlug);
        logger.info("Resolved via series/event to market: {}", fullMarket.getQuestion());
        return fullMarket;
    }

    public String[] getAssetIds(String slug) throws IOException, ParseException {
        Market market = resolveSlugToMarket(slug);

        logger.info("Market outcomes: {}", market.getOutcomes());
        logger.info("Market clobTokenIds: {}", market.getClobTokenIds());

        String yesTokenId = market.getYesTokenId();
        String noTokenId = market.getNoTokenId();

        logger.info("Yes token ID: {}", yesTokenId);
        logger.info("No token ID: {}", noTokenId);

        if (yesTokenId == null || noTokenId == null) {
            throw new IOException("Could not find YES and NO token IDs for market: " + slug);
        }

        return new String[]{yesTokenId, noTokenId};
    }

    public BigDecimal getCurrentPrice(String symbol) throws IOException, ParseException {
        String url = String.format("%s/price?symbol=%s", baseUrl, symbol);
        logger.debug("Fetching current price for symbol: {}", symbol);

        HttpGet request = new HttpGet(url);
        addBrowserHeaders(request);

        try (CloseableHttpResponse response = httpClient.execute(request)) {
            int statusCode = response.getCode();
            String responseBody = EntityUtils.toString(response.getEntity());

            if (statusCode != 200) {
                logger.error("Failed to fetch price. Status: {}, Body: {}", statusCode, responseBody);
                throw new IOException("Failed to fetch price: " + statusCode);
            }

            logger.debug("Price response body: {}", responseBody);

            try {
                JsonNode root = objectMapper.readTree(responseBody);

                String priceStr = root.path("price").asText();
                if (priceStr == null || priceStr.isEmpty()) {
                    throw new IOException("No price found in response");
                }

                BigDecimal price = new BigDecimal(priceStr);
                logger.info("Fetched Polymarket {} price: ${}", symbol, price);
                return price;
            } catch (Exception e) {
                logger.error("Failed to parse price JSON response", e);
                throw new IOException("Failed to parse price response: " + e.getMessage(), e);
            }
        }
    }

    public BigDecimal getBitcoinPrice() throws IOException, ParseException {
        // Use Pyth Network BTC/USD price feed (same source Polymarket uses for resolution)
        String pythFeedId = "0xe62df6c8b4a85fe1a67db44dc12de5db330f7ac66b72dc658afedf0f4a415b43";
        String url = String.format("https://hermes.pyth.network/v2/updates/price/latest?ids[]=%s", pythFeedId);

        logger.debug("Fetching BTC/USD price from Pyth Network");

        HttpGet request = new HttpGet(url);
        addBrowserHeaders(request);

        try (CloseableHttpResponse response = httpClient.execute(request)) {
            int statusCode = response.getCode();
            String responseBody = EntityUtils.toString(response.getEntity());

            if (statusCode != 200) {
                logger.error("Failed to fetch Pyth price. Status: {}, Body: {}", statusCode, responseBody);
                throw new IOException("Failed to fetch Pyth price: " + statusCode);
            }

            logger.debug("Pyth price response: {}", responseBody);

            try {
                JsonNode root = objectMapper.readTree(responseBody);

                // Navigate: parsed[0].price.price and parsed[0].price.expo
                JsonNode parsed = root.path("parsed");
                if (parsed.isEmpty() || !parsed.isArray() || parsed.size() == 0) {
                    throw new IOException("No parsed data in Pyth response");
                }

                JsonNode priceData = parsed.get(0).path("price");
                String priceStr = priceData.path("price").asText();
                String expoStr = priceData.path("expo").asText();

                if (priceStr == null || priceStr.isEmpty()) {
                    throw new IOException("No price found in Pyth response");
                }

                // Pyth returns price and exponent separately: actual_price = price * 10^expo
                // Example: price=9357184048996, expo=-8 -> 93571.84048996
                BigDecimal rawPrice = new BigDecimal(priceStr);
                int exponent = Integer.parseInt(expoStr);

                // Use scaleByPowerOfTen to handle negative exponents correctly
                BigDecimal price = rawPrice.scaleByPowerOfTen(exponent);

                logger.info("Fetched Pyth Network BTC/USD price (Polymarket reference): ${}", price);
                return price;
            } catch (Exception e) {
                logger.error("Failed to parse Pyth JSON response", e);
                throw new IOException("Failed to parse Pyth response: " + e.getMessage(), e);
            }
        }
    }

    public void close() {
        try {
            if (httpClient != null) {
                httpClient.close();
            }
        } catch (IOException e) {
            logger.error("Error closing HTTP client", e);
        }
    }
}
