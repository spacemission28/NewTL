package com.polymarket.orderbook.connector;

import com.polymarket.orderbook.model.WebSocketMessage;
import com.polymarket.orderbook.util.JsonUtil;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

public class PolymarketWebSocketClient extends WebSocketClient {

    private static final Logger logger = LoggerFactory.getLogger(PolymarketWebSocketClient.class);

    private final List<Consumer<WebSocketMessage>> messageHandlers;
    private final List<Runnable> connectionOpenHandlers;
    private final List<Runnable> connectionCloseHandlers;
    private final AtomicBoolean isConnected;

    public PolymarketWebSocketClient(URI serverUri) {
        super(serverUri);
        this.messageHandlers = new ArrayList<>();
        this.connectionOpenHandlers = new ArrayList<>();
        this.connectionCloseHandlers = new ArrayList<>();
        this.isConnected = new AtomicBoolean(false);
    }

    @Override
    public void onOpen(ServerHandshake handshakedata) {
        logger.info("WebSocket connection opened to {}", getURI());
        isConnected.set(true);
        connectionOpenHandlers.forEach(Runnable::run);
    }

    @Override
    public void onMessage(String message) {
        try {
            if (message.trim().startsWith("[")) {
                WebSocketMessage[] wsMessages = JsonUtil.fromJson(message, WebSocketMessage[].class);
                if (wsMessages != null && wsMessages.length > 0) {
                    for (WebSocketMessage wsMessage : wsMessages) {
                        messageHandlers.forEach(handler -> {
                            try {
                                handler.accept(wsMessage);
                            } catch (Exception e) {
                                logger.error("Error in message handler", e);
                            }
                        });
                    }
                } else {
                    logger.warn("Received empty array or failed to parse WebSocket message array");
                }
            } else {
                WebSocketMessage wsMessage = JsonUtil.fromJson(message, WebSocketMessage.class);
                if (wsMessage != null) {
                    messageHandlers.forEach(handler -> {
                        try {
                            handler.accept(wsMessage);
                        } catch (Exception e) {
                            logger.error("Error in message handler", e);
                        }
                    });
                } else {
                    logger.warn("Failed to parse WebSocket message");
                }
            }
        } catch (Exception e) {
            logger.error("Error processing WebSocket message", e);
        }
    }

    @Override
    public void onClose(int code, String reason, boolean remote) {
        logger.info("WebSocket connection closed. Code: {}, Reason: {}, Remote: {}", code, reason, remote);
        isConnected.set(false);
        connectionCloseHandlers.forEach(Runnable::run);
    }

    @Override
    public void onError(Exception ex) {
        logger.error("WebSocket error occurred", ex);
        isConnected.set(false);
    }

    public void subscribeToMarket(String assetId) {
        if (assetId == null || assetId.isEmpty()) {
            logger.error("Cannot subscribe to market: assetId is null or empty");
            throw new IllegalArgumentException("Asset ID cannot be null or empty");
        }

        // Polymarket CLOB market channel format: {"assets_ids": ["token_id"], "type": "market"}
        String subscriptionMessage = String.format(
                "{\"assets_ids\":[\"%s\"],\"type\":\"market\"}",
                assetId
        );
        logger.info("Subscribing to market channel with asset ID: {}", assetId);
        logger.debug("Subscription message: {}", subscriptionMessage);
        send(subscriptionMessage);
    }

    public void unsubscribeFromMarket(String assetId) {
        // Polymarket CLOB market channel unsubscribe format
        // Note: May need to send empty assets_ids array to unsubscribe
        String unsubscribeMessage = String.format(
                "{\"assets_ids\":[],\"type\":\"market\"}",
                assetId
        );
        logger.info("Unsubscribing from market channel: {}", assetId);
        logger.debug("Unsubscribe message: {}", unsubscribeMessage);
        send(unsubscribeMessage);
    }

    public void addMessageHandler(Consumer<WebSocketMessage> handler) {
        messageHandlers.add(handler);
    }

    public void addConnectionOpenHandler(Runnable handler) {
        connectionOpenHandlers.add(handler);
    }

    public void addConnectionCloseHandler(Runnable handler) {
        connectionCloseHandlers.add(handler);
    }

    public boolean isCurrentlyConnected() {
        return isConnected.get() && isOpen();
    }
}
