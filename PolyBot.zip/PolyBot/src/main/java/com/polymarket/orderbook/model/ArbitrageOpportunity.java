package com.polymarket.orderbook.model;

import java.math.BigDecimal;

public class ArbitrageOpportunity {

    private String marketQuestion;
    private String marketSlug;

    private BigDecimal polymarketUpProbability;
    private BigDecimal polymarketDownProbability;

    private BigDecimal coinbasePrice;
    private BigDecimal coinbasePriceAtMarketStart;
    private BigDecimal actualPriceChange;
    private BigDecimal polymarketReferencePrice;

    private BigDecimal impliedPriceChange;
    private BigDecimal arbitrageEdge;

    private ArbitrageDirection direction;
    private long timestamp;

    public enum ArbitrageDirection {
        BUY_UP,      // Polymarket underpricing UP probability
        BUY_DOWN,    // Polymarket underpricing DOWN probability
        SELL_UP,     // Polymarket overpricing UP probability
        SELL_DOWN,   // Polymarket overpricing DOWN probability
        NONE         // No arbitrage opportunity
    }

    public ArbitrageOpportunity() {
        this.timestamp = System.currentTimeMillis();
    }

    public String getMarketQuestion() {
        return marketQuestion;
    }

    public void setMarketQuestion(String marketQuestion) {
        this.marketQuestion = marketQuestion;
    }

    public String getMarketSlug() {
        return marketSlug;
    }

    public void setMarketSlug(String marketSlug) {
        this.marketSlug = marketSlug;
    }

    public BigDecimal getPolymarketUpProbability() {
        return polymarketUpProbability;
    }

    public void setPolymarketUpProbability(BigDecimal polymarketUpProbability) {
        this.polymarketUpProbability = polymarketUpProbability;
    }

    public BigDecimal getPolymarketDownProbability() {
        return polymarketDownProbability;
    }

    public void setPolymarketDownProbability(BigDecimal polymarketDownProbability) {
        this.polymarketDownProbability = polymarketDownProbability;
    }

    public BigDecimal getCoinbasePrice() {
        return coinbasePrice;
    }

    public void setCoinbasePrice(BigDecimal coinbasePrice) {
        this.coinbasePrice = coinbasePrice;
    }

    public BigDecimal getCoinbasePriceAtMarketStart() {
        return coinbasePriceAtMarketStart;
    }

    public void setCoinbasePriceAtMarketStart(BigDecimal coinbasePriceAtMarketStart) {
        this.coinbasePriceAtMarketStart = coinbasePriceAtMarketStart;
    }

    public BigDecimal getActualPriceChange() {
        return actualPriceChange;
    }

    public void setActualPriceChange(BigDecimal actualPriceChange) {
        this.actualPriceChange = actualPriceChange;
    }

    public BigDecimal getPolymarketReferencePrice() {
        return polymarketReferencePrice;
    }

    public void setPolymarketReferencePrice(BigDecimal polymarketReferencePrice) {
        this.polymarketReferencePrice = polymarketReferencePrice;
    }

    public BigDecimal getImpliedPriceChange() {
        return impliedPriceChange;
    }

    public void setImpliedPriceChange(BigDecimal impliedPriceChange) {
        this.impliedPriceChange = impliedPriceChange;
    }

    public BigDecimal getArbitrageEdge() {
        return arbitrageEdge;
    }

    public void setArbitrageEdge(BigDecimal arbitrageEdge) {
        this.arbitrageEdge = arbitrageEdge;
    }

    public ArbitrageDirection getDirection() {
        return direction;
    }

    public void setDirection(ArbitrageDirection direction) {
        this.direction = direction;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public boolean hasOpportunity() {
        return direction != null && direction != ArbitrageDirection.NONE;
    }

    @Override
    public String toString() {
        return String.format("ArbitrageOpportunity{market='%s', direction=%s, edge=%.2f%%, polyUp=%.2f, polyDown=%.2f, actualChange=%.2f%%}",
                marketQuestion, direction,
                arbitrageEdge != null ? arbitrageEdge : BigDecimal.ZERO,
                polymarketUpProbability != null ? polymarketUpProbability : BigDecimal.ZERO,
                polymarketDownProbability != null ? polymarketDownProbability : BigDecimal.ZERO,
                actualPriceChange != null ? actualPriceChange : BigDecimal.ZERO);
    }
}
