package com.polymarket.orderbook.connector;

import com.polymarket.orderbook.config.WebSocketConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class ConnectionManager {

    private static final Logger logger = LoggerFactory.getLogger(ConnectionManager.class);

    private final WebSocketConfig config;
    private PolymarketWebSocketClient client;
    private final AtomicBoolean shouldReconnect;
    private final AtomicInteger reconnectAttempts;
    private final ScheduledExecutorService scheduler;

    public ConnectionManager(WebSocketConfig config) {
        this.config = config;
        this.shouldReconnect = new AtomicBoolean(false);
        this.reconnectAttempts = new AtomicInteger(0);
        this.scheduler = Executors.newScheduledThreadPool(1);
    }

    public synchronized PolymarketWebSocketClient connect() {
        try {
            if (client != null && client.isCurrentlyConnected()) {
                logger.info("Already connected to WebSocket");
                return client;
            }

            URI serverUri = new URI(config.getUrl());
            client = new PolymarketWebSocketClient(serverUri);
            client.setConnectionLostTimeout(30);

            client.addConnectionOpenHandler(() -> {
                logger.info("Connection established successfully");
                reconnectAttempts.set(0);
            });

            client.addConnectionCloseHandler(() -> {
                if (shouldReconnect.get()) {
                    scheduleReconnect();
                }
            });

            logger.info("Connecting to WebSocket: {}", config.getUrl());
            boolean connected = client.connectBlocking(10, TimeUnit.SECONDS);

            if (!connected) {
                throw new RuntimeException("Connection timeout after 10 seconds");
            }

            shouldReconnect.set(true);

            return client;

        } catch (Exception e) {
            logger.error("Failed to connect to WebSocket", e);
            if (shouldReconnect.get()) {
                scheduleReconnect();
            }
            throw new RuntimeException("Failed to connect to WebSocket", e);
        }
    }

    private void scheduleReconnect() {
        int attempts = reconnectAttempts.incrementAndGet();

        if (attempts > config.getMaxReconnectAttempts()) {
            logger.error("Max reconnection attempts ({}) reached. Giving up.", config.getMaxReconnectAttempts());
            shouldReconnect.set(false);
            return;
        }

        long delay = Math.min(config.getReconnectDelay() * attempts, 60000);
        logger.info("Scheduling reconnection attempt {} in {}ms", attempts, delay);

        scheduler.schedule(() -> {
            try {
                connect();
            } catch (Exception e) {
                logger.error("Reconnection attempt {} failed", attempts, e);
            }
        }, delay, TimeUnit.MILLISECONDS);
    }

    public synchronized void disconnect() {
        logger.info("Disconnecting from WebSocket");
        shouldReconnect.set(false);

        if (client != null) {
            try {
                client.close();
            } catch (Exception e) {
                logger.error("Error closing WebSocket connection", e);
            }
        }
    }

    public PolymarketWebSocketClient getClient() {
        return client;
    }

    public boolean isConnected() {
        return client != null && client.isCurrentlyConnected();
    }

    public void shutdown() {
        disconnect();
        scheduler.shutdown();
        try {
            if (!scheduler.awaitTermination(5, TimeUnit.SECONDS)) {
                scheduler.shutdownNow();
            }
        } catch (InterruptedException e) {
            scheduler.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
}
