package com.polymarket.orderbook.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class SimulatedTrade {
    private LocalDateTime openTime;
    private LocalDateTime closeTime;
    private BigDecimal openPriceYes;
    private BigDecimal openPriceNo;
    private BigDecimal closePriceYes;
    private BigDecimal closePriceNo;
    private BigDecimal amount;
    private BigDecimal quantityYes;
    private BigDecimal quantityNo;
    private BigDecimal profitLoss;
    private String strategy;
    private String details;
    private String closedSide;

    public SimulatedTrade() {
        this.openTime = LocalDateTime.now();
    }

    public LocalDateTime getOpenTime() {
        return openTime;
    }

    public void setOpenTime(LocalDateTime openTime) {
        this.openTime = openTime;
    }

    public LocalDateTime getCloseTime() {
        return closeTime;
    }

    public void setCloseTime(LocalDateTime closeTime) {
        this.closeTime = closeTime;
    }

    public BigDecimal getOpenPriceYes() {
        return openPriceYes;
    }

    public void setOpenPriceYes(BigDecimal openPriceYes) {
        this.openPriceYes = openPriceYes;
    }

    public BigDecimal getOpenPriceNo() {
        return openPriceNo;
    }

    public void setOpenPriceNo(BigDecimal openPriceNo) {
        this.openPriceNo = openPriceNo;
    }

    public BigDecimal getClosePriceYes() {
        return closePriceYes;
    }

    public void setClosePriceYes(BigDecimal closePriceYes) {
        this.closePriceYes = closePriceYes;
    }

    public BigDecimal getClosePriceNo() {
        return closePriceNo;
    }

    public void setClosePriceNo(BigDecimal closePriceNo) {
        this.closePriceNo = closePriceNo;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getProfitLoss() {
        return profitLoss;
    }

    public void setProfitLoss(BigDecimal profitLoss) {
        this.profitLoss = profitLoss;
    }

    public String getStrategy() {
        return strategy;
    }

    public void setStrategy(String strategy) {
        this.strategy = strategy;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public BigDecimal getQuantityYes() {
        return quantityYes;
    }

    public void setQuantityYes(BigDecimal quantityYes) {
        this.quantityYes = quantityYes;
    }

    public BigDecimal getQuantityNo() {
        return quantityNo;
    }

    public void setQuantityNo(BigDecimal quantityNo) {
        this.quantityNo = quantityNo;
    }

    public String getClosedSide() {
        return closedSide;
    }

    public void setClosedSide(String closedSide) {
        this.closedSide = closedSide;
    }
}
