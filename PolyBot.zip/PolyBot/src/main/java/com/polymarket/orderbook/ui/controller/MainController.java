package com.polymarket.orderbook.ui.controller;

import com.polymarket.orderbook.config.PolymarketCredentials;
import com.polymarket.orderbook.config.WebSocketConfig;
import com.polymarket.orderbook.connector.ConnectionManager;
import com.polymarket.orderbook.connector.PolymarketWebSocketClient;
import com.polymarket.orderbook.engine.OrderBookEngine;
import com.polymarket.orderbook.model.*;
import com.polymarket.orderbook.service.*;
import com.polymarket.orderbook.ui.dialog.CredentialsDialog;
import com.polymarket.orderbook.ui.service.OrderBookRefreshService;
import com.polymarket.orderbook.ui.service.MarketRefreshService;
import com.polymarket.orderbook.util.PriceFormatter;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Optional;

public class MainController {

    private static final Logger logger = LoggerFactory.getLogger(MainController.class);
    private static final DecimalFormat INTEGER_FORMAT = new DecimalFormat("#,##0");

    @FXML private TextField marketSlugField;
    @FXML private Button connectButton;
    @FXML private Button disconnectButton;
    @FXML private Button shutdownButton;
    @FXML private Label connectionStatus;

    @FXML private Button manageCredentialsButton;
    @FXML private Label authStatus;

    @FXML private Label marketNameLabel;
    @FXML private Label yesAssetLabel;
    @FXML private Label noAssetLabel;

    @FXML private Label yesMidPriceLabel;
    @FXML private Label yesSpreadLabel;
    @FXML private Label noMidPriceLabel;
    @FXML private Label noSpreadLabel;

    @FXML private TextField minEdgeField;
    @FXML private TextField minCentsProfitField;
    @FXML private Label coinbasePriceLabel;
    @FXML private Label polymarketPriceLabel;
    @FXML private Label priceDiffLabel;
    @FXML private Label priceChangeLabel;

    @FXML private TextField totalAmountField;
    @FXML private Label yesQuantityLabel;
    @FXML private Label noQuantityLabel;
    @FXML private Button executeSplitTradeButton;
    @FXML private TextField profitTargetField;
    @FXML private Label tradeStatusLabel;

    @FXML private Label arbTradeSignalLabel;
    @FXML private TextField arbAmountField;
    @FXML private Label arbSideLabel;
    @FXML private Label arbQuantityLabel;
    @FXML private Button executeArbTradeButton;
    @FXML private Button pauseTradingButton;
    @FXML private Label arbTradeStatusLabel;
    @FXML private Label arbProfitDayLabel;
    @FXML private Label arbProfitWeekLabel;
    @FXML private Label arbProfitMonthLabel;
    @FXML private Label deltaProfitDayLabel;
    @FXML private Label deltaProfitWeekLabel;
    @FXML private Label deltaProfitMonthLabel;

    @FXML private Button arbSimToggleButton;
    @FXML private Button arbSimResetButton;
    @FXML private Label arbSimStatusLabel;
    @FXML private Label arbSim5Label;
    @FXML private Label arbSim10Label;
    @FXML private Label arbSim20Label;
    @FXML private Label arbSimAbove20Label;
    @FXML private Label arbSimPLLabel;
    @FXML private Label arbSimUnrealizedPLLabel;

    @FXML private Button deltaSimToggleButton;
    @FXML private Button deltaSimResetButton;
    @FXML private Label deltaSimStatusLabel;
    @FXML private Label deltaSim99Label;
    @FXML private Label deltaSim98Label;
    @FXML private Label deltaSim97Label;
    @FXML private Label deltaSimPLLabel;
    @FXML private Label deltaSimUnrealizedPLLabel;
    @FXML private CheckBox useHoldToResolutionCheckBox;

    private ConnectionManager connectionManager;
    private PolymarketWebSocketClient webSocketClient;
    private OrderBookEngine orderBookEngine;
    private MarketService marketService;
    private TradingService tradingService;
    private ArbitrageDetectionService arbitrageService;
    private DeltaNeutralStrategy deltaNeutralStrategy;
    private ArbitrageSimulation arbitrageSimulation;
    private DeltaNeutralSimulation deltaNeutralSimulation;
    private HoldToResolutionSimulation holdToResolutionSimulation;

    private OrderBookRefreshService<Void> orderBookRefreshService;
    private OrderBookRefreshService<Void> priceUpdateService;
    private MarketRefreshService marketRefreshService;

    private Market currentMarket;
    private String currentSlug;
    private PolymarketCredentials credentials;
    private ArbitrageOpportunity lastOpportunity;

    // Auto-execution throttling
    private long lastAutoExecutionTime = 0;
    private ArbitrageOpportunity.ArbitrageDirection lastExecutedDirection = ArbitrageOpportunity.ArbitrageDirection.NONE;
    private static final long AUTO_EXECUTION_COOLDOWN_MS = 10000; // 10 seconds

    // Trading pause state
    private boolean tradingPaused = false;

    @FXML
    public void initialize() {
        logger.info("Initializing MainController");

        WebSocketConfig wsConfig = WebSocketConfig.fromAppConfig();
        connectionManager = new ConnectionManager(wsConfig);
        orderBookEngine = new OrderBookEngine();
        marketService = new MarketService();

        credentials = new PolymarketCredentials();
        tradingService = new TradingService(credentials);
        arbitrageService = new ArbitrageDetectionService(orderBookEngine);
        deltaNeutralStrategy = new DeltaNeutralStrategy();

        loadCredentials();
        updateProfitLabelsVisibility();
        updateTradeButtonStates();

        logger.info("MainController initialized successfully");
    }

    @FXML
    private void handleConnect() {
        String marketSlug = marketSlugField.getText().trim();
        if (marketSlug.isEmpty()) {
            updateConnectionStatus("Please enter a market slug", false);
            return;
        }

        currentSlug = marketSlug;
        connectButton.setDisable(true);
        updateConnectionStatus("Connecting...", false);

        new Thread(() -> {
            try {
                currentMarket = marketService.fetchMarket(marketSlug);
                if (currentMarket == null) {
                    Platform.runLater(() -> {
                        updateConnectionStatus("Failed to fetch market", false);
                        connectButton.setDisable(false);
                    });
                    return;
                }

                if (arbitrageSimulation == null) {
                    arbitrageSimulation = new ArbitrageSimulation(orderBookEngine, currentMarket.getSlug());
                }
                arbitrageSimulation.setMarketEndDateIso(currentMarket.getEndDateIso());

                if (deltaNeutralSimulation == null) {
                    deltaNeutralSimulation = new DeltaNeutralSimulation(orderBookEngine, currentMarket.getSlug());
                }

                if (holdToResolutionSimulation == null) {
                    holdToResolutionSimulation = new HoldToResolutionSimulation(orderBookEngine, currentMarket.getSlug());
                }

                if (currentMarket.getEndDateIso() != null && !currentMarket.getEndDateIso().isEmpty()) {
                    try {
                        java.time.LocalDateTime endTime = java.time.LocalDateTime.parse(
                            currentMarket.getEndDateIso().replace("Z", ""),
                            java.time.format.DateTimeFormatter.ISO_LOCAL_DATE_TIME
                        );
                        holdToResolutionSimulation.setMarketEndTime(endTime);
                        logger.info("Set market end time: {}", endTime);
                    } catch (Exception e) {
                        logger.warn("Failed to parse market end date: {}", currentMarket.getEndDateIso(), e);
                    }
                }

                Platform.runLater(() -> {
                    updateMarketInfo(currentMarket);
                });

                webSocketClient = connectionManager.connect();
                webSocketClient.addMessageHandler(message -> {
                    orderBookEngine.processMessage(message);
                });

                List<String> tokenIds = currentMarket.getClobTokenIds();
                if (tokenIds != null && tokenIds.size() >= 2) {
                    String yesTokenId = tokenIds.get(0);
                    String noTokenId = tokenIds.get(1);

                    webSocketClient.subscribeToMarket(yesTokenId);
                    webSocketClient.subscribeToMarket(noTokenId);
                }

                arbitrageService.updatePricesAsync();

                Platform.runLater(() -> {
                    updateConnectionStatus("Connected", true);
                    disconnectButton.setDisable(false);
                    startRefreshServices();
                });

            } catch (Exception e) {
                logger.error("Connection failed", e);
                Platform.runLater(() -> {
                    updateConnectionStatus("Connection failed: " + e.getMessage(), false);
                    connectButton.setDisable(false);
                });
            }
        }).start();
    }

    @FXML
    private void handleDisconnect() {
        stopRefreshServices();

        if (connectionManager != null) {
            connectionManager.disconnect();
        }

        updateConnectionStatus("Disconnected", false);
        connectButton.setDisable(false);
        disconnectButton.setDisable(true);

        // Reset auto-execution throttling on disconnect
        lastAutoExecutionTime = 0;
        lastExecutedDirection = ArbitrageOpportunity.ArbitrageDirection.NONE;

        // Reset trading pause state on disconnect
        if (tradingPaused) {
            tradingPaused = false;
            pauseTradingButton.setText("Pause Trading");
            pauseTradingButton.getStyleClass().remove("pause-trading-button-active");
            pauseTradingButton.getStyleClass().add("pause-trading-button");
        }

        clearOrderBooks();
    }

    @FXML
    private void handleManageCredentials() {
        CredentialsDialog dialog = new CredentialsDialog(credentials);
        Optional<PolymarketCredentials> result = dialog.showAndWait();

        if (result.isPresent()) {
            logger.info("Credentials updated via dialog");
            updateAuthStatus();
            updateProfitLabelsVisibility();
            updateTradeButtonStates();
        }
    }

    private void loadCredentials() {
        try {
            credentials.loadFromFile();
            updateAuthStatus();
        } catch (Exception e) {
            logger.warn("No saved credentials found");
        }
        updateTradeButtonStates();
    }

    private void updateAuthStatus() {
        boolean hasApiCreds = credentials.isAuthenticated();
        boolean hasPrivateKey = credentials.hasPrivateKey();

        if (hasApiCreds && hasPrivateKey) {
            authStatus.setText("Ready to Trade");
            authStatus.getStyleClass().setAll("status-connected");
        } else if (hasApiCreds && !hasPrivateKey) {
            authStatus.setText("API Keys OK - Add Private Key to .env");
            authStatus.getStyleClass().setAll("status-disconnected");
        } else if (!hasApiCreds && hasPrivateKey) {
            authStatus.setText("Private Key OK - Add API Keys");
            authStatus.getStyleClass().setAll("status-disconnected");
        } else {
            authStatus.setText("Not Configured");
            authStatus.getStyleClass().setAll("status-disconnected");
        }
    }

    private void startRefreshServices() {
        try {
            arbitrageService.setMinimumEdgeThreshold(new BigDecimal(minEdgeField.getText()));
        } catch (NumberFormatException e) {
            logger.warn("Invalid minimum edge value, using default");
        }

        try {
            BigDecimal minCents = new BigDecimal(minCentsProfitField.getText());
            arbitrageService.setMinimumCentsDivergence(minCents);
            if (arbitrageSimulation != null) {
                arbitrageSimulation.setMinCentsForLiquidation(minCents);
                arbitrageSimulation.setMinDivergenceToTrade(minCents);
            }
        } catch (NumberFormatException e) {
            logger.warn("Invalid minimum cents value, using default");
        }

        priceUpdateService = new OrderBookRefreshService<>("PriceUpdate", () -> {
            arbitrageService.updatePricesAsync();
            return null;
        });
        priceUpdateService.setPeriod(Duration.seconds(10));
        priceUpdateService.start();
        logger.info("Started background price update service (every 10 seconds)");

        orderBookRefreshService = new OrderBookRefreshService<>("OrderBook", () -> {
            Platform.runLater(() -> {
                updateOrderBookUI();
                updateArbitrageDetection();
            });
            return null;
        });
        orderBookRefreshService.setPeriod(Duration.millis(500));
        orderBookRefreshService.start();

        marketRefreshService = new MarketRefreshService(currentSlug, marketService);
        marketRefreshService.setPeriod(Duration.seconds(30));
        marketRefreshService.setOnSucceeded(event -> {
            Market newMarket = marketRefreshService.getValue();
            if (newMarket != null && shouldSwitchToNewMarket(newMarket)) {
                switchToNewMarket(newMarket);
            }
        });
        marketRefreshService.start();
    }

    private void stopRefreshServices() {
        if (priceUpdateService != null) {
            priceUpdateService.cancel();
        }
        if (orderBookRefreshService != null) {
            orderBookRefreshService.cancel();
        }
        if (marketRefreshService != null) {
            marketRefreshService.cancel();
        }
    }

    private boolean shouldSwitchToNewMarket(Market newMarket) {
        if (currentMarket == null) return false;

        boolean idChanged = !currentMarket.getId().equals(newMarket.getId());
        boolean questionChanged = !currentMarket.getQuestion().equals(newMarket.getQuestion());

        if (idChanged || questionChanged) {
            logger.info("Market change detected - Current: {} | New: {}",
                currentMarket.getQuestion(), newMarket.getQuestion());
            return true;
        }
        return false;
    }

    private void switchToNewMarket(Market newMarket) {
        logger.info("Switching to new market: {}", newMarket.getQuestion());

        connectionManager.disconnect();

        currentMarket = newMarket;

        Platform.runLater(() -> {
            updateMarketInfo(newMarket);
            yesMidPriceLabel.setText("$0.00");
            noMidPriceLabel.setText("$0.00");
        });

        arbitrageService.resetMarketStartPrice(newMarket.getSlug());
        if (arbitrageSimulation != null) {
            arbitrageSimulation.resetForNewMarket(newMarket.getSlug(), newMarket.getEndDateIso());
        }
        if (deltaNeutralSimulation != null) {
            deltaNeutralSimulation.resetStats();
        }
        if (holdToResolutionSimulation != null) {
            holdToResolutionSimulation.resetStats();
        }

        try {
            webSocketClient = connectionManager.connect();
            webSocketClient.addMessageHandler(message -> {
                orderBookEngine.processMessage(message);
            });

            List<String> tokenIds = newMarket.getClobTokenIds();
            if (tokenIds != null && tokenIds.size() >= 2) {
                String yesTokenId = tokenIds.get(0);
                String noTokenId = tokenIds.get(1);
                webSocketClient.subscribeToMarket(yesTokenId);
                webSocketClient.subscribeToMarket(noTokenId);
            }

            logger.info("Successfully switched to new market: {}", newMarket.getQuestion());
        } catch (Exception e) {
            logger.error("Failed to switch to new market", e);
        }
    }

    private void updateMarketInfo(Market market) {
        marketNameLabel.setText(market.getQuestion());
        List<String> tokenIds = market.getClobTokenIds();
        if (tokenIds != null && tokenIds.size() >= 2) {
            if (yesAssetLabel != null) {
                yesAssetLabel.setText("YES: " + tokenIds.get(0));
            }
            if (noAssetLabel != null) {
                noAssetLabel.setText("NO: " + tokenIds.get(1));
            }
            logger.debug("Market token IDs - YES: {}, NO: {}", tokenIds.get(0), tokenIds.get(1));
        }
    }

    private void updateConnectionStatus(String message, boolean connected) {
        connectionStatus.setText(message);
        if (connected) {
            connectionStatus.getStyleClass().setAll("status-connected");
        } else {
            connectionStatus.getStyleClass().setAll("status-disconnected");
        }
    }

    private void updateOrderBookUI() {
        if (currentMarket == null) return;

        List<String> tokenIds = currentMarket.getClobTokenIds();
        if (tokenIds == null || tokenIds.size() < 2) return;

        String yesTokenId = tokenIds.get(0);
        String noTokenId = tokenIds.get(1);

        OrderBookSnapshot yesSnapshot = orderBookEngine.getSnapshot(yesTokenId);
        OrderBookSnapshot noSnapshot = orderBookEngine.getSnapshot(noTokenId);

        if (yesSnapshot != null && yesSnapshot.getMidPrice().compareTo(BigDecimal.ZERO) > 0) {
            String formattedPrice = PriceFormatter.formatPrice(yesSnapshot.getMidPrice());
            String formattedSpread = PriceFormatter.formatPrice(yesSnapshot.getSpreadPercentage());
            yesMidPriceLabel.setText(formattedPrice);
            yesSpreadLabel.setText(formattedSpread + "%");
            logger.trace("Updated YES mid price: {}, spread: {}%", formattedPrice, formattedSpread);
        }

        if (noSnapshot != null && noSnapshot.getMidPrice().compareTo(BigDecimal.ZERO) > 0) {
            String formattedPrice = PriceFormatter.formatPrice(noSnapshot.getMidPrice());
            String formattedSpread = PriceFormatter.formatPrice(noSnapshot.getSpreadPercentage());
            noMidPriceLabel.setText(formattedPrice);
            noSpreadLabel.setText(formattedSpread + "%");
            logger.trace("Updated NO mid price: {}, spread: {}%", formattedPrice, formattedSpread);
        }
    }

    private void updateArbitrageDetection() {
        if (currentMarket == null) return;

        try {
            arbitrageService.setMinimumEdgeThreshold(new BigDecimal(minEdgeField.getText()));
        } catch (NumberFormatException e) {
            logger.warn("Invalid minimum edge value");
        }

        try {
            BigDecimal minCents = new BigDecimal(minCentsProfitField.getText());
            arbitrageService.setMinimumCentsDivergence(minCents);
            if (arbitrageSimulation != null) {
                arbitrageSimulation.setMinCentsForLiquidation(minCents);
                arbitrageSimulation.setMinDivergenceToTrade(minCents);
            }
        } catch (NumberFormatException e) {
            logger.warn("Invalid minimum cents value");
        }

        List<String> tokenIds = currentMarket.getClobTokenIds();
        if (tokenIds == null || tokenIds.size() < 2) return;

        String yesTokenId = tokenIds.get(0);
        String noTokenId = tokenIds.get(1);

        ArbitrageOpportunity opportunity = arbitrageService.detectOpportunity(
            yesTokenId, noTokenId, currentMarket.getQuestion(), currentMarket.getSlug()
        );

        if (opportunity != null) {
            lastOpportunity = opportunity;
            updateArbitrageUI(opportunity);

            // Auto-execute live trades when signal detected (like simulation)
            autoExecuteArbitrageTrade(opportunity, yesTokenId, noTokenId);
        }

        if (arbitrageSimulation != null) {
            BigDecimal coinbasePrice = arbitrageService.getCurrentCoinbasePrice();
            BigDecimal chainlinkPrice = arbitrageService.getCurrentChainlinkPrice();
            arbitrageSimulation.checkAndSimulate(opportunity, yesTokenId, noTokenId,
                coinbasePrice, chainlinkPrice);
            updateArbitrageSimulationUI();
        }

        try {
            BigDecimal totalAmount = new BigDecimal(totalAmountField.getText());
            BigDecimal profitTarget = new BigDecimal(profitTargetField.getText());

            if (useHoldToResolutionCheckBox.isSelected()) {
                if (holdToResolutionSimulation != null) {
                    holdToResolutionSimulation.checkAndSimulate(yesTokenId, noTokenId, totalAmount);
                }
            } else {
                if (deltaNeutralSimulation != null) {
                    deltaNeutralSimulation.setProfitTargetCents(profitTarget);
                    deltaNeutralSimulation.checkAndSimulate(yesTokenId, noTokenId, totalAmount);
                }
            }

            updateDeltaNeutralSimulationUI();
        } catch (NumberFormatException e) {
            logger.warn("Invalid total amount or profit target value");
        }
    }

    private void updateArbitrageUI(ArbitrageOpportunity opp) {
        BigDecimal coinbasePrice = arbitrageService.getCurrentCoinbasePrice();
        BigDecimal chainlinkPrice = arbitrageService.getCurrentChainlinkPrice();

        if (coinbasePrice != null) {
            coinbasePriceLabel.setText("$" + INTEGER_FORMAT.format(coinbasePrice.setScale(0, RoundingMode.HALF_UP)));
        } else {
            coinbasePriceLabel.setText("$0");
        }

        if (chainlinkPrice != null) {
            polymarketPriceLabel.setText("$" + INTEGER_FORMAT.format(chainlinkPrice.setScale(0, RoundingMode.HALF_UP)));
        } else {
            polymarketPriceLabel.setText("$0");
        }

        if (coinbasePrice != null && chainlinkPrice != null) {
            BigDecimal diff = coinbasePrice.subtract(chainlinkPrice);
            priceDiffLabel.setText("$" + INTEGER_FORMAT.format(diff.setScale(0, RoundingMode.HALF_UP)));

            if (diff.compareTo(BigDecimal.ZERO) > 0) {
                priceDiffLabel.getStyleClass().setAll("price-diff-positive");
            } else if (diff.compareTo(BigDecimal.ZERO) < 0) {
                priceDiffLabel.getStyleClass().setAll("price-diff-negative");
            } else {
                priceDiffLabel.getStyleClass().setAll("price-diff-neutral");
            }
        } else {
            priceDiffLabel.setText("$0");
            priceDiffLabel.getStyleClass().setAll("price-diff-neutral");
        }

        if (opp.getActualPriceChange() != null && priceChangeLabel != null) {
            priceChangeLabel.setText(opp.getActualPriceChange().setScale(2, RoundingMode.HALF_UP) + "%");

            if (opp.getActualPriceChange().compareTo(BigDecimal.ZERO) > 0) {
                priceChangeLabel.getStyleClass().setAll("price-change-positive");
            } else if (opp.getActualPriceChange().compareTo(BigDecimal.ZERO) < 0) {
                priceChangeLabel.getStyleClass().setAll("price-change-negative");
            }
        }

        String signal = opp.getDirection().toString();
        arbTradeSignalLabel.setText(signal);

        switch (opp.getDirection()) {
            case BUY_UP:
                arbTradeSignalLabel.getStyleClass().setAll("signal-buy");
                break;
            case BUY_DOWN:
                arbTradeSignalLabel.getStyleClass().setAll("signal-sell");
                break;
            default:
                arbTradeSignalLabel.getStyleClass().setAll("signal-none");
        }
    }

    private void clearOrderBooks() {
        yesMidPriceLabel.setText("0.00");
        yesSpreadLabel.setText("0.00%");
        noMidPriceLabel.setText("0.00");
        noSpreadLabel.setText("0.00%");
    }

    private void updateProfitLabelsVisibility() {
        boolean isAuthenticated = credentials != null && credentials.isAuthenticated();
        double opacity = isAuthenticated ? 1.0 : 0.3;

        arbProfitDayLabel.setOpacity(opacity);
        arbProfitWeekLabel.setOpacity(opacity);
        arbProfitMonthLabel.setOpacity(opacity);
        deltaProfitDayLabel.setOpacity(opacity);
        deltaProfitWeekLabel.setOpacity(opacity);
        deltaProfitMonthLabel.setOpacity(opacity);
    }

    private void updateTradeButtonStates() {
        boolean isAuthenticated = credentials != null && credentials.isAuthenticated();
        executeSplitTradeButton.setDisable(!isAuthenticated);
        executeArbTradeButton.setDisable(!isAuthenticated);
    }

    @FXML
    private void handleExecuteSplitTrade() {
        if (!isAuthenticated()) {
            tradeStatusLabel.setText("Not authenticated");
            return;
        }

        if (currentMarket == null) {
            tradeStatusLabel.setText("No market connected");
            return;
        }

        try {
            BigDecimal totalAmount = new BigDecimal(totalAmountField.getText());

            List<String> tokenIds = currentMarket.getClobTokenIds();
            if (tokenIds == null || tokenIds.size() < 2) {
                tradeStatusLabel.setText("Invalid market tokens");
                return;
            }

            String yesTokenId = tokenIds.get(0);
            String noTokenId = tokenIds.get(1);

            OrderBookSnapshot yesSnapshot = orderBookEngine.getSnapshot(yesTokenId);
            OrderBookSnapshot noSnapshot = orderBookEngine.getSnapshot(noTokenId);

            if (yesSnapshot == null || noSnapshot == null) {
                tradeStatusLabel.setText("Order book not available");
                return;
            }

            BigDecimal yesPrice = yesSnapshot.getBestAsk();
            BigDecimal noPrice = noSnapshot.getBestAsk();

            if (yesPrice.compareTo(BigDecimal.ZERO) == 0 || noPrice.compareTo(BigDecimal.ZERO) == 0) {
                tradeStatusLabel.setText("Invalid prices");
                return;
            }

            executeSplitTradeButton.setDisable(true);
            tradeStatusLabel.setText("Executing...");
            logger.info("Executing split trade: ${} total, YES@{}, NO@{}", totalAmount, yesPrice, noPrice);

            tradingService.executeSplitTradeAsync(yesTokenId, noTokenId, yesPrice, noPrice, totalAmount)
                .thenAccept(result -> {
                    Platform.runLater(() -> {
                        tradeStatusLabel.setText("Trade executed successfully");
                        executeSplitTradeButton.setDisable(!isAuthenticated());
                        logger.info("Split trade result: {}", result);
                    });
                })
                .exceptionally(ex -> {
                    Platform.runLater(() -> {
                        tradeStatusLabel.setText("Trade failed: " + ex.getMessage());
                        executeSplitTradeButton.setDisable(!isAuthenticated());
                        logger.error("Split trade failed", ex);
                    });
                    return null;
                });

        } catch (NumberFormatException e) {
            tradeStatusLabel.setText("Invalid amount");
            logger.error("Invalid total amount", e);
        }
    }

    @FXML
    private void handleExecuteArbTrade() {
        if (!isAuthenticated()) {
            arbTradeStatusLabel.setText("Not authenticated");
            return;
        }

        if (currentMarket == null) {
            arbTradeStatusLabel.setText("No market connected");
            return;
        }

        if (lastOpportunity == null || !lastOpportunity.hasOpportunity()) {
            arbTradeStatusLabel.setText("No arbitrage signal");
            return;
        }

        try {
            BigDecimal amount = new BigDecimal(arbAmountField.getText());

            List<String> tokenIds = currentMarket.getClobTokenIds();
            if (tokenIds == null || tokenIds.size() < 2) {
                arbTradeStatusLabel.setText("Invalid market tokens");
                return;
            }

            String yesTokenId = tokenIds.get(0);
            String noTokenId = tokenIds.get(1);

            OrderBookSnapshot yesSnapshot = orderBookEngine.getSnapshot(yesTokenId);
            OrderBookSnapshot noSnapshot = orderBookEngine.getSnapshot(noTokenId);

            if (yesSnapshot == null || noSnapshot == null) {
                arbTradeStatusLabel.setText("Order book not available");
                return;
            }

            String assetId;
            BigDecimal price;
            String side = "BUY";

            if (lastOpportunity.getDirection() == ArbitrageOpportunity.ArbitrageDirection.BUY_UP) {
                assetId = yesTokenId;
                price = yesSnapshot.getBestAsk();
                logger.info("Executing BUY YES arbitrage trade");
            } else if (lastOpportunity.getDirection() == ArbitrageOpportunity.ArbitrageDirection.BUY_DOWN) {
                assetId = noTokenId;
                price = noSnapshot.getBestAsk();
                logger.info("Executing BUY NO arbitrage trade");
            } else {
                arbTradeStatusLabel.setText("Invalid trade direction");
                return;
            }

            if (price.compareTo(BigDecimal.ZERO) == 0) {
                arbTradeStatusLabel.setText("Invalid price");
                return;
            }

            executeArbTradeButton.setDisable(true);
            arbTradeStatusLabel.setText("Executing...");
            logger.info("Executing arbitrage trade: {} ${} @ {} on {}", side, amount, price,
                    assetId.substring(0, Math.min(8, assetId.length())));

            tradingService.executeArbitrageTradeAsync(assetId, side, price, amount)
                .thenAccept(result -> {
                    Platform.runLater(() -> {
                        arbTradeStatusLabel.setText("Trade executed successfully");
                        executeArbTradeButton.setDisable(!isAuthenticated());
                        logger.info("Arbitrage trade result: {}", result);
                    });
                })
                .exceptionally(ex -> {
                    Platform.runLater(() -> {
                        String errorMsg = extractErrorMessage(ex);
                        arbTradeStatusLabel.setText("Trade failed: " + errorMsg);
                        executeArbTradeButton.setDisable(!isAuthenticated());
                        logger.error("Arbitrage trade failed", ex);
                    });
                    return null;
                });

        } catch (NumberFormatException e) {
            arbTradeStatusLabel.setText("Invalid amount");
            logger.error("Invalid arbitrage amount", e);
        }
    }

    @FXML
    private void handlePauseTrading() {
        tradingPaused = !tradingPaused;

        if (tradingPaused) {
            pauseTradingButton.setText("Resume Trading");
            pauseTradingButton.getStyleClass().remove("pause-trading-button");
            pauseTradingButton.getStyleClass().add("pause-trading-button-active");
            arbTradeStatusLabel.setText("Trading PAUSED - No new trades");
            logger.info("Trading paused - no new trades will be executed");
        } else {
            pauseTradingButton.setText("Pause Trading");
            pauseTradingButton.getStyleClass().remove("pause-trading-button-active");
            pauseTradingButton.getStyleClass().add("pause-trading-button");
            arbTradeStatusLabel.setText("Trading resumed");
            logger.info("Trading resumed - auto-execution active");
        }
    }

    private boolean isAuthenticated() {
        return credentials != null && credentials.hasAllCredentials();
    }

    /**
     * Auto-execute arbitrage trades when valid signal detected (like simulation)
     */
    private void autoExecuteArbitrageTrade(ArbitrageOpportunity opportunity, String yesTokenId, String noTokenId) {
        // Only auto-execute if authenticated
        if (!isAuthenticated()) {
            return;
        }

        // Check if trading is paused
        if (tradingPaused) {
            logger.debug("Auto-execute blocked: trading is paused");
            return;
        }

        // Only execute if direction is valid (not NONE)
        if (opportunity.getDirection() == ArbitrageOpportunity.ArbitrageDirection.NONE) {
            return;
        }

        // Throttle: prevent multiple rapid executions
        long currentTime = System.currentTimeMillis();
        long timeSinceLastExecution = currentTime - lastAutoExecutionTime;

        if (timeSinceLastExecution < AUTO_EXECUTION_COOLDOWN_MS &&
            lastExecutedDirection == opportunity.getDirection()) {
            logger.debug("Auto-execute throttled: {} ms since last execution (direction: {})",
                timeSinceLastExecution, opportunity.getDirection());
            return;
        }

        // Check if we have valid snapshots
        OrderBookSnapshot yesSnapshot = orderBookEngine.getSnapshot(yesTokenId);
        OrderBookSnapshot noSnapshot = orderBookEngine.getSnapshot(noTokenId);

        if (yesSnapshot == null || noSnapshot == null) {
            logger.warn("Auto-execute blocked: order book snapshots not available");
            return;
        }

        try {
            // Use amount from UI field, or default to 2.0 if empty
            String amountText = arbAmountField.getText();
            BigDecimal amount = (amountText == null || amountText.trim().isEmpty())
                ? new BigDecimal("2")
                : new BigDecimal(amountText);

            String assetId;
            BigDecimal price;
            String side = "BUY";

            if (opportunity.getDirection() == ArbitrageOpportunity.ArbitrageDirection.BUY_UP) {
                assetId = yesTokenId;
                price = yesSnapshot.getBestAsk();
                logger.info("AUTO-EXECUTING BUY YES arbitrage trade");
            } else {
                assetId = noTokenId;
                price = noSnapshot.getBestAsk();
                logger.info("AUTO-EXECUTING BUY NO arbitrage trade");
            }

            if (price.compareTo(BigDecimal.ZERO) == 0) {
                logger.warn("Auto-execute blocked: invalid price");
                return;
            }

            // Execute the trade
            Platform.runLater(() -> {
                arbTradeStatusLabel.setText("Auto-executing...");
                executeArbTradeButton.setDisable(true);
            });

            logger.info("Auto-executing arbitrage trade: {} ${} @ {} on {}",
                side, amount, price, assetId.substring(0, Math.min(8, assetId.length())));

            // Update throttling state
            lastAutoExecutionTime = currentTime;
            lastExecutedDirection = opportunity.getDirection();

            tradingService.executeArbitrageTradeAsync(assetId, side, price, amount)
                .thenAccept(result -> {
                    Platform.runLater(() -> {
                        arbTradeStatusLabel.setText("Auto-trade executed: " + result);
                        executeArbTradeButton.setDisable(!isAuthenticated());
                        logger.info("Auto-arbitrage trade result: {}", result);
                    });
                })
                .exceptionally(ex -> {
                    Platform.runLater(() -> {
                        String errorMsg = extractErrorMessage(ex);
                        arbTradeStatusLabel.setText("Auto-trade failed: " + errorMsg);
                        executeArbTradeButton.setDisable(!isAuthenticated());
                        logger.error("Auto-arbitrage trade failed", ex);
                    });
                    return null;
                });

        } catch (NumberFormatException e) {
            logger.warn("Auto-execute blocked: invalid amount in UI field");
        } catch (Exception e) {
            logger.error("Auto-execute failed", e);
        }
    }

    @FXML
    private void handleArbSimToggle() {
        if (arbitrageSimulation == null) {
            arbSimStatusLabel.setText("Connect to market first");
            arbSimStatusLabel.getStyleClass().setAll("status-disconnected");
            logger.warn("Cannot start simulation - not connected to market");
            return;
        }

        boolean isEnabled = arbitrageSimulation.isSimulationEnabled();
        arbitrageSimulation.setSimulationEnabled(!isEnabled);

        if (!isEnabled) {
            arbSimToggleButton.setText("Stop Sim");
            arbSimToggleButton.getStyleClass().remove("sim-button");
            arbSimToggleButton.getStyleClass().add("sim-button-active");
            arbSimStatusLabel.setText("Active - Monitoring");
            arbSimStatusLabel.getStyleClass().setAll("sim-status-active");
            logger.info("Exchange Arbitrage simulation started");
        } else {
            arbSimToggleButton.setText("Start Sim");
            arbSimToggleButton.getStyleClass().remove("sim-button-active");
            arbSimToggleButton.getStyleClass().add("sim-button");
            arbSimStatusLabel.setText("Inactive");
            arbSimStatusLabel.getStyleClass().setAll("sim-status-inactive");
            logger.info("Exchange Arbitrage simulation stopped");
        }
    }

    @FXML
    private void handleArbSimReset() {
        if (arbitrageSimulation == null) return;

        arbitrageSimulation.setSimulationEnabled(false);
        arbitrageSimulation.reset();

        arbSimToggleButton.setText("Start Sim");
        arbSimToggleButton.getStyleClass().remove("sim-button-active");
        arbSimToggleButton.getStyleClass().add("sim-button");
        arbSimStatusLabel.setText("Inactive");
        arbSimStatusLabel.getStyleClass().setAll("sim-status-inactive");

        updateArbitrageSimulationUI();
        logger.info("Exchange Arbitrage simulation reset");
    }

    @FXML
    private void handleDeltaSimToggle() {
        if (useHoldToResolutionCheckBox.isSelected()) {
            if (holdToResolutionSimulation == null) {
                deltaSimStatusLabel.setText("Connect to market first");
                deltaSimStatusLabel.getStyleClass().setAll("status-disconnected");
                logger.warn("Cannot start simulation - not connected to market");
                return;
            }

            boolean isEnabled = holdToResolutionSimulation.isSimulationEnabled();
            holdToResolutionSimulation.setSimulationEnabled(!isEnabled);

            if (!isEnabled) {
                deltaSimToggleButton.setText("Stop Sim");
                deltaSimToggleButton.getStyleClass().remove("sim-button");
                deltaSimToggleButton.getStyleClass().add("sim-button-active");
                deltaSimStatusLabel.setText("Active - Hold-to-Resolution");
                deltaSimStatusLabel.getStyleClass().setAll("sim-status-active");
                logger.info("Hold-to-Resolution simulation started");
            } else {
                deltaSimToggleButton.setText("Start Sim");
                deltaSimToggleButton.getStyleClass().remove("sim-button-active");
                deltaSimToggleButton.getStyleClass().add("sim-button");
                deltaSimStatusLabel.setText("Inactive");
                deltaSimStatusLabel.getStyleClass().setAll("sim-status-inactive");
                logger.info("Hold-to-Resolution simulation stopped");
            }
        } else {
            if (deltaNeutralSimulation == null) {
                deltaSimStatusLabel.setText("Connect to market first");
                deltaSimStatusLabel.getStyleClass().setAll("status-disconnected");
                logger.warn("Cannot start simulation - not connected to market");
                return;
            }

            boolean isEnabled = deltaNeutralSimulation.isSimulationEnabled();
            deltaNeutralSimulation.setSimulationEnabled(!isEnabled);

            if (!isEnabled) {
                deltaSimToggleButton.setText("Stop Sim");
                deltaSimToggleButton.getStyleClass().remove("sim-button");
                deltaSimToggleButton.getStyleClass().add("sim-button-active");
                deltaSimStatusLabel.setText("Active - Monitoring");
                deltaSimStatusLabel.getStyleClass().setAll("sim-status-active");
                logger.info("Delta Neutral simulation started");
            } else {
                deltaSimToggleButton.setText("Start Sim");
                deltaSimToggleButton.getStyleClass().remove("sim-button-active");
                deltaSimToggleButton.getStyleClass().add("sim-button");
                deltaSimStatusLabel.setText("Inactive");
                deltaSimStatusLabel.getStyleClass().setAll("sim-status-inactive");
                logger.info("Delta Neutral simulation stopped");
            }
        }
    }

    @FXML
    private void handleDeltaSimReset() {
        if (useHoldToResolutionCheckBox.isSelected()) {
            if (holdToResolutionSimulation == null) return;

            holdToResolutionSimulation.setSimulationEnabled(false);
            holdToResolutionSimulation.reset();
            logger.info("Hold-to-Resolution simulation reset");
        } else {
            if (deltaNeutralSimulation == null) return;

            deltaNeutralSimulation.setSimulationEnabled(false);
            deltaNeutralSimulation.reset();
            logger.info("Delta Neutral simulation reset");
        }

        deltaSimToggleButton.setText("Start Sim");
        deltaSimToggleButton.getStyleClass().remove("sim-button-active");
        deltaSimToggleButton.getStyleClass().add("sim-button");
        deltaSimStatusLabel.setText("Inactive");
        deltaSimStatusLabel.getStyleClass().setAll("sim-status-inactive");

        updateDeltaNeutralSimulationUI();
    }

    private void updateArbitrageSimulationUI() {
        if (arbitrageSimulation == null) return;

        arbSim5Label.setText(String.valueOf(arbitrageSimulation.getCount5Dollar()));
        arbSim10Label.setText(String.valueOf(arbitrageSimulation.getCount10Dollar()));
        arbSim20Label.setText(String.valueOf(arbitrageSimulation.getCount20Dollar()));
        arbSimAbove20Label.setText(String.valueOf(arbitrageSimulation.getCountAbove20Dollar()));

        BigDecimal realizedPL = arbitrageSimulation.getCumulativeProfitLoss();
        arbSimPLLabel.setText("$" + realizedPL.setScale(2, RoundingMode.HALF_UP));

        if (realizedPL.compareTo(BigDecimal.ZERO) > 0) {
            arbSimPLLabel.getStyleClass().setAll("profit-label", "price-change-positive");
        } else if (realizedPL.compareTo(BigDecimal.ZERO) < 0) {
            arbSimPLLabel.getStyleClass().setAll("profit-label", "price-change-negative");
        } else {
            arbSimPLLabel.getStyleClass().setAll("profit-label");
        }

        if (arbSimUnrealizedPLLabel != null) {
            BigDecimal unrealizedPL = arbitrageSimulation.getUnrealizedProfitLoss();
            arbSimUnrealizedPLLabel.setText("$" + unrealizedPL.setScale(2, RoundingMode.HALF_UP));

            if (unrealizedPL.compareTo(BigDecimal.ZERO) > 0) {
                arbSimUnrealizedPLLabel.getStyleClass().setAll("profit-label", "price-change-positive");
            } else if (unrealizedPL.compareTo(BigDecimal.ZERO) < 0) {
                arbSimUnrealizedPLLabel.getStyleClass().setAll("profit-label", "price-change-negative");
            } else {
                arbSimUnrealizedPLLabel.getStyleClass().setAll("profit-label");
            }
        }
    }

    private void updateDeltaNeutralSimulationUI() {
        if (currentMarket == null) return;

        List<String> tokenIds = currentMarket.getClobTokenIds();
        if (tokenIds == null || tokenIds.size() < 2) return;

        String yesTokenId = tokenIds.get(0);
        String noTokenId = tokenIds.get(1);

        if (useHoldToResolutionCheckBox.isSelected()) {
            if (holdToResolutionSimulation == null) return;

            deltaSim99Label.setText(String.valueOf(holdToResolutionSimulation.getTradesOpened()));
            deltaSim98Label.setText(String.valueOf(holdToResolutionSimulation.getTradesClosedEarly()));
            deltaSim97Label.setText(String.valueOf(holdToResolutionSimulation.getOpenTradesCount()));

            BigDecimal yesQty = holdToResolutionSimulation.getTotalYesQuantity();
            BigDecimal noQty = holdToResolutionSimulation.getTotalNoQuantity();
            yesQuantityLabel.setText(yesQty.setScale(2, RoundingMode.HALF_UP).toString());
            noQuantityLabel.setText(noQty.setScale(2, RoundingMode.HALF_UP).toString());

            BigDecimal pl = holdToResolutionSimulation.getCumulativeProfitLoss();
            deltaSimPLLabel.setText("$" + pl.setScale(2, RoundingMode.HALF_UP));

            BigDecimal unrealizedPL = holdToResolutionSimulation.calculateUnrealizedPL(yesTokenId, noTokenId);
            deltaSimUnrealizedPLLabel.setText("$" + unrealizedPL.setScale(2, RoundingMode.HALF_UP));

            if (pl.compareTo(BigDecimal.ZERO) > 0) {
                deltaSimPLLabel.getStyleClass().setAll("profit-label", "price-change-positive");
            } else if (pl.compareTo(BigDecimal.ZERO) < 0) {
                deltaSimPLLabel.getStyleClass().setAll("profit-label", "price-change-negative");
            } else {
                deltaSimPLLabel.getStyleClass().setAll("profit-label");
            }

            if (unrealizedPL.compareTo(BigDecimal.ZERO) > 0) {
                deltaSimUnrealizedPLLabel.getStyleClass().setAll("profit-label", "price-change-positive");
            } else if (unrealizedPL.compareTo(BigDecimal.ZERO) < 0) {
                deltaSimUnrealizedPLLabel.getStyleClass().setAll("profit-label", "price-change-negative");
            } else {
                deltaSimUnrealizedPLLabel.getStyleClass().setAll("profit-label");
            }
        } else {
            if (deltaNeutralSimulation == null) return;

            deltaSim99Label.setText(String.valueOf(deltaNeutralSimulation.getCount99c()));
            deltaSim98Label.setText(String.valueOf(deltaNeutralSimulation.getCount98c()));
            deltaSim97Label.setText(String.valueOf(deltaNeutralSimulation.getCount97cOrBelow()));

            BigDecimal yesQty = deltaNeutralSimulation.getTotalYesQuantity();
            BigDecimal noQty = deltaNeutralSimulation.getTotalNoQuantity();
            yesQuantityLabel.setText(yesQty.setScale(2, RoundingMode.HALF_UP).toString());
            noQuantityLabel.setText(noQty.setScale(2, RoundingMode.HALF_UP).toString());

            BigDecimal pl = deltaNeutralSimulation.getCumulativeProfitLoss();
            deltaSimPLLabel.setText("$" + pl.setScale(2, RoundingMode.HALF_UP));

            BigDecimal unrealizedPL = deltaNeutralSimulation.calculateUnrealizedPL(yesTokenId, noTokenId);
            deltaSimUnrealizedPLLabel.setText("$" + unrealizedPL.setScale(2, RoundingMode.HALF_UP));

            if (pl.compareTo(BigDecimal.ZERO) > 0) {
                deltaSimPLLabel.getStyleClass().setAll("profit-label", "price-change-positive");
            } else if (pl.compareTo(BigDecimal.ZERO) < 0) {
                deltaSimPLLabel.getStyleClass().setAll("profit-label", "price-change-negative");
            } else {
                deltaSimPLLabel.getStyleClass().setAll("profit-label");
            }

            if (unrealizedPL.compareTo(BigDecimal.ZERO) > 0) {
                deltaSimUnrealizedPLLabel.getStyleClass().setAll("profit-label", "price-change-positive");
            } else if (unrealizedPL.compareTo(BigDecimal.ZERO) < 0) {
                deltaSimUnrealizedPLLabel.getStyleClass().setAll("profit-label", "price-change-negative");
            } else {
                deltaSimUnrealizedPLLabel.getStyleClass().setAll("profit-label");
            }
        }
    }

    @FXML
    private void handleShutdown() {
        logger.info("Shutdown button clicked - initiating safe shutdown");
        shutdown();
        Platform.exit();
        System.exit(0);
    }

    private String extractErrorMessage(Throwable ex) {
        String msg = ex.getMessage();
        if (msg == null) {
            return "Unknown error";
        }

        if (msg.contains("status 403") || msg.contains("Cloudflare")) {
            return "Blocked by Cloudflare - Check API credentials or try again later";
        }

        if (msg.contains("<!DOCTYPE html>") || msg.contains("<html")) {
            int titleStart = msg.indexOf("<title>");
            int titleEnd = msg.indexOf("</title>");
            if (titleStart >= 0 && titleEnd > titleStart) {
                return msg.substring(titleStart + 7, titleEnd);
            }
            return "HTTP error - Check logs for details";
        }

        if (msg.length() > 200) {
            return msg.substring(0, 200) + "...";
        }

        return msg;
    }

    public void shutdown() {
        logger.info("Shutting down MainController");
        stopRefreshServices();
        if (connectionManager != null) {
            connectionManager.disconnect();
        }
    }
}
