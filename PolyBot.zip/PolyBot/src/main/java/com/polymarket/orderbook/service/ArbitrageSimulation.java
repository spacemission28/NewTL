package com.polymarket.orderbook.service;

import com.polymarket.orderbook.engine.OrderBookEngine;
import com.polymarket.orderbook.model.ArbitrageOpportunity;
import com.polymarket.orderbook.model.OrderBookSnapshot;
import com.polymarket.orderbook.model.SimulatedTrade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class ArbitrageSimulation {

    private static final Logger logger = LoggerFactory.getLogger(ArbitrageSimulation.class);
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final BigDecimal DEFAULT_TRADE_AMOUNT = new BigDecimal("20.0");

    private final OrderBookEngine orderBookEngine;
    private final String logFilePath;

    private boolean simulationEnabled;
    private int count5Dollar;
    private int count10Dollar;
    private int count20Dollar;
    private int countAbove20Dollar;
    private BigDecimal cumulativeProfitLoss;
    private List<SimulatedTrade> openTrades;
    private BigDecimal minCentsThreshold;
    private BigDecimal minDivergenceToTrade;
    private String marketEndDateIso;
    private BigDecimal unrealizedProfitLoss;

    public ArbitrageSimulation(OrderBookEngine orderBookEngine, String marketSlug) {
        this.orderBookEngine = orderBookEngine;
        this.logFilePath = "arbitrage_trades_" + marketSlug.replaceAll("[^a-zA-Z0-9-]", "_") + ".txt";
        this.simulationEnabled = false;
        this.count5Dollar = 0;
        this.count10Dollar = 0;
        this.count20Dollar = 0;
        this.countAbove20Dollar = 0;
        this.cumulativeProfitLoss = BigDecimal.ZERO;
        this.openTrades = new ArrayList<>();
        this.minCentsThreshold = new BigDecimal("2.0");
        this.minDivergenceToTrade = new BigDecimal("2.0");
        this.marketEndDateIso = null;
        this.unrealizedProfitLoss = BigDecimal.ZERO;
        initializeLogFile();
    }

    private void initializeLogFile() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(logFilePath, false))) {
            writer.println("=== Exchange Arbitrage Strategy Simulation Log ===");
            writer.println("Format: Open Time | Side | Entry ASK (¢) | Shares | CB Signal | Exit Time | Exit BID (¢) | P&L ($) | Details");
            writer.println("=====================================================================================================");
        } catch (IOException e) {
            logger.error("Failed to initialize log file: {}", logFilePath, e);
        }
    }

    public void setMarketEndDateIso(String endDateIso) {
        this.marketEndDateIso = endDateIso;
        logger.info("Market end date set to: {}", endDateIso);
    }

    private boolean isWithinTwoMinutesOfEnd() {
        if (marketEndDateIso == null || marketEndDateIso.isEmpty()) {
            return false;
        }

        try {
            Instant endTime = Instant.parse(marketEndDateIso);
            Instant now = Instant.now();
            Instant twoMinutesBeforeEnd = endTime.minusSeconds(120);

            boolean withinCutoff = now.isAfter(twoMinutesBeforeEnd) || now.equals(twoMinutesBeforeEnd);
            if (withinCutoff) {
                logger.info("Within 2-minute cutoff window (now: {}, cutoff: {}, end: {})",
                    now, twoMinutesBeforeEnd, endTime);
            }
            return withinCutoff;
        } catch (Exception e) {
            logger.warn("Failed to parse market end date: {}", marketEndDateIso, e);
            return false;
        }
    }

    public void checkAndSimulate(ArbitrageOpportunity opportunity, String yesAssetId, String noAssetId,
                                  BigDecimal coinbasePrice, BigDecimal polymarketPrice) {
        if (!simulationEnabled) {
            return;
        }

        if (coinbasePrice == null || polymarketPrice == null) {
            return;
        }

        boolean withinCutoff = isWithinTwoMinutesOfEnd();

        if (withinCutoff && !openTrades.isEmpty()) {
            logger.info("Market within 2-minute cutoff - auto-liquidating {} open positions", openTrades.size());
            autoLiquidateAllPositions(yesAssetId, noAssetId);
            return;
        }

        BigDecimal divergence = coinbasePrice.subtract(polymarketPrice).abs();
        BigDecimal priceDifference = coinbasePrice.subtract(polymarketPrice);

        // Only trade when divergence meets minimum threshold
        if (!withinCutoff && divergence.compareTo(minDivergenceToTrade) >= 0) {
            ArbitrageOpportunity.ArbitrageDirection tradeDirection;
            if (priceDifference.compareTo(BigDecimal.ZERO) > 0) {
                tradeDirection = ArbitrageOpportunity.ArbitrageDirection.BUY_UP;
            } else {
                tradeDirection = ArbitrageOpportunity.ArbitrageDirection.BUY_DOWN;
            }

            // Update divergence bucket counters
            if (divergence.compareTo(new BigDecimal("20.0")) > 0) {
                countAbove20Dollar++;
                logger.info("Exchange Arbitrage >$20 divergence detected. Total: {}", countAbove20Dollar);
            } else if (divergence.compareTo(new BigDecimal("20.0")) >= 0) {
                count20Dollar++;
                logger.info("Exchange Arbitrage $20 divergence detected. Total: {}", count20Dollar);
            } else if (divergence.compareTo(new BigDecimal("10.0")) >= 0) {
                count10Dollar++;
                logger.info("Exchange Arbitrage $10 divergence detected. Total: {}", count10Dollar);
            } else if (divergence.compareTo(new BigDecimal("5.0")) >= 0) {
                count5Dollar++;
                logger.info("Exchange Arbitrage $5 divergence detected. Total: {}", count5Dollar);
            }
            // Note: Divergences < $5 will trade if minDivergenceToTrade allows, but won't increment counters

            simulateTradeWithDirection(tradeDirection, yesAssetId, noAssetId, coinbasePrice, divergence);
        }

        checkCloseTrades(yesAssetId, noAssetId, coinbasePrice);
        updateUnrealizedProfitLoss(yesAssetId, noAssetId);
    }

    private void simulateTradeWithDirection(ArbitrageOpportunity.ArbitrageDirection direction, String yesAssetId, String noAssetId,
                               BigDecimal coinbasePrice, BigDecimal divergence) {
        OrderBookSnapshot yesSnapshot = orderBookEngine.getSnapshot(yesAssetId);
        OrderBookSnapshot noSnapshot = orderBookEngine.getSnapshot(noAssetId);

        if (yesSnapshot == null || noSnapshot == null) {
            logger.warn("Cannot simulate trade - order book snapshots not available");
            return;
        }

        SimulatedTrade trade = new SimulatedTrade();
        trade.setStrategy("Exchange Arbitrage");

        String side;
        BigDecimal entryAskCents;
        BigDecimal entryAskDollars;
        BigDecimal shares;

        if (direction == ArbitrageOpportunity.ArbitrageDirection.BUY_UP) {
            side = "BUY YES";
            BigDecimal yesAsk = yesSnapshot.getBestAsk();
            entryAskCents = yesAsk.multiply(new BigDecimal("100"));
            entryAskDollars = yesAsk;
            shares = DEFAULT_TRADE_AMOUNT.divide(entryAskDollars, 2, RoundingMode.HALF_UP);

            trade.setOpenPriceYes(entryAskCents);
            trade.setOpenPriceNo(BigDecimal.ZERO);
        } else {
            side = "BUY NO";
            BigDecimal noAsk = noSnapshot.getBestAsk();
            entryAskCents = noAsk.multiply(new BigDecimal("100"));
            entryAskDollars = noAsk;
            shares = DEFAULT_TRADE_AMOUNT.divide(entryAskDollars, 2, RoundingMode.HALF_UP);

            trade.setOpenPriceYes(BigDecimal.ZERO);
            trade.setOpenPriceNo(entryAskCents);
        }

        trade.setAmount(shares);
        trade.setDetails("Side: " + side + ", Entry: " + entryAskCents.setScale(2, RoundingMode.HALF_UP) + "¢, " +
                        "Shares: " + shares + ", CB Signal: $" + coinbasePrice.setScale(2, RoundingMode.HALF_UP) +
                        ", Divergence: $" + divergence.setScale(2, RoundingMode.HALF_UP));

        openTrades.add(trade);
        logger.info("Simulated trade opened: {} @ {}¢, Shares: {}, Coinbase Signal: ${}",
            side, entryAskCents.setScale(2, RoundingMode.HALF_UP), shares, coinbasePrice);
    }

    private void checkCloseTrades(String yesAssetId, String noAssetId, BigDecimal currentCoinbasePrice) {
        if (currentCoinbasePrice == null) {
            return;
        }

        OrderBookSnapshot yesSnapshot = orderBookEngine.getSnapshot(yesAssetId);
        OrderBookSnapshot noSnapshot = orderBookEngine.getSnapshot(noAssetId);

        if (yesSnapshot == null || noSnapshot == null) {
            return;
        }

        List<SimulatedTrade> tradesToClose = new ArrayList<>();
        LocalDateTime oneMinuteAgo = LocalDateTime.now().minusMinutes(1);

        for (SimulatedTrade trade : openTrades) {
            if (trade.getOpenTime().isBefore(oneMinuteAgo)) {
                trade.setCloseTime(LocalDateTime.now());
                trade.setClosePriceYes(BigDecimal.ZERO);
                trade.setClosePriceNo(BigDecimal.ZERO);
                trade.setProfitLoss(BigDecimal.ZERO);
                tradesToClose.add(trade);
                logger.debug("Removed stale arbitrage trade older than 1 minute");
                continue;
            }

            boolean isYesTrade = trade.getOpenPriceYes().compareTo(BigDecimal.ZERO) > 0;
            BigDecimal entryAskCents = isYesTrade ? trade.getOpenPriceYes() : trade.getOpenPriceNo();
            BigDecimal shares = trade.getAmount();

            BigDecimal currentBidCents;
            if (isYesTrade) {
                BigDecimal yesBid = yesSnapshot.getBestBid();
                currentBidCents = yesBid.multiply(new BigDecimal("100"));
            } else {
                BigDecimal noBid = noSnapshot.getBestBid();
                currentBidCents = noBid.multiply(new BigDecimal("100"));
            }

            BigDecimal priceGainCents = currentBidCents.subtract(entryAskCents);
            BigDecimal pnlDollars = priceGainCents.divide(new BigDecimal("100"), 6, RoundingMode.HALF_UP)
                                                   .multiply(shares);

            if (priceGainCents.compareTo(minCentsThreshold) >= 0) {
                trade.setCloseTime(LocalDateTime.now());
                if (isYesTrade) {
                    trade.setClosePriceYes(currentBidCents);
                    trade.setClosePriceNo(BigDecimal.ZERO);
                } else {
                    trade.setClosePriceYes(BigDecimal.ZERO);
                    trade.setClosePriceNo(currentBidCents);
                }
                trade.setProfitLoss(pnlDollars);

                cumulativeProfitLoss = cumulativeProfitLoss.add(pnlDollars);
                tradesToClose.add(trade);

                logTradeToFile(trade);
                logger.info("Simulated trade closed: Entry: {}¢, Exit: {}¢, Gain: {}¢, Shares: {}, P&L: ${}",
                    entryAskCents.setScale(2, RoundingMode.HALF_UP),
                    currentBidCents.setScale(2, RoundingMode.HALF_UP),
                    priceGainCents.setScale(2, RoundingMode.HALF_UP),
                    shares,
                    pnlDollars.setScale(2, RoundingMode.HALF_UP));
            }
        }

        openTrades.removeAll(tradesToClose);
    }

    private void autoLiquidateAllPositions(String yesAssetId, String noAssetId) {
        OrderBookSnapshot yesSnapshot = orderBookEngine.getSnapshot(yesAssetId);
        OrderBookSnapshot noSnapshot = orderBookEngine.getSnapshot(noAssetId);

        if (yesSnapshot == null || noSnapshot == null) {
            logger.warn("Cannot auto-liquidate - order book snapshots not available");
            return;
        }

        List<SimulatedTrade> tradesToClose = new ArrayList<>(openTrades);

        for (SimulatedTrade trade : tradesToClose) {
            boolean isYesTrade = trade.getOpenPriceYes().compareTo(BigDecimal.ZERO) > 0;
            BigDecimal entryAskCents = isYesTrade ? trade.getOpenPriceYes() : trade.getOpenPriceNo();
            BigDecimal shares = trade.getAmount();

            BigDecimal currentBidCents;
            if (isYesTrade) {
                BigDecimal yesBid = yesSnapshot.getBestBid();
                currentBidCents = yesBid.multiply(new BigDecimal("100"));
            } else {
                BigDecimal noBid = noSnapshot.getBestBid();
                currentBidCents = noBid.multiply(new BigDecimal("100"));
            }

            BigDecimal priceGainCents = currentBidCents.subtract(entryAskCents);
            BigDecimal pnlDollars = priceGainCents.divide(new BigDecimal("100"), 6, RoundingMode.HALF_UP)
                                                   .multiply(shares);

            trade.setCloseTime(LocalDateTime.now());
            if (isYesTrade) {
                trade.setClosePriceYes(currentBidCents);
                trade.setClosePriceNo(BigDecimal.ZERO);
            } else {
                trade.setClosePriceYes(BigDecimal.ZERO);
                trade.setClosePriceNo(currentBidCents);
            }
            trade.setProfitLoss(pnlDollars);

            cumulativeProfitLoss = cumulativeProfitLoss.add(pnlDollars);

            logTradeToFile(trade);
            logger.info("AUTO-LIQUIDATED: Entry: {}¢, Exit: {}¢, Gain: {}¢, Shares: {}, P&L: ${}",
                entryAskCents.setScale(2, RoundingMode.HALF_UP),
                currentBidCents.setScale(2, RoundingMode.HALF_UP),
                priceGainCents.setScale(2, RoundingMode.HALF_UP),
                shares,
                pnlDollars.setScale(2, RoundingMode.HALF_UP));
        }

        openTrades.clear();
        unrealizedProfitLoss = BigDecimal.ZERO;
    }

    private void updateUnrealizedProfitLoss(String yesAssetId, String noAssetId) {
        if (openTrades.isEmpty()) {
            unrealizedProfitLoss = BigDecimal.ZERO;
            return;
        }

        OrderBookSnapshot yesSnapshot = orderBookEngine.getSnapshot(yesAssetId);
        OrderBookSnapshot noSnapshot = orderBookEngine.getSnapshot(noAssetId);

        if (yesSnapshot == null || noSnapshot == null) {
            return;
        }

        BigDecimal totalUnrealized = BigDecimal.ZERO;

        for (SimulatedTrade trade : openTrades) {
            boolean isYesTrade = trade.getOpenPriceYes().compareTo(BigDecimal.ZERO) > 0;
            BigDecimal entryAskCents = isYesTrade ? trade.getOpenPriceYes() : trade.getOpenPriceNo();
            BigDecimal shares = trade.getAmount();

            BigDecimal currentBidCents;
            if (isYesTrade) {
                BigDecimal yesBid = yesSnapshot.getBestBid();
                currentBidCents = yesBid.multiply(new BigDecimal("100"));
            } else {
                BigDecimal noBid = noSnapshot.getBestBid();
                currentBidCents = noBid.multiply(new BigDecimal("100"));
            }

            BigDecimal priceGainCents = currentBidCents.subtract(entryAskCents);
            BigDecimal pnlDollars = priceGainCents.divide(new BigDecimal("100"), 6, RoundingMode.HALF_UP)
                                                   .multiply(shares);

            totalUnrealized = totalUnrealized.add(pnlDollars);
        }

        unrealizedProfitLoss = totalUnrealized;
    }

    private void logTradeToFile(SimulatedTrade trade) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(logFilePath, true))) {
            String openTime = trade.getOpenTime().format(TIME_FORMAT);
            String closeTime = trade.getCloseTime() != null ? trade.getCloseTime().format(TIME_FORMAT) : "OPEN";

            boolean isYesTrade = trade.getOpenPriceYes().compareTo(BigDecimal.ZERO) > 0;
            String side = isYesTrade ? "YES" : "NO";
            String entryAsk = (isYesTrade ? trade.getOpenPriceYes() : trade.getOpenPriceNo()).setScale(2, RoundingMode.HALF_UP).toString();
            String exitBid = trade.getCloseTime() != null ?
                (isYesTrade ? trade.getClosePriceYes() : trade.getClosePriceNo()).setScale(2, RoundingMode.HALF_UP).toString() : "N/A";
            String shares = trade.getAmount().setScale(2, RoundingMode.HALF_UP).toString();
            String pnl = trade.getProfitLoss() != null ? "$" + trade.getProfitLoss().setScale(2, RoundingMode.HALF_UP).toString() : "N/A";

            writer.printf("%s | %s | %s¢ | %s | %s | %s | %s¢ | %s | %s%n",
                openTime, side, entryAsk, shares, trade.getDetails().split("CB Signal: ")[1].split(",")[0],
                closeTime, exitBid, pnl, trade.getDetails());
        } catch (IOException e) {
            logger.error("Failed to write trade to log file", e);
        }
    }

    public void reset() {
        count5Dollar = 0;
        count10Dollar = 0;
        count20Dollar = 0;
        countAbove20Dollar = 0;
        cumulativeProfitLoss = BigDecimal.ZERO;
        openTrades.clear();
        unrealizedProfitLoss = BigDecimal.ZERO;
        marketEndDateIso = null;
        initializeLogFile();
        logger.info("Exchange Arbitrage simulation reset (including cumulative P/L)");
    }

    public void resetForNewMarket(String newMarketSlug, String newMarketEndDateIso) {
        count5Dollar = 0;
        count10Dollar = 0;
        count20Dollar = 0;
        countAbove20Dollar = 0;
        openTrades.clear();
        unrealizedProfitLoss = BigDecimal.ZERO;
        marketEndDateIso = newMarketEndDateIso;
        logger.info("Exchange Arbitrage simulation reset for new market (cumulative P/L preserved: ${})",
            cumulativeProfitLoss.setScale(2, RoundingMode.HALF_UP));
    }

    public void setSimulationEnabled(boolean enabled) {
        this.simulationEnabled = enabled;
        if (enabled) {
            logger.info("Exchange Arbitrage simulation ENABLED");
        } else {
            logger.info("Exchange Arbitrage simulation DISABLED");
        }
    }

    public boolean isSimulationEnabled() {
        return simulationEnabled;
    }

    public void setMinCentsForLiquidation(BigDecimal minCents) {
        this.minCentsThreshold = minCents;
    }

    public BigDecimal getMinCentsForLiquidation() {
        return minCentsThreshold;
    }

    public void setMinDivergenceToTrade(BigDecimal minDivergence) {
        this.minDivergenceToTrade = minDivergence;
        logger.info("Exchange Arbitrage simulation minimum divergence set to: ${}", minDivergence);
    }

    public BigDecimal getMinDivergenceToTrade() {
        return minDivergenceToTrade;
    }

    public int getCount5Dollar() {
        return count5Dollar;
    }

    public int getCount10Dollar() {
        return count10Dollar;
    }

    public int getCount20Dollar() {
        return count20Dollar;
    }

    public int getCountAbove20Dollar() {
        return countAbove20Dollar;
    }

    public BigDecimal getCumulativeProfitLoss() {
        return cumulativeProfitLoss;
    }

    public BigDecimal getUnrealizedProfitLoss() {
        return unrealizedProfitLoss;
    }

    public int getOpenTradesCount() {
        return openTrades.size();
    }

    public void resetStats() {
        reset();
    }
}
