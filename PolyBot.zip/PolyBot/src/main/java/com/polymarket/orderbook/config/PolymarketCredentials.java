package com.polymarket.orderbook.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.Properties;

public class PolymarketCredentials {

    private static final Logger logger = LoggerFactory.getLogger(PolymarketCredentials.class);
    private static final String CREDENTIALS_FILE = ".polymarket_credentials";
    private static final String ENCRYPTION_KEY = "PolymarketOrderBook2024Key!"; // Simple encryption

    private String apiKey;
    private String apiSecret;
    private String apiPassphrase;
    private String privateKey;
    private String walletAddress;
    private boolean authenticated;

    public PolymarketCredentials() {
        loadFromFile();
        loadPrivateKeyFromEnv();
    }

    public void setCredentials(String apiKey, String apiSecret, String apiPassphrase) {
        this.apiKey = apiKey;
        this.apiSecret = apiSecret;
        this.apiPassphrase = apiPassphrase;
        this.authenticated = (apiKey != null && !apiKey.isEmpty());
    }

    public void setCredentials(String apiKey, String apiSecret, String apiPassphrase, String privateKey) {
        this.apiKey = apiKey;
        this.apiSecret = apiSecret;
        this.apiPassphrase = apiPassphrase;
        this.privateKey = privateKey;
        this.authenticated = (apiKey != null && !apiKey.isEmpty());
    }

    public void saveToFile() {
        try {
            Path credentialsPath = Paths.get(System.getProperty("user.home"), CREDENTIALS_FILE);
            Properties props = new Properties();

            if (apiKey != null && !apiKey.isEmpty()) {
                props.setProperty("api_key", encrypt(apiKey));
                props.setProperty("api_secret", encrypt(apiSecret));
                props.setProperty("api_passphrase", encrypt(apiPassphrase));
            }

            if (privateKey != null && !privateKey.isEmpty()) {
                props.setProperty("private_key", encrypt(privateKey));
                savePrivateKeyToEnv();
            }

            if (walletAddress != null && !walletAddress.isEmpty()) {
                props.setProperty("wallet_address", encrypt(walletAddress));
            }

            try (OutputStream output = Files.newOutputStream(credentialsPath)) {
                props.store(output, "Polymarket Credentials (Encrypted)");
            }

            logger.info("Saved credentials to: {}", credentialsPath);
            authenticated = true;

        } catch (Exception e) {
            logger.error("Failed to save credentials", e);
            authenticated = false;
        }
    }

    private void savePrivateKeyToEnv() {
        try {
            Path envPath = Paths.get(".env");
            Properties props = new Properties();

            if (Files.exists(envPath)) {
                try (InputStream input = Files.newInputStream(envPath)) {
                    props.load(input);
                }
            }

            props.setProperty("POLYMARKET_PRIVATE_KEY", privateKey);

            try (OutputStream output = Files.newOutputStream(envPath)) {
                props.store(output, "Polymarket Configuration");
            }

            logger.info("Updated private key in .env file");

        } catch (Exception e) {
            logger.error("Failed to save private key to .env", e);
        }
    }

    public void loadFromFile() {
        try {
            Path credentialsPath = Paths.get(System.getProperty("user.home"), CREDENTIALS_FILE);

            if (!Files.exists(credentialsPath)) {
                logger.debug("No credentials file found");
                authenticated = false;
                return;
            }

            Properties props = new Properties();
            try (InputStream input = Files.newInputStream(credentialsPath)) {
                props.load(input);
            }

            String encryptedKey = props.getProperty("api_key");
            String encryptedSecret = props.getProperty("api_secret");
            String encryptedPassphrase = props.getProperty("api_passphrase");
            String encryptedPrivateKey = props.getProperty("private_key");
            String encryptedWalletAddress = props.getProperty("wallet_address");

            if (encryptedKey != null) {
                apiKey = decrypt(encryptedKey);
                apiSecret = decrypt(encryptedSecret);
                apiPassphrase = decrypt(encryptedPassphrase);

                if (encryptedPrivateKey != null) {
                    privateKey = decrypt(encryptedPrivateKey);
                    logger.info("Loaded credentials including private key from file");
                } else {
                    logger.info("Loaded credentials from file (no private key stored)");
                }

                if (encryptedWalletAddress != null) {
                    walletAddress = decrypt(encryptedWalletAddress);
                    logger.info("Loaded wallet address from file: {}", walletAddress);
                }

                authenticated = true;
            } else {
                authenticated = false;
            }

        } catch (Exception e) {
            logger.error("Failed to load credentials", e);
            authenticated = false;
        }
    }

    private void loadPrivateKeyFromEnv() {
        if (privateKey != null && !privateKey.isEmpty() && walletAddress != null && !walletAddress.isEmpty()) {
            logger.debug("Private key and wallet address already loaded from credentials file, skipping .env");
            return;
        }

        try {
            Path envPath = Paths.get(".env");
            if (!Files.exists(envPath)) {
                logger.debug("No .env file found");
                return;
            }

            Properties props = new Properties();
            try (InputStream input = Files.newInputStream(envPath)) {
                props.load(input);
            }

            String envPrivateKey = props.getProperty("POLYMARKET_PRIVATE_KEY");
            String envWalletAddress = props.getProperty("POLYMARKET_WALLET_ADDRESS");

            if (privateKey == null || privateKey.isEmpty()) {
                if (envPrivateKey != null && !envPrivateKey.isEmpty() && !envPrivateKey.contains("your_private_key")) {
                    privateKey = envPrivateKey;
                    logger.info("Loaded private key from .env file");
                } else {
                    logger.warn("Private key not configured in .env");
                }
            }

            if (walletAddress == null || walletAddress.isEmpty()) {
                if (envWalletAddress != null && !envWalletAddress.isEmpty()
                    && !envWalletAddress.contains("your_wallet")
                    && !envWalletAddress.contains("YourWallet")
                    && !envWalletAddress.equalsIgnoreCase("0xYourWalletAddressHere")) {
                    walletAddress = envWalletAddress;
                    logger.info("Loaded wallet address from .env file: {}", walletAddress);
                } else if (privateKey != null) {
                    walletAddress = deriveWalletAddressFromPrivateKey(privateKey);
                    if (walletAddress != null) {
                        logger.info("Derived wallet address from private key: {}", walletAddress);
                    } else {
                        logger.error("Failed to derive wallet address from private key");
                    }
                } else {
                    logger.warn("No valid wallet address - needs valid private key to derive");
                }
            }

        } catch (Exception e) {
            logger.error("Failed to load private key from .env", e);
            privateKey = null;
        }
    }

    private String deriveWalletAddressFromPrivateKey(String privateKey) {
        try {
            String cleanPrivateKey = privateKey.startsWith("0x") ? privateKey.substring(2) : privateKey;
            org.web3j.crypto.ECKeyPair keyPair = org.web3j.crypto.ECKeyPair.create(
                    new java.math.BigInteger(cleanPrivateKey, 16)
            );
            org.web3j.crypto.Credentials credentials = org.web3j.crypto.Credentials.create(keyPair);
            return credentials.getAddress();
        } catch (Exception e) {
            logger.error("Failed to derive wallet address from private key", e);
            return null;
        }
    }

    public void clearCredentials() {
        apiKey = null;
        apiSecret = null;
        apiPassphrase = null;
        privateKey = null;
        authenticated = false;

        try {
            Path credentialsPath = Paths.get(System.getProperty("user.home"), CREDENTIALS_FILE);
            Files.deleteIfExists(credentialsPath);
            logger.info("Cleared credentials");
        } catch (IOException e) {
            logger.error("Failed to delete credentials file", e);
        }
    }

    private String encrypt(String value) throws Exception {
        if (value == null) return "";

        SecretKey key = new SecretKeySpec(ENCRYPTION_KEY.getBytes(StandardCharsets.UTF_8), 0, 16, "AES");
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, key);

        byte[] encrypted = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(encrypted);
    }

    private String decrypt(String encrypted) throws Exception {
        if (encrypted == null || encrypted.isEmpty()) return "";

        SecretKey key = new SecretKeySpec(ENCRYPTION_KEY.getBytes(StandardCharsets.UTF_8), 0, 16, "AES");
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, key);

        byte[] decoded = Base64.getDecoder().decode(encrypted);
        byte[] decrypted = cipher.doFinal(decoded);
        return new String(decrypted, StandardCharsets.UTF_8);
    }

    public String getApiKey() {
        return apiKey;
    }

    public String getApiSecret() {
        return apiSecret;
    }

    public String getApiPassphrase() {
        return apiPassphrase;
    }

    public boolean isAuthenticated() {
        return authenticated && apiKey != null && !apiKey.isEmpty();
    }

    public String getMaskedApiKey() {
        if (apiKey == null || apiKey.length() < 8) {
            return "****";
        }
        return apiKey.substring(0, 4) + "..." + apiKey.substring(apiKey.length() - 4);
    }

    public String getPrivateKey() {
        return privateKey;
    }

    public void setPrivateKey(String privateKey) {
        this.privateKey = privateKey;
    }

    public boolean hasPrivateKey() {
        return privateKey != null && !privateKey.isEmpty();
    }

    public boolean hasAllCredentials() {
        return isAuthenticated() && hasPrivateKey();
    }

    public String getWalletAddress() {
        return walletAddress;
    }

    public void setWalletAddress(String walletAddress) {
        this.walletAddress = walletAddress;
    }

    public boolean hasWalletAddress() {
        return walletAddress != null && !walletAddress.isEmpty();
    }
}
