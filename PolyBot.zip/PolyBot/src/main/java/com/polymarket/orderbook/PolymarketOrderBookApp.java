package com.polymarket.orderbook;

import com.polymarket.orderbook.ui.controller.MainController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PolymarketOrderBookApp extends Application {

    private static final Logger logger = LoggerFactory.getLogger(PolymarketOrderBookApp.class);
    private MainController mainController;

    @Override
    public void start(Stage primaryStage) throws Exception {
        logger.info("Starting Polymarket OrderBook Application");

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/main-view.fxml"));
        Parent root = loader.load();
        mainController = loader.getController();

        Scene scene = new Scene(root, 1400, 900);

        primaryStage.setTitle("Polymarket Real-Time Order Book");
        primaryStage.setScene(scene);
        primaryStage.setOnCloseRequest(event -> {
            logger.info("Application closing");
            if (mainController != null) {
                mainController.shutdown();
            }
        });

        primaryStage.show();
        logger.info("Application started successfully");
    }

    @Override
    public void stop() throws Exception {
        logger.info("Application stopping");
        if (mainController != null) {
            mainController.shutdown();
        }
        super.stop();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
