package com.polymarket.orderbook.engine;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class PriceCalculator {

    private static final Logger logger = LoggerFactory.getLogger(PriceCalculator.class);
    private static final int SCALE = 4;

    public static BigDecimal calculateQuantityForAmount(BigDecimal usdcAmount, BigDecimal price) {
        if (price.compareTo(BigDecimal.ZERO) == 0) {
            logger.warn("Cannot calculate quantity with zero price");
            return BigDecimal.ZERO;
        }

        return usdcAmount.divide(price, SCALE, RoundingMode.HALF_UP);
    }

    public static BigDecimal calculateTotalCost(BigDecimal quantity, BigDecimal price) {
        return quantity.multiply(price).setScale(SCALE, RoundingMode.HALF_UP);
    }

    public static SplitTradeCalculation calculateSplitTrade(BigDecimal totalAmount,
                                                             BigDecimal yesPrice,
                                                             BigDecimal noPrice) {
        if (yesPrice.compareTo(BigDecimal.ZERO) == 0 || noPrice.compareTo(BigDecimal.ZERO) == 0) {
            logger.error("Cannot calculate split trade with zero prices");
            return null;
        }

        BigDecimal halfAmount = totalAmount.divide(new BigDecimal("2"), SCALE, RoundingMode.HALF_UP);

        BigDecimal yesQuantity = calculateQuantityForAmount(halfAmount, yesPrice);
        BigDecimal noQuantity = calculateQuantityForAmount(halfAmount, noPrice);

        BigDecimal yesActualCost = calculateTotalCost(yesQuantity, yesPrice);
        BigDecimal noActualCost = calculateTotalCost(noQuantity, noPrice);

        logger.info("Split trade calculation: YES {}@{} = ${}, NO {}@{} = ${}",
                yesQuantity, yesPrice, yesActualCost, noQuantity, noPrice, noActualCost);

        return new SplitTradeCalculation(
                yesQuantity,
                noQuantity,
                yesActualCost,
                noActualCost,
                yesActualCost.add(noActualCost)
        );
    }

    public static BigDecimal calculateProfitAtSettlement(SplitTradeCalculation trade,
                                                          boolean yesWins) {
        if (yesWins) {
            return trade.getYesQuantity().subtract(trade.getTotalCost());
        } else {
            return trade.getNoQuantity().subtract(trade.getTotalCost());
        }
    }

    public static class SplitTradeCalculation {
        private final BigDecimal yesQuantity;
        private final BigDecimal noQuantity;
        private final BigDecimal yesCost;
        private final BigDecimal noCost;
        private final BigDecimal totalCost;

        public SplitTradeCalculation(BigDecimal yesQuantity, BigDecimal noQuantity,
                                      BigDecimal yesCost, BigDecimal noCost, BigDecimal totalCost) {
            this.yesQuantity = yesQuantity;
            this.noQuantity = noQuantity;
            this.yesCost = yesCost;
            this.noCost = noCost;
            this.totalCost = totalCost;
        }

        public BigDecimal getYesQuantity() {
            return yesQuantity;
        }

        public BigDecimal getNoQuantity() {
            return noQuantity;
        }

        public BigDecimal getYesCost() {
            return yesCost;
        }

        public BigDecimal getNoCost() {
            return noCost;
        }

        public BigDecimal getTotalCost() {
            return totalCost;
        }
    }
}
