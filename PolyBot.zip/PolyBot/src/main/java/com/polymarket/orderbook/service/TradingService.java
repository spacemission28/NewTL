package com.polymarket.orderbook.service;

import com.polymarket.orderbook.api.PolymarketApiClient;
import com.polymarket.orderbook.api.PolymarketAuthenticatedClient;
import com.polymarket.orderbook.config.AppConfig;
import com.polymarket.orderbook.config.PolymarketCredentials;
import com.polymarket.orderbook.engine.PriceCalculator;
import com.polymarket.orderbook.model.TradeRequest;
import org.apache.hc.core5.http.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.concurrent.CompletableFuture;

public class TradingService {

    private static final Logger logger = LoggerFactory.getLogger(TradingService.class);
    private final PolymarketApiClient apiClient;
    private final PolymarketAuthenticatedClient authenticatedClient;
    private final PolymarketCredentials credentials;

    public TradingService(PolymarketCredentials credentials) {
        this.apiClient = new PolymarketApiClient();
        this.credentials = credentials;

        if (credentials.hasPrivateKey()) {
            String clobUrl = AppConfig.getInstance().getClobApiUrl();
            this.authenticatedClient = PolymarketAuthenticatedClient.fromCredentials(credentials, clobUrl);
            logger.info("Trading service initialized with authenticated client");
        } else {
            this.authenticatedClient = null;
            logger.warn("Trading service initialized without authentication - trades will not be executed");
        }
    }

    public CompletableFuture<String> executeSplitTradeAsync(String yesAssetId,
                                                             String noAssetId,
                                                             BigDecimal yesPrice,
                                                             BigDecimal noPrice,
                                                             BigDecimal totalAmount) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                return executeSplitTrade(yesAssetId, noAssetId, yesPrice, noPrice, totalAmount);
            } catch (IOException | ParseException e) {
                logger.error("Failed to execute split trade", e);
                throw new RuntimeException("Failed to execute split trade", e);
            }
        });
    }

    public String executeSplitTrade(String yesAssetId,
                                     String noAssetId,
                                     BigDecimal yesPrice,
                                     BigDecimal noPrice,
                                     BigDecimal totalAmount) throws IOException, ParseException {

        if (authenticatedClient == null) {
            throw new IOException("Private key not configured. Please add it to your .env file.");
        }

        logger.info("Executing split trade: Total ${}, YES@{}, NO@{}",
                totalAmount, yesPrice, noPrice);

        PriceCalculator.SplitTradeCalculation calc =
                PriceCalculator.calculateSplitTrade(totalAmount, yesPrice, noPrice);

        if (calc == null) {
            throw new IOException("Failed to calculate split trade");
        }

        TradeRequest yesOrder = TradeRequest.builder()
                .assetId(yesAssetId)
                .side("BUY")
                .price(yesPrice)
                .size(calc.getYesQuantity())
                .orderType("MARKET")
                .totalUsdcAmount(calc.getYesCost())
                .build();

        TradeRequest noOrder = TradeRequest.builder()
                .assetId(noAssetId)
                .side("BUY")
                .price(noPrice)
                .size(calc.getNoQuantity())
                .orderType("MARKET")
                .totalUsdcAmount(calc.getNoCost())
                .build();

        logger.info("Submitting YES order: {} tokens @ ${}", calc.getYesQuantity(), yesPrice);
        String yesResult = authenticatedClient.submitOrder(yesOrder).join();

        logger.info("Submitting NO order: {} tokens @ ${}", calc.getNoQuantity(), noPrice);
        String noResult = authenticatedClient.submitOrder(noOrder).join();

        String result = String.format("Split trade executed successfully.\nYES: %s\nNO: %s",
                yesResult, noResult);

        logger.info("Split trade completed successfully");
        return result;
    }

    public CompletableFuture<String> executeArbitrageTradeAsync(String assetId,
                                                                  String side,
                                                                  BigDecimal price,
                                                                  BigDecimal amount) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                return executeArbitrageTrade(assetId, side, price, amount);
            } catch (IOException | ParseException e) {
                logger.error("Failed to execute arbitrage trade", e);
                throw new RuntimeException("Failed to execute arbitrage trade", e);
            }
        });
    }

    public String executeArbitrageTrade(String assetId,
                                         String side,
                                         BigDecimal price,
                                         BigDecimal amount) throws IOException, ParseException {

        if (authenticatedClient == null) {
            throw new IOException("Private key not configured. Please add it to your .env file.");
        }

        logger.info("Executing arbitrage trade: {} ${} @ {} on side {}",
                side, amount, price, assetId.substring(0, 8) + "...");

        BigDecimal quantity = amount.divide(price, 2, BigDecimal.ROUND_DOWN);

        TradeRequest order = TradeRequest.builder()
                .assetId(assetId)
                .side(side)
                .price(price)
                .size(quantity)
                .orderType("MARKET")
                .totalUsdcAmount(amount)
                .build();

        logger.info("Submitting arbitrage order: {} {} tokens @ ${}", side, quantity, price);
        String result = authenticatedClient.submitOrder(order).join();

        logger.info("Arbitrage trade completed successfully: Order ID {}", result);
        return result;
    }

    public void close() {
        apiClient.close();
        if (authenticatedClient != null) {
            authenticatedClient.close();
        }
    }
}
