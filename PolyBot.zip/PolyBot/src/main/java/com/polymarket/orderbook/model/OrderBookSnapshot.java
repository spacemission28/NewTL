package com.polymarket.orderbook.model;

import java.math.BigDecimal;
import java.util.List;

public class OrderBookSnapshot {

    private String assetId;
    private List<PriceLevel> bids;
    private List<PriceLevel> asks;
    private BigDecimal midPrice;
    private BigDecimal spread;
    private BigDecimal spreadPercentage;
    private Long timestamp;

    public OrderBookSnapshot() {
    }

    public OrderBookSnapshot(String assetId, List<PriceLevel> bids, List<PriceLevel> asks,
                             BigDecimal midPrice, BigDecimal spread, BigDecimal spreadPercentage, Long timestamp) {
        this.assetId = assetId;
        this.bids = bids;
        this.asks = asks;
        this.midPrice = midPrice;
        this.spread = spread;
        this.spreadPercentage = spreadPercentage;
        this.timestamp = timestamp;
    }

    public String getAssetId() {
        return assetId;
    }

    public void setAssetId(String assetId) {
        this.assetId = assetId;
    }

    public List<PriceLevel> getBids() {
        return bids;
    }

    public void setBids(List<PriceLevel> bids) {
        this.bids = bids;
    }

    public List<PriceLevel> getAsks() {
        return asks;
    }

    public void setAsks(List<PriceLevel> asks) {
        this.asks = asks;
    }

    public BigDecimal getMidPrice() {
        return midPrice;
    }

    public void setMidPrice(BigDecimal midPrice) {
        this.midPrice = midPrice;
    }

    public BigDecimal getSpread() {
        return spread;
    }

    public void setSpread(BigDecimal spread) {
        this.spread = spread;
    }

    public BigDecimal getSpreadPercentage() {
        return spreadPercentage;
    }

    public void setSpreadPercentage(BigDecimal spreadPercentage) {
        this.spreadPercentage = spreadPercentage;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }

    public BigDecimal getBestBid() {
        return bids.isEmpty() ? BigDecimal.ZERO : bids.get(0).getPrice();
    }

    public BigDecimal getBestAsk() {
        return asks.isEmpty() ? BigDecimal.ZERO : asks.get(0).getPrice();
    }
}
