package com.polymarket.orderbook.service;

import com.polymarket.orderbook.engine.OrderBookState;
import com.polymarket.orderbook.engine.PriceCalculator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class DeltaNeutralStrategy {

    private static final Logger logger = LoggerFactory.getLogger(DeltaNeutralStrategy.class);

    public static BalancingRecommendation calculateBalancingAction(
            OrderBookState yesBook,
            OrderBookState noBook,
            BigDecimal currentYesPosition,
            BigDecimal currentNoPosition,
            BigDecimal targetExposure) {

        BigDecimal yesMidPrice = yesBook.getMidPrice();
        BigDecimal noMidPrice = noBook.getMidPrice();

        if (yesMidPrice.compareTo(BigDecimal.ZERO) == 0 || noMidPrice.compareTo(BigDecimal.ZERO) == 0) {
            logger.warn("Cannot calculate balancing with zero prices");
            return null;
        }

        BigDecimal currentYesValue = currentYesPosition.multiply(yesMidPrice);
        BigDecimal currentNoValue = currentNoPosition.multiply(noMidPrice);

        BigDecimal totalValue = currentYesValue.add(currentNoValue);
        BigDecimal imbalance = currentYesValue.subtract(currentNoValue).abs();

        BigDecimal imbalancePercentage = BigDecimal.ZERO;
        if (totalValue.compareTo(BigDecimal.ZERO) > 0) {
            imbalancePercentage = imbalance.divide(totalValue, 4, RoundingMode.HALF_UP)
                    .multiply(new BigDecimal("100"));
        }

        logger.info("Position analysis - YES: ${}, NO: ${}, Imbalance: {}%",
                currentYesValue, currentNoValue, imbalancePercentage);

        if (imbalancePercentage.compareTo(new BigDecimal("5")) < 0) {
            logger.info("Position is balanced (imbalance < 5%)");
            return new BalancingRecommendation(true, null, BigDecimal.ZERO, null, BigDecimal.ZERO);
        }

        String sideToBalance = currentYesValue.compareTo(currentNoValue) > 0 ? "NO" : "YES";
        BigDecimal amountToRebalance = imbalance.divide(new BigDecimal("2"), 4, RoundingMode.HALF_UP);
        BigDecimal quantityNeeded;

        if ("YES".equals(sideToBalance)) {
            quantityNeeded = PriceCalculator.calculateQuantityForAmount(amountToRebalance, yesMidPrice);
        } else {
            quantityNeeded = PriceCalculator.calculateQuantityForAmount(amountToRebalance, noMidPrice);
        }

        logger.info("Rebalancing recommendation: Buy {} {} tokens (${} worth)",
                quantityNeeded, sideToBalance, amountToRebalance);

        return new BalancingRecommendation(false, sideToBalance, quantityNeeded,
                sideToBalance.equals("YES") ? yesMidPrice : noMidPrice, imbalancePercentage);
    }

    public static class BalancingRecommendation {
        private final boolean isBalanced;
        private final String sideToBuy;
        private final BigDecimal quantityToBuy;
        private final BigDecimal priceToUse;
        private final BigDecimal imbalancePercentage;

        public BalancingRecommendation(boolean isBalanced, String sideToBuy,
                                        BigDecimal quantityToBuy, BigDecimal priceToUse,
                                        BigDecimal imbalancePercentage) {
            this.isBalanced = isBalanced;
            this.sideToBuy = sideToBuy;
            this.quantityToBuy = quantityToBuy;
            this.priceToUse = priceToUse;
            this.imbalancePercentage = imbalancePercentage;
        }

        public boolean isBalanced() {
            return isBalanced;
        }

        public String getSideToBuy() {
            return sideToBuy;
        }

        public BigDecimal getQuantityToBuy() {
            return quantityToBuy;
        }

        public BigDecimal getPriceToUse() {
            return priceToUse;
        }

        public BigDecimal getImbalancePercentage() {
            return imbalancePercentage;
        }
    }
}
