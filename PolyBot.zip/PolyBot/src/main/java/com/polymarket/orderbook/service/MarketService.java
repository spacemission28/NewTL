package com.polymarket.orderbook.service;

import com.polymarket.orderbook.api.GammaApiClient;
import com.polymarket.orderbook.model.Market;
import org.apache.hc.core5.http.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.concurrent.CompletableFuture;

public class MarketService {

    private static final Logger logger = LoggerFactory.getLogger(MarketService.class);
    private final GammaApiClient gammaApiClient;

    public MarketService() {
        this.gammaApiClient = new GammaApiClient();
    }

    public CompletableFuture<Market> fetchMarketAsync(String slug) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                logger.info("Fetching market for slug: {}", slug);
                return gammaApiClient.resolveSlugToMarket(slug);
            } catch (IOException | ParseException e) {
                logger.error("Failed to fetch market for slug: {}", slug, e);
                String errorMsg = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
                throw new RuntimeException("Failed to fetch market: " + errorMsg, e);
            }
        });
    }

    public CompletableFuture<String[]> fetchAssetIdsAsync(String slug) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                logger.info("Fetching asset IDs for slug: {}", slug);
                return gammaApiClient.getAssetIds(slug);
            } catch (IOException | ParseException e) {
                logger.error("Failed to fetch asset IDs for slug: {}", slug, e);
                throw new RuntimeException("Failed to fetch asset IDs", e);
            }
        });
    }

    public Market fetchMarket(String slug) throws IOException, ParseException {
        return gammaApiClient.resolveSlugToMarket(slug);
    }

    public void close() {
        gammaApiClient.close();
    }
}
