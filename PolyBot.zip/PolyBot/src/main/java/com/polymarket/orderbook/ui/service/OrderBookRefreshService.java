package com.polymarket.orderbook.ui.service;

import javafx.concurrent.ScheduledService;
import javafx.concurrent.Task;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Supplier;

public class OrderBookRefreshService<T> extends ScheduledService<T> {

    private static final Logger logger = LoggerFactory.getLogger(OrderBookRefreshService.class);
    private final Supplier<T> dataSupplier;
    private final String serviceName;

    public OrderBookRefreshService(String serviceName, Supplier<T> dataSupplier) {
        this.serviceName = serviceName;
        this.dataSupplier = dataSupplier;
    }

    @Override
    protected Task<T> createTask() {
        return new Task<T>() {
            @Override
            protected T call() {
                try {
                    return dataSupplier.get();
                } catch (Exception e) {
                    logger.error("Error in {} refresh task", serviceName, e);
                    return null;
                }
            }
        };
    }

    @Override
    protected void succeeded() {
        super.succeeded();
        logger.trace("{} refresh succeeded", serviceName);
    }

    @Override
    protected void failed() {
        super.failed();
        Throwable exception = getException();
        if (exception != null) {
            logger.error("{} refresh failed", serviceName, exception);
        }
    }
}
