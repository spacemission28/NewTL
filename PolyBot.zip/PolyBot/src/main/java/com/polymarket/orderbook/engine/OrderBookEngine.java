package com.polymarket.orderbook.engine;

import com.polymarket.orderbook.config.AppConfig;
import com.polymarket.orderbook.model.OrderBookSnapshot;
import com.polymarket.orderbook.model.WebSocketMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class OrderBookEngine {

    private static final Logger logger = LoggerFactory.getLogger(OrderBookEngine.class);

    private final Map<String, OrderBookState> orderBooks;
    private final AppConfig config;

    public OrderBookEngine() {
        this.orderBooks = new ConcurrentHashMap<>();
        this.config = AppConfig.getInstance();
    }

    public void processMessage(WebSocketMessage message) {
        if (message == null) {
            logger.warn("Received null WebSocket message");
            return;
        }

        String eventType = message.getEventType();
        if (eventType == null) {
            logger.warn("Message has no event type");
            return;
        }

        switch (eventType.toLowerCase()) {
            case "book":
            case "snapshot":
                handleSnapshot(message);
                break;
            case "price_change":
            case "update":
                handlePriceChange(message);
                break;
            default:
                break;
        }
    }

    private void handleSnapshot(WebSocketMessage message) {
        logger.info("Processing order book snapshot for market: {}", message.getMarket());

        if (message.getBook() != null) {
            WebSocketMessage.OrderBookData book = message.getBook();

            // Note: For snapshots with full order book, we'd need to know which asset_id
            // this corresponds to. For now, log the snapshot data.
            logger.info("Received book snapshot - Bids: {}, Asks: {}",
                    book.getBids() != null ? book.getBids().size() : 0,
                    book.getAsks() != null ? book.getAsks().size() : 0);

            // TODO: Process full order book snapshot when asset_id mapping is available
        }
    }

    private void handlePriceChange(WebSocketMessage message) {
        if (message.getPriceChanges() == null || message.getPriceChanges().isEmpty()) {
            return;
        }

        for (WebSocketMessage.PriceChange change : message.getPriceChanges()) {
            String assetId = change.getAssetId();
            if (assetId == null) {
                logger.warn("Price change missing asset_id");
                continue;
            }

            OrderBookState state = orderBooks.computeIfAbsent(assetId, OrderBookState::new);

            if (change.getBestBid() != null && change.getBestAsk() != null) {
                state.updateFromPriceChange(
                    change.getBestBid(),
                    change.getBestAsk(),
                    change.getPrice(),
                    change.getSize(),
                    change.getSide()
                );
            }
        }
    }

    public OrderBookSnapshot getSnapshot(String assetId) {
        OrderBookState state = orderBooks.get(assetId);
        if (state == null) {
            return null;
        }

        int depth = config.getOrderBookDepth();

        OrderBookSnapshot snapshot = new OrderBookSnapshot();
        snapshot.setAssetId(assetId);
        snapshot.setBids(state.getTopBids(depth));
        snapshot.setAsks(state.getTopAsks(depth));
        snapshot.setMidPrice(state.getMidPrice());
        snapshot.setSpread(state.getSpread());
        snapshot.setSpreadPercentage(state.getSpreadPercentage());
        snapshot.setTimestamp(state.getLastUpdateTimestamp());

        return snapshot;
    }

    public OrderBookState getOrderBookState(String assetId) {
        return orderBooks.get(assetId);
    }

    public void removeOrderBook(String assetId) {
        OrderBookState removed = orderBooks.remove(assetId);
        if (removed != null) {
            logger.info("Removed order book for asset: {}", assetId);
        }
    }

    public void clearAll() {
        orderBooks.clear();
        logger.info("Cleared all order books");
    }
}
