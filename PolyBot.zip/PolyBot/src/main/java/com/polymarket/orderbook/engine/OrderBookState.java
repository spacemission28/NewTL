package com.polymarket.orderbook.engine;

import com.polymarket.orderbook.model.PriceLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentSkipListMap;
import java.util.stream.Collectors;

public class OrderBookState {

    private static final Logger logger = LoggerFactory.getLogger(OrderBookState.class);

    private final String assetId;
    private final ConcurrentSkipListMap<BigDecimal, BigDecimal> bids;
    private final ConcurrentSkipListMap<BigDecimal, BigDecimal> asks;
    private volatile long lastUpdateTimestamp;

    public OrderBookState(String assetId) {
        this.assetId = assetId;
        this.bids = new ConcurrentSkipListMap<>(Collections.reverseOrder());
        this.asks = new ConcurrentSkipListMap<>();
        this.lastUpdateTimestamp = System.currentTimeMillis();
    }

    public void updateBid(BigDecimal price, BigDecimal size) {
        if (size.compareTo(BigDecimal.ZERO) == 0) {
            bids.remove(price);
        } else {
            bids.put(price, size);
        }
        lastUpdateTimestamp = System.currentTimeMillis();
    }

    public void updateAsk(BigDecimal price, BigDecimal size) {
        if (size.compareTo(BigDecimal.ZERO) == 0) {
            asks.remove(price);
        } else {
            asks.put(price, size);
        }
        lastUpdateTimestamp = System.currentTimeMillis();
    }

    public void updateBids(List<List<String>> bidUpdates) {
        for (List<String> update : bidUpdates) {
            if (update.size() >= 2) {
                BigDecimal price = new BigDecimal(update.get(0));
                BigDecimal size = new BigDecimal(update.get(1));
                updateBid(price, size);
            }
        }
    }

    public void updateAsks(List<List<String>> askUpdates) {
        for (List<String> update : askUpdates) {
            if (update.size() >= 2) {
                BigDecimal price = new BigDecimal(update.get(0));
                BigDecimal size = new BigDecimal(update.get(1));
                updateAsk(price, size);
            }
        }
    }

    public List<PriceLevel> getTopBids(int depth) {
        return bids.entrySet().stream()
                .limit(depth)
                .map(e -> new PriceLevel(e.getKey(), e.getValue()))
                .collect(Collectors.toList());
    }

    public List<PriceLevel> getTopAsks(int depth) {
        return asks.entrySet().stream()
                .limit(depth)
                .map(e -> new PriceLevel(e.getKey(), e.getValue()))
                .collect(Collectors.toList());
    }

    public BigDecimal getBestBid() {
        return bids.isEmpty() ? BigDecimal.ZERO : bids.firstKey();
    }

    public BigDecimal getBestAsk() {
        return asks.isEmpty() ? BigDecimal.ZERO : asks.firstKey();
    }

    public BigDecimal getMidPrice() {
        BigDecimal bestBid = getBestBid();
        BigDecimal bestAsk = getBestAsk();

        if (bestBid.compareTo(BigDecimal.ZERO) == 0 || bestAsk.compareTo(BigDecimal.ZERO) == 0) {
            return BigDecimal.ZERO;
        }

        return bestBid.add(bestAsk).divide(new BigDecimal("2"), 4, RoundingMode.HALF_UP);
    }

    public BigDecimal getSpread() {
        BigDecimal bestBid = getBestBid();
        BigDecimal bestAsk = getBestAsk();

        if (bestBid.compareTo(BigDecimal.ZERO) == 0 || bestAsk.compareTo(BigDecimal.ZERO) == 0) {
            return BigDecimal.ZERO;
        }

        return bestAsk.subtract(bestBid);
    }

    public BigDecimal getSpreadPercentage() {
        BigDecimal spread = getSpread();
        BigDecimal midPrice = getMidPrice();

        if (midPrice.compareTo(BigDecimal.ZERO) == 0) {
            return BigDecimal.ZERO;
        }

        return spread.divide(midPrice, 4, RoundingMode.HALF_UP)
                .multiply(new BigDecimal("100"));
    }

    public void clear() {
        bids.clear();
        asks.clear();
        lastUpdateTimestamp = System.currentTimeMillis();
    }

    public int getBidDepth() {
        return bids.size();
    }

    public int getAskDepth() {
        return asks.size();
    }

    public String getAssetId() {
        return assetId;
    }

    public ConcurrentSkipListMap<BigDecimal, BigDecimal> getBids() {
        return bids;
    }

    public ConcurrentSkipListMap<BigDecimal, BigDecimal> getAsks() {
        return asks;
    }

    public long getLastUpdateTimestamp() {
        return lastUpdateTimestamp;
    }

    public void updateFromPriceChange(String bestBidStr, String bestAskStr,
                                      String priceStr, String sizeStr, String side) {
        try {
            BigDecimal bestBid = new BigDecimal(bestBidStr);
            BigDecimal bestAsk = new BigDecimal(bestAskStr);

            // Update or add the best bid/ask to the order book
            // For simplicity, we'll maintain at least the top of book
            // In a more complete implementation, we'd integrate this with full book updates

            // Clear and set the best bid if we have one
            if (bestBid.compareTo(BigDecimal.ZERO) > 0) {
                bids.clear();
                // Use a placeholder size for best bid/ask since price_change doesn't give us the size at that level
                bids.put(bestBid, BigDecimal.ONE);
            }

            // Clear and set the best ask if we have one
            if (bestAsk.compareTo(BigDecimal.ZERO) > 0) {
                asks.clear();
                // Use a placeholder size for best bid/ask
                asks.put(bestAsk, BigDecimal.ONE);
            }

            lastUpdateTimestamp = System.currentTimeMillis();

            logger.trace("Updated order book from price change - bid: {}, ask: {}",
                        bestBid, bestAsk);

        } catch (NumberFormatException e) {
            logger.error("Failed to parse price change values: bid={}, ask={}",
                        bestBidStr, bestAskStr, e);
        }
    }
}
