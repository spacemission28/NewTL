package com.polymarket.orderbook.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.Instant;
import java.util.Comparator;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Series {

    @JsonProperty("id")
    private String id;

    @JsonProperty("slug")
    private String slug;

    @JsonProperty("ticker")
    private String ticker;

    @JsonProperty("title")
    private String title;

    @JsonProperty("seriesType")
    private String seriesType;

    @JsonProperty("recurrence")
    private String recurrence;

    @JsonProperty("active")
    private Boolean active;

    @JsonProperty("closed")
    private Boolean closed;

    @JsonProperty("events")
    private List<Event> events;

    public Series() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public String getTicker() {
        return ticker;
    }

    public void setTicker(String ticker) {
        this.ticker = ticker;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSeriesType() {
        return seriesType;
    }

    public void setSeriesType(String seriesType) {
        this.seriesType = seriesType;
    }

    public String getRecurrence() {
        return recurrence;
    }

    public void setRecurrence(String recurrence) {
        this.recurrence = recurrence;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public Boolean getClosed() {
        return closed;
    }

    public void setClosed(Boolean closed) {
        this.closed = closed;
    }

    public List<Event> getEvents() {
        return events;
    }

    public void setEvents(List<Event> events) {
        this.events = events;
    }

    public Event getCurrentEvent() {
        if (events == null || events.isEmpty()) {
            return null;
        }

        Instant now = Instant.now();

        return events.stream()
                .filter(e -> Boolean.TRUE.equals(e.getActive()) && Boolean.FALSE.equals(e.getClosed()))
                .filter(e -> {
                    try {
                        if (e.getEndDate() != null) {
                            Instant endDate = Instant.parse(e.getEndDate());
                            return endDate.isAfter(now);
                        }
                        return true;
                    } catch (Exception ex) {
                        return true;
                    }
                })
                .min(Comparator.comparing(e -> {
                    try {
                        return e.getEndDate() != null ? Instant.parse(e.getEndDate()) : Instant.MAX;
                    } catch (Exception ex) {
                        return Instant.MAX;
                    }
                }))
                .orElse(null);
    }
}
