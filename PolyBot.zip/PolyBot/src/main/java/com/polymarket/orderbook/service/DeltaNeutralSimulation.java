package com.polymarket.orderbook.service;

import com.polymarket.orderbook.engine.OrderBookEngine;
import com.polymarket.orderbook.model.OrderBookSnapshot;
import com.polymarket.orderbook.model.SimulatedTrade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class DeltaNeutralSimulation {

    private static final Logger logger = LoggerFactory.getLogger(DeltaNeutralSimulation.class);
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final OrderBookEngine orderBookEngine;
    private final String logFilePath;

    private boolean simulationEnabled;
    private boolean shouldEnterInitialTrade;
    private int count99c;
    private int count98c;
    private int count97cOrBelow;
    private BigDecimal cumulativeProfitLoss;
    private List<SimulatedTrade> openTrades;
    private BigDecimal profitTargetCents;
    private LocalDateTime pollEndTime;

    public DeltaNeutralSimulation(OrderBookEngine orderBookEngine, String marketSlug) {
        this.orderBookEngine = orderBookEngine;
        this.logFilePath = "delta_neutral_trades_" + marketSlug.replaceAll("[^a-zA-Z0-9-]", "_") + ".txt";
        this.simulationEnabled = false;
        this.shouldEnterInitialTrade = false;
        this.count99c = 0;
        this.count98c = 0;
        this.count97cOrBelow = 0;
        this.cumulativeProfitLoss = BigDecimal.ZERO;
        this.openTrades = new ArrayList<>();
        this.profitTargetCents = BigDecimal.ONE;
        this.pollEndTime = null;
        initializeLogFile();
    }

    private void initializeLogFile() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(logFilePath, false))) {
            writer.println("=== Delta Neutral Strategy Simulation Log ===");
            writer.println("Format: Open Time | Open YES Qty | Open YES Price | Open NO Qty | Open NO Price | Total Cost | Close Time | Closed Side | P&L | Details");
            writer.println("=====================================================================================================");
        } catch (IOException e) {
            logger.error("Failed to initialize log file: {}", logFilePath, e);
        }
    }

    public void setProfitTargetCents(BigDecimal profitTargetCents) {
        this.profitTargetCents = profitTargetCents;
        logger.info("Profit target set to {} cents", profitTargetCents);
    }

    public void setPollDurationMinutes(int minutes) {
        if (minutes > 0) {
            this.pollEndTime = LocalDateTime.now().plusMinutes(minutes);
            logger.info("Poll end time set to {} ({} minutes from now)", pollEndTime, minutes);
        }
    }

    public void checkAndSimulate(String yesAssetId, String noAssetId, BigDecimal totalAmount) {
        if (!simulationEnabled) {
            return;
        }

        OrderBookSnapshot yesSnapshot = orderBookEngine.getSnapshot(yesAssetId);
        OrderBookSnapshot noSnapshot = orderBookEngine.getSnapshot(noAssetId);

        if (yesSnapshot == null || noSnapshot == null) {
            return;
        }

        BigDecimal yesMidPrice = yesSnapshot.getMidPrice();
        BigDecimal noMidPrice = noSnapshot.getMidPrice();

        if (yesMidPrice.compareTo(BigDecimal.ZERO) == 0 || noMidPrice.compareTo(BigDecimal.ZERO) == 0) {
            return;
        }

        BigDecimal totalCost = yesMidPrice.add(noMidPrice);

        if (shouldEnterInitialTrade && openTrades.isEmpty()) {
            logger.info("Entering initial delta neutral split trade at start of simulation");
            int cents = totalCost.multiply(new BigDecimal("100")).intValue();

            if (cents == 99) {
                count99c++;
            } else if (cents == 98) {
                count98c++;
            } else if (cents <= 97) {
                count97cOrBelow++;
            }

            simulateTrade(yesMidPrice, noMidPrice, totalAmount, totalCost);
            shouldEnterInitialTrade = false;
        } else if (totalCost.compareTo(new BigDecimal("1.00")) < 0) {
            int cents = totalCost.multiply(new BigDecimal("100")).intValue();

            if (cents == 99) {
                count99c++;
                logger.info("Delta Neutral 99c opportunity detected. Total: {}", count99c);
            } else if (cents == 98) {
                count98c++;
                logger.info("Delta Neutral 98c opportunity detected. Total: {}", count98c);
            } else if (cents <= 97) {
                count97cOrBelow++;
                logger.info("Delta Neutral 97c or below opportunity detected. Total: {}", count97cOrBelow);
            }

            simulateTrade(yesMidPrice, noMidPrice, totalAmount, totalCost);
        }

        checkCloseTrades(yesAssetId, noAssetId);
    }

    private void simulateTrade(BigDecimal yesPrice, BigDecimal noPrice, BigDecimal totalAmount, BigDecimal totalCost) {
        BigDecimal halfAmount = totalAmount.divide(new BigDecimal("2"), 4, RoundingMode.HALF_UP);
        BigDecimal yesQuantity = halfAmount.divide(yesPrice, 4, RoundingMode.HALF_UP);
        BigDecimal noQuantity = halfAmount.divide(noPrice, 4, RoundingMode.HALF_UP);

        SimulatedTrade trade = new SimulatedTrade();
        trade.setStrategy("Delta Neutral");
        trade.setOpenPriceYes(yesPrice);
        trade.setOpenPriceNo(noPrice);
        trade.setQuantityYes(yesQuantity);
        trade.setQuantityNo(noQuantity);
        trade.setAmount(totalAmount);
        trade.setDetails("Split: " + yesQuantity.setScale(2, RoundingMode.HALF_UP) + " YES @ $" +
                        yesPrice.setScale(4, RoundingMode.HALF_UP) + ", " +
                        noQuantity.setScale(2, RoundingMode.HALF_UP) + " NO @ $" +
                        noPrice.setScale(4, RoundingMode.HALF_UP));

        openTrades.add(trade);
        logger.info("Simulated Delta Neutral split trade opened: {} YES @ {}, {} NO @ {}, Total Cost={}",
            yesQuantity.setScale(2, RoundingMode.HALF_UP), yesPrice,
            noQuantity.setScale(2, RoundingMode.HALF_UP), noPrice, totalCost);
    }

    private void checkCloseTrades(String yesAssetId, String noAssetId) {
        OrderBookSnapshot yesSnapshot = orderBookEngine.getSnapshot(yesAssetId);
        OrderBookSnapshot noSnapshot = orderBookEngine.getSnapshot(noAssetId);

        if (yesSnapshot == null || noSnapshot == null) {
            return;
        }

        BigDecimal yesMidPrice = yesSnapshot.getMidPrice();
        BigDecimal noMidPrice = noSnapshot.getMidPrice();
        LocalDateTime now = LocalDateTime.now();

        List<SimulatedTrade> tradesToClose = new ArrayList<>();

        for (SimulatedTrade trade : openTrades) {
            if (trade.getClosedSide() != null) {
                continue;
            }

            BigDecimal profitTargetDollars = profitTargetCents.divide(new BigDecimal("100"), 4, RoundingMode.HALF_UP);

            BigDecimal yesCurrentValue = trade.getQuantityYes().multiply(yesMidPrice);
            BigDecimal noCurrentValue = trade.getQuantityNo().multiply(noMidPrice);
            BigDecimal yesCost = trade.getQuantityYes().multiply(trade.getOpenPriceYes());
            BigDecimal noCost = trade.getQuantityNo().multiply(trade.getOpenPriceNo());

            BigDecimal yesProfitDollars = yesCurrentValue.subtract(yesCost);
            BigDecimal noProfitDollars = noCurrentValue.subtract(noCost);

            boolean hasTimeRemaining = (pollEndTime == null) || now.isBefore(pollEndTime.minusMinutes(3));

            if (hasTimeRemaining) {
                if (yesProfitDollars.compareTo(profitTargetDollars) >= 0) {
                    trade.setClosedSide("YES");
                    trade.setClosePriceYes(yesMidPrice);
                    BigDecimal pnl = yesProfitDollars;
                    cumulativeProfitLoss = cumulativeProfitLoss.add(pnl);
                    logger.info("YES side closed with profit ${}, NO side remains open",
                        pnl.setScale(4, RoundingMode.HALF_UP));
                } else if (noProfitDollars.compareTo(profitTargetDollars) >= 0) {
                    trade.setClosedSide("NO");
                    trade.setClosePriceNo(noMidPrice);
                    BigDecimal pnl = noProfitDollars;
                    cumulativeProfitLoss = cumulativeProfitLoss.add(pnl);
                    logger.info("NO side closed with profit ${}, YES side remains open",
                        pnl.setScale(4, RoundingMode.HALF_UP));
                }
            }

            if (pollEndTime != null && now.isAfter(pollEndTime)) {
                trade.setCloseTime(now);
                trade.setClosePriceYes(yesMidPrice);
                trade.setClosePriceNo(noMidPrice);

                BigDecimal pnl = BigDecimal.ZERO;

                if ("YES".equals(trade.getClosedSide())) {
                    BigDecimal noPL = noCurrentValue.subtract(noCost);
                    pnl = yesProfitDollars.add(noPL);
                } else if ("NO".equals(trade.getClosedSide())) {
                    BigDecimal yesPL = yesCurrentValue.subtract(yesCost);
                    pnl = noProfitDollars.add(yesPL);
                } else {
                    pnl = BigDecimal.ZERO;
                }

                trade.setProfitLoss(pnl);
                cumulativeProfitLoss = cumulativeProfitLoss.add(pnl);
                tradesToClose.add(trade);

                logTradeToFile(trade);
                logger.info("Poll ended - trade closed with P&L=${}, Cumulative=${}",
                    pnl.setScale(4, RoundingMode.HALF_UP),
                    cumulativeProfitLoss.setScale(2, RoundingMode.HALF_UP));
            }
        }

        openTrades.removeAll(tradesToClose);
    }

    private void logTradeToFile(SimulatedTrade trade) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(logFilePath, true))) {
            String openTime = trade.getOpenTime().format(TIME_FORMAT);
            String closeTime = trade.getCloseTime() != null ? trade.getCloseTime().format(TIME_FORMAT) : "OPEN";
            String yesQty = trade.getQuantityYes() != null ? trade.getQuantityYes().setScale(2, RoundingMode.HALF_UP).toString() : "0";
            String openYes = trade.getOpenPriceYes().setScale(4, RoundingMode.HALF_UP).toString();
            String noQty = trade.getQuantityNo() != null ? trade.getQuantityNo().setScale(2, RoundingMode.HALF_UP).toString() : "0";
            String openNo = trade.getOpenPriceNo().setScale(4, RoundingMode.HALF_UP).toString();
            BigDecimal totalCost = trade.getQuantityYes().multiply(trade.getOpenPriceYes())
                .add(trade.getQuantityNo().multiply(trade.getOpenPriceNo()));
            String closedSide = trade.getClosedSide() != null ? trade.getClosedSide() : "BOTH";
            String pnl = trade.getProfitLoss() != null ? trade.getProfitLoss().setScale(4, RoundingMode.HALF_UP).toString() : "N/A";

            writer.printf("%s | %s | %s | %s | %s | $%s | %s | %s | $%s | %s%n",
                openTime, yesQty, openYes, noQty, openNo, totalCost.setScale(4, RoundingMode.HALF_UP),
                closeTime, closedSide, pnl, trade.getDetails());
        } catch (IOException e) {
            logger.error("Failed to write trade to log file", e);
        }
    }

    public void reset() {
        count99c = 0;
        count98c = 0;
        count97cOrBelow = 0;
        cumulativeProfitLoss = BigDecimal.ZERO;
        openTrades.clear();
        shouldEnterInitialTrade = simulationEnabled;
        initializeLogFile();
        logger.info("Delta Neutral simulation reset");
    }

    public void setSimulationEnabled(boolean enabled) {
        this.simulationEnabled = enabled;
        if (enabled) {
            this.shouldEnterInitialTrade = true;
            logger.info("Delta Neutral simulation ENABLED - will enter initial trade on next check");
        } else {
            this.shouldEnterInitialTrade = false;
            logger.info("Delta Neutral simulation DISABLED");
        }
    }

    public boolean isSimulationEnabled() {
        return simulationEnabled;
    }

    public int getCount99c() {
        return count99c;
    }

    public int getCount98c() {
        return count98c;
    }

    public int getCount97cOrBelow() {
        return count97cOrBelow;
    }

    public BigDecimal getCumulativeProfitLoss() {
        return cumulativeProfitLoss;
    }

    public int getOpenTradesCount() {
        return openTrades.size();
    }

    public void resetStats() {
        reset();
    }

    public BigDecimal calculateUnrealizedPL(String yesAssetId, String noAssetId) {
        OrderBookSnapshot yesSnapshot = orderBookEngine.getSnapshot(yesAssetId);
        OrderBookSnapshot noSnapshot = orderBookEngine.getSnapshot(noAssetId);

        if (yesSnapshot == null || noSnapshot == null) {
            return BigDecimal.ZERO;
        }

        BigDecimal yesMidPrice = yesSnapshot.getMidPrice();
        BigDecimal noMidPrice = noSnapshot.getMidPrice();
        BigDecimal totalUnrealized = BigDecimal.ZERO;

        for (SimulatedTrade trade : openTrades) {
            BigDecimal yesCurrentValue = trade.getQuantityYes().multiply(yesMidPrice);
            BigDecimal noCurrentValue = trade.getQuantityNo().multiply(noMidPrice);
            BigDecimal yesCost = trade.getQuantityYes().multiply(trade.getOpenPriceYes());
            BigDecimal noCost = trade.getQuantityNo().multiply(trade.getOpenPriceNo());

            BigDecimal unrealizedPL = BigDecimal.ZERO;

            if ("YES".equals(trade.getClosedSide())) {
                unrealizedPL = noCurrentValue.subtract(noCost);
            } else if ("NO".equals(trade.getClosedSide())) {
                unrealizedPL = yesCurrentValue.subtract(yesCost);
            } else {
                unrealizedPL = (yesCurrentValue.add(noCurrentValue)).subtract(yesCost.add(noCost));
            }

            totalUnrealized = totalUnrealized.add(unrealizedPL);
        }

        return totalUnrealized;
    }

    public BigDecimal getTotalYesQuantity() {
        BigDecimal total = BigDecimal.ZERO;
        for (SimulatedTrade trade : openTrades) {
            if (!"YES".equals(trade.getClosedSide()) && trade.getQuantityYes() != null) {
                total = total.add(trade.getQuantityYes());
            }
        }
        return total;
    }

    public BigDecimal getTotalNoQuantity() {
        BigDecimal total = BigDecimal.ZERO;
        for (SimulatedTrade trade : openTrades) {
            if (!"NO".equals(trade.getClosedSide()) && trade.getQuantityNo() != null) {
                total = total.add(trade.getQuantityNo());
            }
        }
        return total;
    }
}
