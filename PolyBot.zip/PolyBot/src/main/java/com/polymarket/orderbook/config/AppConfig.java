package com.polymarket.orderbook.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class AppConfig {

    private static AppConfig instance;
    private final Properties properties;

    private AppConfig() {
        properties = new Properties();
        try (InputStream input = getClass().getClassLoader().getResourceAsStream("application.properties")) {
            if (input == null) {
                throw new IOException("Unable to find application.properties");
            }
            properties.load(input);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load application configuration", e);
        }
    }

    public static synchronized AppConfig getInstance() {
        if (instance == null) {
            instance = new AppConfig();
        }
        return instance;
    }

    public String getWebSocketUrl() {
        return properties.getProperty("polymarket.ws.url");
    }

    public String getGammaApiUrl() {
        return properties.getProperty("polymarket.gamma.url");
    }

    public String getClobApiUrl() {
        return properties.getProperty("polymarket.clob.url");
    }

    public int getUiRefreshInterval() {
        return Integer.parseInt(properties.getProperty("ui.refresh.interval", "50"));
    }

    public int getOrderBookDepth() {
        return Integer.parseInt(properties.getProperty("ui.orderbook.depth", "10"));
    }

    public double getDefaultTradingAmount() {
        return Double.parseDouble(properties.getProperty("trading.default.amount", "20.0"));
    }

    public boolean isSplitTradingEnabled() {
        return Boolean.parseBoolean(properties.getProperty("trading.split.enabled", "true"));
    }

    public long getWebSocketReconnectDelay() {
        return Long.parseLong(properties.getProperty("polymarket.ws.reconnect.delay", "5000"));
    }

    public long getWebSocketHeartbeatInterval() {
        return Long.parseLong(properties.getProperty("polymarket.ws.heartbeat.interval", "30000"));
    }

    public String getProperty(String key) {
        return properties.getProperty(key);
    }

    public String getProperty(String key, String defaultValue) {
        return properties.getProperty(key, defaultValue);
    }

    public Properties getProperties() {
        return properties;
    }
}
