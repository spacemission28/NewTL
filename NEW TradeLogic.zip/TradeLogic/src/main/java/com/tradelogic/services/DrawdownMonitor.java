package com.tradelogic.services;

import com.tradelogic.Logger;
import com.tradelogic.models.RobotConfig;
import com.tradelogic.models.RobotState;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class DrawdownMonitor {
    private static DrawdownMonitor instance;
    private final Map<Long, Double> highWaterMarks = new ConcurrentHashMap<>();
    private final Map<Long, Double> currentDrawdowns = new ConcurrentHashMap<>();
    private double startingEquity = 10000.0;
    private double currentEquity = 10000.0;
    private double startOfDayEquity = 10000.0;
    private double currentAccountEquity = 10000.0;
    private long lastEquityUpdateTime = 0;

    private DrawdownMonitor() {}

    public static synchronized DrawdownMonitor getInstance() {
        if (instance == null) {
            instance = new DrawdownMonitor();
        }
        return instance;
    }

    public Map<String, Object> getDrawdownStats() {
        Map<String, Object> stats = new ConcurrentHashMap<>();
        stats.put("starting_equity", startingEquity);
        stats.put("current_equity", currentEquity);
        stats.put("start_of_day_equity", startOfDayEquity);
        stats.put("current_account_equity", currentAccountEquity);

        double drawdownPercent = 0.0;
        if (startingEquity > 0) {
            drawdownPercent = ((startingEquity - currentEquity) / startingEquity) * 100.0;
        }
        stats.put("drawdown_percent", drawdownPercent);

        double dailyPLPercent = 0.0;
        if (startOfDayEquity > 0) {
            dailyPLPercent = ((currentAccountEquity - startOfDayEquity) / startOfDayEquity) * 100.0;
        }
        stats.put("daily_dd_percent", dailyPLPercent);

        return stats;
    }

    public void setStartingEquity(double equity) {
        this.startingEquity = equity;
    }

    public void setCurrentEquity(double equity) {
        this.currentEquity = equity;
    }

    public void setStartOfDayEquity(double equity) {
        this.startOfDayEquity = equity;
        Logger.info(String.format("Start-of-day equity set to: %.2f", equity));
    }

    public void updateAccountEquity(double equity) {
        this.currentAccountEquity = equity;
        this.lastEquityUpdateTime = System.currentTimeMillis();
    }

    public double getStartOfDayEquity() {
        return startOfDayEquity;
    }

    public double getCurrentAccountEquity() {
        return currentAccountEquity;
    }

    public double getDailyDrawdownPercent() {
        if (startOfDayEquity > 0) {
            return ((currentAccountEquity - startOfDayEquity) / startOfDayEquity) * 100.0;
        }
        return 0.0;
    }

    public void updateState(RobotState state, RobotConfig config) {
        long magicNumber = state.getRobotConfigId().hashCode();
        double currentEquity = state.getCurrentProfitLoss();

        double highWaterMark = highWaterMarks.getOrDefault(magicNumber, currentEquity);
        if (currentEquity > highWaterMark) {
            highWaterMark = currentEquity;
            highWaterMarks.put(magicNumber, highWaterMark);
        }

        double drawdown = 0.0;
        if (highWaterMark > 0) {
            drawdown = ((highWaterMark - currentEquity) / highWaterMark) * 100.0;
        }
        currentDrawdowns.put(magicNumber, drawdown);

        if (drawdown > 10.0) {
            Logger.warning(String.format("Robot %s drawdown: %.2f%%", config.getSymbol(), drawdown));
        }
    }

    public double getCurrentDrawdown(long magicNumber) {
        return currentDrawdowns.getOrDefault(magicNumber, 0.0);
    }

    public void reset(long magicNumber) {
        highWaterMarks.remove(magicNumber);
        currentDrawdowns.remove(magicNumber);
    }
}
