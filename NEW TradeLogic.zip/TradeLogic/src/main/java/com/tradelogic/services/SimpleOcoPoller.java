package com.tradelogic.services;

import com.tradelogic.Logger;
import com.tradelogic.models.TradeCommand;
import com.tradelogic.models.TradeHistoryEntry;

import java.util.*;
import java.util.concurrent.*;

/**
 * BULLETPROOF OCO SOLUTION
 *
 * Simple polling-based OCO that:
 * 1. Tracks which magic numbers have pending OCO orders
 * 2. Polls trade history every 100ms
 * 3. When ANY order fills, IMMEDIATELY deletes opposite side
 *
 * NO COMPLEX LOGIC. NO FEEDBACK WAITING. JUST POLL AND ACT.
 */
public class SimpleOcoPoller {
    private static SimpleOcoPoller instance;

    // Map: magicNumber -> OcoGroup
    private final Map<String, OcoGroup> activeOcoGroups = new ConcurrentHashMap<>();

    // Polling thread
    private ScheduledExecutorService poller;
    private TradeHistoryCache historyCache;
    private TradeCommandQueue commandQueue;
    private PendingCommandsManager pendingCommandsManager;

    private volatile boolean running = false;

    private static class OcoGroup {
        final String magicNumber;
        final String symbol;
        final long registrationTime;
        boolean deleteSent = false;

        OcoGroup(String magicNumber, String symbol) {
            this.magicNumber = magicNumber;
            this.symbol = symbol;
            this.registrationTime = System.currentTimeMillis();
        }
    }

    private SimpleOcoPoller() {}

    public static synchronized SimpleOcoPoller getInstance() {
        if (instance == null) {
            instance = new SimpleOcoPoller();
        }
        return instance;
    }

    public void initialize(TradeHistoryCache historyCache, TradeCommandQueue commandQueue,
                          PendingCommandsManager pendingCommandsManager) {
        this.historyCache = historyCache;
        this.commandQueue = commandQueue;
        this.pendingCommandsManager = pendingCommandsManager;
    }

    /**
     * Register a magic number for OCO monitoring
     * Call this IMMEDIATELY after placing 14 orders
     */
    public void registerOcoGroup(String magicNumber, String symbol) {
        if (magicNumber == null || symbol == null) {
            Logger.error("OCO POLLER: Cannot register null magicNumber or symbol");
            return;
        }

        OcoGroup group = new OcoGroup(magicNumber, symbol);
        activeOcoGroups.put(magicNumber, group);

        Logger.info("★★★ OCO POLLER: Registered magic " + magicNumber + " for " + symbol +
                   " (Total groups: " + activeOcoGroups.size() + ")");
    }

    /**
     * Start the OCO poller
     */
    public synchronized void start() {
        if (running) {
            Logger.warning("OCO POLLER: Already running");
            return;
        }

        running = true;
        poller = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "OCO-Poller");
            t.setDaemon(true);
            return t;
        });

        // Poll every 100ms
        poller.scheduleAtFixedRate(this::pollAndCheck, 0, 100, TimeUnit.MILLISECONDS);

        Logger.info("★★★ OCO POLLER: STARTED - polling every 100ms");
    }

    /**
     * Stop the OCO poller
     */
    public synchronized void stop() {
        running = false;
        if (poller != null) {
            poller.shutdown();
            try {
                if (!poller.awaitTermination(1, TimeUnit.SECONDS)) {
                    poller.shutdownNow();
                }
            } catch (InterruptedException e) {
                poller.shutdownNow();
            }
            poller = null;
        }
        activeOcoGroups.clear();
        Logger.info("OCO POLLER: STOPPED");
    }

    /**
     * The core polling logic - called every 100ms
     */
    private void pollAndCheck() {
        if (activeOcoGroups.isEmpty() || historyCache == null) {
            return;
        }

        // Get recent trades (last 2 seconds)
        List<TradeHistoryEntry> recentTrades = historyCache.getTradesInLast(2);

        if (recentTrades.isEmpty()) {
            return;
        }

        // Check each active OCO group
        for (OcoGroup group : new ArrayList<>(activeOcoGroups.values())) {
            if (group.deleteSent) {
                continue; // Already processed
            }

            // Look for ANY filled order with this magic number
            for (TradeHistoryEntry trade : recentTrades) {
                if (trade.getMagic() == Long.parseLong(group.magicNumber) &&
                    trade.getSymbol().equals(group.symbol)) {

                    String orderType = trade.getOrderType();
                    String state = trade.getState();

                    // Check if this is a FILLED order (not just pending)
                    if (orderType != null && state != null &&
                        (orderType.contains("BUY") || orderType.contains("SELL")) &&
                        (state.equals("FILLED") || state.equals("ORDER_STARTED"))) {

                        // FILL DETECTED! Trigger OCO deletion
                        triggerOcoDeletion(group, orderType);
                        break; // Stop checking trades for this group
                    }
                }
            }
        }
    }

    /**
     * Trigger OCO deletion - delete opposite side orders
     */
    private void triggerOcoDeletion(OcoGroup group, String filledOrderType) {
        if (group.deleteSent) {
            return; // Already sent
        }

        group.deleteSent = true;

        // Determine opposite type
        String filledSide = filledOrderType.contains("BUY") ? "BUY" : "SELL";
        String oppositeType = filledSide.equals("BUY") ? "SELL_STOP" : "BUY_STOP";

        Logger.info("★★★★★ OCO POLLER: FILL DETECTED for magic " + group.magicNumber + " - " + filledSide + " order filled");
        Logger.info("★★★★★ OCO POLLER: DELETING ALL " + oppositeType + " orders NOW!");

        // Create delete command
        Map<String, Object> params = new HashMap<>();
        params.put("magic_number", group.magicNumber);
        params.put("order_type", oppositeType);

        TradeCommand deleteCommand = new TradeCommand(
            null,
            group.magicNumber,
            "DELETE_OPPOSITE_SIDE",
            params
        );

        // Queue with HIGHEST priority
        if (commandQueue != null) {
            commandQueue.addFirst(deleteCommand);
            if (pendingCommandsManager != null) {
                pendingCommandsManager.addPending(deleteCommand);
            }
            Logger.info("★★★ OCO POLLER: DELETE command queued with HIGH PRIORITY");

            // Mark as processed but keep in map so we don't reprocess
            // Group will only be removed manually or on application shutdown
            // NO TIME LIMITS - can monitor for days/weeks if needed
        }
    }

    /**
     * Manually remove a magic number from monitoring
     */
    public void removeGroup(String magicNumber) {
        OcoGroup removed = activeOcoGroups.remove(magicNumber);
        if (removed != null) {
            Logger.info("OCO POLLER: Manually removed magic " + magicNumber + " from monitoring");
        }
    }

    public boolean isRunning() {
        return running;
    }

    public int getActiveGroupCount() {
        return activeOcoGroups.size();
    }

    public Set<String> getActiveMagicNumbers() {
        return new HashSet<>(activeOcoGroups.keySet());
    }
}
