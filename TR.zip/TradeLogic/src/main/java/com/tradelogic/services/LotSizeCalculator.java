package com.tradelogic.services;

import com.tradelogic.Logger;
import com.tradelogic.models.RobotConfig;
import java.util.HashMap;
import java.util.Map;

/**
 * Calculates lot sizes for trade orders based on risk parameters, candle height,
 * stop loss distance, and optional commission costs.
 *
 * Mirrors the EA's CalculateLotSize function with support for:
 * - RPT as percentage of balance or fixed amount
 * - Commission costs (FX_per_Lot or ETF_Stock)
 * - Multiple TP levels with volume distribution
 * - Currency conversion for cross-rate instruments
 */
public class LotSizeCalculator {

    private static final double DEFAULT_CONTRACT_SIZE = 100000.0;
    private static final double MIN_LOT = 0.01;
    private static final double MAX_LOT = 100.0;
    private static final double LOT_STEP = 0.01;

    private final Map<String, Double> contractSizeCache;
    private final Map<String, Double> lotStepCache;

    public LotSizeCalculator() {
        this.contractSizeCache = new HashMap<>();
        this.lotStepCache = new HashMap<>();
        initializeContractSizes();
    }

    private void initializeContractSizes() {
        // Metals
        contractSizeCache.put("XAUUSD", 100.0);
        contractSizeCache.put("XAGUSD", 5000.0);

        // Crypto
        contractSizeCache.put("BTCUSD", 1.0);
        contractSizeCache.put("ETHUSD", 1.0);

        // Forex - all use 100,000
        contractSizeCache.put("EURUSD", 100000.0);
        contractSizeCache.put("GBPUSD", 100000.0);
        contractSizeCache.put("AUDUSD", 100000.0);
        contractSizeCache.put("NZDUSD", 100000.0);
        contractSizeCache.put("USDCAD", 100000.0);
        contractSizeCache.put("USDCHF", 100000.0);
        contractSizeCache.put("USDJPY", 100000.0);
        contractSizeCache.put("EURJPY", 100000.0);
        contractSizeCache.put("GBPJPY", 100000.0);
        contractSizeCache.put("AUDJPY", 100000.0);
        contractSizeCache.put("NZDJPY", 100000.0);
        contractSizeCache.put("CADJPY", 100000.0);
        contractSizeCache.put("CHFJPY", 100000.0);

        // Indices - use 1.0 (1 lot = 1 contract)
        contractSizeCache.put("FRA40", 1.0);  // CAC 40
        contractSizeCache.put("GER40", 1.0);  // DAX
        contractSizeCache.put("UK100", 1.0);  // FTSE 100
        contractSizeCache.put("US30", 1.0);   // Dow Jones
        contractSizeCache.put("NAS100", 1.0); // NASDAQ
        contractSizeCache.put("SPX500", 1.0); // S&P 500
        contractSizeCache.put("JPN225", 1.0); // Nikkei
        contractSizeCache.put("AUS200", 1.0); // ASX 200

        // Lot step overrides (default is 0.01 for FX/metals)
        // Indices typically use 0.1 lot step
        lotStepCache.put("FRA40", 0.1);
        lotStepCache.put("GER40", 0.1);
        lotStepCache.put("UK100", 0.1);
        lotStepCache.put("US30", 0.1);
        lotStepCache.put("NAS100", 0.1);
        lotStepCache.put("SPX500", 0.1);
        lotStepCache.put("JPN225", 0.1);
        lotStepCache.put("AUS200", 0.1);
    }

    /**
     * Calculates lot sizes for all 7 TP levels on one side (BUY or SELL)
     *
     * @param robot Robot configuration with TP levels and volumes
     * @param accountBalance Current account balance
     * @param stopLossDistance Distance from entry to stop loss in price units
     * @param symbol Trading symbol (e.g., "XAUUSD")
     * @param accountCurrency Account currency (e.g., "USD")
     * @param conversionRates Map of conversion rates (e.g., "EURUSD" -> 1.0850)
     * @return Array of 7 lot sizes (one per TP level), 0.0 if volume is 0
     */
    public double[] calculateLotSizes(
            RobotConfig robot,
            double accountBalance,
            double stopLossDistance,
            String symbol,
            String accountCurrency,
            Map<String, Double> conversionRates) {

        double[] lotSizes = new double[7];

        if (accountBalance <= 0) {
            Logger.error("        [CALC ERROR] Account balance is ZERO! Cannot calculate lot sizes. Wait for MT5 to send account info.");
            Logger.error("        [CALC ERROR] Ensure MT5 EA is running and sending /account-info every 5 seconds.");
            return lotSizes;
        }

        double totalRiskAmount = calculateTotalRiskAmount(robot, accountBalance);

        Logger.info("        [CALC] Account Balance: $" + String.format("%.2f", accountBalance));
        Logger.info("        [CALC] Total Risk Amount: $" + String.format("%.2f", totalRiskAmount));

        if (totalRiskAmount <= 0) {
            Logger.error("        [CALC ERROR] Total risk amount is ZERO! Check RPT % or RPT Fixed Amount in robot config.");
            return lotSizes;
        }

        double contractSize = getContractSize(symbol);
        Logger.info("        [CALC] Contract Size for " + symbol + ": " + contractSize);

        double riskPerLotInQuoteCurrency = stopLossDistance * contractSize;
        Logger.info("        [CALC] Risk per Lot (Quote Currency): " + riskPerLotInQuoteCurrency +
                   " (SL Distance: " + stopLossDistance + " * Contract: " + contractSize + ")");

        double riskPerLotInAccountCurrency = convertToAccountCurrency(
            riskPerLotInQuoteCurrency,
            symbol,
            accountCurrency,
            conversionRates
        );
        Logger.info("        [CALC] Risk per Lot (Account Currency " + accountCurrency + "): " + riskPerLotInAccountCurrency);

        if (robot.isCommissionsEnabled()) {
            double commissionCost = calculateCommissionCost(
                robot.getCommissionType(),
                robot.getCommissionValue(),
                1.0,
                symbol,
                accountCurrency,
                conversionRates
            );
            riskPerLotInAccountCurrency += commissionCost;
        }

        if (riskPerLotInAccountCurrency <= 0) {
            Logger.error("Risk per lot is zero or negative for " + symbol);
            return lotSizes;
        }

        int[] tpVolumes = {
            robot.getTp1Volume(),
            robot.getTp2Volume(),
            robot.getTp3Volume(),
            robot.getTp4Volume(),
            robot.getTp5Volume(),
            robot.getTp6Volume(),
            robot.getTp7Volume()
        };

        for (int i = 0; i < 7; i++) {
            if (tpVolumes[i] > 0) {
                double volumePercent = tpVolumes[i] / 100.0;
                double riskForThisOrder = totalRiskAmount * volumePercent;
                double rawLotSize = riskForThisOrder / riskPerLotInAccountCurrency;
                lotSizes[i] = normalizeLotSize(rawLotSize, symbol);
                Logger.info("        [CALC] TP" + (i+1) + " Volume: " + tpVolumes[i] + "% | Risk: $" +
                           String.format("%.2f", riskForThisOrder) + " | Raw Lot: " +
                           String.format("%.4f", rawLotSize) + " | Normalized: " +
                           String.format("%.2f", lotSizes[i]));
            } else {
                lotSizes[i] = 0.0;
            }
        }

        return lotSizes;
    }

    /**
     * Calculates total risk amount based on RPT configuration
     */
    private double calculateTotalRiskAmount(RobotConfig robot, double accountBalance) {
        if (robot.getRptFixedAmount() != null && robot.getRptFixedAmount() > 0) {
            return robot.getRptFixedAmount();
        } else if (robot.getRptPercent() != null && robot.getRptPercent() > 0) {
            return accountBalance * (robot.getRptPercent() / 100.0);
        }
        return 0.0;
    }

    /**
     * Gets contract size for a symbol
     */
    private double getContractSize(String symbol) {
        return contractSizeCache.getOrDefault(symbol, DEFAULT_CONTRACT_SIZE);
    }

    /**
     * Converts amount from quote currency to account currency
     */
    private double convertToAccountCurrency(
            double amount,
            String symbol,
            String accountCurrency,
            Map<String, Double> conversionRates) {

        String quoteCurrency = extractQuoteCurrency(symbol);

        if (quoteCurrency.equals(accountCurrency)) {
            return amount;
        }

        String conversionPair = quoteCurrency + accountCurrency;
        if (conversionRates.containsKey(conversionPair)) {
            return amount * conversionRates.get(conversionPair);
        }

        String inverseConversionPair = accountCurrency + quoteCurrency;
        if (conversionRates.containsKey(inverseConversionPair)) {
            double rate = conversionRates.get(inverseConversionPair);
            if (rate > 0) {
                return amount / rate;
            }
        }

        Logger.warning("No conversion rate found for " + quoteCurrency + " to " + accountCurrency + ", using 1:1");
        return amount;
    }

    /**
     * Calculates commission cost for one lot
     * - FX_per_Lot: commission per lot (e.g., $7 per lot)
     * - ETF_Stock: commission per share, hardcoded at $0.02
     * - No_Commissions: no commission (for instruments with spread-based costs like XAUUSD)
     */
    private double calculateCommissionCost(
            String commissionType,
            double commissionValue,
            double lotSize,
            String symbol,
            String accountCurrency,
            Map<String, Double> conversionRates) {

        if ("No_Commissions".equals(commissionType)) {
            return 0.0;
        } else if ("FX_per_Lot".equals(commissionType)) {
            return commissionValue * lotSize * 2;
        } else if ("ETF_Stock".equals(commissionType)) {
            double commissionPerShare = 0.02;
            double contractSize = getContractSize(symbol);
            double commissionInQuote = commissionPerShare * contractSize * lotSize * 2;
            return convertToAccountCurrency(
                commissionInQuote,
                symbol,
                accountCurrency,
                conversionRates
            );
        }

        return 0.0;
    }

    /**
     * Extracts quote currency from symbol (e.g., "XAUUSD" -> "USD")
     */
    private String extractQuoteCurrency(String symbol) {
        String upper = symbol.toUpperCase();

        // Indices - quote currency varies by index
        if (upper.contains("FRA40") || upper.contains("CAC")) return "EUR";  // French index
        if (upper.contains("GER40") || upper.contains("DAX")) return "EUR";  // German index
        if (upper.contains("UK100") || upper.contains("FTSE")) return "GBP"; // UK index
        if (upper.contains("JPN225") || upper.contains("NIKKEI")) return "JPY"; // Japan index
        if (upper.contains("US30") || upper.contains("DOW")) return "USD";  // US index
        if (upper.contains("NAS100") || upper.contains("NASDAQ")) return "USD"; // US index
        if (upper.contains("SPX500") || upper.contains("SP500")) return "USD"; // US index
        if (upper.contains("AUS200") || upper.contains("ASX")) return "AUD"; // Australian index

        // Metals and crypto
        if (upper.contains("XAU") || upper.contains("XAG") || upper.contains("GOLD") || upper.contains("SILVER")) return "USD";
        if (upper.contains("BTC") || upper.contains("ETH")) return "USD";

        // Forex pairs - extract last 3 characters
        if (symbol.length() >= 6) {
            return symbol.substring(symbol.length() - 3).toUpperCase();
        }

        return "USD";
    }

    /**
     * Normalizes lot size to broker's min/max/step requirements
     * Uses symbol-specific lot step (e.g., 0.1 for indices, 0.01 for FX/metals)
     */
    private double normalizeLotSize(double lotSize, String symbol) {
        double lotStep = lotStepCache.getOrDefault(symbol, LOT_STEP);

        if (lotSize < MIN_LOT) {
            return 0.0;
        }

        if (lotSize > MAX_LOT) {
            lotSize = MAX_LOT;
        }

        double normalized = Math.round(lotSize / lotStep) * lotStep;

        return Math.max(MIN_LOT, Math.min(MAX_LOT, normalized));
    }

    /**
     * Validates that TP volumes sum to 100%
     */
    public boolean validateTPVolumes(RobotConfig robot) {
        int total = robot.getTp1Volume() + robot.getTp2Volume() +
                   robot.getTp3Volume() + robot.getTp4Volume() +
                   robot.getTp5Volume() + robot.getTp6Volume() +
                   robot.getTp7Volume();

        if (total != 100) {
            Logger.error("        ✗ TP Volume validation failed for robot '" + robot.getRobotName() + "': " +
                robot.getTp1Volume() + "+" + robot.getTp2Volume() + "+" +
                robot.getTp3Volume() + "+" + robot.getTp4Volume() + "+" +
                robot.getTp5Volume() + "+" + robot.getTp6Volume() + "+" +
                robot.getTp7Volume() + " = " + total + "% (must equal 100%)");
            return false;
        }

        return true;
    }

    /**
     * Sets a custom contract size for a symbol
     */
    public void setContractSize(String symbol, double contractSize) {
        contractSizeCache.put(symbol, contractSize);
    }
}
