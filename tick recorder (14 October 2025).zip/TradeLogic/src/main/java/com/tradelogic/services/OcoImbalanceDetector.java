package com.tradelogic.services;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.tradelogic.Logger;
import com.tradelogic.models.TradeCommand;

import java.lang.reflect.Type;
import java.util.*;
import java.util.concurrent.*;

/**
 * Detects severe OCO order imbalances after placement attempts complete.
 *
 * PURPOSE:
 * In fast-moving markets after X1 closes, sometimes all 7 orders on one side place
 * successfully, but 0 orders on the opposite side place (market moved too far).
 * This leaves orphaned orders that will likely never trigger.
 *
 * MECHANICS:
 * 1. Runs AFTER OcoFillWatcher completes (OcoFillWatcher handles fills immediately)
 * 2. Waits 20 seconds after placement commands are sent
 * 3. Queries actual MT5 pending order counts via trade_history table
 * 4. If one side has ≥5 orders AND opposite side has exactly 0 orders → DELETE the side with orders
 * 5. Otherwise, no action taken (normal OCO continues)
 *
 * THRESHOLD: ≥5 vs 0 only. Anything less is acceptable variance.
 */
public class OcoImbalanceDetector {
    private static OcoImbalanceDetector instance;

    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(2);
    private final Map<String, ScheduledFuture<?>> scheduledChecks = new ConcurrentHashMap<>();

    private TradeCommandQueue commandQueue;
    private SupabaseClient supabaseClient;
    private final Gson gson = new Gson();

    private OcoImbalanceDetector() {}

    public static synchronized OcoImbalanceDetector getInstance() {
        if (instance == null) {
            instance = new OcoImbalanceDetector();
        }
        return instance;
    }

    public void setCommandQueue(TradeCommandQueue queue) {
        this.commandQueue = queue;
    }

    public void setSupabaseClient(SupabaseClient client) {
        this.supabaseClient = client;
    }

    /**
     * Schedules an imbalance check for a magic number, 20 seconds after placement
     *
     * @param magicNumber Magic number of the OCO group
     * @param robotConfigId Robot UUID for logging
     */
    public void scheduleImbalanceCheck(String magicNumber, UUID robotConfigId) {
        Logger.info("OCO IMBALANCE: Scheduled 20-second check for magic " + magicNumber);

        ScheduledFuture<?> future = scheduler.schedule(
            () -> checkForImbalance(magicNumber, robotConfigId),
            20,
            TimeUnit.SECONDS
        );

        scheduledChecks.put(magicNumber, future);
    }

    /**
     * Checks for severe imbalance (≥5 vs 0) and deletes if found
     */
    private void checkForImbalance(String magicNumber, UUID robotConfigId) {
        try {
            Logger.info("OCO IMBALANCE: Starting 20-second check for magic " + magicNumber);

            // Query actual pending order counts from MT5 via database
            Map<String, Integer> counts = queryPendingOrderCounts(magicNumber);

            int buyCount = counts.getOrDefault("BUY", 0);
            int sellCount = counts.getOrDefault("SELL", 0);

            Logger.info(String.format("OCO IMBALANCE: Magic %s - BUY: %d, SELL: %d",
                magicNumber, buyCount, sellCount));

            // Check threshold: ≥5 on one side, 0 on the other
            if (buyCount >= 5 && sellCount == 0) {
                Logger.warning(String.format(
                    "⚠️ OCO IMBALANCE DETECTED: Magic %s has %d BUY orders but 0 SELL orders - DELETING BUY orders",
                    magicNumber, buyCount));
                deleteAllOrdersForMagic(magicNumber, "BUY_STOP", robotConfigId);

            } else if (sellCount >= 5 && buyCount == 0) {
                Logger.warning(String.format(
                    "⚠️ OCO IMBALANCE DETECTED: Magic %s has %d SELL orders but 0 BUY orders - DELETING SELL orders",
                    magicNumber, sellCount));
                deleteAllOrdersForMagic(magicNumber, "SELL_STOP", robotConfigId);

            } else {
                Logger.info(String.format(
                    "OCO IMBALANCE: Magic %s is balanced or within threshold - no action needed",
                    magicNumber));
            }

        } catch (Exception e) {
            Logger.error("OCO IMBALANCE: Error checking imbalance for magic " + magicNumber + ": " + e.getMessage());
            e.printStackTrace();
        } finally {
            scheduledChecks.remove(magicNumber);
        }
    }

    /**
     * Queries the trade_history table to count pending orders by type
     *
     * @param magicNumber Magic number to query
     * @return Map with "BUY" and "SELL" counts
     */
    private Map<String, Integer> queryPendingOrderCounts(String magicNumber) {
        Map<String, Integer> counts = new HashMap<>();
        counts.put("BUY", 0);
        counts.put("SELL", 0);

        if (supabaseClient == null) {
            Logger.warning("OCO IMBALANCE: SupabaseClient not set, cannot query pending orders");
            return counts;
        }

        try {
            String filters = String.format(
                "magic_number=eq.%s&state=eq.ORDER_STATE_PLACED",
                magicNumber
            );

            String jsonResponse = supabaseClient.select("trade_history", "order_type", filters);

            Type listType = new TypeToken<List<Map<String, Object>>>() {}.getType();
            List<Map<String, Object>> results = gson.fromJson(jsonResponse, listType);

            if (results != null) {
                for (Map<String, Object> row : results) {
                    String orderType = (String) row.get("order_type");

                    if (orderType != null) {
                        if (orderType.contains("BUY")) {
                            counts.put("BUY", counts.get("BUY") + 1);
                        } else if (orderType.contains("SELL")) {
                            counts.put("SELL", counts.get("SELL") + 1);
                        }
                    }
                }
            }

            Logger.info("OCO IMBALANCE: Query returned " + (results != null ? results.size() : 0) + " pending orders");

        } catch (Exception e) {
            Logger.error("OCO IMBALANCE: Error querying pending orders: " + e.getMessage());
            e.printStackTrace();
        }

        return counts;
    }

    /**
     * Creates and queues a DELETE command for all orders of a specific type and magic
     */
    private void deleteAllOrdersForMagic(String magicNumber, String orderType, UUID robotConfigId) {
        if (commandQueue == null) {
            Logger.error("OCO IMBALANCE: CommandQueue not set, cannot delete orders");
            return;
        }

        Map<String, Object> params = new HashMap<>();
        params.put("magic_number", magicNumber);
        params.put("order_type", orderType);

        TradeCommand deleteCommand = new TradeCommand(
            robotConfigId,
            magicNumber,
            "DELETE_ALL_MAGIC",
            params
        );

        commandQueue.addFirst(deleteCommand);
        Logger.info(String.format(
            "OCO IMBALANCE: Queued DELETE_ALL_MAGIC command for %s orders with magic %s",
            orderType, magicNumber));
    }

    /**
     * Cancels a scheduled check (e.g., if OcoFillWatcher already handled it)
     */
    public void cancelScheduledCheck(String magicNumber) {
        ScheduledFuture<?> future = scheduledChecks.remove(magicNumber);
        if (future != null) {
            future.cancel(false);
            Logger.info("OCO IMBALANCE: Cancelled scheduled check for magic " + magicNumber);
        }
    }

    /**
     * Shuts down the scheduler (call on application exit)
     */
    public void shutdown() {
        scheduler.shutdownNow();
        scheduledChecks.clear();
        Logger.info("OCO IMBALANCE: Detector shutdown complete");
    }
}
