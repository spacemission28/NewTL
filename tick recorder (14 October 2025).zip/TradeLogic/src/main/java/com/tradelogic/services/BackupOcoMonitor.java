package com.tradelogic.services;

import com.tradelogic.Logger;
import com.tradelogic.models.PendingOcoGroup;

import java.util.List;
import java.util.Map;
import java.util.concurrent.*;

public class BackupOcoMonitor {
    private static BackupOcoMonitor instance;
    private final Map<Long, PendingOcoGroup> pendingGroups = new ConcurrentHashMap<>();
    private final OcoManager ocoManager;
    private final TradeHistoryCache tradeHistoryCache;
    private ScheduledExecutorService scheduler;
    private volatile boolean running = false;

    private static final int CHECK_INTERVAL_SECONDS = 10;
    private static final int MIN_AGE_BEFORE_CHECK_MS = 10000; // 10 seconds
    private static final int MAX_AGE_MS = 60000; // 60 seconds

    private BackupOcoMonitor() {
        this.ocoManager = OcoManager.getInstance();
        this.tradeHistoryCache = TradeHistoryCache.getInstance();
    }

    public static synchronized BackupOcoMonitor getInstance() {
        if (instance == null) {
            instance = new BackupOcoMonitor();
        }
        return instance;
    }

    public void start() {
        if (running) {
            Logger.warning("BackupOcoMonitor already running");
            return;
        }

        scheduler = Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(
            this::checkPendingGroups,
            CHECK_INTERVAL_SECONDS,
            CHECK_INTERVAL_SECONDS,
            TimeUnit.SECONDS
        );

        running = true;
        Logger.info("BackupOcoMonitor started (checking every " + CHECK_INTERVAL_SECONDS + " seconds)");
    }

    public void stop() {
        if (!running) {
            return;
        }

        if (scheduler != null && !scheduler.isShutdown()) {
            scheduler.shutdown();
            try {
                if (!scheduler.awaitTermination(5, TimeUnit.SECONDS)) {
                    scheduler.shutdownNow();
                }
            } catch (InterruptedException e) {
                scheduler.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }

        running = false;
        Logger.info("BackupOcoMonitor stopped");
    }

    public void registerOcoGroup(long magicNumber, String symbol, List<String> orderTickets) {
        PendingOcoGroup group = new PendingOcoGroup(magicNumber, symbol, orderTickets);
        pendingGroups.put(magicNumber, group);

        Logger.info(String.format("BACKUP OCO: Registered Magic %d for monitoring (%d orders, symbol=%s)",
            magicNumber, orderTickets.size(), symbol));
    }

    public void removeOcoGroup(long magicNumber) {
        PendingOcoGroup removed = pendingGroups.remove(magicNumber);
        if (removed != null) {
            Logger.info(String.format("BACKUP OCO: Removed Magic %d from monitoring", magicNumber));
        }
    }

    private void checkPendingGroups() {
        if (pendingGroups.isEmpty()) {
            return;
        }

        long now = System.currentTimeMillis();
        List<Long> groupsToRemove = new CopyOnWriteArrayList<>();

        for (Map.Entry<Long, PendingOcoGroup> entry : pendingGroups.entrySet()) {
            Long magicNumber = entry.getKey();
            PendingOcoGroup group = entry.getValue();

            long age = now - group.getTimestamp();

            if (age < MIN_AGE_BEFORE_CHECK_MS) {
                continue;
            }

            group.incrementCheckCount();

            boolean hasFill = checkForFills(group.getMagicNumber(), group.getSymbol());

            if (hasFill && !group.isCleanupAttempted()) {
                Logger.info(String.format(
                    "BACKUP OCO: Fill detected for Magic %d (symbol=%s, age=%dms, checks=%d) - triggering cleanup",
                    group.getMagicNumber(), group.getSymbol(), age, group.getCheckCount()
                ));

                try {
                    ocoManager.cancelOpposite(group.getMagicNumber(), group.getSymbol());
                    group.setCleanupAttempted(true);
                    Logger.info(String.format("BACKUP OCO: OCO cleanup completed for Magic %d", magicNumber));
                } catch (Exception e) {
                    Logger.error(String.format("BACKUP OCO: Failed to cleanup Magic %d: %s",
                        magicNumber, e.getMessage()));
                }
            }

            if (age > MAX_AGE_MS || group.isCleanupAttempted()) {
                groupsToRemove.add(magicNumber);
            }
        }

        for (Long magicNumber : groupsToRemove) {
            PendingOcoGroup group = pendingGroups.remove(magicNumber);
            if (group != null) {
                String reason = group.isCleanupAttempted() ? "cleanup complete" : "max age reached";
                Logger.info(String.format(
                    "BACKUP OCO: Removed Magic %d from monitoring (checks=%d, reason=%s)",
                    magicNumber, group.getCheckCount(), reason
                ));
            }
        }
    }

    private boolean checkForFills(long magicNumber, String symbol) {
        return tradeHistoryCache.hasFilledOrders(magicNumber, symbol, 60);
    }

    public int getPendingGroupsCount() {
        return pendingGroups.size();
    }

    public boolean isRunning() {
        return running;
    }

    public Map<Long, PendingOcoGroup> getPendingGroups() {
        return new ConcurrentHashMap<>(pendingGroups);
    }
}
