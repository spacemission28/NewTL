package com.tradelogic.services;

import com.tradelogic.models.RobotConfig;
import java.util.List;
import java.util.Map;

public interface DatabaseClient {
    void upsertRobotConfig(String userId, RobotConfig config) throws Exception;
    List<RobotConfig> loadRobotConfigs(String userId) throws Exception;
    void saveDefaultValues(String userId, Map<String, Object> defaults) throws Exception;
    Map<String, Object> loadDefaultValues(String userId) throws Exception;
    void deleteRobotConfigs(String userId, List<Integer> robotNumbers) throws Exception;
}
