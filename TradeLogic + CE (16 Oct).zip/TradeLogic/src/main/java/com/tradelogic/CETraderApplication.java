package com.tradelogic;

import com.tradelogic.models.CERobotConfig;
import com.tradelogic.models.MarketBarData;
import com.tradelogic.models.TradeCommand;
import com.tradelogic.services.*;
import com.tradelogic.services.FileDataReader;
import com.tradelogic.ui.CERobotMatrixTable;
import com.tradelogic.ui.ConnectionIndicator;
import com.tradelogic.ui.DatabaseConfigDialog;
import com.tradelogic.ui.LoginDialog;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.io.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;

public class CETraderApplication extends Application {

    private DatabaseClient dbClient;
    private FileDataReader fileDataReader;
    private LocalFileConfigStorage localConfigStorage;
    private String dataSourceMode = "file";
    private CEStrategyService ceStrategy;
    private CEOcoManager ceOcoManager;
    private TradeHistoryCache tradeHistoryCache;
    private TradeCommandQueue commandQueue;
    private ScheduledExecutorService strategyExecutor;
    private CERobotMatrixTable robotMatrix;
    private ConnectionIndicator connectionIndicator;
    private TextArea logArea;
    private boolean masterEnabled = false;
    private boolean muted = false;

    // Status displays
    private Label currentPnLLabel;
    private Label activeRobotsLabel;
    private Label totalRptLabel;

    private static final long STRATEGY_INTERVAL_MS = 10000;
    private final Set<String> processedCandles = ConcurrentHashMap.newKeySet();
    private long lastTickDataCheck = 0;
    private boolean tickRecorderAlive = false;
    private double accountBalance = 10000.0;
    private String accountCurrency = "USD";
    private Map<String, Double> conversionRates = new ConcurrentHashMap<>();

    @Override
    public void start(Stage primaryStage) {
        Logger.info("C.E. Trader Application starting...");

        if (!showLoginDialog(primaryStage)) {
            Platform.exit();
            return;
        }

        if (!showDatabaseConfigDialog()) {
            Platform.exit();
            return;
        }

        primaryStage.setTitle("C.E. Trader - Continuous Entry Strategy");
        primaryStage.setScene(createMainScene());
        primaryStage.setWidth(1800);
        primaryStage.setHeight(950);
        primaryStage.setOnCloseRequest(event -> shutdown());
        primaryStage.show();

        // Initialize services after UI is shown to prevent blocking
        Platform.runLater(() -> {
            initializeServices();
            startStrategyLoop();
            startCommandExecutor();
            checkTickRecorderStatus();
            startStatusUpdateLoop();
            logMessage("Application initialized - mode: " + dataSourceMode);
        });
    }

    private boolean showLoginDialog(Stage owner) {
        LoginDialog dialog = new LoginDialog(owner);
        boolean success = dialog.showAndWait();
        if (success) {
            Logger.info("Login successful");
            return true;
        }
        return false;
    }

    private boolean showDatabaseConfigDialog() {
        DatabaseConfigDialog dialog = new DatabaseConfigDialog();
        Optional<DatabaseConfigDialog.DatabaseConfig> result = dialog.showAndWait();

        if (result.isPresent()) {
            DatabaseConfigDialog.DatabaseConfig config = result.get();
            dataSourceMode = config.type;

            try {
                if ("file".equals(config.type)) {
                    fileDataReader = new FileDataReader(config.fileDataPath);
                    localConfigStorage = new LocalFileConfigStorage(config.fileDataPath);
                    Logger.info("File-based data reader initialized: " + config.fileDataPath);
                    Logger.info("Using local file storage for robot configurations");
                    logMessage("═══ FILE MODE CONFIGURATION ═══");
                    logMessage("Data Directory: " + config.fileDataPath);
                    logMessage("CE Trader will read bar data from: " + config.fileDataPath + "/<SYMBOL>_candles.txt");
                    logMessage("═══════════════════════════════");
                } else {
                    switch (config.type) {
                        case "supabase" -> {
                            SupabaseClient.initialize(config.supabaseUrl, config.supabaseKey);
                            dbClient = new SupabaseDatabaseAdapter(SupabaseClient.getInstance());
                            DatabaseFactory.initialize(dbClient);
                            Logger.info("Supabase database initialized");
                        }
                        case "postgres" -> {
                            PostgresClient.initialize(config.postgresUrl, config.postgresUser, config.postgresPassword);
                            dbClient = PostgresClient.getInstance();
                            DatabaseFactory.initialize(dbClient);
                            Logger.info("PostgreSQL database initialized");
                        }
                        case "bolt" -> {
                            BoltDatabaseAdapter.initialize(config.boltUrl, "");
                            dbClient = BoltDatabaseAdapter.getInstance();
                            DatabaseFactory.initialize(dbClient);
                            Logger.info("Bolt database initialized");
                        }
                        default -> {
                            Logger.error("Unknown database type: " + config.type);
                            return false;
                        }
                    }
                }
                return true;
            } catch (Exception e) {
                Logger.error("Failed to initialize database: " + e.getMessage());
                return false;
            }
        }
        return false;
    }

    private void initializeServices() {
        // Only initialize dbClient if not in file mode
        if (dbClient == null && !"file".equals(dataSourceMode)) {
            dbClient = new SupabaseDatabaseAdapter(SupabaseClient.getInstance());
        }
        commandQueue = new TradeCommandQueue();
        tradeHistoryCache = TradeHistoryCache.getInstance();
        ceOcoManager = new CEOcoManager();
        ceOcoManager.setTradeHistoryCache(tradeHistoryCache);
        ceStrategy = new CEStrategyService(ceOcoManager, tradeHistoryCache);
        Logger.info("C.E. services initialized (mode: " + dataSourceMode + ")");
    }

    private Scene createMainScene() {
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(10));
        root.setTop(createTopBar());
        root.setCenter(createCenterContent());
        root.setBottom(createBottomBar());
        return new Scene(root);
    }

    private VBox createTopBar() {
        VBox topContainer = new VBox(5);

        // Main control bar
        HBox controlBar = new HBox(15);
        controlBar.setAlignment(Pos.CENTER_LEFT);
        controlBar.setPadding(new Insets(10));
        controlBar.setStyle("-fx-background-color: #2c3e50;");

        Label title = new Label("C.E. TRADER - CONTINUOUS ENTRY");
        title.setStyle("-fx-text-fill: white; -fx-font-size: 18px; -fx-font-weight: bold;");

        connectionIndicator = new ConnectionIndicator();

        Button goButton = new Button("GO: OFF");
        goButton.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-background-color: #95a5a6;");
        goButton.setOnAction(e -> {
            masterEnabled = !masterEnabled;
            goButton.setText("GO: " + (masterEnabled ? "ON" : "OFF"));
            goButton.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-background-color: " +
                (masterEnabled ? "#27ae60;" : "#95a5a6;"));
            robotMatrix.setMasterEnabled(masterEnabled);
            Logger.info("GO toggle: " + (masterEnabled ? "ON" : "OFF"));
            logMessage("GO " + (masterEnabled ? "ENABLED - Trading active" : "DISABLED - No trading"));

            if (masterEnabled) {
                verifyDataAccess();
            }
        });

        Button muteButton = new Button("MUTE");
        muteButton.setStyle("-fx-font-size: 12px;");
        muteButton.setOnAction(e -> {
            muted = !muted;
            muteButton.setText(muted ? "UNMUTE" : "MUTE");
            Logger.info("Mute toggle: " + (muted ? "ON" : "OFF"));
            logMessage(muted ? "Muted - No alerts/sounds" : "Unmuted - Alerts enabled");
        });

        Button shutdownButton = new Button("SHUT DOWN");
        shutdownButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
        shutdownButton.setOnAction(e -> shutdown());

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        controlBar.getChildren().addAll(title, connectionIndicator, spacer, goButton, muteButton, shutdownButton);

        // Status bar with P&L, Active Robots, Total RPT
        HBox statusBar = new HBox(30);
        statusBar.setAlignment(Pos.CENTER_LEFT);
        statusBar.setPadding(new Insets(10));
        statusBar.setStyle("-fx-background-color: #34495e;");

        currentPnLLabel = new Label("Current P&L: $0.00");
        currentPnLLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold;");

        activeRobotsLabel = new Label("Active Robots: 0");
        activeRobotsLabel.setStyle("-fx-text-fill: #3498db; -fx-font-size: 14px; -fx-font-weight: bold;");

        totalRptLabel = new Label("Total RPT: $0.00");
        totalRptLabel.setStyle("-fx-text-fill: #f39c12; -fx-font-size: 14px; -fx-font-weight: bold;");

        statusBar.getChildren().addAll(currentPnLLabel, activeRobotsLabel, totalRptLabel);

        topContainer.getChildren().addAll(controlBar, statusBar);
        return topContainer;
    }

    private VBox createCenterContent() {
        VBox center = new VBox(10);
        center.setPadding(new Insets(10));

        Label warning = new Label("⚠ Trade Logic TickRecorder MUST be running - C.E. Trader reads its data");
        warning.setStyle("-fx-background-color: #f39c12; -fx-padding: 10px; -fx-font-weight: bold;");

        robotMatrix = new CERobotMatrixTable();
        loadCERobotConfigs();

        HBox buttonBar = new HBox(10);
        buttonBar.setAlignment(Pos.CENTER_LEFT);
        buttonBar.setPadding(new Insets(10, 0, 0, 0));

        Button addButton = new Button("+ Add Robot");
        addButton.setStyle("-fx-font-size: 14px; -fx-background-color: #27ae60; -fx-text-fill: white; -fx-padding: 8px 16px;");
        addButton.setOnAction(e -> addNewRobot());

        Button setDefaultsButton = new Button("Set Defaults");
        setDefaultsButton.setStyle("-fx-font-size: 14px; -fx-background-color: #9b59b6; -fx-text-fill: white; -fx-padding: 8px 16px;");
        setDefaultsButton.setOnAction(e -> showSetDefaultsDialog());

        Button saveLayoutButton = new Button("Save Layout");
        saveLayoutButton.setStyle("-fx-font-size: 14px; -fx-background-color: #3498db; -fx-text-fill: white; -fx-padding: 8px 16px;");
        saveLayoutButton.setOnAction(e -> saveLayout());

        Button loadLayoutButton = new Button("Load Layout");
        loadLayoutButton.setStyle("-fx-font-size: 14px; -fx-background-color: #16a085; -fx-text-fill: white; -fx-padding: 8px 16px;");
        loadLayoutButton.setOnAction(e -> loadLayout());

        buttonBar.getChildren().addAll(addButton, setDefaultsButton, saveLayoutButton, loadLayoutButton);

        center.getChildren().addAll(warning, robotMatrix, buttonBar);
        VBox.setVgrow(robotMatrix, Priority.ALWAYS);
        return center;
    }

    private HBox createBottomBar() {
        HBox bottomBar = new HBox(10);
        bottomBar.setPadding(new Insets(10));
        bottomBar.setAlignment(Pos.CENTER_LEFT);

        logArea = new TextArea();
        logArea.setEditable(false);
        logArea.setPrefHeight(200);
        logArea.setStyle("-fx-font-family: monospace; -fx-font-size: 13px;");

        ContextMenu logContextMenu = new ContextMenu();

        MenuItem copySelectionItem = new MenuItem("Copy Selection");
        copySelectionItem.setOnAction(e -> {
            String selectedText = logArea.getSelectedText();
            if (selectedText != null && !selectedText.isEmpty()) {
                final javafx.scene.input.Clipboard clipboard = javafx.scene.input.Clipboard.getSystemClipboard();
                final javafx.scene.input.ClipboardContent content = new javafx.scene.input.ClipboardContent();
                content.putString(selectedText);
                clipboard.setContent(content);
                logMessage("Selected text copied to clipboard");
            }
        });

        MenuItem copyAllItem = new MenuItem("Copy All");
        copyAllItem.setOnAction(e -> {
            final javafx.scene.input.Clipboard clipboard = javafx.scene.input.Clipboard.getSystemClipboard();
            final javafx.scene.input.ClipboardContent content = new javafx.scene.input.ClipboardContent();
            content.putString(logArea.getText());
            clipboard.setContent(content);
            logMessage("Log contents copied to clipboard");
        });

        logContextMenu.getItems().addAll(copySelectionItem, copyAllItem);
        logArea.setContextMenu(logContextMenu);

        HBox.setHgrow(logArea, Priority.ALWAYS);
        bottomBar.getChildren().add(logArea);
        return bottomBar;
    }

    private void loadCERobotConfigs() {
        new Thread(() -> {
            try {
                List<CERobotConfig> configs;
                CERobotConfig defaults;

                if ("file".equals(dataSourceMode) && localConfigStorage != null) {
                    configs = localConfigStorage.loadCERobotConfigs();
                    defaults = localConfigStorage.loadCEDefaultValues();
                } else if (dbClient != null) {
                    configs = dbClient.loadCERobotConfigs();
                    defaults = dbClient.loadCEDefaultValues();
                } else {
                    configs = new ArrayList<>();
                    defaults = null;
                }

                Platform.runLater(() -> {
                    if (defaults != null) {
                        robotMatrix.setDefaultValues(defaults);
                    }
                    robotMatrix.loadConfigs(configs);
                    logMessage("Loaded " + configs.size() + " C.E. robot configurations");
                    updateStatusDisplays();
                });
            } catch (Exception e) {
                Logger.error("Failed to load C.E. configs: " + e.getMessage());
                logMessage("ERROR: Failed to load configs - " + e.getMessage());
            }
        }).start();
    }

    private void saveCERobotConfig(CERobotConfig config) {
        try {
            if ("file".equals(dataSourceMode) && localConfigStorage != null) {
                localConfigStorage.saveCERobotConfig(config);
            } else {
                dbClient.saveCERobotConfig(config);
            }
        } catch (Exception e) {
            Logger.error("Failed to save robot config: " + e.getMessage());
        }
    }

    private void addNewRobot() {
        CERobotConfig newConfig = new CERobotConfig();
        newConfig.setRobotName("");
        newConfig.setSymbol("");
        newConfig.setMasterEnabled(false);
        newConfig.setCeMagicBase(0);
        newConfig.setCeMaxSequence(0);
        newConfig.setTimeframe("");
        newConfig.setCloseHour(0);
        newConfig.setCloseMinute(0);
        newConfig.setMinX1Height(0.0);
        newConfig.setX1Type("");
        newConfig.setTrigPercent(0.0);
        newConfig.setStopLossPercent(0.0);
        newConfig.setRptPercent(0.0);
        newConfig.setRptFixedAmount(0.0);
        newConfig.setTp1Percent(0.0);
        newConfig.setTp1Volume(0);
        newConfig.setTp2Percent(0.0);
        newConfig.setTp2Volume(0);
        newConfig.setTp3Percent(0.0);
        newConfig.setTp3Volume(0);
        newConfig.setTp4Percent(0.0);
        newConfig.setTp4Volume(0);
        newConfig.setTp5Percent(0.0);
        newConfig.setTp5Volume(0);
        newConfig.setTp6Percent(0.0);
        newConfig.setTp6Volume(0);
        newConfig.setTp7Percent(0.0);
        newConfig.setTp7Volume(0);
        newConfig.setCommissionsEnabled(false);
        newConfig.setCommissionType("No_Commissions");
        newConfig.setCommissionValue(0.0);
        newConfig.setDisableLeapfrog(false);

        robotMatrix.addNewRow(newConfig);
        logMessage("Added new empty robot row - check to populate with defaults");
        updateStatusDisplays();
    }

    private void showSetDefaultsDialog() {
        new Thread(() -> {
            try {
                CERobotConfig defaults;
                if ("file".equals(dataSourceMode) && localConfigStorage != null) {
                    defaults = localConfigStorage.loadCEDefaultValues();
                } else if (dbClient != null) {
                    defaults = dbClient.loadCEDefaultValues();
                } else {
                    defaults = null;
                }
                if (defaults == null) {
                    defaults = new CERobotConfig();
                    defaults.setCeMaxSequence(5);
                    defaults.setTimeframe("H1");
                    defaults.setCloseHour(0);
                    defaults.setCloseMinute(0);
                    defaults.setMinX1Height(50.0);
                    defaults.setX1Type("Cents");
                    defaults.setTrigPercent(50.0);
                    defaults.setStopLossPercent(100.0);
                    defaults.setRptPercent(1.0);
                    defaults.setTp1Percent(100.0);
                    defaults.setTp1Volume(100);
                    defaults.setTp2Percent(200.0);
                    defaults.setTp2Volume(0);
                    defaults.setTp3Percent(300.0);
                    defaults.setTp3Volume(0);
                    defaults.setTp4Percent(400.0);
                    defaults.setTp4Volume(0);
                    defaults.setTp5Percent(500.0);
                    defaults.setTp5Volume(0);
                    defaults.setTp6Percent(600.0);
                    defaults.setTp6Volume(0);
                    defaults.setTp7Percent(700.0);
                    defaults.setTp7Volume(0);
                    defaults.setCommissionsEnabled(false);
                    defaults.setCommissionType("No_Commissions");
                    defaults.setDisableLeapfrog(false);
                }

                CERobotConfig finalDefaults = defaults;
                Platform.runLater(() -> openDefaultsDialog(finalDefaults));
            } catch (Exception e) {
                Logger.error("Failed to load CE defaults: " + e.getMessage());
                Platform.runLater(() -> logMessage("ERROR: Failed to load defaults - " + e.getMessage()));
            }
        }).start();
    }

    private void openDefaultsDialog(CERobotConfig currentDefaults) {
        Dialog<CERobotConfig> dialog = new Dialog<>();
        dialog.setTitle("Set C.E. Default Values");
        dialog.setHeaderText("Configure default values for all C.E. robots");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(5);
        grid.setPadding(new Insets(10, 10, 10, 10));

        ScrollPane scrollPane = new ScrollPane(grid);
        scrollPane.setFitToWidth(true);
        scrollPane.setPrefHeight(500);
        scrollPane.setStyle("-fx-background-color: transparent;");

        int row = 0;

        TextField symbolField = new TextField(currentDefaults.getSymbol() != null ? currentDefaults.getSymbol() : "");
        symbolField.setPromptText("e.g., XAUUSD, GER40");
        grid.add(new Label("Symbol:"), 0, row);
        grid.add(symbolField, 1, row++);

        ComboBox<String> tfCombo = new ComboBox<>(FXCollections.observableArrayList("M1", "M2", "M3", "M5", "M10", "M15", "M30", "H1", "H3", "H4", "D1"));
        tfCombo.setValue(currentDefaults.getTimeframe());
        grid.add(new Label("Timeframe:"), 0, row);
        grid.add(tfCombo, 1, row++);

        ComboBox<Integer> hrCombo = new ComboBox<>();
        for (int i = 0; i <= 23; i++) hrCombo.getItems().add(i);
        hrCombo.setValue(currentDefaults.getCloseHour());
        grid.add(new Label("Close Hour:"), 0, row);
        grid.add(hrCombo, 1, row++);

        ComboBox<Integer> minCombo = new ComboBox<>();
        for (int i = 0; i <= 59; i++) minCombo.getItems().add(i);
        minCombo.setValue(currentDefaults.getCloseMinute());
        grid.add(new Label("Close Minute:"), 0, row);
        grid.add(minCombo, 1, row++);

        TextField minX1Field = new TextField(String.valueOf(currentDefaults.getMinX1Height()));
        grid.add(new Label("Min X1 Height:"), 0, row);
        grid.add(minX1Field, 1, row++);

        ComboBox<String> x1TypeCombo = new ComboBox<>(FXCollections.observableArrayList("Yen Pips", "Non-Yen Pips", "Cents", "Points"));
        x1TypeCombo.setValue(currentDefaults.getX1Type());
        grid.add(new Label("X1 Type:"), 0, row);
        grid.add(x1TypeCombo, 1, row++);

        TextField trigField = new TextField(String.valueOf(currentDefaults.getTrigPercent()));
        grid.add(new Label("Trig %:"), 0, row);
        grid.add(trigField, 1, row++);

        TextField slField = new TextField(String.valueOf(currentDefaults.getStopLossPercent()));
        grid.add(new Label("Stop Loss %:"), 0, row);
        grid.add(slField, 1, row++);

        TextField rptPercentField = new TextField(String.valueOf(currentDefaults.getRptPercent() != null ? currentDefaults.getRptPercent() : 0.0));
        grid.add(new Label("RPT %:"), 0, row);
        grid.add(rptPercentField, 1, row++);

        TextField rptFixedField = new TextField(String.valueOf(currentDefaults.getRptFixedAmount() != null ? currentDefaults.getRptFixedAmount() : 0.0));
        grid.add(new Label("RPT Fixed $:"), 0, row);
        grid.add(rptFixedField, 1, row++);

        TextField tp1PercentField = new TextField(String.valueOf(currentDefaults.getTp1Percent()));
        TextField tp1VolField = new TextField(String.valueOf(currentDefaults.getTp1Volume()));
        tp1VolField.setPrefWidth(60);
        grid.add(new Label("TP1 %:"), 0, row);
        grid.add(tp1PercentField, 1, row);
        grid.add(new Label("Vol %:"), 2, row);
        grid.add(tp1VolField, 3, row++);

        TextField tp2PercentField = new TextField(String.valueOf(currentDefaults.getTp2Percent()));
        TextField tp2VolField = new TextField(String.valueOf(currentDefaults.getTp2Volume()));
        tp2VolField.setPrefWidth(60);
        grid.add(new Label("TP2 %:"), 0, row);
        grid.add(tp2PercentField, 1, row);
        grid.add(new Label("Vol %:"), 2, row);
        grid.add(tp2VolField, 3, row++);

        TextField tp3PercentField = new TextField(String.valueOf(currentDefaults.getTp3Percent()));
        TextField tp3VolField = new TextField(String.valueOf(currentDefaults.getTp3Volume()));
        tp3VolField.setPrefWidth(60);
        grid.add(new Label("TP3 %:"), 0, row);
        grid.add(tp3PercentField, 1, row);
        grid.add(new Label("Vol %:"), 2, row);
        grid.add(tp3VolField, 3, row++);

        TextField tp4PercentField = new TextField(String.valueOf(currentDefaults.getTp4Percent()));
        TextField tp4VolField = new TextField(String.valueOf(currentDefaults.getTp4Volume()));
        tp4VolField.setPrefWidth(60);
        grid.add(new Label("TP4 %:"), 0, row);
        grid.add(tp4PercentField, 1, row);
        grid.add(new Label("Vol %:"), 2, row);
        grid.add(tp4VolField, 3, row++);

        TextField tp5PercentField = new TextField(String.valueOf(currentDefaults.getTp5Percent()));
        TextField tp5VolField = new TextField(String.valueOf(currentDefaults.getTp5Volume()));
        tp5VolField.setPrefWidth(60);
        grid.add(new Label("TP5 %:"), 0, row);
        grid.add(tp5PercentField, 1, row);
        grid.add(new Label("Vol %:"), 2, row);
        grid.add(tp5VolField, 3, row++);

        TextField tp6PercentField = new TextField(String.valueOf(currentDefaults.getTp6Percent()));
        TextField tp6VolField = new TextField(String.valueOf(currentDefaults.getTp6Volume()));
        tp6VolField.setPrefWidth(60);
        grid.add(new Label("TP6 %:"), 0, row);
        grid.add(tp6PercentField, 1, row);
        grid.add(new Label("Vol %:"), 2, row);
        grid.add(tp6VolField, 3, row++);

        TextField tp7PercentField = new TextField(String.valueOf(currentDefaults.getTp7Percent()));
        TextField tp7VolField = new TextField(String.valueOf(currentDefaults.getTp7Volume()));
        tp7VolField.setPrefWidth(60);
        grid.add(new Label("TP7 %:"), 0, row);
        grid.add(tp7PercentField, 1, row);
        grid.add(new Label("Vol %:"), 2, row);
        grid.add(tp7VolField, 3, row++);

        CheckBox commissionsCheckBox = new CheckBox();
        commissionsCheckBox.setSelected(currentDefaults.isCommissionsEnabled());
        grid.add(new Label("Commissions Enabled:"), 0, row);
        grid.add(commissionsCheckBox, 1, row++);

        ComboBox<String> commTypeCombo = new ComboBox<>(FXCollections.observableArrayList("No_Commissions", "FX_per_Lot", "ETF_Stock"));
        commTypeCombo.setValue(currentDefaults.getCommissionType());
        grid.add(new Label("Commission Type:"), 0, row);
        grid.add(commTypeCombo, 1, row++);

        TextField commValueField = new TextField(String.valueOf(currentDefaults.getCommissionValue() != null ? currentDefaults.getCommissionValue() : 0.0));
        grid.add(new Label("Commission Value:"), 0, row);
        grid.add(commValueField, 1, row++);

        CheckBox leapfrogCheckBox = new CheckBox();
        leapfrogCheckBox.setSelected(currentDefaults.isDisableLeapfrog());
        grid.add(new Label("Disable Leapfrog:"), 0, row);
        grid.add(leapfrogCheckBox, 1, row++);

        dialog.getDialogPane().setContent(scrollPane);
        ButtonType applyButtonType = new ButtonType("Save Defaults", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(applyButtonType, ButtonType.CANCEL);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == applyButtonType) {
                try {
                    currentDefaults.setSymbol(symbolField.getText().trim().toUpperCase());
                    currentDefaults.setTimeframe(tfCombo.getValue());
                    currentDefaults.setCloseHour(hrCombo.getValue());
                    currentDefaults.setCloseMinute(minCombo.getValue());
                    currentDefaults.setMinX1Height(Double.parseDouble(minX1Field.getText()));
                    currentDefaults.setX1Type(x1TypeCombo.getValue());
                    currentDefaults.setTrigPercent(Double.parseDouble(trigField.getText()));
                    currentDefaults.setStopLossPercent(Double.parseDouble(slField.getText()));
                    currentDefaults.setRptPercent(Double.parseDouble(rptPercentField.getText()));
                    currentDefaults.setRptFixedAmount(Double.parseDouble(rptFixedField.getText()));
                    currentDefaults.setTp1Percent(Double.parseDouble(tp1PercentField.getText()));
                    currentDefaults.setTp1Volume(Integer.parseInt(tp1VolField.getText()));
                    currentDefaults.setTp2Percent(Double.parseDouble(tp2PercentField.getText()));
                    currentDefaults.setTp2Volume(Integer.parseInt(tp2VolField.getText()));
                    currentDefaults.setTp3Percent(Double.parseDouble(tp3PercentField.getText()));
                    currentDefaults.setTp3Volume(Integer.parseInt(tp3VolField.getText()));
                    currentDefaults.setTp4Percent(Double.parseDouble(tp4PercentField.getText()));
                    currentDefaults.setTp4Volume(Integer.parseInt(tp4VolField.getText()));
                    currentDefaults.setTp5Percent(Double.parseDouble(tp5PercentField.getText()));
                    currentDefaults.setTp5Volume(Integer.parseInt(tp5VolField.getText()));
                    currentDefaults.setTp6Percent(Double.parseDouble(tp6PercentField.getText()));
                    currentDefaults.setTp6Volume(Integer.parseInt(tp6VolField.getText()));
                    currentDefaults.setTp7Percent(Double.parseDouble(tp7PercentField.getText()));
                    currentDefaults.setTp7Volume(Integer.parseInt(tp7VolField.getText()));
                    currentDefaults.setCommissionsEnabled(commissionsCheckBox.isSelected());
                    currentDefaults.setCommissionType(commTypeCombo.getValue());
                    currentDefaults.setCommissionValue(Double.parseDouble(commValueField.getText()));
                    currentDefaults.setDisableLeapfrog(leapfrogCheckBox.isSelected());
                    return currentDefaults;
                } catch (NumberFormatException e) {
                    return null;
                }
            }
            return null;
        });

        Optional<CERobotConfig> result = dialog.showAndWait();
        result.ifPresent(defaults -> {
            Logger.info("Dialog returned defaults - saving...");
            robotMatrix.updateDefaultValues(defaults);
            new Thread(() -> {
                try {
                    if ("file".equals(dataSourceMode) && localConfigStorage != null) {
                        Logger.info("Saving CE defaults to file...");
                        localConfigStorage.saveCEDefaultValues(defaults);
                        Logger.info("CE defaults saved to file successfully");
                    } else if (dbClient != null) {
                        Logger.info("Saving CE defaults to database...");
                        dbClient.saveCEDefaultValues(defaults);
                        Logger.info("CE defaults saved to database successfully");
                    }
                    Platform.runLater(() -> logMessage("Default values saved successfully"));
                } catch (Exception e) {
                    Logger.error("Failed to save CE default values: " + e.getMessage());
                    e.printStackTrace();
                    Platform.runLater(() -> logMessage("Error saving defaults: " + e.getMessage()));
                }
            }).start();
        });
    }

    private void saveLayout() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save C.E. Robot Layout");
        fileChooser.setInitialFileName("ce_layout.csv");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));

        File file = fileChooser.showSaveDialog(null);
        if (file != null) {
            new Thread(() -> {
                try {
                    List<CERobotConfig> configs = robotMatrix.getAllConfigs();
                    for (CERobotConfig config : configs) {
                        saveCERobotConfig(config);
                    }

                    try (PrintWriter writer = new PrintWriter(file)) {
                        writer.println("robot_name,symbol,master_enabled,ce_magic_base,ce_max_sequence,timeframe,close_hour,close_minute," +
                                "min_x1_height,x1_type,trig_percent,stop_loss_percent,rpt_percent,rpt_fixed_amount," +
                                "tp1_percent,tp1_volume,tp2_percent,tp2_volume,tp3_percent,tp3_volume," +
                                "tp4_percent,tp4_volume,tp5_percent,tp5_volume,tp6_percent,tp6_volume,tp7_percent,tp7_volume," +
                                "commissions_enabled,commission_type,commission_value,disable_leapfrog");

                        for (CERobotConfig config : configs) {
                            writer.println(String.format("%s,%s,%b,%s,%d,%s,%d,%d,%.2f,%s,%.2f,%.2f,%.2f,%.2f," +
                                    "%.2f,%d,%.2f,%d,%.2f,%d,%.2f,%d,%.2f,%d,%.2f,%d,%.2f,%d,%b,%s,%.2f,%b",
                                    config.getRobotName(), config.getSymbol(), config.isMasterEnabled(),
                                    config.getCeMagicBase(), config.getCeMaxSequence(), config.getTimeframe(),
                                    config.getCloseHour(), config.getCloseMinute(),
                                    config.getMinX1Height(), config.getX1Type(), config.getTrigPercent(), config.getStopLossPercent(),
                                    config.getRptPercent() != null ? config.getRptPercent() : 0.0,
                                    config.getRptFixedAmount() != null ? config.getRptFixedAmount() : 0.0,
                                    config.getTp1Percent(), config.getTp1Volume(), config.getTp2Percent(), config.getTp2Volume(),
                                    config.getTp3Percent(), config.getTp3Volume(), config.getTp4Percent(), config.getTp4Volume(),
                                    config.getTp5Percent(), config.getTp5Volume(), config.getTp6Percent(), config.getTp6Volume(),
                                    config.getTp7Percent(), config.getTp7Volume(),
                                    config.isCommissionsEnabled(), config.getCommissionType(),
                                    config.getCommissionValue() != null ? config.getCommissionValue() : 0.0,
                                    config.isDisableLeapfrog()));
                        }
                    }

                    Platform.runLater(() -> logMessage("✓ Saved layout to " + file.getName() + " (" + configs.size() + " robots)"));
                } catch (Exception e) {
                    Logger.error("Failed to save layout: " + e.getMessage());
                    Platform.runLater(() -> logMessage("ERROR: Failed to save layout - " + e.getMessage()));
                }
            }).start();
        }
    }

    private void loadLayout() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Load C.E. Robot Layout");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));

        File file = fileChooser.showOpenDialog(null);
        if (file != null) {
            new Thread(() -> {
                try {
                    List<CERobotConfig> configs = new ArrayList<>();
                    try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                        String line = reader.readLine(); // Skip header
                        while ((line = reader.readLine()) != null) {
                            String[] parts = line.split(",");
                            if (parts.length >= 32) {
                                CERobotConfig config = new CERobotConfig();
                                config.setRobotName(parts[0]);
                                config.setSymbol(parts[1]);
                                config.setMasterEnabled(Boolean.parseBoolean(parts[2]));
                                config.setCeMagicBase(Integer.parseInt(parts[3]));
                                config.setCeMaxSequence(Integer.parseInt(parts[4]));
                                config.setTimeframe(parts[5]);
                                config.setCloseHour(Integer.parseInt(parts[6]));
                                config.setCloseMinute(Integer.parseInt(parts[7]));
                                config.setMinX1Height(Double.parseDouble(parts[8]));
                                config.setX1Type(parts[9]);
                                config.setTrigPercent(Double.parseDouble(parts[10]));
                                config.setStopLossPercent(Double.parseDouble(parts[11]));
                                config.setRptPercent(Double.parseDouble(parts[12]));
                                config.setRptFixedAmount(Double.parseDouble(parts[13]));
                                config.setTp1Percent(Double.parseDouble(parts[14]));
                                config.setTp1Volume(Integer.parseInt(parts[15]));
                                config.setTp2Percent(Double.parseDouble(parts[16]));
                                config.setTp2Volume(Integer.parseInt(parts[17]));
                                config.setTp3Percent(Double.parseDouble(parts[18]));
                                config.setTp3Volume(Integer.parseInt(parts[19]));
                                config.setTp4Percent(Double.parseDouble(parts[20]));
                                config.setTp4Volume(Integer.parseInt(parts[21]));
                                config.setTp5Percent(Double.parseDouble(parts[22]));
                                config.setTp5Volume(Integer.parseInt(parts[23]));
                                config.setTp6Percent(Double.parseDouble(parts[24]));
                                config.setTp6Volume(Integer.parseInt(parts[25]));
                                config.setTp7Percent(Double.parseDouble(parts[26]));
                                config.setTp7Volume(Integer.parseInt(parts[27]));
                                config.setCommissionsEnabled(Boolean.parseBoolean(parts[28]));
                                config.setCommissionType(parts[29]);
                                config.setCommissionValue(Double.parseDouble(parts[30]));
                                config.setDisableLeapfrog(Boolean.parseBoolean(parts[31]));
                                configs.add(config);
                            }
                        }
                    }

                    for (CERobotConfig config : configs) {
                        saveCERobotConfig(config);
                    }

                    Platform.runLater(() -> {
                        robotMatrix.loadConfigs(configs);
                        logMessage("✓ Loaded layout from " + file.getName() + " (" + configs.size() + " robots)");
                        updateStatusDisplays();
                    });
                } catch (Exception e) {
                    Logger.error("Failed to load layout: " + e.getMessage());
                    Platform.runLater(() -> logMessage("ERROR: Failed to load layout - " + e.getMessage()));
                }
            }).start();
        }
    }

    private void startStrategyLoop() {
        strategyExecutor = Executors.newScheduledThreadPool(1);
        strategyExecutor.scheduleAtFixedRate(this::runCEStrategy, 5, STRATEGY_INTERVAL_MS / 1000, TimeUnit.SECONDS);
        Logger.info("C.E. strategy loop started (interval: " + STRATEGY_INTERVAL_MS + "ms)");
        logMessage("Strategy loop started - monitoring for valid signal candles");
    }

    private void runCEStrategy() {
        if (!masterEnabled) {
            Logger.info("Strategy skipped: masterEnabled=false (press GO to enable)");
            return;
        }

        if (muted) {
            Logger.info("Strategy skipped: muted=true");
            return;
        }

        if (!tickRecorderAlive) {
            Logger.info("Strategy skipped: tickRecorderAlive=false (no live data)");
            return;
        }

        try {
            List<CERobotConfig> robots = robotMatrix.getAllConfigs();
            Logger.info("Strategy loop running - checking " + robots.size() + " robots");

            for (CERobotConfig robot : robots) {
                if (!robot.isFullyEnabled()) {
                    Logger.info("Skipping robot " + robot.getCeMagicBase() + " - not fully enabled");
                    continue;
                }

                // Check if we're at or past the start time for this robot
                LocalTime now = LocalTime.now(ZoneId.of("Europe/Athens"));
                LocalTime startTime = LocalTime.of(robot.getCloseHour(), robot.getCloseMinute());
                if (now.isBefore(startTime)) {
                    Logger.info("Skipping robot " + robot.getCeMagicBase() + " - before start time " + startTime + " EET (current: " + now + ")");
                    continue;
                }

                Logger.info("Processing robot: " + robot.getCeMagicBase() + " | " + robot.getSymbol() + " | " + robot.getTimeframe());

                List<MarketBarData> recentBars;
                if ("file".equals(dataSourceMode) && fileDataReader != null) {
                    recentBars = fileDataReader.getRecentCompletedBars(robot.getSymbol(), robot.getTimeframe(), 5);
                } else if (dbClient != null) {
                    recentBars = dbClient.getRecentCompletedBars(robot.getSymbol(), robot.getTimeframe(), 5);
                } else {
                    recentBars = new ArrayList<>();
                }

                if (recentBars.isEmpty()) {
                    Logger.info("No bar data available for robot " + robot.getCeMagicBase() + " (data source: " + dataSourceMode + ")");
                    continue;
                }

                Logger.info("Retrieved " + recentBars.size() + " bars for " + robot.getSymbol());

                // Update last tick data check whenever we successfully get bar data
                lastTickDataCheck = System.currentTimeMillis();

                MarketBarData latestBar = recentBars.get(recentBars.size() - 1);
                String canKey = robot.getCeMagicBase() + "_" + latestBar.getCloseTime();

                Logger.info("Latest bar: H=" + latestBar.getHigh() + " L=" + latestBar.getLow() +
                           " Height=" + (latestBar.getHigh() - latestBar.getLow()) +
                           " MinX1=" + robot.getMinX1Height());

                if (processedCandles.contains(canKey)) {
                    Logger.info("Candle already processed: " + canKey);
                    continue;
                }

                if (ceStrategy.isValidSignalCandle(latestBar, robot)) {
                    Logger.info("VALID SIGNAL DETECTED! Generating trade command...");
                    TradeCommand command = ceStrategy.generateCETradeCommand(robot, latestBar, accountBalance);
                    if (command != null) {
                        commandQueue.add(command);
                        processedCandles.add(canKey);
                        Logger.info("Command queued: " + command.getOrderType() + " " + command.getSymbol() +
                                   " @ " + command.getPrice() + " (Queue size: " + commandQueue.size() + ")");
                        if (!muted) {
                            logMessage("✓ CE Signal: " + robot.getRobotName() + " | " + command.getOrderType() +
                                    " | Lots: " + command.getLots());
                        }
                    } else {
                        Logger.warning("Signal was valid but command generation returned null!");
                    }
                } else {
                    Logger.info("Bar does NOT meet signal criteria (height too small)");
                }
            }
        } catch (Exception e) {
            Logger.error("CE Strategy error: " + e.getMessage());
        }
    }

    private void startCommandExecutor() {
        if ("file".equals(dataSourceMode)) {
            Logger.info("Command executor not started - file mode does not support trade execution");
            return;
        }

        ScheduledExecutorService commandExecutor = Executors.newScheduledThreadPool(1);
        commandExecutor.scheduleAtFixedRate(() -> {
            try {
                if (!masterEnabled || dbClient == null) {
                    return;
                }

                TradeCommand command = commandQueue.poll();
                if (command != null) {
                    Logger.info("Executing trade command: " + command.getOrderType() + " " +
                               command.getSymbol() + " " + command.getLots() + " lots @ " + command.getPrice());
                    dbClient.insertTradeCommand(command);
                    logMessage("✓ Command sent to MT5: " + command.getOrderType() + " " + command.getSymbol());
                }
            } catch (Exception e) {
                Logger.error("Command executor error: " + e.getMessage());
                e.printStackTrace();
            }
        }, 1, 1, TimeUnit.SECONDS);

        Logger.info("Command executor started - checking queue every 1 second");
    }

    private void checkTickRecorderStatus() {
        ScheduledExecutorService tickChecker = Executors.newScheduledThreadPool(1);
        tickChecker.scheduleAtFixedRate(() -> {
            try {
                long timestamp;
                if ("file".equals(dataSourceMode) && fileDataReader != null) {
                    timestamp = fileDataReader.getLatestDataTimestamp();
                } else if (dbClient != null) {
                    timestamp = dbClient.getLatestTickTimestamp();
                } else {
                    timestamp = 0;
                }

                long now = System.currentTimeMillis();
                long ageSeconds = timestamp > 0 ? (now - timestamp) / 1000 : -1;

                if (timestamp > 0 && (now - timestamp) < 60000) {
                    lastTickDataCheck = now;
                    if (!tickRecorderAlive) {
                        Logger.info("TickRecorder is NOW ALIVE (data age: " + ageSeconds + "s)");
                        logMessage("✓ TickRecorder CONNECTED - Trading logic ACTIVE");
                        tickRecorderAlive = true;
                    }
                    Platform.runLater(() -> connectionIndicator.setConnected(true));
                } else {
                    if (now - lastTickDataCheck > 30000) {
                        if (tickRecorderAlive) {
                            Logger.warning("TickRecorder is NOW DEAD (data age: " + ageSeconds + "s)");
                        }
                        tickRecorderAlive = false;
                        Platform.runLater(() -> connectionIndicator.setConnected(false));
                    }
                }
            } catch (Exception e) {
                Logger.error("Failed to check for tick data: " + e.getMessage());
                e.printStackTrace();
                tickRecorderAlive = false;
                Platform.runLater(() -> connectionIndicator.setConnected(false));
            }
        }, 0, 5, TimeUnit.SECONDS);
    }

    private void startStatusUpdateLoop() {
        ScheduledExecutorService statusUpdater = Executors.newScheduledThreadPool(1);
        statusUpdater.scheduleAtFixedRate(() -> Platform.runLater(this::updateStatusDisplays), 0, 2, TimeUnit.SECONDS);
    }

    private void updateStatusDisplays() {
        List<CERobotConfig> allRobots = robotMatrix.getAllConfigs();
        long activeCount = allRobots.stream().filter(CERobotConfig::isMasterEnabled).count();

        double totalRpt = allRobots.stream()
                .filter(CERobotConfig::isMasterEnabled)
                .mapToDouble(r -> r.getRptPercent() != null ? r.getRptPercent() : 0.0)
                .sum();

        activeRobotsLabel.setText("Active Robots: " + activeCount);
        totalRptLabel.setText("Total RPT: " + String.format("%.2f%%", totalRpt));

        // TODO: Calculate actual P&L from trade history
        currentPnLLabel.setText("Current P&L: $0.00");
    }

    private void logMessage(String message) {
        Platform.runLater(() -> {
            ZonedDateTime eetTime = ZonedDateTime.now(ZoneId.of("Europe/Athens"));
            String timeStr = eetTime.format(DateTimeFormatter.ofPattern("HH:mm:ss"));
            logArea.appendText(String.format("[%s] %s\n", timeStr, message));
        });
    }

    private void verifyDataAccess() {
        new Thread(() -> {
            try {
                logMessage("═══════════════════════════════════════════════════════════");
                logMessage("VERIFYING TICKRECORDER DATA ACCESS...");
                logMessage("═══════════════════════════════════════════════════════════");

                List<CERobotConfig> robots = robotMatrix.getAllConfigs();
                int enabledCount = (int) robots.stream().filter(CERobotConfig::isFullyEnabled).count();

                logMessage("▶ Data Source Mode: " + dataSourceMode.toUpperCase());
                logMessage("▶ Total Robots: " + robots.size());
                logMessage("▶ Fully Enabled Robots: " + enabledCount);

                if (enabledCount == 0) {
                    logMessage("⚠ WARNING: No robots are fully enabled!");
                    logMessage("  → Enable both Master AND CE checkbox for each robot");
                    return;
                }

                logMessage("");
                logMessage("CHECKING DATA ACCESS FOR EACH ROBOT:");
                logMessage("───────────────────────────────────────────────────────────");

                for (CERobotConfig robot : robots) {
                    if (!robot.isFullyEnabled()) {
                        logMessage("⊗ Robot " + robot.getCeMagicBase() + " (" + robot.getRobotName() + "): DISABLED");
                        continue;
                    }

                    logMessage("");
                    logMessage("✓ Robot " + robot.getCeMagicBase() + " - " + robot.getRobotName());
                    logMessage("  Symbol: " + robot.getSymbol() + " | Timeframe: " + robot.getTimeframe());
                    logMessage("  Min X1 Height: " + robot.getMinX1Height() + " " + robot.getX1Type());

                    try {
                        List<MarketBarData> bars;
                        if ("file".equals(dataSourceMode) && fileDataReader != null) {
                            String dataDir = fileDataReader.getDataDirectory();
                            String fileName = robot.getSymbol() + "_candles.txt";
                            java.nio.file.Path filePath = java.nio.file.Paths.get(dataDir, fileName);

                            logMessage("  → File System Check:");
                            logMessage("    Data Directory: " + dataDir);
                            logMessage("    Looking for file: " + fileName);
                            logMessage("    Full path: " + filePath);
                            logMessage("    File exists: " + java.nio.file.Files.exists(filePath));

                            if (java.nio.file.Files.exists(filePath)) {
                                try {
                                    long fileSize = java.nio.file.Files.size(filePath);
                                    java.nio.file.attribute.FileTime modTime = java.nio.file.Files.getLastModifiedTime(filePath);
                                    logMessage("    File size: " + fileSize + " bytes");
                                    logMessage("    Last modified: " + modTime);

                                    // Read first 3 lines to show format
                                    java.util.List<String> lines = java.nio.file.Files.readAllLines(filePath);
                                    logMessage("    Total lines: " + lines.size());
                                    logMessage("    First 3 lines:");
                                    for (int i = 0; i < Math.min(3, lines.size()); i++) {
                                        logMessage("      " + lines.get(i));
                                    }
                                } catch (Exception e) {
                                    logMessage("    Error reading file details: " + e.getMessage());
                                }
                            }

                            logMessage("  → Looking for: Symbol=" + robot.getSymbol() + ", Timeframe=" + robot.getTimeframe());
                            bars = fileDataReader.getRecentCompletedBars(robot.getSymbol(), robot.getTimeframe(), 5);
                        } else if (dbClient != null) {
                            bars = dbClient.getRecentCompletedBars(robot.getSymbol(), robot.getTimeframe(), 5);
                        } else {
                            bars = new ArrayList<>();
                        }

                        if (bars.isEmpty()) {
                            logMessage("  ✗ NO BAR DATA AVAILABLE!");
                            logMessage("    Possible causes:");
                            logMessage("    - TickRecorder not running or not generating " + robot.getTimeframe() + " bars");
                            logMessage("    - Symbol '" + robot.getSymbol() + "' not being collected");
                            logMessage("    - Timeframe '" + robot.getTimeframe() + "' not being generated by TickRecorder");
                            logMessage("    - File format mismatch (check " + robot.getSymbol() + "_candles.txt manually)");
                            logMessage("    → ACTION: Check TickRecorder console - is it writing " + robot.getTimeframe() + " bars?");
                        } else {
                            logMessage("  ✓ Data Access: SUCCESS - Retrieved " + bars.size() + " bars");
                            MarketBarData latest = bars.get(bars.size() - 1);

                            // Check if we're at or past the start time
                            LocalTime now = LocalTime.now(ZoneId.of("Europe/Athens"));
                            LocalTime startTime = LocalTime.of(robot.getCloseHour(), robot.getCloseMinute());
                            boolean pastStartTime = now.isAfter(startTime) || now.equals(startTime);

                            if (pastStartTime) {
                                logMessage("  ✓ Past start time (" + startTime + ") - Robot is ACTIVE and monitoring for X1 candles");
                                logMessage("  → Waiting for next " + robot.getTimeframe() + " candle close at or after start time");
                            } else {
                                logMessage("  ⏸ Before start time (" + startTime + ") - Robot will activate at " + startTime + " EET");
                                long minutesUntilStart = java.time.Duration.between(now, startTime).toMinutes();
                                logMessage("  → " + minutesUntilStart + " minutes until activation");
                            }

                            double currentBid;
                            if ("file".equals(dataSourceMode) && fileDataReader != null) {
                                currentBid = latest.getClose();
                            } else if (dbClient != null) {
                                currentBid = dbClient.getLatestBid(robot.getSymbol());
                            } else {
                                currentBid = 0.0;
                            }
                            logMessage("  Current Bid Price: " + String.format("%.5f", currentBid));
                        }

                        long latestTimestamp;
                        if ("file".equals(dataSourceMode) && fileDataReader != null) {
                            latestTimestamp = fileDataReader.getLatestDataTimestamp();
                        } else if (dbClient != null) {
                            latestTimestamp = dbClient.getLatestTickTimestamp();
                        } else {
                            latestTimestamp = 0;
                        }

                        if (latestTimestamp > 0) {
                            long ageSeconds = (System.currentTimeMillis() - latestTimestamp) / 1000;
                            logMessage("  Latest Data Age: " + ageSeconds + " seconds ago");
                            if (ageSeconds > 60) {
                                logMessage("    ⚠ WARNING: Data is stale (>" + ageSeconds + "s old)");
                                logMessage("    → Check if TickRecorder is running and sending data");
                            }
                        }

                    } catch (Exception ex) {
                        logMessage("  ✗ ERROR accessing data: " + ex.getMessage());
                        Logger.error("Data access error for robot " + robot.getCeMagicBase() + ": " + ex.getMessage());
                        ex.printStackTrace();
                    }
                }

                logMessage("");
                logMessage("═══════════════════════════════════════════════════════════");
                logMessage("DATA ACCESS VERIFICATION COMPLETE");
                logMessage("═══════════════════════════════════════════════════════════");
                logMessage("");

            } catch (Exception e) {
                logMessage("✗ VERIFICATION FAILED: " + e.getMessage());
                Logger.error("Data verification error: " + e.getMessage());
                e.printStackTrace();
            }
        }).start();
    }

    private void shutdown() {
        Logger.info("C.E. Trader shutting down...");
        if (strategyExecutor != null) {
            strategyExecutor.shutdownNow();
        }
        if (dbClient != null) {
            dbClient.close();
        }
        Platform.exit();
        System.exit(0);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
