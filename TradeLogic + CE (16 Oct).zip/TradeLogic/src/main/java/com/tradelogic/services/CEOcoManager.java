package com.tradelogic.services;

import com.tradelogic.Logger;
import com.tradelogic.models.TradeCommand;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class CEOcoManager {

    private final Map<String, OcoGroup> ocoGroups = new ConcurrentHashMap<>();
    private final Map<String, Integer> robotSequences = new ConcurrentHashMap<>();
    private TradeHistoryCache tradeHistoryCache;

    public void setTradeHistoryCache(TradeHistoryCache cache) {
        this.tradeHistoryCache = cache;
    }

    public void registerOcoGroup(String magicNumber, String robotName, int sequence) {
        OcoGroup group = new OcoGroup(magicNumber, robotName, sequence);
        ocoGroups.put(magicNumber, group);
        robotSequences.put(robotName, sequence + 1);
    }

    public int getNextSequenceForRobot(String robotName) {
        return robotSequences.getOrDefault(robotName, 0);
    }

    public Optional<TradeCommand> handleOcoFill(TradeCommand filledCommand) {
        String magic = filledCommand.getMagicNumber();
        OcoGroup group = ocoGroups.get(magic);

        if (group == null) {
            return Optional.empty();
        }

        Map<String, Object> params = filledCommand.getParameters();
        String orderType = (String) params.get("order_type");
        String side = extractSide(orderType);
        String oppositeSide = side.equals("BUY") ? "SELL" : "BUY";
        String symbol = (String) params.get("symbol");

        Map<String, Object> deleteParams = new HashMap<>();
        deleteParams.put("symbol", symbol);
        deleteParams.put("side", oppositeSide);
        deleteParams.put("magic", magic);

        TradeCommand deleteCommand = new TradeCommand(
            filledCommand.getRobotConfigId(),
            magic,
            "DELETE_OPPOSITE_SIDE",
            deleteParams
        );

        return Optional.of(deleteCommand);
    }

    private String extractSide(String orderType) {
        if (orderType.startsWith("BUY")) return "BUY";
        if (orderType.startsWith("SELL")) return "SELL";
        return "";
    }

    private static class OcoGroup {
        final String magicNumber;
        final String robotName;
        final int sequence;
        boolean buyFilled = false;
        boolean sellFilled = false;

        OcoGroup(String magicNumber, String robotName, int sequence) {
            this.magicNumber = magicNumber;
            this.robotName = robotName;
            this.sequence = sequence;
        }
    }
}
