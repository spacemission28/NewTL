package com.tradelogic.services;

import com.tradelogic.Logger;
import com.tradelogic.models.ExecutionFeedback;
import com.tradelogic.models.TradeCommand;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * DEFINITIVE OCO SOLUTION - Watches for filled orders and executes OCO cancellation
 *
 * This helper's ONLY JOB:
 * 1. Listen for FILLED pending orders for each active robot
 * 2. When a fill is detected, identify the order TYPE (BUY or SELL)
 * 3. IMMEDIATELY delete ALL orders with same magic number BUT opposite type
 *
 * No complex timeout logic. No command ID tracking. Just watch fills and execute OCO.
 */
public class OcoFillWatcher {
    private static OcoFillWatcher instance;

    // Map: magicNumber -> Set of pending order ticket numbers
    private final Map<String, Set<String>> activePendingOrders = new ConcurrentHashMap<>();

    // Map: magicNumber -> order type that filled (BUY or SELL)
    private final Map<String, String> filledOrderTypes = new ConcurrentHashMap<>();

    private boolean isWatching = false;
    private TradeCommandQueue commandQueue;

    private OcoFillWatcher() {}

    public static synchronized OcoFillWatcher getInstance() {
        if (instance == null) {
            instance = new OcoFillWatcher();
        }
        return instance;
    }

    public void setCommandQueue(TradeCommandQueue queue) {
        this.commandQueue = queue;
    }

    /**
     * Start watching for fills (called when Master ON button is pressed)
     */
    public void startWatching() {
        isWatching = true;
        Logger.info("OCO FILL WATCHER: Started watching for order fills");
    }

    /**
     * Stop watching (called when Master is MUTED)
     */
    public void stopWatching() {
        isWatching = false;
        activePendingOrders.clear();
        filledOrderTypes.clear();
        Logger.info("OCO FILL WATCHER: Stopped watching - cleared all tracking");
    }

    /**
     * Register a new pending order for a magic number
     * Called immediately after order placement succeeds
     */
    public void registerPendingOrder(String magicNumber, String ticket, String orderType) {
        if (!isWatching) return;

        activePendingOrders.computeIfAbsent(magicNumber, k -> ConcurrentHashMap.newKeySet())
                          .add(ticket);
    }

    /**
     * Process order fill notification from MT5
     * This is THE CRITICAL METHOD - when an order fills, cancel opposite side
     */
    public void processOrderFill(ExecutionFeedback feedback) {
        if (!isWatching) return;

        String magicNumber = feedback.getMagicNumber();
        Object orderTypeObj = feedback.getDetail("order_type");

        if (magicNumber == null || orderTypeObj == null) {
            return;
        }

        String orderType = orderTypeObj.toString(); // "BUY_STOP" or "SELL_STOP"

        // Check if this magic number has pending orders
        Set<String> pendingTickets = activePendingOrders.get(magicNumber);
        if (pendingTickets == null || pendingTickets.isEmpty()) {
            return;
        }

        // Determine filled type (BUY or SELL)
        String filledType = orderType.startsWith("BUY") ? "BUY" : "SELL";

        Logger.info("★★★ OCO FILL DETECTED: Magic " + magicNumber + " - " + filledType + " order filled");
        Logger.info("★★★ OCO: Cancelling ALL " + (filledType.equals("BUY") ? "SELL" : "BUY") + " orders for magic " + magicNumber);

        // Store the filled type
        filledOrderTypes.put(magicNumber, filledType);

        // Execute OCO cancellation - delete opposite side orders
        executeOcoCancellation(magicNumber, filledType);
    }

    /**
     * Execute OCO cancellation - delete all opposite side orders
     */
    private void executeOcoCancellation(String magicNumber, String filledType) {
        Set<String> pendingTickets = activePendingOrders.get(magicNumber);
        if (pendingTickets == null || pendingTickets.isEmpty()) {
            Logger.warning("OCO: No pending orders found for magic " + magicNumber);
            return;
        }

        // Determine opposite type to cancel
        String oppositeType = filledType.equals("BUY") ? "SELL_STOP" : "BUY_STOP";

        // Create a single bulk delete command for opposite side
        Map<String, Object> params = new HashMap<>();
        params.put("magic_number", magicNumber);
        params.put("order_type", oppositeType);

        TradeCommand deleteCommand = new TradeCommand(null, magicNumber, "DELETE_OPPOSITE_SIDE", params);

        // Queue the delete command with HIGH priority
        if (commandQueue != null) {
            Logger.info("★★★ OCO: Queueing bulk DELETE command for " + oppositeType + " orders (Magic: " + magicNumber + ")");
            commandQueue.addFirst(deleteCommand);
        }

        // Clear pending orders for this magic number
        activePendingOrders.remove(magicNumber);
        Logger.info("OCO: Cleared pending orders tracking for magic " + magicNumber);
    }

    /**
     * Remove a ticket from tracking (called when order is manually cancelled or expires)
     */
    public void removePendingOrder(String magicNumber, String ticket) {
        Set<String> tickets = activePendingOrders.get(magicNumber);
        if (tickets != null) {
            tickets.remove(ticket);
            if (tickets.isEmpty()) {
                activePendingOrders.remove(magicNumber);
            }
        }
    }

    /**
     * Check if a magic number has already had an order filled
     */
    public boolean hasOrderFilled(String magicNumber) {
        return filledOrderTypes.containsKey(magicNumber);
    }

    /**
     * Get the type of order that filled for a magic number
     */
    public String getFilledOrderType(String magicNumber) {
        return filledOrderTypes.get(magicNumber);
    }

    /**
     * Clear fill status for a magic number (called when robot is reset)
     */
    public void clearFillStatus(String magicNumber) {
        filledOrderTypes.remove(magicNumber);
        activePendingOrders.remove(magicNumber);
    }

    public boolean isWatching() {
        return isWatching;
    }

    /**
     * Get count of magic numbers being tracked
     */
    public int getTrackedMagicCount() {
        return activePendingOrders.size();
    }

    /**
     * Get total pending orders being tracked
     */
    public int getTotalPendingOrders() {
        return activePendingOrders.values().stream()
            .mapToInt(Set::size)
            .sum();
    }
}
