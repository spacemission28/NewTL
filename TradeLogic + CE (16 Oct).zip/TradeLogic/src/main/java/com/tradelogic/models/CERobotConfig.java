package com.tradelogic.models;

import java.time.Instant;

/**
 * Model class representing a Continuous Entry (C.E.) robot configuration.
 * Maps to the ce_robot_configs table in Supabase.
 *
 * C.E. robots use the SAME calculation logic as Trade Logic robots:
 * - Min X1 Height and X1 Type
 * - Trig % and SL %
 * - RPT % and RPT Fixed Amount
 * - TP1-7 with percentages and volumes
 *
 * The difference is WHEN orders are placed:
 * - Trade Logic: Places orders ONCE per signal candle
 * - C.E.: Places orders CONTINUOUSLY using sequential magic numbers
 */
public class CERobotConfig {
    private Long id;
    private String robotName;
    private String symbol;
    private boolean masterEnabled;
    private int ceMagicBase;
    private int ceMaxSequence;
    private String timeframe;
    private int closeHour;
    private int closeMinute;

    private double minX1Height;
    private String x1Type;
    private double trigPercent;
    private double stopLossPercent;
    private Double rptPercent;
    private Double rptFixedAmount;
    private double dailyDdLimit;

    private double tp1Percent;
    private int tp1Volume;
    private double tp2Percent;
    private int tp2Volume;
    private double tp3Percent;
    private int tp3Volume;
    private double tp4Percent;
    private int tp4Volume;
    private double tp5Percent;
    private int tp5Volume;
    private double tp6Percent;
    private int tp6Volume;
    private double tp7Percent;
    private int tp7Volume;

    private boolean commissionsEnabled;
    private String commissionType;
    private Double commissionValue;

    private boolean disableLeapfrog;

    private Instant createdAt;
    private Instant updatedAt;

    public CERobotConfig() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRobotName() {
        return robotName;
    }

    public void setRobotName(String robotName) {
        this.robotName = robotName;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public boolean isMasterEnabled() {
        return masterEnabled;
    }

    public void setMasterEnabled(boolean masterEnabled) {
        this.masterEnabled = masterEnabled;
    }

    public int getCeMagicBase() {
        return ceMagicBase;
    }

    public void setCeMagicBase(int ceMagicBase) {
        this.ceMagicBase = ceMagicBase;
    }

    public int getCeMaxSequence() {
        return ceMaxSequence;
    }

    public void setCeMaxSequence(int ceMaxSequence) {
        this.ceMaxSequence = ceMaxSequence;
    }

    public String getTimeframe() {
        return timeframe;
    }

    public void setTimeframe(String timeframe) {
        this.timeframe = timeframe;
    }

    public int getCloseHour() {
        return closeHour;
    }

    public void setCloseHour(int closeHour) {
        this.closeHour = closeHour;
    }

    public int getCloseMinute() {
        return closeMinute;
    }

    public void setCloseMinute(int closeMinute) {
        this.closeMinute = closeMinute;
    }

    public double getMinX1Height() {
        return minX1Height;
    }

    public void setMinX1Height(double minX1Height) {
        this.minX1Height = minX1Height;
    }

    public String getX1Type() {
        return x1Type;
    }

    public void setX1Type(String x1Type) {
        this.x1Type = x1Type;
    }

    public double getTrigPercent() {
        return trigPercent;
    }

    public void setTrigPercent(double trigPercent) {
        this.trigPercent = trigPercent;
    }

    public double getStopLossPercent() {
        return stopLossPercent;
    }

    public void setStopLossPercent(double stopLossPercent) {
        this.stopLossPercent = stopLossPercent;
    }

    public Double getRptPercent() {
        return rptPercent;
    }

    public void setRptPercent(Double rptPercent) {
        this.rptPercent = rptPercent;
    }

    public Double getRptFixedAmount() {
        return rptFixedAmount;
    }

    public void setRptFixedAmount(Double rptFixedAmount) {
        this.rptFixedAmount = rptFixedAmount;
    }

    public double getDailyDdLimit() {
        return dailyDdLimit;
    }

    public void setDailyDdLimit(double dailyDdLimit) {
        this.dailyDdLimit = dailyDdLimit;
    }

    public double getTp1Percent() {
        return tp1Percent;
    }

    public void setTp1Percent(double tp1Percent) {
        this.tp1Percent = tp1Percent;
    }

    public int getTp1Volume() {
        return tp1Volume;
    }

    public void setTp1Volume(int tp1Volume) {
        this.tp1Volume = tp1Volume;
    }

    public double getTp2Percent() {
        return tp2Percent;
    }

    public void setTp2Percent(double tp2Percent) {
        this.tp2Percent = tp2Percent;
    }

    public int getTp2Volume() {
        return tp2Volume;
    }

    public void setTp2Volume(int tp2Volume) {
        this.tp2Volume = tp2Volume;
    }

    public double getTp3Percent() {
        return tp3Percent;
    }

    public void setTp3Percent(double tp3Percent) {
        this.tp3Percent = tp3Percent;
    }

    public int getTp3Volume() {
        return tp3Volume;
    }

    public void setTp3Volume(int tp3Volume) {
        this.tp3Volume = tp3Volume;
    }

    public double getTp4Percent() {
        return tp4Percent;
    }

    public void setTp4Percent(double tp4Percent) {
        this.tp4Percent = tp4Percent;
    }

    public int getTp4Volume() {
        return tp4Volume;
    }

    public void setTp4Volume(int tp4Volume) {
        this.tp4Volume = tp4Volume;
    }

    public double getTp5Percent() {
        return tp5Percent;
    }

    public void setTp5Percent(double tp5Percent) {
        this.tp5Percent = tp5Percent;
    }

    public int getTp5Volume() {
        return tp5Volume;
    }

    public void setTp5Volume(int tp5Volume) {
        this.tp5Volume = tp5Volume;
    }

    public double getTp6Percent() {
        return tp6Percent;
    }

    public void setTp6Percent(double tp6Percent) {
        this.tp6Percent = tp6Percent;
    }

    public int getTp6Volume() {
        return tp6Volume;
    }

    public void setTp6Volume(int tp6Volume) {
        this.tp6Volume = tp6Volume;
    }

    public double getTp7Percent() {
        return tp7Percent;
    }

    public void setTp7Percent(double tp7Percent) {
        this.tp7Percent = tp7Percent;
    }

    public int getTp7Volume() {
        return tp7Volume;
    }

    public void setTp7Volume(int tp7Volume) {
        this.tp7Volume = tp7Volume;
    }

    public boolean isCommissionsEnabled() {
        return commissionsEnabled;
    }

    public void setCommissionsEnabled(boolean commissionsEnabled) {
        this.commissionsEnabled = commissionsEnabled;
    }

    public String getCommissionType() {
        return commissionType;
    }

    public void setCommissionType(String commissionType) {
        this.commissionType = commissionType;
    }

    public Double getCommissionValue() {
        return commissionValue;
    }

    public void setCommissionValue(Double commissionValue) {
        this.commissionValue = commissionValue;
    }

    public boolean isDisableLeapfrog() {
        return disableLeapfrog;
    }

    public void setDisableLeapfrog(boolean disableLeapfrog) {
        this.disableLeapfrog = disableLeapfrog;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    /**
     * Calculates the magic number for a specific sequence level
     * @param sequenceLevel The sequence level (0 = base, 1 = first increment, etc.)
     * @return The magic number string for this sequence
     */
    public String getMagicNumberForSequence(int sequenceLevel) {
        return String.valueOf(ceMagicBase + sequenceLevel);
    }

    /**
     * Checks if C.E. robot is fully enabled
     */
    public boolean isFullyEnabled() {
        return masterEnabled;
    }

    /**
     * Validates that TP volumes sum to 100%
     * @return true if valid, false otherwise
     */
    public boolean validateTPVolumes() {
        int total = tp1Volume + tp2Volume + tp3Volume + tp4Volume +
                   tp5Volume + tp6Volume + tp7Volume;
        return total == 100;
    }
}
