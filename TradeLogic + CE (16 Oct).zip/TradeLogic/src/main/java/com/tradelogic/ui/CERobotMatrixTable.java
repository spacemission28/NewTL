package com.tradelogic.ui;

import com.tradelogic.Logger;
import com.tradelogic.models.CERobotConfig;
import javafx.application.Platform;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.VBox;
import javafx.util.StringConverter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CERobotMatrixTable extends VBox {
    private final TableView<CERobotRow> table;
    private final ObservableList<CERobotRow> rows;
    private Set<Integer> lockedRows = new HashSet<>();
    private boolean masterEnabled = false;
    private CERobotConfig defaultValues;

    public CERobotMatrixTable() {
        this.rows = FXCollections.observableArrayList();
        this.table = createTable();
        getChildren().add(table);
    }

    private TableView<CERobotRow> createTable() {
        TableView<CERobotRow> tbl = new TableView<>();
        tbl.setEditable(true);
        tbl.setItems(rows);
        tbl.setStyle("-fx-alignment: CENTER;");

        // #
        TableColumn<CERobotRow, Number> idCol = new TableColumn<>("#");
        idCol.setCellValueFactory(data -> data.getValue().rowNumber);
        idCol.setMinWidth(40);
        idCol.setMaxWidth(50);

        // Checkbox (Master Enable)
        TableColumn<CERobotRow, Boolean> masterCol = new TableColumn<>("Master");
        masterCol.setCellValueFactory(data -> data.getValue().masterEnabled);
        masterCol.setCellFactory(CheckBoxTableCell.forTableColumn(masterCol));
        masterCol.setMinWidth(60);
        masterCol.setMaxWidth(70);

        // C.E Magic (Integer)
        TableColumn<CERobotRow, Number> ceMagicCol = new TableColumn<>("C.E Magic");
        ceMagicCol.setCellValueFactory(data -> data.getValue().ceMagicBase);
        ceMagicCol.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.IntegerNumberConverter()));
        ceMagicCol.setMinWidth(80);
        ceMagicCol.setMaxWidth(90);
        ceMagicCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().ceMagicBase.set(e.getNewValue().intValue());
        });

        // Robot Name
        TableColumn<CERobotRow, String> nameCol = new TableColumn<>("Robot Name");
        nameCol.setCellValueFactory(data -> data.getValue().robotName);
        nameCol.setCellFactory(col -> createCommittingCell(new javafx.util.StringConverter<String>() {
            @Override
            public String toString(String object) {
                return object == null ? "" : object;
            }
            @Override
            public String fromString(String string) {
                return string;
            }
        }));
        nameCol.setMinWidth(120);
        nameCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().robotName.set(e.getNewValue());
        });

        // Symbol
        TableColumn<CERobotRow, String> symbolCol = new TableColumn<>("Symbol");
        symbolCol.setCellValueFactory(data -> data.getValue().symbol);
        symbolCol.setCellFactory(col -> createCommittingCell(new javafx.util.StringConverter<String>() {
            @Override
            public String toString(String object) {
                return object == null ? "" : object;
            }
            @Override
            public String fromString(String string) {
                return string;
            }
        }));
        symbolCol.setMinWidth(80);
        symbolCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().symbol.set(e.getNewValue());
        });

        // Max Seq
        TableColumn<CERobotRow, Number> maxSeqCol = new TableColumn<>("Max Seq");
        maxSeqCol.setCellValueFactory(data -> data.getValue().ceMaxSequence);
        maxSeqCol.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.IntegerNumberConverter()));
        maxSeqCol.setMinWidth(70);
        maxSeqCol.setMaxWidth(80);
        maxSeqCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().ceMaxSequence.set(e.getNewValue().intValue());
        });

        // TF (Timeframe) - Dropdown
        TableColumn<CERobotRow, String> tfCol = new TableColumn<>("TF");
        tfCol.setCellValueFactory(data -> data.getValue().timeframe);
        tfCol.setCellFactory(ComboBoxTableCell.forTableColumn("M1", "M2", "M3", "M5", "M10", "M15", "M30", "H1", "H3", "H4", "D1"));
        tfCol.setMinWidth(50);
        tfCol.setMaxWidth(60);
        tfCol.setOnEditCommit(e -> {
            CERobotRow row = e.getRowValue();
            if (masterEnabled && lockedRows.contains(row.rowNumber.get())) {
                return;
            }
            e.getRowValue().timeframe.set(e.getNewValue());
        });

        // Hr (Hour) - Dropdown (0-23)
        TableColumn<CERobotRow, Number> hrCol = new TableColumn<>("Hr");
        hrCol.setCellValueFactory(data -> data.getValue().closeHour);
        Integer[] hours = new Integer[24];
        for (int i = 0; i < 24; i++) hours[i] = i;
        hrCol.setCellFactory(ComboBoxTableCell.forTableColumn(hours));
        hrCol.setMinWidth(50);
        hrCol.setMaxWidth(60);
        hrCol.setOnEditCommit(e -> {
            CERobotRow row = e.getRowValue();
            if (masterEnabled && lockedRows.contains(row.rowNumber.get())) {
                return;
            }
            e.getRowValue().closeHour.set(e.getNewValue().intValue());
        });

        // Min (Minute) - Dropdown (0-59)
        TableColumn<CERobotRow, Number> minCol = new TableColumn<>("Min");
        minCol.setCellValueFactory(data -> data.getValue().closeMinute);
        Integer[] minutes = new Integer[60];
        for (int i = 0; i < 60; i++) minutes[i] = i;
        minCol.setCellFactory(ComboBoxTableCell.forTableColumn(minutes));
        minCol.setMinWidth(50);
        minCol.setMaxWidth(60);
        minCol.setOnEditCommit(e -> {
            CERobotRow row = e.getRowValue();
            if (masterEnabled && lockedRows.contains(row.rowNumber.get())) {
                return;
            }
            e.getRowValue().closeMinute.set(e.getNewValue().intValue());
        });

        // Min X1
        TableColumn<CERobotRow, Number> minX1Col = new TableColumn<>("Min X1");
        minX1Col.setCellValueFactory(data -> data.getValue().minX1Height);
        minX1Col.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.DoubleNumberConverter()));
        minX1Col.setMinWidth(70);
        minX1Col.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().minX1Height.set(e.getNewValue().doubleValue());
        });

        // X1 Type - Dropdown
        TableColumn<CERobotRow, String> x1TypeCol = new TableColumn<>("X1 Type");
        x1TypeCol.setCellValueFactory(data -> data.getValue().x1Type);
        x1TypeCol.setCellFactory(ComboBoxTableCell.forTableColumn("Yen Pips", "Non-Yen Pips", "Cents", "Points"));
        x1TypeCol.setMinWidth(100);
        x1TypeCol.setOnEditCommit(e -> {
            CERobotRow row = e.getRowValue();
            if (masterEnabled && lockedRows.contains(row.rowNumber.get())) {
                return;
            }
            e.getRowValue().x1Type.set(e.getNewValue());
        });

        // Trig %
        TableColumn<CERobotRow, Number> trigCol = new TableColumn<>("Trig %");
        trigCol.setCellValueFactory(data -> data.getValue().trigPercent);
        trigCol.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.DoubleNumberConverter()));
        trigCol.setMinWidth(70);
        trigCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().trigPercent.set(e.getNewValue().doubleValue());
        });

        // SL %
        TableColumn<CERobotRow, Number> slCol = new TableColumn<>("SL %");
        slCol.setCellValueFactory(data -> data.getValue().stopLossPercent);
        slCol.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.DoubleNumberConverter()));
        slCol.setMinWidth(70);
        slCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().stopLossPercent.set(e.getNewValue().doubleValue());
        });

        // RPT %
        TableColumn<CERobotRow, Number> rptPercentCol = new TableColumn<>("RPT %");
        rptPercentCol.setCellValueFactory(data -> data.getValue().rptPercent);
        rptPercentCol.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.DoubleNumberConverter()));
        rptPercentCol.setMinWidth(70);
        rptPercentCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().rptPercent.set(e.getNewValue().doubleValue());
        });

        // RPT $
        TableColumn<CERobotRow, Number> rptDollarCol = new TableColumn<>("RPT $");
        rptDollarCol.setCellValueFactory(data -> data.getValue().rptFixedAmount);
        rptDollarCol.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.DoubleNumberConverter()));
        rptDollarCol.setMinWidth(70);
        rptDollarCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().rptFixedAmount.set(e.getNewValue().doubleValue());
        });

        // TP1%, TP1 Vol
        TableColumn<CERobotRow, Number> tp1PercentCol = new TableColumn<>("TP1%");
        tp1PercentCol.setCellValueFactory(data -> data.getValue().tp1Percent);
        tp1PercentCol.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.DoubleNumberConverter()));
        tp1PercentCol.setMinWidth(70);
        tp1PercentCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().tp1Percent.set(e.getNewValue().doubleValue());
        });

        TableColumn<CERobotRow, Number> tp1VolCol = new TableColumn<>("TP1 Vol");
        tp1VolCol.setCellValueFactory(data -> data.getValue().tp1Volume);
        tp1VolCol.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.IntegerNumberConverter()));
        tp1VolCol.setMinWidth(70);
        tp1VolCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().tp1Volume.set(e.getNewValue().intValue());
        });

        // TP2%, TP2 Vol
        TableColumn<CERobotRow, Number> tp2PercentCol = new TableColumn<>("TP2%");
        tp2PercentCol.setCellValueFactory(data -> data.getValue().tp2Percent);
        tp2PercentCol.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.DoubleNumberConverter()));
        tp2PercentCol.setMinWidth(70);
        tp2PercentCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().tp2Percent.set(e.getNewValue().doubleValue());
        });

        TableColumn<CERobotRow, Number> tp2VolCol = new TableColumn<>("TP2 Vol");
        tp2VolCol.setCellValueFactory(data -> data.getValue().tp2Volume);
        tp2VolCol.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.IntegerNumberConverter()));
        tp2VolCol.setMinWidth(70);
        tp2VolCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().tp2Volume.set(e.getNewValue().intValue());
        });

        // TP3%, TP3 Vol
        TableColumn<CERobotRow, Number> tp3PercentCol = new TableColumn<>("TP3%");
        tp3PercentCol.setCellValueFactory(data -> data.getValue().tp3Percent);
        tp3PercentCol.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.DoubleNumberConverter()));
        tp3PercentCol.setMinWidth(70);
        tp3PercentCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().tp3Percent.set(e.getNewValue().doubleValue());
        });

        TableColumn<CERobotRow, Number> tp3VolCol = new TableColumn<>("TP3 Vol");
        tp3VolCol.setCellValueFactory(data -> data.getValue().tp3Volume);
        tp3VolCol.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.IntegerNumberConverter()));
        tp3VolCol.setMinWidth(70);
        tp3VolCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().tp3Volume.set(e.getNewValue().intValue());
        });

        // TP4%, TP4 Vol
        TableColumn<CERobotRow, Number> tp4PercentCol = new TableColumn<>("TP4%");
        tp4PercentCol.setCellValueFactory(data -> data.getValue().tp4Percent);
        tp4PercentCol.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.DoubleNumberConverter()));
        tp4PercentCol.setMinWidth(70);
        tp4PercentCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().tp4Percent.set(e.getNewValue().doubleValue());
        });

        TableColumn<CERobotRow, Number> tp4VolCol = new TableColumn<>("TP4 Vol");
        tp4VolCol.setCellValueFactory(data -> data.getValue().tp4Volume);
        tp4VolCol.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.IntegerNumberConverter()));
        tp4VolCol.setMinWidth(70);
        tp4VolCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().tp4Volume.set(e.getNewValue().intValue());
        });

        // TP5%, TP5 Vol
        TableColumn<CERobotRow, Number> tp5PercentCol = new TableColumn<>("TP5%");
        tp5PercentCol.setCellValueFactory(data -> data.getValue().tp5Percent);
        tp5PercentCol.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.DoubleNumberConverter()));
        tp5PercentCol.setMinWidth(70);
        tp5PercentCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().tp5Percent.set(e.getNewValue().doubleValue());
        });

        TableColumn<CERobotRow, Number> tp5VolCol = new TableColumn<>("TP5 Vol");
        tp5VolCol.setCellValueFactory(data -> data.getValue().tp5Volume);
        tp5VolCol.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.IntegerNumberConverter()));
        tp5VolCol.setMinWidth(70);
        tp5VolCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().tp5Volume.set(e.getNewValue().intValue());
        });

        // TP6%, TP6 Vol
        TableColumn<CERobotRow, Number> tp6PercentCol = new TableColumn<>("TP6%");
        tp6PercentCol.setCellValueFactory(data -> data.getValue().tp6Percent);
        tp6PercentCol.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.DoubleNumberConverter()));
        tp6PercentCol.setMinWidth(70);
        tp6PercentCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().tp6Percent.set(e.getNewValue().doubleValue());
        });

        TableColumn<CERobotRow, Number> tp6VolCol = new TableColumn<>("TP6 Vol");
        tp6VolCol.setCellValueFactory(data -> data.getValue().tp6Volume);
        tp6VolCol.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.IntegerNumberConverter()));
        tp6VolCol.setMinWidth(70);
        tp6VolCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().tp6Volume.set(e.getNewValue().intValue());
        });

        // TP7%, TP7 Vol
        TableColumn<CERobotRow, Number> tp7PercentCol = new TableColumn<>("TP7%");
        tp7PercentCol.setCellValueFactory(data -> data.getValue().tp7Percent);
        tp7PercentCol.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.DoubleNumberConverter()));
        tp7PercentCol.setMinWidth(70);
        tp7PercentCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().tp7Percent.set(e.getNewValue().doubleValue());
        });

        TableColumn<CERobotRow, Number> tp7VolCol = new TableColumn<>("TP7 Vol");
        tp7VolCol.setCellValueFactory(data -> data.getValue().tp7Volume);
        tp7VolCol.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.IntegerNumberConverter()));
        tp7VolCol.setMinWidth(70);
        tp7VolCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().tp7Volume.set(e.getNewValue().intValue());
        });

        // Comm Enabled
        TableColumn<CERobotRow, Boolean> commEnabledCol = new TableColumn<>("Comm Enabled");
        commEnabledCol.setCellValueFactory(data -> data.getValue().commissionsEnabled);
        commEnabledCol.setCellFactory(CheckBoxTableCell.forTableColumn(commEnabledCol));
        commEnabledCol.setMinWidth(90);

        // Comm Type - Dropdown
        TableColumn<CERobotRow, String> commTypeCol = new TableColumn<>("Comm Type");
        commTypeCol.setCellValueFactory(data -> data.getValue().commissionType);
        commTypeCol.setCellFactory(ComboBoxTableCell.forTableColumn("No_Commissions", "FX_per_Lot", "ETF_Stock"));
        commTypeCol.setMinWidth(130);
        commTypeCol.setOnEditCommit(e -> {
            CERobotRow row = e.getRowValue();
            if (masterEnabled && lockedRows.contains(row.rowNumber.get())) {
                return;
            }
            e.getRowValue().commissionType.set(e.getNewValue());
        });

        // Comm Value
        TableColumn<CERobotRow, Number> commValueCol = new TableColumn<>("Comm Value");
        commValueCol.setCellValueFactory(data -> data.getValue().commissionValue);
        commValueCol.setCellFactory(TextFieldTableCell.forTableColumn(new NumberConverters.DoubleNumberConverter()));
        commValueCol.setMinWidth(90);
        commValueCol.setOnEditCommit(e -> {
            if (isRowLocked(e.getRowValue())) return;
            e.getRowValue().commissionValue.set(e.getNewValue().doubleValue());
        });

        // Disable Leapfrog
        TableColumn<CERobotRow, Boolean> leapfrogCol = new TableColumn<>("Disable Leapfrog");
        leapfrogCol.setCellValueFactory(data -> data.getValue().disableLeapfrog);
        leapfrogCol.setCellFactory(CheckBoxTableCell.forTableColumn(leapfrogCol));
        leapfrogCol.setMinWidth(110);

        tbl.getColumns().addAll(
            idCol, masterCol, ceMagicCol, nameCol, symbolCol, maxSeqCol, tfCol, hrCol, minCol,
            minX1Col, x1TypeCol, trigCol, slCol, rptPercentCol, rptDollarCol,
            tp1PercentCol, tp1VolCol, tp2PercentCol, tp2VolCol, tp3PercentCol, tp3VolCol,
            tp4PercentCol, tp4VolCol, tp5PercentCol, tp5VolCol, tp6PercentCol, tp6VolCol,
            tp7PercentCol, tp7VolCol, commEnabledCol, commTypeCol, commValueCol, leapfrogCol
        );

        // Center-align all columns
        for (TableColumn<CERobotRow, ?> col : tbl.getColumns()) {
            col.setStyle("-fx-alignment: CENTER;");
        }

        // Add listener to commit edit when clicking outside the table
        tbl.focusedProperty().addListener((obs, wasFocused, isNowFocused) -> {
            if (wasFocused && !isNowFocused) {
                // Table lost focus, commit any pending edits
                tbl.getSelectionModel().clearSelection();
            }
        });

        // Add context menu for right-click on rows and row highlighting
        tbl.setRowFactory(tv -> {
            TableRow<CERobotRow> row = new TableRow<CERobotRow>() {
                @Override
                protected void updateItem(CERobotRow item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setStyle("");
                    } else {
                        if (item.masterEnabled.get()) {
                            setStyle("-fx-background-color: lightblue;");
                        } else {
                            setStyle("");
                        }

                        item.masterEnabled.addListener((obs, wasChecked, isChecked) -> {
                            if (isChecked) {
                                setStyle("-fx-background-color: lightblue;");
                                applyDefaultsToRow(item);
                            } else {
                                setStyle("");
                            }
                        });
                    }
                }
            };

            row.setOnContextMenuRequested(event -> {
                if (row.getItem() != null) {
                    ContextMenu menu = createRowContextMenu(row.getItem());
                    menu.show(row, event.getScreenX(), event.getScreenY());
                }
            });
            return row;
        });

        return tbl;
    }

    public void loadConfigs(List<CERobotConfig> configs) {
        rows.clear();
        for (int i = 0; i < configs.size(); i++) {
            rows.add(new CERobotRow(i + 1, configs.get(i)));
        }
    }

    public List<CERobotConfig> getAllConfigs() {
        List<CERobotConfig> configs = new ArrayList<>();
        for (CERobotRow row : rows) {
            configs.add(row.toConfig());
        }
        return configs;
    }

    public void addNewRow(CERobotConfig config) {
        int nextRowNum = rows.size() + 1;
        rows.add(new CERobotRow(nextRowNum, config));
    }

    public CERobotRow getSelectedRow() {
        return table.getSelectionModel().getSelectedItem();
    }

    public void deleteRow(CERobotRow row) {
        rows.remove(row);
        renumberRows();
    }

    private void renumberRows() {
        for (int i = 0; i < rows.size(); i++) {
            rows.get(i).rowNumber.set(i + 1);
        }
    }

    public void setDefaultValues(CERobotConfig defaults) {
        this.defaultValues = defaults;
        for (CERobotRow row : rows) {
            row.applyDefaults(defaults);
        }
    }

    public void updateDefaultValues(CERobotConfig defaults) {
        this.defaultValues = defaults;
        Logger.info("Default values updated (not applied to existing robots)");
    }

    private void applyDefaultsToRow(CERobotRow row) {
        if (defaultValues != null && isRowEmpty(row)) {
            row.applyDefaults(defaultValues);
            table.refresh();
            Logger.info("Applied defaults to row " + row.rowNumber.get());
        } else if (defaultValues != null && !isRowEmpty(row)) {
            Logger.info("Row " + row.rowNumber.get() + " has custom values - defaults NOT applied");
        }
    }

    private boolean isRowEmpty(CERobotRow row) {
        // Check if key fields are empty/default
        boolean robotNameEmpty = row.robotName.get() == null || row.robotName.get().isEmpty();
        boolean symbolEmpty = row.symbol.get() == null || row.symbol.get().isEmpty();
        boolean ceMagicZero = row.ceMagicBase.get() == 0;

        // Row is considered "empty" if these critical fields are not set
        return robotNameEmpty && symbolEmpty && ceMagicZero;
    }

    public void setMasterEnabled(boolean enabled) {
        this.masterEnabled = enabled;
        updateLockedRows();
        table.refresh();
    }

    private void updateLockedRows() {
        lockedRows.clear();
        if (masterEnabled) {
            for (CERobotRow row : rows) {
                if (row.masterEnabled.get()) {
                    lockedRows.add(row.rowNumber.get());
                }
            }
        }
    }

    private boolean isRowLocked(CERobotRow row) {
        return row != null && masterEnabled && lockedRows.contains(row.rowNumber.get());
    }

    private ContextMenu createRowContextMenu(CERobotRow row) {
        ContextMenu menu = new ContextMenu();
        menu.setStyle("-fx-background-color: white; -fx-text-fill: black;");

        MenuItem fillDownItem = new MenuItem("Fill Down (from this row to bottom)");
        fillDownItem.setStyle("-fx-text-fill: black;");
        fillDownItem.setOnAction(e -> fillDown(row));

        MenuItem duplicateRowItem = new MenuItem("Duplicate Row Below");
        duplicateRowItem.setStyle("-fx-text-fill: black;");
        duplicateRowItem.setOnAction(e -> duplicateRow(row));

        MenuItem clearRowItem = new MenuItem("Clear This Row");
        clearRowItem.setStyle("-fx-text-fill: black;");
        clearRowItem.setOnAction(e -> clearRow(row));

        MenuItem clearAllRowsItem = new MenuItem("Clear All Rows (from this row to bottom)");
        clearAllRowsItem.setStyle("-fx-text-fill: black;");
        clearAllRowsItem.setOnAction(e -> clearAllRows(row));

        MenuItem deleteRowItem = new MenuItem("Delete This Row");
        deleteRowItem.setStyle("-fx-text-fill: black;");
        deleteRowItem.setOnAction(e -> deleteRow(row));

        menu.getItems().addAll(fillDownItem, duplicateRowItem, new SeparatorMenuItem(), clearRowItem, clearAllRowsItem, deleteRowItem);
        return menu;
    }

    private void fillDown(CERobotRow sourceRow) {
        int startIndex = rows.indexOf(sourceRow);
        if (startIndex < 0) return;

        for (int i = startIndex + 1; i < rows.size(); i++) {
            CERobotRow target = rows.get(i);
            copyRowData(sourceRow, target);
        }
        table.refresh();
        Logger.info("Filled down from row " + sourceRow.rowNumber.get());
    }

    private void duplicateRow(CERobotRow sourceRow) {
        CERobotConfig config = sourceRow.toConfig();
        config.setId(null);
        config.setRobotName(sourceRow.robotName.get() + " (Copy)");
        int insertIndex = rows.indexOf(sourceRow) + 1;
        rows.add(insertIndex, new CERobotRow(insertIndex + 1, config));
        renumberRows();
        Logger.info("Duplicated row " + sourceRow.rowNumber.get());
    }

    private void clearRow(CERobotRow row) {
        row.masterEnabled.set(false);
        row.ceMagicBase.set(0);
        row.robotName.set("");
        row.symbol.set("");
        row.ceMaxSequence.set(0);
        row.timeframe.set("");
        row.closeHour.set(0);
        row.closeMinute.set(0);
        row.minX1Height.set(0.0);
        row.x1Type.set("");
        row.trigPercent.set(0.0);
        row.stopLossPercent.set(0.0);
        row.rptPercent.set(0.0);
        row.rptFixedAmount.set(0.0);
        row.tp1Percent.set(0.0);
        row.tp1Volume.set(0);
        row.tp2Percent.set(0.0);
        row.tp2Volume.set(0);
        row.tp3Percent.set(0.0);
        row.tp3Volume.set(0);
        row.tp4Percent.set(0.0);
        row.tp4Volume.set(0);
        row.tp5Percent.set(0.0);
        row.tp5Volume.set(0);
        row.tp6Percent.set(0.0);
        row.tp6Volume.set(0);
        row.tp7Percent.set(0.0);
        row.tp7Volume.set(0);
        row.commissionsEnabled.set(false);
        row.commissionType.set("No_Commissions");
        row.commissionValue.set(0.0);
        row.disableLeapfrog.set(false);
        table.refresh();
        Logger.info("Cleared row " + row.rowNumber.get());
    }

    private void clearAllRows(CERobotRow startRow) {
        int startIndex = rows.indexOf(startRow);
        if (startIndex < 0) return;

        for (int i = startIndex; i < rows.size(); i++) {
            clearRow(rows.get(i));
        }
        table.refresh();
        Logger.info("Cleared all rows from row " + startRow.rowNumber.get());
    }

    private void copyRowData(CERobotRow source, CERobotRow target) {
        target.ceMagicBase.set(source.ceMagicBase.get());
        target.ceMaxSequence.set(source.ceMaxSequence.get());
        target.timeframe.set(source.timeframe.get());
        target.closeHour.set(source.closeHour.get());
        target.closeMinute.set(source.closeMinute.get());
        target.minX1Height.set(source.minX1Height.get());
        target.x1Type.set(source.x1Type.get());
        target.trigPercent.set(source.trigPercent.get());
        target.stopLossPercent.set(source.stopLossPercent.get());
        target.rptPercent.set(source.rptPercent.get());
        target.rptFixedAmount.set(source.rptFixedAmount.get());
        target.tp1Percent.set(source.tp1Percent.get());
        target.tp1Volume.set(source.tp1Volume.get());
        target.tp2Percent.set(source.tp2Percent.get());
        target.tp2Volume.set(source.tp2Volume.get());
        target.tp3Percent.set(source.tp3Percent.get());
        target.tp3Volume.set(source.tp3Volume.get());
        target.tp4Percent.set(source.tp4Percent.get());
        target.tp4Volume.set(source.tp4Volume.get());
        target.tp5Percent.set(source.tp5Percent.get());
        target.tp5Volume.set(source.tp5Volume.get());
        target.tp6Percent.set(source.tp6Percent.get());
        target.tp6Volume.set(source.tp6Volume.get());
        target.tp7Percent.set(source.tp7Percent.get());
        target.tp7Volume.set(source.tp7Volume.get());
        target.commissionsEnabled.set(source.commissionsEnabled.get());
        target.commissionType.set(source.commissionType.get());
        target.commissionValue.set(source.commissionValue.get());
        target.disableLeapfrog.set(source.disableLeapfrog.get());
    }

    public static class CERobotRow {
        private Long configId;
        public final IntegerProperty rowNumber;
        public final BooleanProperty masterEnabled;
        public final IntegerProperty ceMagicBase;
        public final StringProperty robotName;
        public final StringProperty symbol;
        public final IntegerProperty ceMaxSequence;
        public final StringProperty timeframe;
        public final IntegerProperty closeHour;
        public final IntegerProperty closeMinute;
        public final DoubleProperty minX1Height;
        public final StringProperty x1Type;
        public final DoubleProperty trigPercent;
        public final DoubleProperty stopLossPercent;
        public final DoubleProperty rptPercent;
        public final DoubleProperty rptFixedAmount;
        public final DoubleProperty tp1Percent;
        public final IntegerProperty tp1Volume;
        public final DoubleProperty tp2Percent;
        public final IntegerProperty tp2Volume;
        public final DoubleProperty tp3Percent;
        public final IntegerProperty tp3Volume;
        public final DoubleProperty tp4Percent;
        public final IntegerProperty tp4Volume;
        public final DoubleProperty tp5Percent;
        public final IntegerProperty tp5Volume;
        public final DoubleProperty tp6Percent;
        public final IntegerProperty tp6Volume;
        public final DoubleProperty tp7Percent;
        public final IntegerProperty tp7Volume;
        public final BooleanProperty commissionsEnabled;
        public final StringProperty commissionType;
        public final DoubleProperty commissionValue;
        public final BooleanProperty disableLeapfrog;

        public CERobotRow(int rowNum, CERobotConfig config) {
            this.configId = config.getId();
            this.rowNumber = new SimpleIntegerProperty(rowNum);
            this.masterEnabled = new SimpleBooleanProperty(config.isMasterEnabled());
            this.ceMagicBase = new SimpleIntegerProperty(config.getCeMagicBase());
            this.robotName = new SimpleStringProperty(config.getRobotName());
            this.symbol = new SimpleStringProperty(config.getSymbol());
            this.ceMaxSequence = new SimpleIntegerProperty(config.getCeMaxSequence());
            this.timeframe = new SimpleStringProperty(config.getTimeframe());
            this.closeHour = new SimpleIntegerProperty(config.getCloseHour());
            this.closeMinute = new SimpleIntegerProperty(config.getCloseMinute());
            this.minX1Height = new SimpleDoubleProperty(config.getMinX1Height());
            this.x1Type = new SimpleStringProperty(config.getX1Type());
            this.trigPercent = new SimpleDoubleProperty(config.getTrigPercent());
            this.stopLossPercent = new SimpleDoubleProperty(config.getStopLossPercent());
            this.rptPercent = new SimpleDoubleProperty(config.getRptPercent() != null ? config.getRptPercent() : 0.0);
            this.rptFixedAmount = new SimpleDoubleProperty(config.getRptFixedAmount() != null ? config.getRptFixedAmount() : 0.0);
            this.tp1Percent = new SimpleDoubleProperty(config.getTp1Percent());
            this.tp1Volume = new SimpleIntegerProperty(config.getTp1Volume());
            this.tp2Percent = new SimpleDoubleProperty(config.getTp2Percent());
            this.tp2Volume = new SimpleIntegerProperty(config.getTp2Volume());
            this.tp3Percent = new SimpleDoubleProperty(config.getTp3Percent());
            this.tp3Volume = new SimpleIntegerProperty(config.getTp3Volume());
            this.tp4Percent = new SimpleDoubleProperty(config.getTp4Percent());
            this.tp4Volume = new SimpleIntegerProperty(config.getTp4Volume());
            this.tp5Percent = new SimpleDoubleProperty(config.getTp5Percent());
            this.tp5Volume = new SimpleIntegerProperty(config.getTp5Volume());
            this.tp6Percent = new SimpleDoubleProperty(config.getTp6Percent());
            this.tp6Volume = new SimpleIntegerProperty(config.getTp6Volume());
            this.tp7Percent = new SimpleDoubleProperty(config.getTp7Percent());
            this.tp7Volume = new SimpleIntegerProperty(config.getTp7Volume());
            this.commissionsEnabled = new SimpleBooleanProperty(config.isCommissionsEnabled());
            this.commissionType = new SimpleStringProperty(config.getCommissionType());
            this.commissionValue = new SimpleDoubleProperty(config.getCommissionValue() != null ? config.getCommissionValue() : 0.0);
            this.disableLeapfrog = new SimpleBooleanProperty(config.isDisableLeapfrog());
        }

        public CERobotConfig toConfig() {
            CERobotConfig config = new CERobotConfig();
            config.setId(configId);
            config.setMasterEnabled(masterEnabled.get());
            config.setCeMagicBase(ceMagicBase.get());
            config.setRobotName(robotName.get());
            config.setSymbol(symbol.get());
            config.setCeMaxSequence(ceMaxSequence.get());
            config.setTimeframe(timeframe.get());
            config.setCloseHour(closeHour.get());
            config.setCloseMinute(closeMinute.get());
            config.setMinX1Height(minX1Height.get());
            config.setX1Type(x1Type.get());
            config.setTrigPercent(trigPercent.get());
            config.setStopLossPercent(stopLossPercent.get());
            config.setRptPercent(rptPercent.get());
            config.setRptFixedAmount(rptFixedAmount.get());
            config.setTp1Percent(tp1Percent.get());
            config.setTp1Volume(tp1Volume.get());
            config.setTp2Percent(tp2Percent.get());
            config.setTp2Volume(tp2Volume.get());
            config.setTp3Percent(tp3Percent.get());
            config.setTp3Volume(tp3Volume.get());
            config.setTp4Percent(tp4Percent.get());
            config.setTp4Volume(tp4Volume.get());
            config.setTp5Percent(tp5Percent.get());
            config.setTp5Volume(tp5Volume.get());
            config.setTp6Percent(tp6Percent.get());
            config.setTp6Volume(tp6Volume.get());
            config.setTp7Percent(tp7Percent.get());
            config.setTp7Volume(tp7Volume.get());
            config.setCommissionsEnabled(commissionsEnabled.get());
            config.setCommissionType(commissionType.get());
            config.setCommissionValue(commissionValue.get());
            config.setDisableLeapfrog(disableLeapfrog.get());
            return config;
        }

        public void applyDefaults(CERobotConfig defaults) {
            this.symbol.set(defaults.getSymbol());
            this.ceMaxSequence.set(defaults.getCeMaxSequence());
            this.timeframe.set(defaults.getTimeframe());
            this.closeHour.set(defaults.getCloseHour());
            this.closeMinute.set(defaults.getCloseMinute());
            this.minX1Height.set(defaults.getMinX1Height());
            this.x1Type.set(defaults.getX1Type());
            this.trigPercent.set(defaults.getTrigPercent());
            this.stopLossPercent.set(defaults.getStopLossPercent());
            this.rptPercent.set(defaults.getRptPercent() != null ? defaults.getRptPercent() : 0.0);
            this.rptFixedAmount.set(defaults.getRptFixedAmount() != null ? defaults.getRptFixedAmount() : 0.0);
            this.tp1Percent.set(defaults.getTp1Percent());
            this.tp1Volume.set(defaults.getTp1Volume());
            this.tp2Percent.set(defaults.getTp2Percent());
            this.tp2Volume.set(defaults.getTp2Volume());
            this.tp3Percent.set(defaults.getTp3Percent());
            this.tp3Volume.set(defaults.getTp3Volume());
            this.tp4Percent.set(defaults.getTp4Percent());
            this.tp4Volume.set(defaults.getTp4Volume());
            this.tp5Percent.set(defaults.getTp5Percent());
            this.tp5Volume.set(defaults.getTp5Volume());
            this.tp6Percent.set(defaults.getTp6Percent());
            this.tp6Volume.set(defaults.getTp6Volume());
            this.tp7Percent.set(defaults.getTp7Percent());
            this.tp7Volume.set(defaults.getTp7Volume());
            this.commissionsEnabled.set(defaults.isCommissionsEnabled());
            this.commissionType.set(defaults.getCommissionType());
            this.commissionValue.set(defaults.getCommissionValue() != null ? defaults.getCommissionValue() : 0.0);
            this.disableLeapfrog.set(defaults.isDisableLeapfrog());
        }
    }

    private <T> javafx.scene.control.TableCell<CERobotRow, T> createCommittingCell(
            javafx.util.StringConverter<T> converter) {
        return new javafx.scene.control.TableCell<>() {
            private javafx.scene.control.TextField textField;

            @Override
            public void startEdit() {
                CERobotRow row = getTableRow().getItem();
                if (isRowLocked(row)) {
                    return;
                }

                super.startEdit();

                if (textField == null) {
                    textField = new javafx.scene.control.TextField();

                    textField.setOnAction(e -> commitFromTextField());

                    textField.focusedProperty().addListener((obs, was, is) -> {
                        if (was && !is) {
                            javafx.application.Platform.runLater(() -> {
                                if (isEditing()) {
                                    commitFromTextField();
                                }
                            });
                        }
                    });
                }

                T item = getItem();
                String text = item == null ? "" : converter.toString(item);
                textField.setText(text);

                setText(null);
                setGraphic(textField);

                javafx.application.Platform.runLater(() -> {
                    textField.requestFocus();
                    textField.selectAll();
                });
            }

            @Override
            public void cancelEdit() {
                if (textField != null && isEditing()) {
                    commitFromTextField();
                } else {
                    super.cancelEdit();
                    setText(getItem() == null ? "" : converter.toString(getItem()));
                    setGraphic(null);
                }
            }

            @Override
            public void updateItem(T item, boolean empty) {
                super.updateItem(item, empty);

                if (empty) {
                    setText(null);
                    setGraphic(null);
                } else {
                    if (isEditing()) {
                        if (textField != null) {
                            textField.setText(converter.toString(item));
                        }
                        setText(null);
                        setGraphic(textField);
                    } else {
                        setText(converter.toString(item));
                        setGraphic(null);
                    }
                }
            }

            private void commitFromTextField() {
                if (!isEditing()) return;

                try {
                    String text = textField.getText();
                    if (text == null) text = "";
                    T newValue = converter.fromString(text);
                    commitEdit(newValue);
                } catch (Exception e) {
                    cancelEdit();
                }
            }
        };
    }
}
