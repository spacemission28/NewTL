package com.polymarket.orderbook.config;

public class WebSocketConfig {

    private String url;
    private long reconnectDelay;
    private long heartbeatInterval;
    private int maxReconnectAttempts;

    public WebSocketConfig() {
    }

    public WebSocketConfig(String url, long reconnectDelay, long heartbeatInterval, int maxReconnectAttempts) {
        this.url = url;
        this.reconnectDelay = reconnectDelay;
        this.heartbeatInterval = heartbeatInterval;
        this.maxReconnectAttempts = maxReconnectAttempts;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static WebSocketConfig fromAppConfig() {
        AppConfig config = AppConfig.getInstance();
        return WebSocketConfig.builder()
                .url(config.getWebSocketUrl())
                .reconnectDelay(config.getWebSocketReconnectDelay())
                .heartbeatInterval(config.getWebSocketHeartbeatInterval())
                .maxReconnectAttempts(10)
                .build();
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public long getReconnectDelay() {
        return reconnectDelay;
    }

    public void setReconnectDelay(long reconnectDelay) {
        this.reconnectDelay = reconnectDelay;
    }

    public long getHeartbeatInterval() {
        return heartbeatInterval;
    }

    public void setHeartbeatInterval(long heartbeatInterval) {
        this.heartbeatInterval = heartbeatInterval;
    }

    public int getMaxReconnectAttempts() {
        return maxReconnectAttempts;
    }

    public void setMaxReconnectAttempts(int maxReconnectAttempts) {
        this.maxReconnectAttempts = maxReconnectAttempts;
    }

    public static class Builder {
        private String url;
        private long reconnectDelay;
        private long heartbeatInterval;
        private int maxReconnectAttempts;

        public Builder url(String url) {
            this.url = url;
            return this;
        }

        public Builder reconnectDelay(long reconnectDelay) {
            this.reconnectDelay = reconnectDelay;
            return this;
        }

        public Builder heartbeatInterval(long heartbeatInterval) {
            this.heartbeatInterval = heartbeatInterval;
            return this;
        }

        public Builder maxReconnectAttempts(int maxReconnectAttempts) {
            this.maxReconnectAttempts = maxReconnectAttempts;
            return this;
        }

        public WebSocketConfig build() {
            return new WebSocketConfig(url, reconnectDelay, heartbeatInterval, maxReconnectAttempts);
        }
    }
}
