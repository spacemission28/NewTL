package com.polymarket.orderbook.util;

import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.web3j.crypto.Credentials;
import org.web3j.crypto.ECKeyPair;
import org.web3j.crypto.Hash;
import org.web3j.crypto.Sign;
import org.web3j.utils.Numeric;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * EIP-712 signature utility for Polymarket order signing
 * Implements the typed structured data signing standard
 */
public class EIP712Signer {

    private static final Logger logger = LoggerFactory.getLogger(EIP712Signer.class);

    // Polymarket's contract address on Polygon
    private static final String VERIFYING_CONTRACT = "0x4bFb41d5B3570DeFd03C39a9A4D8dE6Bd8B8982E";

    // Polygon mainnet chain ID
    private static final int CHAIN_ID = 137;

    // EIP-712 Domain
    private static final String DOMAIN_NAME = "Polymarket CTF Exchange";
    private static final String DOMAIN_VERSION = "1";

    // Type hashes
    private static final String DOMAIN_TYPE_HASH = "EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)";
    private static final String ORDER_TYPE_HASH = "Order(uint256 salt,address maker,address signer,address taker,uint256 tokenId,uint256 makerAmount,uint256 takerAmount,uint256 expiration,uint256 nonce,uint256 feeRateBps,uint8 side,uint8 signatureType)";

    /**
     * Sign a Polymarket order using EIP-712 (instance method for ObjectNode)
     * @param orderNode ObjectNode containing order parameters
     * @param keyPair ECKeyPair for signing
     * @return Signature string in format: 0x{r}{s}{v}
     */
    public String signOrder(ObjectNode orderNode, ECKeyPair keyPair) {
        try {
            String salt = orderNode.get("salt").asText();
            String maker = orderNode.get("maker").asText();
            String signer = maker;
            String taker = orderNode.get("taker").asText();
            String tokenId = orderNode.get("tokenId").asText();
            String makerAmount = orderNode.get("makerAmount").asText();
            String takerAmount = orderNode.get("takerAmount").asText();
            String expiration = orderNode.get("expiration").asText();
            String nonce = orderNode.get("nonce").asText();
            String feeRateBps = orderNode.get("feeRateBps").asText();

            String side = orderNode.get("side").asText();
            int sideValue = side.equalsIgnoreCase("BUY") ? 0 : 1;

            String signatureType = orderNode.get("signatureType").asText();
            int sigTypeValue = signatureType.equals("EOA") ? 0 : 1;

            byte[] domainSeparator = buildDomainSeparator();
            byte[] orderStructHash = buildOrderStructHash(
                    salt, maker, signer, taker, tokenId, makerAmount,
                    takerAmount, expiration, nonce, feeRateBps,
                    String.valueOf(sideValue), String.valueOf(sigTypeValue)
            );

            byte[] message = new byte[2 + 32 + 32];
            message[0] = 0x19;
            message[1] = 0x01;
            System.arraycopy(domainSeparator, 0, message, 2, 32);
            System.arraycopy(orderStructHash, 0, message, 34, 32);

            byte[] messageHash = Hash.sha3(message);
            Sign.SignatureData signature = Sign.signMessage(messageHash, keyPair, false);

            String r = Numeric.toHexStringNoPrefix(signature.getR());
            String s = Numeric.toHexStringNoPrefix(signature.getS());
            String v = Numeric.toHexStringNoPrefix(signature.getV());

            return "0x" + r + s + v;

        } catch (Exception e) {
            logger.error("Failed to sign order: {}", e.getMessage(), e);
            throw new RuntimeException("Order signing failed: " + e.getMessage(), e);
        }
    }

    /**
     * Sign a Polymarket order using EIP-712
     * @param orderParams Map containing order parameters
     * @param privateKey Hex-encoded private key (with or without 0x prefix)
     * @return Signature string in format: 0x{r}{s}{v}
     */
    public static String signOrder(
            String salt,
            String maker,
            String signer,
            String taker,
            String tokenId,
            String makerAmount,
            String takerAmount,
            String expiration,
            String nonce,
            String feeRateBps,
            String side,
            String signatureType,
            String privateKey) {

        try {
            // Clean and validate private key
            String cleanPrivateKey = privateKey.startsWith("0x") ? privateKey.substring(2) : privateKey;
            if (cleanPrivateKey.length() != 64) {
                throw new IllegalArgumentException("Private key must be 64 hex characters (32 bytes)");
            }

            // Create credentials from private key
            ECKeyPair keyPair = ECKeyPair.create(new BigInteger(cleanPrivateKey, 16));
            Credentials credentials = Credentials.create(keyPair);

            // Build domain separator
            byte[] domainSeparator = buildDomainSeparator();

            // Build order struct hash
            byte[] orderStructHash = buildOrderStructHash(
                    salt, maker, signer, taker, tokenId, makerAmount,
                    takerAmount, expiration, nonce, feeRateBps, side, signatureType
            );

            // Combine for final message: 0x1901 + domainSeparator + structHash
            byte[] message = new byte[2 + 32 + 32];
            message[0] = 0x19;
            message[1] = 0x01;
            System.arraycopy(domainSeparator, 0, message, 2, 32);
            System.arraycopy(orderStructHash, 0, message, 34, 32);

            // Hash the final message
            byte[] messageHash = Hash.sha3(message);

            // Sign the hash
            Sign.SignatureData signature = Sign.signMessage(messageHash, keyPair, false);

            // Format signature as 0x{r}{s}{v}
            String r = Numeric.toHexStringNoPrefix(signature.getR());
            String s = Numeric.toHexStringNoPrefix(signature.getS());
            String v = Numeric.toHexStringNoPrefix(signature.getV());

            String fullSignature = "0x" + r + s + v;
            logger.debug("Order signed successfully");

            return fullSignature;

        } catch (Exception e) {
            logger.error("Failed to sign order: {}", e.getMessage(), e);
            throw new RuntimeException("Order signing failed: " + e.getMessage(), e);
        }
    }

    /**
     * Build the EIP-712 domain separator
     */
    private static byte[] buildDomainSeparator() {
        // Hash the domain type string
        byte[] domainTypeHash = Hash.sha3(DOMAIN_TYPE_HASH.getBytes(StandardCharsets.UTF_8));

        // Hash the domain name
        byte[] nameHash = Hash.sha3(DOMAIN_NAME.getBytes(StandardCharsets.UTF_8));

        // Hash the domain version
        byte[] versionHash = Hash.sha3(DOMAIN_VERSION.getBytes(StandardCharsets.UTF_8));

        // Encode: keccak256(DOMAIN_TYPEHASH || nameHash || versionHash || chainId || verifyingContract)
        List<byte[]> parts = new ArrayList<>();
        parts.add(domainTypeHash);
        parts.add(nameHash);
        parts.add(versionHash);
        parts.add(encodeUint256(BigInteger.valueOf(CHAIN_ID)));
        parts.add(encodeAddress(VERIFYING_CONTRACT));

        byte[] encoded = concat(parts);
        return Hash.sha3(encoded);
    }

    /**
     * Build the order struct hash
     */
    private static byte[] buildOrderStructHash(
            String salt, String maker, String signer, String taker,
            String tokenId, String makerAmount, String takerAmount,
            String expiration, String nonce, String feeRateBps,
            String side, String signatureType) {

        // Hash the order type string
        byte[] orderTypeHash = Hash.sha3(ORDER_TYPE_HASH.getBytes(StandardCharsets.UTF_8));

        // Encode all parameters
        List<byte[]> parts = new ArrayList<>();
        parts.add(orderTypeHash);
        parts.add(encodeUint256(new BigInteger(salt)));
        parts.add(encodeAddress(maker));
        parts.add(encodeAddress(signer));
        parts.add(encodeAddress(taker));
        parts.add(encodeUint256(new BigInteger(tokenId)));
        parts.add(encodeUint256(new BigInteger(makerAmount)));
        parts.add(encodeUint256(new BigInteger(takerAmount)));
        parts.add(encodeUint256(new BigInteger(expiration)));
        parts.add(encodeUint256(new BigInteger(nonce)));
        parts.add(encodeUint256(new BigInteger(feeRateBps)));
        parts.add(encodeUint8(Integer.parseInt(side)));
        parts.add(encodeUint8(Integer.parseInt(signatureType)));

        byte[] encoded = concat(parts);
        return Hash.sha3(encoded);
    }

    /**
     * Encode a uint256 value (32 bytes, big-endian)
     */
    private static byte[] encodeUint256(BigInteger value) {
        byte[] result = new byte[32];
        byte[] valueBytes = value.toByteArray();

        // Handle negative values (shouldn't happen but be safe)
        if (valueBytes[0] == 0 && valueBytes.length > 1) {
            // Remove sign byte
            System.arraycopy(valueBytes, 1, result, 32 - valueBytes.length + 1, valueBytes.length - 1);
        } else {
            // Copy to right-aligned position
            System.arraycopy(valueBytes, 0, result, 32 - valueBytes.length, valueBytes.length);
        }

        return result;
    }

    /**
     * Encode a uint8 value (32 bytes with value in rightmost byte)
     */
    private static byte[] encodeUint8(int value) {
        return encodeUint256(BigInteger.valueOf(value));
    }

    /**
     * Encode an address (32 bytes with 20-byte address right-aligned)
     */
    private static byte[] encodeAddress(String address) {
        byte[] result = new byte[32];
        String cleanAddress = address.startsWith("0x") ? address.substring(2) : address;

        // Validate address length (should be 40 hex characters = 20 bytes)
        if (cleanAddress.length() != 40) {
            throw new IllegalArgumentException(
                "Invalid Ethereum address length. Expected 40 hex characters, got " + cleanAddress.length() +
                ". Address: " + address +
                ". Please check your wallet address in credentials."
            );
        }

        byte[] addressBytes = Numeric.hexStringToByteArray(cleanAddress);

        if (addressBytes.length != 20) {
            throw new IllegalArgumentException(
                "Invalid Ethereum address. Expected 20 bytes, got " + addressBytes.length +
                ". Address: " + address
            );
        }

        // Addresses are 20 bytes, right-aligned in 32 bytes
        System.arraycopy(addressBytes, 0, result, 12, 20);
        return result;
    }

    /**
     * Concatenate multiple byte arrays
     */
    private static byte[] concat(List<byte[]> arrays) {
        int totalLength = arrays.stream().mapToInt(arr -> arr.length).sum();
        byte[] result = new byte[totalLength];
        int offset = 0;
        for (byte[] array : arrays) {
            System.arraycopy(array, 0, result, offset, array.length);
            offset += array.length;
        }
        return result;
    }
}
