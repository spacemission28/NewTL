package com.polymarket.orderbook.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;

public class PriceFormatter {

    private static final DecimalFormat PRICE_FORMAT = new DecimalFormat("0.00");
    private static final DecimalFormat SIZE_FORMAT = new DecimalFormat("#,##0.00");
    private static final DecimalFormat PERCENTAGE_FORMAT = new DecimalFormat("0.00");

    static {
        PRICE_FORMAT.setRoundingMode(RoundingMode.HALF_UP);
        SIZE_FORMAT.setRoundingMode(RoundingMode.HALF_UP);
        PERCENTAGE_FORMAT.setRoundingMode(RoundingMode.HALF_UP);
    }

    public static String formatPrice(BigDecimal price) {
        if (price == null) {
            return "0.00";
        }
        return PRICE_FORMAT.format(price);
    }

    public static String formatSize(BigDecimal size) {
        if (size == null) {
            return "0.00";
        }
        return SIZE_FORMAT.format(size);
    }

    public static String formatTotal(BigDecimal total) {
        if (total == null) {
            return "$0.00";
        }
        return "$" + SIZE_FORMAT.format(total);
    }

    public static String formatPercentage(BigDecimal percentage) {
        if (percentage == null) {
            return "0.00%";
        }
        return PERCENTAGE_FORMAT.format(percentage) + "%";
    }

    public static BigDecimal calculatePercentage(BigDecimal value, BigDecimal total) {
        if (total == null || total.compareTo(BigDecimal.ZERO) == 0) {
            return BigDecimal.ZERO;
        }
        return value.divide(total, 4, RoundingMode.HALF_UP)
                .multiply(new BigDecimal("100"));
    }
}
