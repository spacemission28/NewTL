package com.polymarket.orderbook.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.polymarket.orderbook.config.PolymarketCredentials;
import com.polymarket.orderbook.model.TradeRequest;
import com.polymarket.orderbook.util.EIP712Signer;
import org.apache.hc.client5.http.classic.methods.HttpDelete;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.web3j.crypto.Credentials;
import org.web3j.crypto.ECKeyPair;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.concurrent.CompletableFuture;

public class PolymarketAuthenticatedClient {

    private static final Logger logger = LoggerFactory.getLogger(PolymarketAuthenticatedClient.class);
    private static final ObjectMapper objectMapper = new ObjectMapper();

    private final String privateKey;
    private final String walletAddress;
    private final String clobUrl;
    private final CloseableHttpClient httpClient;
    private final EIP712Signer signer;

    public PolymarketAuthenticatedClient(String privateKey, String walletAddress, String clobUrl) {
        this.privateKey = privateKey;
        this.walletAddress = walletAddress;
        this.clobUrl = clobUrl;
        this.httpClient = HttpClients.createDefault();
        this.signer = new EIP712Signer();

        logger.info("PolymarketAuthenticatedClient initialized with wallet: {}", walletAddress);
    }

    public static PolymarketAuthenticatedClient fromCredentials(PolymarketCredentials credentials, String clobUrl) {
        return new PolymarketAuthenticatedClient(
                credentials.getPrivateKey(),
                credentials.getWalletAddress(),
                clobUrl
        );
    }

    public CompletableFuture<String> submitOrder(TradeRequest tradeRequest) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                logger.info("Submitting order: {} {} tokens @ ${} on asset {}",
                        tradeRequest.getSide(), tradeRequest.getSize(),
                        tradeRequest.getPrice(), tradeRequest.getAssetId());

                BigInteger salt = new BigInteger(String.valueOf(Instant.now().toEpochMilli()));
                long expiration = Instant.now().getEpochSecond() + 86400;

                BigInteger priceWei = tradeRequest.getPrice()
                        .multiply(new BigDecimal("1000000"))
                        .toBigInteger();

                BigInteger sizeWei = tradeRequest.getSize()
                        .multiply(new BigDecimal("1000000"))
                        .toBigInteger();

                ObjectNode orderPayload = objectMapper.createObjectNode();
                orderPayload.put("maker", walletAddress);
                orderPayload.put("taker", "0x0000000000000000000000000000000000000000");
                orderPayload.put("tokenId", tradeRequest.getAssetId());
                orderPayload.put("makerAmount", sizeWei.toString());
                orderPayload.put("takerAmount", priceWei.toString());
                orderPayload.put("side", tradeRequest.getSide().toUpperCase());
                orderPayload.put("expiration", expiration);
                orderPayload.put("salt", salt.toString());
                orderPayload.put("feeRateBps", "0");
                orderPayload.put("nonce", "0");
                orderPayload.put("signatureType", "EOA");

                ECKeyPair keyPair = ECKeyPair.create(new BigInteger(privateKey, 16));
                String signature = signer.signOrder(orderPayload, keyPair);
                orderPayload.put("signature", signature);

                HttpPost httpPost = new HttpPost(clobUrl + "/order");
                httpPost.setHeader("Accept", "application/json");
                httpPost.setHeader("Accept-Language", "en-US,en;q=0.9");
                httpPost.setHeader("Accept-Encoding", "gzip, deflate, br");
                httpPost.setHeader("Content-Type", "application/json");
                httpPost.setHeader("Origin", "https://polymarket.com");
                httpPost.setHeader("Referer", "https://polymarket.com/");
                httpPost.setHeader("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
                httpPost.setHeader("sec-ch-ua", "\"Not_A Brand\";v=\"8\", \"Chromium\";v=\"120\", \"Google Chrome\";v=\"120\"");
                httpPost.setHeader("sec-ch-ua-mobile", "?0");
                httpPost.setHeader("sec-ch-ua-platform", "\"macOS\"");
                httpPost.setHeader("sec-fetch-dest", "empty");
                httpPost.setHeader("sec-fetch-mode", "cors");
                httpPost.setHeader("sec-fetch-site", "cross-site");
                httpPost.setHeader("Connection", "keep-alive");
                httpPost.setEntity(new StringEntity(orderPayload.toString(), StandardCharsets.UTF_8));

                String response = httpClient.execute(httpPost, httpResponse -> {
                    int statusCode = httpResponse.getCode();
                    String body = EntityUtils.toString(httpResponse.getEntity());

                    if (statusCode >= 200 && statusCode < 300) {
                        return body;
                    } else {
                        throw new IOException("Order submission failed with status " + statusCode + ": " + body);
                    }
                });

                JsonNode responseNode = objectMapper.readTree(response);
                String orderId = responseNode.has("orderID")
                    ? responseNode.get("orderID").asText()
                    : responseNode.get("id").asText();

                logger.info("Order submitted successfully. Order ID: {}", orderId);
                return orderId;

            } catch (Exception e) {
                logger.error("Failed to submit order", e);
                throw new RuntimeException("Failed to submit order: " + e.getMessage(), e);
            }
        });
    }

    public CompletableFuture<Void> cancelOrder(String orderId) {
        return CompletableFuture.runAsync(() -> {
            try {
                logger.info("Cancelling order: {}", orderId);

                HttpDelete httpDelete = new HttpDelete(clobUrl + "/order/" + orderId);
                httpDelete.setHeader("Accept", "application/json");
                httpDelete.setHeader("Accept-Language", "en-US,en;q=0.9");
                httpDelete.setHeader("Accept-Encoding", "gzip, deflate, br");
                httpDelete.setHeader("Content-Type", "application/json");
                httpDelete.setHeader("Origin", "https://polymarket.com");
                httpDelete.setHeader("Referer", "https://polymarket.com/");
                httpDelete.setHeader("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
                httpDelete.setHeader("sec-ch-ua", "\"Not_A Brand\";v=\"8\", \"Chromium\";v=\"120\", \"Google Chrome\";v=\"120\"");
                httpDelete.setHeader("sec-ch-ua-mobile", "?0");
                httpDelete.setHeader("sec-ch-ua-platform", "\"macOS\"");
                httpDelete.setHeader("sec-fetch-dest", "empty");
                httpDelete.setHeader("sec-fetch-mode", "cors");
                httpDelete.setHeader("sec-fetch-site", "cross-site");
                httpDelete.setHeader("Connection", "keep-alive");

                httpClient.execute(httpDelete, httpResponse -> {
                    int statusCode = httpResponse.getCode();
                    if (statusCode >= 200 && statusCode < 300) {
                        logger.info("Order cancelled successfully: {}", orderId);
                        return null;
                    } else {
                        String body = EntityUtils.toString(httpResponse.getEntity());
                        throw new IOException("Order cancellation failed with status " + statusCode + ": " + body);
                    }
                });

            } catch (Exception e) {
                logger.error("Failed to cancel order: {}", orderId, e);
                throw new RuntimeException("Failed to cancel order: " + e.getMessage(), e);
            }
        });
    }

    public String getWalletAddress() {
        return walletAddress;
    }

    public void close() {
        try {
            httpClient.close();
            logger.info("PolymarketAuthenticatedClient closed");
        } catch (IOException e) {
            logger.error("Error closing HTTP client", e);
        }
    }
}
