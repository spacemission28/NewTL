package com.polymarket.orderbook.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.ParseException;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.apache.hc.core5.util.Timeout;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.math.BigDecimal;

public class CoinbaseApiClient {

    private static final Logger logger = LoggerFactory.getLogger(CoinbaseApiClient.class);
    private static final String COINBASE_EXCHANGE_API_BASE = "https://api.exchange.coinbase.com";

    private final CloseableHttpClient httpClient;
    private final ObjectMapper objectMapper;

    public CoinbaseApiClient() {
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(Timeout.ofSeconds(10))
                .setConnectionRequestTimeout(Timeout.ofSeconds(10))
                .setResponseTimeout(Timeout.ofSeconds(30))
                .build();

        this.httpClient = HttpClients.custom()
                .setDefaultRequestConfig(requestConfig)
                .build();
        this.objectMapper = new ObjectMapper();

        logger.debug("CoinbaseApiClient initialized with 10s connect timeout and 30s response timeout");
    }

    private void addBrowserHeaders(HttpGet request) {
        request.setHeader("Accept", "application/json");
        request.setHeader("Accept-Language", "en-US,en;q=0.9");
        request.setHeader("Accept-Encoding", "gzip, deflate, br");
        request.setHeader("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
        request.setHeader("sec-ch-ua", "\"Not_A Brand\";v=\"8\", \"Chromium\";v=\"120\", \"Google Chrome\";v=\"120\"");
        request.setHeader("sec-ch-ua-mobile", "?0");
        request.setHeader("sec-ch-ua-platform", "\"macOS\"");
        request.setHeader("sec-fetch-dest", "empty");
        request.setHeader("sec-fetch-mode", "cors");
        request.setHeader("sec-fetch-site", "cross-site");
        request.setHeader("Connection", "keep-alive");
    }

    public BigDecimal getBitcoinPrice() throws IOException, ParseException {
        return getTickerPrice("BTC-USD");
    }

    public BigDecimal getTickerPrice(String productId) throws IOException, ParseException {
        String endpoint = String.format("%s/products/%s/ticker", COINBASE_EXCHANGE_API_BASE, productId);

        HttpGet request = new HttpGet(endpoint);
        addBrowserHeaders(request);

        try (CloseableHttpResponse response = httpClient.execute(request)) {
            String responseBody = EntityUtils.toString(response.getEntity());

            logger.debug("Coinbase Exchange API response: {}", responseBody);

            TickerResponse tickerResponse = objectMapper.readValue(responseBody, TickerResponse.class);

            if (tickerResponse.getPrice() == null) {
                throw new IOException("Invalid response from Coinbase Exchange API");
            }

            BigDecimal price = new BigDecimal(tickerResponse.getPrice());
            logger.info("Fetched {} ticker price: ${} (bid: ${}, ask: ${})",
                productId, price,
                tickerResponse.getBid() != null ? tickerResponse.getBid() : "N/A",
                tickerResponse.getAsk() != null ? tickerResponse.getAsk() : "N/A");

            return price;
        }
    }

    public PriceData getBitcoinPriceWithTimestamp() throws IOException, ParseException {
        String endpoint = String.format("%s/products/BTC-USD/ticker", COINBASE_EXCHANGE_API_BASE);

        HttpGet request = new HttpGet(endpoint);
        addBrowserHeaders(request);

        try (CloseableHttpResponse response = httpClient.execute(request)) {
            String responseBody = EntityUtils.toString(response.getEntity());

            TickerResponse tickerResponse = objectMapper.readValue(responseBody, TickerResponse.class);

            if (tickerResponse.getPrice() == null) {
                throw new IOException("Invalid response from Coinbase Exchange API");
            }

            PriceData priceData = new PriceData();
            priceData.setPrice(new BigDecimal(tickerResponse.getPrice()));
            priceData.setCurrency("USD");
            priceData.setTimestamp(System.currentTimeMillis());

            return priceData;
        }
    }

    public void close() {
        try {
            if (httpClient != null) {
                httpClient.close();
            }
        } catch (IOException e) {
            logger.error("Failed to close Coinbase API client", e);
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class TickerResponse {

        @JsonProperty("trade_id")
        private Long tradeId;

        @JsonProperty("price")
        private String price;

        @JsonProperty("size")
        private String size;

        @JsonProperty("time")
        private String time;

        @JsonProperty("bid")
        private String bid;

        @JsonProperty("ask")
        private String ask;

        @JsonProperty("volume")
        private String volume;

        public Long getTradeId() {
            return tradeId;
        }

        public void setTradeId(Long tradeId) {
            this.tradeId = tradeId;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getSize() {
            return size;
        }

        public void setSize(String size) {
            this.size = size;
        }

        public String getTime() {
            return time;
        }

        public void setTime(String time) {
            this.time = time;
        }

        public String getBid() {
            return bid;
        }

        public void setBid(String bid) {
            this.bid = bid;
        }

        public String getAsk() {
            return ask;
        }

        public void setAsk(String ask) {
            this.ask = ask;
        }

        public String getVolume() {
            return volume;
        }

        public void setVolume(String volume) {
            this.volume = volume;
        }
    }

    public static class PriceData {
        private BigDecimal price;
        private String currency;
        private long timestamp;

        public BigDecimal getPrice() {
            return price;
        }

        public void setPrice(BigDecimal price) {
            this.price = price;
        }

        public String getCurrency() {
            return currency;
        }

        public void setCurrency(String currency) {
            this.currency = currency;
        }

        public long getTimestamp() {
            return timestamp;
        }

        public void setTimestamp(long timestamp) {
            this.timestamp = timestamp;
        }
    }
}
