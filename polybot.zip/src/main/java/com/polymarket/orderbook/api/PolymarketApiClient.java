package com.polymarket.orderbook.api;

import com.polymarket.orderbook.config.AppConfig;
import com.polymarket.orderbook.model.TradeRequest;
import com.polymarket.orderbook.util.EIP712Signer;
import com.polymarket.orderbook.util.JsonUtil;
import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.ParseException;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.apache.hc.core5.util.Timeout;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.web3j.crypto.Credentials;
import org.web3j.crypto.ECKeyPair;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PolymarketApiClient {

    private static final Logger logger = LoggerFactory.getLogger(PolymarketApiClient.class);
    private final String baseUrl;
    private final CloseableHttpClient httpClient;

    public PolymarketApiClient() {
        this.baseUrl = AppConfig.getInstance().getClobApiUrl();

        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(Timeout.ofSeconds(10))
                .setConnectionRequestTimeout(Timeout.ofSeconds(10))
                .setResponseTimeout(Timeout.ofSeconds(30))
                .build();

        this.httpClient = HttpClients.custom()
                .setDefaultRequestConfig(requestConfig)
                .setUserAgent("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                .build();

        logger.debug("PolymarketApiClient initialized with 10s connect timeout and 30s response timeout");
    }

    private void addBrowserHeaders(HttpGet request) {
        request.setHeader("Accept", "application/json, text/plain, */*");
        request.setHeader("Accept-Language", "en-US,en;q=0.9");
        request.setHeader("Accept-Encoding", "gzip, deflate, br");
        request.setHeader("Origin", "https://polymarket.com");
        request.setHeader("Referer", "https://polymarket.com/");
        request.setHeader("sec-ch-ua", "\"Not_A Brand\";v=\"8\", \"Chromium\";v=\"120\", \"Google Chrome\";v=\"120\"");
        request.setHeader("sec-ch-ua-mobile", "?0");
        request.setHeader("sec-ch-ua-platform", "\"macOS\"");
        request.setHeader("Sec-Fetch-Dest", "empty");
        request.setHeader("Sec-Fetch-Mode", "cors");
        request.setHeader("Sec-Fetch-Site", "same-site");
    }

    private void addBrowserHeaders(HttpPost request) {
        request.setHeader("Accept", "application/json, text/plain, */*");
        request.setHeader("Accept-Language", "en-US,en;q=0.9");
        request.setHeader("Accept-Encoding", "gzip, deflate, br");
        request.setHeader("Origin", "https://polymarket.com");
        request.setHeader("Referer", "https://polymarket.com/");
        request.setHeader("sec-ch-ua", "\"Not_A Brand\";v=\"8\", \"Chromium\";v=\"120\", \"Google Chrome\";v=\"120\"");
        request.setHeader("sec-ch-ua-mobile", "?0");
        request.setHeader("sec-ch-ua-platform", "\"macOS\"");
        request.setHeader("Sec-Fetch-Dest", "empty");
        request.setHeader("Sec-Fetch-Mode", "cors");
        request.setHeader("Sec-Fetch-Site", "same-site");
    }

    public Map<String, Object> getOrderBook(String tokenId) throws IOException, ParseException {
        String url = String.format("%s/book?token_id=%s", baseUrl, tokenId);
        logger.debug("Fetching order book for token: {}", tokenId);

        HttpGet request = new HttpGet(url);
        addBrowserHeaders(request);

        try (CloseableHttpResponse response = httpClient.execute(request)) {
            String responseBody = EntityUtils.toString(response.getEntity());
            return JsonUtil.fromJson(responseBody, Map.class);
        }
    }

    public String submitOrder(TradeRequest tradeRequest, String privateKey) throws IOException, ParseException {
        String url = baseUrl + "/order";
        logger.info("Submitting order: {} {} {} @ {}", tradeRequest.getSide(),
                tradeRequest.getSize(), tradeRequest.getAssetId(), tradeRequest.getPrice());

        // Derive wallet address from private key
        String cleanPrivateKey = privateKey.startsWith("0x") ? privateKey.substring(2) : privateKey;
        ECKeyPair keyPair = ECKeyPair.create(new BigInteger(cleanPrivateKey, 16));
        Credentials credentials = Credentials.create(keyPair);
        String makerAddress = credentials.getAddress();

        logger.debug("Using maker address: {}", makerAddress);

        // Generate order parameters
        String salt = generateSalt();
        String nonce = String.valueOf(System.currentTimeMillis() / 1000); // Unix timestamp in seconds
        String expiration = String.valueOf((System.currentTimeMillis() / 1000) + 3600); // 1 hour from now
        String feeRateBps = "0"; // 0 basis points (0%)
        String signatureType = "0"; // EOA signature
        String taker = "0x0000000000000000000000000000000000000000"; // Zero address = any taker

        // Convert side to numeric (0 = BUY, 1 = SELL)
        String sideNumeric = tradeRequest.getSide().equalsIgnoreCase("BUY") ? "0" : "1";

        // Convert amounts to wei (6 decimals for USDC)
        BigInteger makerAmountWei = tradeRequest.getSize().multiply(new BigDecimal("1000000")).toBigInteger();
        BigInteger takerAmountWei = tradeRequest.getSize()
                .multiply(tradeRequest.getPrice())
                .multiply(new BigDecimal("1000000"))
                .toBigInteger();

        // Sign the order using EIP-712
        String signature = EIP712Signer.signOrder(
                salt,
                makerAddress,
                makerAddress, // signer = maker
                taker,
                tradeRequest.getAssetId(),
                makerAmountWei.toString(),
                takerAmountWei.toString(),
                expiration,
                nonce,
                feeRateBps,
                sideNumeric,
                signatureType,
                privateKey
        );

        logger.info("Order signed with EIP-712 signature");

        // Build the API payload
        Map<String, Object> orderPayload = new HashMap<>();
        orderPayload.put("salt", salt);
        orderPayload.put("maker", makerAddress);
        orderPayload.put("signer", makerAddress);
        orderPayload.put("taker", taker);
        orderPayload.put("tokenId", tradeRequest.getAssetId());
        orderPayload.put("makerAmount", makerAmountWei.toString());
        orderPayload.put("takerAmount", takerAmountWei.toString());
        orderPayload.put("expiration", expiration);
        orderPayload.put("nonce", nonce);
        orderPayload.put("feeRateBps", feeRateBps);
        orderPayload.put("side", sideNumeric);
        orderPayload.put("signatureType", signatureType);
        orderPayload.put("signature", signature);

        HttpPost request = new HttpPost(url);
        addBrowserHeaders(request);
        request.setHeader("Content-Type", "application/json");
        request.setEntity(new StringEntity(JsonUtil.toJson(orderPayload), ContentType.APPLICATION_JSON));

        try (CloseableHttpResponse response = httpClient.execute(request)) {
            String responseBody = EntityUtils.toString(response.getEntity());
            int statusCode = response.getCode();

            if (statusCode != 200 && statusCode != 201) {
                logger.error("Failed to submit order. Status: {}, Body: {}", statusCode, responseBody);
                throw new IOException("Failed to submit order: " + statusCode + " - " + responseBody);
            }

            logger.info("Order submitted successfully: {}", responseBody);
            return responseBody;
        }
    }

    /**
     * Generate a random salt for order uniqueness
     */
    private String generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] saltBytes = new byte[32];
        random.nextBytes(saltBytes);
        return new BigInteger(1, saltBytes).toString();
    }

    public BigDecimal getMidPrice(String tokenId) throws IOException, ParseException {
        Map<String, Object> orderBook = getOrderBook(tokenId);

        List<List<String>> bids = (List<List<String>>) orderBook.get("bids");
        List<List<String>> asks = (List<List<String>>) orderBook.get("asks");

        if (bids == null || bids.isEmpty() || asks == null || asks.isEmpty()) {
            return BigDecimal.ZERO;
        }

        BigDecimal bestBid = new BigDecimal(bids.get(0).get(0));
        BigDecimal bestAsk = new BigDecimal(asks.get(0).get(0));

        return bestBid.add(bestAsk).divide(new BigDecimal("2"));
    }

    public BigDecimal getCurrentPrice(String tokenId, String side) throws IOException, ParseException {
        String url = String.format("%s/price?token_id=%s&side=%s", baseUrl, tokenId, side);
        logger.debug("Fetching current price for token: {} (side: {})", tokenId, side);

        HttpGet request = new HttpGet(url);
        addBrowserHeaders(request);

        try (CloseableHttpResponse response = httpClient.execute(request)) {
            String responseBody = EntityUtils.toString(response.getEntity());
            Map<String, Object> priceData = JsonUtil.fromJson(responseBody, Map.class);

            String priceStr = (String) priceData.get("price");
            if (priceStr == null || priceStr.isEmpty()) {
                return BigDecimal.ZERO;
            }

            return new BigDecimal(priceStr);
        }
    }

    public void close() {
        try {
            if (httpClient != null) {
                httpClient.close();
            }
        } catch (IOException e) {
            logger.error("Error closing HTTP client", e);
        }
    }
}
