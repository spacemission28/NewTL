package com.polymarket.orderbook;

import com.polymarket.orderbook.api.GammaApiClient;
import com.polymarket.orderbook.model.Market;

public class TestMarketFetch {
    public static void main(String[] args) {
        GammaApiClient client = new GammaApiClient();

        try {
            System.out.println("Testing market resolution for: btc-updown-15m-1767452400");
            System.out.println("This will automatically detect if it's an Event or Market slug...\n");

            Market market = client.resolveSlugToMarket("btc-updown-15m-1767452400");

            System.out.println("=== SUCCESS! ===");
            System.out.println("Question: " + market.getQuestion());
            System.out.println("Market ID: " + market.getId());
            System.out.println("Condition ID: " + market.getConditionId());
            System.out.println("YES Token ID: " + market.getYesTokenId());
            System.out.println("NO Token ID: " + market.getNoTokenId());
            System.out.println("YES Outcome: " + market.getYesOutcomeName());
            System.out.println("NO Outcome: " + market.getNoOutcomeName());

        } catch (Exception e) {
            System.err.println("FAILED: " + e.getMessage());
            e.printStackTrace();
        } finally {
            client.close();
        }
    }
}
