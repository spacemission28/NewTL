package com.polymarket.orderbook.model;

import java.math.BigDecimal;

public class PriceLevel {

    private BigDecimal price;
    private BigDecimal size;
    private BigDecimal total;

    public PriceLevel() {
    }

    public PriceLevel(BigDecimal price, BigDecimal size, BigDecimal total) {
        this.price = price;
        this.size = size;
        this.total = total;
    }

    public PriceLevel(BigDecimal price, BigDecimal size) {
        this.price = price;
        this.size = size;
        this.total = price.multiply(size);
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getSize() {
        return size;
    }

    public void setSize(BigDecimal size) {
        this.size = size;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    public void updateSize(BigDecimal newSize) {
        this.size = newSize;
        this.total = this.price.multiply(newSize);
    }
}
