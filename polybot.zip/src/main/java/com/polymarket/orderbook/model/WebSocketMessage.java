package com.polymarket.orderbook.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class WebSocketMessage {

    @JsonProperty("event_type")
    private String eventType;

    @JsonProperty("market")
    private String market;

    @JsonProperty("timestamp")
    private String timestamp;

    @JsonProperty("price_changes")
    private List<PriceChange> priceChanges;

    @JsonProperty("book")
    private OrderBookData book;

    public WebSocketMessage() {
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getMarket() {
        return market;
    }

    public void setMarket(String market) {
        this.market = market;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public List<PriceChange> getPriceChanges() {
        return priceChanges;
    }

    public void setPriceChanges(List<PriceChange> priceChanges) {
        this.priceChanges = priceChanges;
    }

    public OrderBookData getBook() {
        return book;
    }

    public void setBook(OrderBookData book) {
        this.book = book;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class PriceChange {

        @JsonProperty("asset_id")
        private String assetId;

        @JsonProperty("price")
        private String price;

        @JsonProperty("size")
        private String size;

        @JsonProperty("side")
        private String side;

        @JsonProperty("hash")
        private String hash;

        @JsonProperty("best_bid")
        private String bestBid;

        @JsonProperty("best_ask")
        private String bestAsk;

        public PriceChange() {
        }

        public String getAssetId() {
            return assetId;
        }

        public void setAssetId(String assetId) {
            this.assetId = assetId;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getSize() {
            return size;
        }

        public void setSize(String size) {
            this.size = size;
        }

        public String getSide() {
            return side;
        }

        public void setSide(String side) {
            this.side = side;
        }

        public String getHash() {
            return hash;
        }

        public void setHash(String hash) {
            this.hash = hash;
        }

        public String getBestBid() {
            return bestBid;
        }

        public void setBestBid(String bestBid) {
            this.bestBid = bestBid;
        }

        public String getBestAsk() {
            return bestAsk;
        }

        public void setBestAsk(String bestAsk) {
            this.bestAsk = bestAsk;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class OrderBookData {

        @JsonProperty("bids")
        private List<List<String>> bids;

        @JsonProperty("asks")
        private List<List<String>> asks;

        @JsonProperty("timestamp")
        private Long timestamp;

        public OrderBookData() {
        }

        public List<List<String>> getBids() {
            return bids;
        }

        public void setBids(List<List<String>> bids) {
            this.bids = bids;
        }

        public List<List<String>> getAsks() {
            return asks;
        }

        public void setAsks(List<List<String>> asks) {
            this.asks = asks;
        }

        public Long getTimestamp() {
            return timestamp;
        }

        public void setTimestamp(Long timestamp) {
            this.timestamp = timestamp;
        }
    }
}
