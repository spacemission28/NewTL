package com.polymarket.orderbook.model;

import java.math.BigDecimal;

public class TradeRequest {

    private String assetId;
    private String side;
    private BigDecimal price;
    private BigDecimal size;
    private String orderType;
    private BigDecimal totalUsdcAmount;

    public TradeRequest() {
    }

    public TradeRequest(String assetId, String side, BigDecimal price, BigDecimal size,
                        String orderType, BigDecimal totalUsdcAmount) {
        this.assetId = assetId;
        this.side = side;
        this.price = price;
        this.size = size;
        this.orderType = orderType;
        this.totalUsdcAmount = totalUsdcAmount;
    }

    public static TradeRequestBuilder builder() {
        return new TradeRequestBuilder();
    }

    public String getAssetId() {
        return assetId;
    }

    public void setAssetId(String assetId) {
        this.assetId = assetId;
    }

    public String getSide() {
        return side;
    }

    public void setSide(String side) {
        this.side = side;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getSize() {
        return size;
    }

    public void setSize(BigDecimal size) {
        this.size = size;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public BigDecimal getTotalUsdcAmount() {
        return totalUsdcAmount;
    }

    public void setTotalUsdcAmount(BigDecimal totalUsdcAmount) {
        this.totalUsdcAmount = totalUsdcAmount;
    }

    public enum Side {
        BUY, SELL
    }

    public enum OrderType {
        MARKET, LIMIT, GTC, IOC, FOK
    }

    public static class TradeRequestBuilder {
        private String assetId;
        private String side;
        private BigDecimal price;
        private BigDecimal size;
        private String orderType;
        private BigDecimal totalUsdcAmount;

        public TradeRequestBuilder assetId(String assetId) {
            this.assetId = assetId;
            return this;
        }

        public TradeRequestBuilder side(String side) {
            this.side = side;
            return this;
        }

        public TradeRequestBuilder price(BigDecimal price) {
            this.price = price;
            return this;
        }

        public TradeRequestBuilder size(BigDecimal size) {
            this.size = size;
            return this;
        }

        public TradeRequestBuilder orderType(String orderType) {
            this.orderType = orderType;
            return this;
        }

        public TradeRequestBuilder totalUsdcAmount(BigDecimal totalUsdcAmount) {
            this.totalUsdcAmount = totalUsdcAmount;
            return this;
        }

        public TradeRequest build() {
            return new TradeRequest(assetId, side, price, size, orderType, totalUsdcAmount);
        }
    }
}
