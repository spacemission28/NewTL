package com.polymarket.orderbook.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Market {

    @JsonProperty("id")
    private String id;

    @JsonProperty("question")
    private String question;

    @JsonProperty("slug")
    private String slug;

    @JsonProperty("conditionId")
    private String conditionId;

    @JsonProperty("tokens")
    private List<Token> tokens;

    @JsonProperty("clobTokenIds")
    private String clobTokenIdsRaw;

    @JsonProperty("outcomes")
    private String outcomesRaw;

    @JsonProperty("outcomePrices")
    private String outcomePricesRaw;

    private List<String> clobTokenIds;
    private List<String> outcomes;
    private List<String> outcomePrices;

    @JsonProperty("active")
    private Boolean active;

    @JsonProperty("end_date_iso")
    private String endDateIso;

    public Market() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public String getConditionId() {
        return conditionId;
    }

    public void setConditionId(String conditionId) {
        this.conditionId = conditionId;
    }

    public List<Token> getTokens() {
        return tokens;
    }

    public void setTokens(List<Token> tokens) {
        this.tokens = tokens;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public String getEndDateIso() {
        return endDateIso;
    }

    public void setEndDateIso(String endDateIso) {
        this.endDateIso = endDateIso;
    }

    public List<String> getClobTokenIds() {
        if (clobTokenIds == null && clobTokenIdsRaw != null) {
            clobTokenIds = parseJsonArray(clobTokenIdsRaw);
        }
        return clobTokenIds;
    }

    public void setClobTokenIds(List<String> clobTokenIds) {
        this.clobTokenIds = clobTokenIds;
    }

    public void setClobTokenIdsRaw(String clobTokenIdsRaw) {
        this.clobTokenIdsRaw = clobTokenIdsRaw;
        this.clobTokenIds = null;
    }

    public List<String> getOutcomes() {
        if (outcomes == null && outcomesRaw != null) {
            outcomes = parseJsonArray(outcomesRaw);
        }
        return outcomes;
    }

    public void setOutcomes(List<String> outcomes) {
        this.outcomes = outcomes;
    }

    public void setOutcomesRaw(String outcomesRaw) {
        this.outcomesRaw = outcomesRaw;
        this.outcomes = null;
    }

    public List<String> getOutcomePrices() {
        if (outcomePrices == null && outcomePricesRaw != null) {
            outcomePrices = parseJsonArray(outcomePricesRaw);
        }
        return outcomePrices;
    }

    public void setOutcomePrices(List<String> outcomePrices) {
        this.outcomePrices = outcomePrices;
    }

    public void setOutcomePricesRaw(String outcomePricesRaw) {
        this.outcomePricesRaw = outcomePricesRaw;
        this.outcomePrices = null;
    }

    private static final ObjectMapper mapper = new ObjectMapper();
    private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(Market.class);

    private List<String> parseJsonArray(String jsonArray) {
        if (jsonArray == null || jsonArray.isEmpty()) {
            return null;
        }
        try {
            return mapper.readValue(jsonArray, new TypeReference<List<String>>() {});
        } catch (Exception e) {
            logger.error("Failed to parse JSON array: {}", jsonArray, e);
            return null;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Token {

        @JsonProperty("token_id")
        private String tokenId;

        @JsonProperty("outcome")
        private String outcome;

        @JsonProperty("price")
        private String price;

        public Token() {
        }

        public String getTokenId() {
            return tokenId;
        }

        public void setTokenId(String tokenId) {
            this.tokenId = tokenId;
        }

        public String getOutcome() {
            return outcome;
        }

        public void setOutcome(String outcome) {
            this.outcome = outcome;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }
    }

    public String getYesTokenId() {
        List<String> tokenIds = getClobTokenIds();
        List<String> outcomesList = getOutcomes();

        if (tokenIds != null && outcomesList != null && !tokenIds.isEmpty() && !outcomesList.isEmpty()) {
            for (int i = 0; i < outcomesList.size(); i++) {
                String outcome = outcomesList.get(i);
                if ("Yes".equalsIgnoreCase(outcome) || "Up".equalsIgnoreCase(outcome)) {
                    return tokenIds.get(i);
                }
            }
        }

        if (tokens != null) {
            return tokens.stream()
                    .filter(t -> "Yes".equalsIgnoreCase(t.getOutcome()) || "Up".equalsIgnoreCase(t.getOutcome()))
                    .map(Token::getTokenId)
                    .findFirst()
                    .orElse(null);
        }

        logger.warn("No YES/Up token ID found for market: {}", question);
        return null;
    }

    public String getNoTokenId() {
        List<String> tokenIds = getClobTokenIds();
        List<String> outcomesList = getOutcomes();

        if (tokenIds != null && outcomesList != null && !tokenIds.isEmpty() && !outcomesList.isEmpty()) {
            for (int i = 0; i < outcomesList.size(); i++) {
                String outcome = outcomesList.get(i);
                if ("No".equalsIgnoreCase(outcome) || "Down".equalsIgnoreCase(outcome)) {
                    return tokenIds.get(i);
                }
            }
        }

        if (tokens != null) {
            return tokens.stream()
                    .filter(t -> "No".equalsIgnoreCase(t.getOutcome()) || "Down".equalsIgnoreCase(t.getOutcome()))
                    .map(Token::getTokenId)
                    .findFirst()
                    .orElse(null);
        }

        logger.warn("No NO/Down token ID found for market: {}", question);
        return null;
    }

    public String getYesOutcomeName() {
        // Call getter method to trigger lazy parsing!
        List<String> outcomesList = getOutcomes();

        if (outcomesList != null && !outcomesList.isEmpty()) {
            for (String outcome : outcomesList) {
                if ("Yes".equalsIgnoreCase(outcome) || "Up".equalsIgnoreCase(outcome)) {
                    return outcome;
                }
            }
        }

        if (tokens != null) {
            return tokens.stream()
                    .filter(t -> "Yes".equalsIgnoreCase(t.getOutcome()) || "Up".equalsIgnoreCase(t.getOutcome()))
                    .map(Token::getOutcome)
                    .findFirst()
                    .orElse("YES");
        }

        return "YES";
    }

    public String getNoOutcomeName() {
        // Call getter method to trigger lazy parsing!
        List<String> outcomesList = getOutcomes();

        if (outcomesList != null && !outcomesList.isEmpty()) {
            for (String outcome : outcomesList) {
                if ("No".equalsIgnoreCase(outcome) || "Down".equalsIgnoreCase(outcome)) {
                    return outcome;
                }
            }
        }

        if (tokens != null) {
            return tokens.stream()
                    .filter(t -> "No".equalsIgnoreCase(t.getOutcome()) || "Down".equalsIgnoreCase(t.getOutcome()))
                    .map(Token::getOutcome)
                    .findFirst()
                    .orElse("NO");
        }

        return "NO";
    }
}
