package com.polymarket.orderbook.service;

import com.polymarket.orderbook.api.CoinbaseApiClient;
import com.polymarket.orderbook.api.GammaApiClient;
import com.polymarket.orderbook.engine.OrderBookEngine;
import com.polymarket.orderbook.model.ArbitrageOpportunity;
import com.polymarket.orderbook.model.OrderBookSnapshot;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ArbitrageDetectionService {

    private static final Logger logger = LoggerFactory.getLogger(ArbitrageDetectionService.class);
    private BigDecimal minimumEdgeThreshold = new BigDecimal("5.0");
    private BigDecimal minimumCentsDivergence = new BigDecimal("2.0");

    private final CoinbaseApiClient coinbaseClient;
    private final GammaApiClient gammaClient;
    private final OrderBookEngine orderBookEngine;

    private final Map<String, BigDecimal> marketStartPrices;
    private volatile BigDecimal currentCoinbasePrice;
    private volatile BigDecimal currentPolymarketPrice;
    private volatile long lastCoinbaseUpdate;
    private volatile long lastPolymarketUpdate;

    public ArbitrageDetectionService(OrderBookEngine orderBookEngine) {
        this.coinbaseClient = new CoinbaseApiClient();
        this.gammaClient = new GammaApiClient();
        this.orderBookEngine = orderBookEngine;
        this.marketStartPrices = new ConcurrentHashMap<>();
        this.lastCoinbaseUpdate = 0;
        this.lastPolymarketUpdate = 0;
    }

    public ArbitrageOpportunity detectOpportunity(String yesAssetId, String noAssetId,
                                                  String marketQuestion, String marketSlug) {

        ArbitrageOpportunity opportunity = new ArbitrageOpportunity();
        opportunity.setMarketQuestion(marketQuestion);
        opportunity.setMarketSlug(marketSlug);

        if (currentCoinbasePrice == null || currentPolymarketPrice == null) {
            logger.debug("Price data not available yet (Coinbase: {}, Polymarket: {})",
                currentCoinbasePrice, currentPolymarketPrice);
            opportunity.setDirection(ArbitrageOpportunity.ArbitrageDirection.NONE);
            return opportunity;
        }

        try {

            opportunity.setCoinbasePrice(currentCoinbasePrice);

            BigDecimal startPrice = marketStartPrices.computeIfAbsent(marketSlug, k -> currentPolymarketPrice);
            opportunity.setCoinbasePriceAtMarketStart(startPrice);

            BigDecimal actualChange = calculatePercentageChange(startPrice, currentCoinbasePrice);
            opportunity.setActualPriceChange(actualChange);

            opportunity.setPolymarketReferencePrice(currentPolymarketPrice);

            // Calculate price difference: Coinbase - Polymarket
            // Positive = Coinbase higher = BTC going UP = BUY UP on Polymarket
            // Negative = Coinbase lower = BTC going DOWN = BUY DOWN on Polymarket
            BigDecimal priceDifference = currentCoinbasePrice.subtract(currentPolymarketPrice);
            opportunity.setArbitrageEdge(priceDifference.abs());

            logger.debug("Price comparison: Coinbase=${}, Polymarket=${}, Diff=${}, AbsDiff=${}, Threshold=${}",
                currentCoinbasePrice, currentPolymarketPrice, priceDifference,
                priceDifference.abs(), minimumEdgeThreshold);

            // Determine direction based ONLY on price difference (not order book)
            ArbitrageOpportunity.ArbitrageDirection direction = determineDirectionByPriceDivergence(
                priceDifference);
            opportunity.setDirection(direction);

            logger.debug("Direction determined: {} (hasOpportunity={})",
                direction, direction != ArbitrageOpportunity.ArbitrageDirection.NONE);

            if (opportunity.hasOpportunity()) {
                logger.info("ARBITRAGE DETECTED: Coinbase ${} vs Polymarket ${}, Diff: ${} -> {}",
                    currentCoinbasePrice, currentPolymarketPrice, priceDifference, direction);
            }

        } catch (Exception e) {
            logger.error("Error detecting arbitrage opportunity", e);
            opportunity.setDirection(ArbitrageOpportunity.ArbitrageDirection.NONE);
            return opportunity;
        }

        // Optional: Load order book data for UI display (not required for signal)
        // This is done outside the main try-catch so exceptions here don't affect the arbitrage signal
        try {
            OrderBookSnapshot yesSnapshot = orderBookEngine.getSnapshot(yesAssetId);
            OrderBookSnapshot noSnapshot = orderBookEngine.getSnapshot(noAssetId);

            if (yesSnapshot != null && noSnapshot != null) {
                BigDecimal yesMidPrice = yesSnapshot.getMidPrice();
                BigDecimal noMidPrice = noSnapshot.getMidPrice();

                if (yesMidPrice != null && noMidPrice != null &&
                    yesMidPrice.compareTo(BigDecimal.ZERO) > 0 && noMidPrice.compareTo(BigDecimal.ZERO) > 0) {
                    opportunity.setPolymarketUpProbability(yesMidPrice.multiply(new BigDecimal("100")));
                    opportunity.setPolymarketDownProbability(noMidPrice.multiply(new BigDecimal("100")));
                }
            }
        } catch (Exception e) {
            logger.warn("Failed to load order book data for UI display (signal still valid): {}", e.getMessage());
        }

        return opportunity;
    }

    public void updatePricesAsync() {
        new Thread(() -> {
            try {
                updateCoinbasePriceIfNeeded();
            } catch (Exception e) {
                logger.error("Failed to update Coinbase price: {}", e.getMessage(), e);
            }

            try {
                updatePolymarketPriceIfNeeded();
            } catch (Exception e) {
                logger.error("Failed to update Polymarket reference price: {}", e.getMessage(), e);
            }
        }, "PriceUpdateThread").start();
    }

    private void updateCoinbasePriceIfNeeded() throws Exception {
        currentCoinbasePrice = coinbaseClient.getBitcoinPrice();
        lastCoinbaseUpdate = System.currentTimeMillis();
        logger.info("Updated Coinbase BTC/USD spot price: ${}", currentCoinbasePrice);
    }

    private void updatePolymarketPriceIfNeeded() throws Exception {
        currentPolymarketPrice = gammaClient.getBitcoinPrice();
        lastPolymarketUpdate = System.currentTimeMillis();
        logger.info("Updated Polymarket BTC reference price: ${}", currentPolymarketPrice);
    }

    private BigDecimal calculatePercentageChange(BigDecimal startPrice, BigDecimal currentPrice) {
        if (startPrice.compareTo(BigDecimal.ZERO) == 0) {
            return BigDecimal.ZERO;
        }

        return currentPrice.subtract(startPrice)
                .divide(startPrice, 6, RoundingMode.HALF_UP)
                .multiply(new BigDecimal("100"));
    }

    /**
     * Determines which direction to trade on POLYMARKET based on Coinbase price divergence.
     *
     * TRADING LOGIC:
     * - priceDifference = Coinbase - Polymarket Reference (in dollars)
     * - minimumEdgeThreshold = minimum dollar difference required to trigger signal
     * - If Coinbase > Polymarket (positive) AND exceeds threshold: BTC trending UP -> BUY UP on Polymarket
     * - If Coinbase < Polymarket (negative) AND exceeds threshold: BTC trending DOWN -> BUY DOWN on Polymarket
     *
     * Example 1: Coinbase $93,400, Polymarket $93,350 -> diff = +$50, threshold $5 -> BUY UP
     * Example 2: Coinbase $93,300, Polymarket $93,350 -> diff = -$50, threshold $5 -> BUY DOWN
     * Example 3: Coinbase $93,302, Polymarket $93,350 -> diff = -$48, threshold $50 -> NONE
     */
    private ArbitrageOpportunity.ArbitrageDirection determineDirectionByPriceDivergence(
            BigDecimal priceDifference) {

        BigDecimal absDiff = priceDifference.abs();
        int comparisonResult = absDiff.compareTo(minimumEdgeThreshold);

        logger.debug("Threshold check: |{}| vs {} => comparison={} ({})",
            priceDifference, minimumEdgeThreshold, comparisonResult,
            comparisonResult >= 0 ? "PASS" : "FAIL");

        if (comparisonResult < 0) {
            logger.debug("Below threshold, returning NONE");
            return ArbitrageOpportunity.ArbitrageDirection.NONE;
        }

        // Coinbase price HIGHER than Polymarket reference -> BUY UP
        if (priceDifference.compareTo(BigDecimal.ZERO) > 0) {
            logger.debug("Coinbase > Polymarket => BUY_UP");
            return ArbitrageOpportunity.ArbitrageDirection.BUY_UP;
        }
        // Coinbase price LOWER than Polymarket reference -> BUY DOWN
        else {
            logger.debug("Coinbase < Polymarket => BUY_DOWN");
            return ArbitrageOpportunity.ArbitrageDirection.BUY_DOWN;
        }
    }

    public void resetMarketStartPrice(String marketSlug) {
        marketStartPrices.remove(marketSlug);
        logger.info("Reset market start price for slug: {}", marketSlug);
    }

    public BigDecimal getCurrentCoinbasePrice() {
        return currentCoinbasePrice;
    }

    public BigDecimal getCurrentChainlinkPrice() {
        return currentPolymarketPrice;
    }

    public BigDecimal getCurrentPolymarketPrice() {
        return currentPolymarketPrice;
    }

    public void setMinimumEdgeThreshold(BigDecimal threshold) {
        this.minimumEdgeThreshold = threshold;
        logger.info("Updated minimum BTC price difference threshold to: ${} USD", threshold);
    }

    public BigDecimal getMinimumEdgeThreshold() {
        return minimumEdgeThreshold;
    }

    public void setMinimumCentsDivergence(BigDecimal cents) {
        this.minimumCentsDivergence = cents;
        logger.info("Updated minimum cents divergence to: {} cents (${} threshold)",
            cents, cents.divide(new BigDecimal("100"), 4, RoundingMode.HALF_UP));
    }

    public BigDecimal getMinimumCentsDivergence() {
        return minimumCentsDivergence;
    }

    public void close() {
        coinbaseClient.close();
        gammaClient.close();
    }
}
