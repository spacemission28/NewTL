package com.polymarket.orderbook.service;

import com.polymarket.orderbook.engine.OrderBookEngine;
import com.polymarket.orderbook.model.OrderBookSnapshot;
import com.polymarket.orderbook.model.SimulatedTrade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class HoldToResolutionSimulation {

    private static final Logger logger = LoggerFactory.getLogger(HoldToResolutionSimulation.class);
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final OrderBookEngine orderBookEngine;
    private final String logFilePath;

    private boolean simulationEnabled;
    private boolean shouldEnterInitialTrade;
    private int tradesOpened;
    private int tradesClosedEarly;
    private int tradesWon;
    private int tradesLost;
    private BigDecimal cumulativeProfitLoss;
    private List<HoldToResolutionTrade> openTrades;
    private LocalDateTime marketEndTime;

    public HoldToResolutionSimulation(OrderBookEngine orderBookEngine, String marketSlug) {
        this.orderBookEngine = orderBookEngine;
        this.logFilePath = "hold_to_resolution_trades_" + marketSlug.replaceAll("[^a-zA-Z0-9-]", "_") + ".txt";
        this.simulationEnabled = false;
        this.shouldEnterInitialTrade = false;
        this.tradesOpened = 0;
        this.tradesClosedEarly = 0;
        this.tradesWon = 0;
        this.tradesLost = 0;
        this.cumulativeProfitLoss = BigDecimal.ZERO;
        this.openTrades = new ArrayList<>();
        initializeLogFile();
    }

    private void initializeLogFile() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(logFilePath, false))) {
            writer.println("=== Hold To Resolution Strategy Simulation Log ===");
            writer.println("Format: Open Time | Entry YES Price | Entry NO Price | Closed Side | Close Price | Close Time | P&L | Status");
            writer.println("=====================================================================================================");
        } catch (IOException e) {
            logger.error("Failed to initialize log file: {}", logFilePath, e);
        }
    }

    public void setMarketEndTime(LocalDateTime endTime) {
        this.marketEndTime = endTime;
        logger.info("Market end time set to: {}", endTime);
    }

    public void checkAndSimulate(String yesAssetId, String noAssetId, BigDecimal totalAmount) {
        if (!simulationEnabled) {
            return;
        }

        OrderBookSnapshot yesSnapshot = orderBookEngine.getSnapshot(yesAssetId);
        OrderBookSnapshot noSnapshot = orderBookEngine.getSnapshot(noAssetId);

        if (yesSnapshot == null || noSnapshot == null) {
            return;
        }

        BigDecimal yesMidPrice = yesSnapshot.getMidPrice();
        BigDecimal noMidPrice = noSnapshot.getMidPrice();

        if (yesMidPrice.compareTo(BigDecimal.ZERO) == 0 || noMidPrice.compareTo(BigDecimal.ZERO) == 0) {
            return;
        }

        BigDecimal totalCost = yesMidPrice.add(noMidPrice);

        if (shouldEnterInitialTrade && openTrades.isEmpty()) {
            logger.info("Entering initial hold-to-resolution split trade at start of simulation");
            simulateTrade(yesAssetId, noAssetId, yesMidPrice, noMidPrice, totalAmount, totalCost);
            shouldEnterInitialTrade = false;
        } else if (totalCost.compareTo(new BigDecimal("1.00")) < 0) {
            simulateTrade(yesAssetId, noAssetId, yesMidPrice, noMidPrice, totalAmount, totalCost);
        }

        checkCloseTrades(yesAssetId, noAssetId);
    }

    private void simulateTrade(String yesAssetId, String noAssetId, BigDecimal yesPrice,
                               BigDecimal noPrice, BigDecimal totalAmount, BigDecimal totalCost) {

        BigDecimal halfAmount = totalAmount.divide(new BigDecimal("2"), 4, RoundingMode.HALF_UP);
        BigDecimal yesQuantity = halfAmount.divide(yesPrice, 4, RoundingMode.HALF_UP);
        BigDecimal noQuantity = halfAmount.divide(noPrice, 4, RoundingMode.HALF_UP);

        HoldToResolutionTrade trade = new HoldToResolutionTrade();
        trade.setYesAssetId(yesAssetId);
        trade.setNoAssetId(noAssetId);
        trade.setOpenPriceYes(yesPrice);
        trade.setOpenPriceNo(noPrice);
        trade.setYesAmount(halfAmount);
        trade.setNoAmount(halfAmount);
        trade.setYesQuantity(yesQuantity);
        trade.setNoQuantity(noQuantity);
        trade.setTotalCost(totalCost.multiply(totalAmount));

        openTrades.add(trade);
        tradesOpened++;

        logger.info("Hold-to-Resolution trade opened: YES={} (${}) + NO={} (${}) = Total Cost ${}",
            yesPrice, halfAmount, noPrice, halfAmount, trade.getTotalCost());
    }

    private void checkCloseTrades(String yesAssetId, String noAssetId) {
        if (marketEndTime == null) {
            return;
        }

        OrderBookSnapshot yesSnapshot = orderBookEngine.getSnapshot(yesAssetId);
        OrderBookSnapshot noSnapshot = orderBookEngine.getSnapshot(noAssetId);

        if (yesSnapshot == null || noSnapshot == null) {
            return;
        }

        BigDecimal yesMidPrice = yesSnapshot.getMidPrice();
        BigDecimal noMidPrice = noSnapshot.getMidPrice();

        LocalDateTime now = LocalDateTime.now();
        LocalDateTime threeMinutesBeforeEnd = marketEndTime.minusMinutes(3);

        boolean canClose = now.isAfter(threeMinutesBeforeEnd);

        List<HoldToResolutionTrade> tradesToUpdate = new ArrayList<>();

        for (HoldToResolutionTrade trade : openTrades) {
            if (trade.isYesClosed() && trade.isNoClosed()) {
                continue;
            }

            if (canClose) {
                if (!trade.isYesClosed() && yesMidPrice.compareTo(new BigDecimal("0.10")) <= 0) {
                    trade.setYesClosed(true);
                    trade.setYesClosePrice(yesMidPrice);
                    trade.setYesCloseTime(now);
                    tradesClosedEarly++;
                    logger.info("Closed YES side at ${} (reached 10c threshold)", yesMidPrice);
                    tradesToUpdate.add(trade);
                }

                if (!trade.isNoClosed() && noMidPrice.compareTo(new BigDecimal("0.10")) <= 0) {
                    trade.setNoClosed(true);
                    trade.setNoClosePrice(noMidPrice);
                    trade.setNoCloseTime(now);
                    tradesClosedEarly++;
                    logger.info("Closed NO side at ${} (reached 10c threshold)", noMidPrice);
                    tradesToUpdate.add(trade);
                }
            }
        }

        for (HoldToResolutionTrade trade : tradesToUpdate) {
            logTradeToFile(trade, "Partial Close");
        }
    }

    public void simulateResolution(String winningSide) {
        for (HoldToResolutionTrade trade : openTrades) {
            BigDecimal pnl = BigDecimal.ZERO;

            BigDecimal yesProceeds = BigDecimal.ZERO;
            if (trade.isYesClosed()) {
                yesProceeds = trade.getYesClosePrice().multiply(trade.getYesAmount());
            } else if ("YES".equalsIgnoreCase(winningSide)) {
                yesProceeds = trade.getYesAmount();
                tradesWon++;
            } else {
                tradesLost++;
            }

            BigDecimal noProceeds = BigDecimal.ZERO;
            if (trade.isNoClosed()) {
                noProceeds = trade.getNoClosePrice().multiply(trade.getNoAmount());
            } else if ("NO".equalsIgnoreCase(winningSide)) {
                noProceeds = trade.getNoAmount();
                tradesWon++;
            } else {
                tradesLost++;
            }

            pnl = yesProceeds.add(noProceeds).subtract(trade.getTotalCost());
            trade.setProfitLoss(pnl);
            cumulativeProfitLoss = cumulativeProfitLoss.add(pnl);

            logTradeToFile(trade, "Resolved - " + winningSide + " won");
        }

        openTrades.clear();
    }

    public BigDecimal calculateUnrealizedPL(String yesAssetId, String noAssetId) {
        OrderBookSnapshot yesSnapshot = orderBookEngine.getSnapshot(yesAssetId);
        OrderBookSnapshot noSnapshot = orderBookEngine.getSnapshot(noAssetId);

        if (yesSnapshot == null || noSnapshot == null) {
            return BigDecimal.ZERO;
        }

        BigDecimal yesMidPrice = yesSnapshot.getMidPrice();
        BigDecimal noMidPrice = noSnapshot.getMidPrice();
        BigDecimal totalUnrealized = BigDecimal.ZERO;

        for (HoldToResolutionTrade trade : openTrades) {
            BigDecimal yesValue = trade.isYesClosed() ?
                trade.getYesClosePrice().multiply(trade.getYesAmount()) :
                yesMidPrice.multiply(trade.getYesAmount());

            BigDecimal noValue = trade.isNoClosed() ?
                trade.getNoClosePrice().multiply(trade.getNoAmount()) :
                noMidPrice.multiply(trade.getNoAmount());

            BigDecimal unrealizedPL = yesValue.add(noValue).subtract(trade.getTotalCost());
            totalUnrealized = totalUnrealized.add(unrealizedPL);
        }

        return totalUnrealized;
    }

    private void logTradeToFile(HoldToResolutionTrade trade, String status) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(logFilePath, true))) {
            String openTime = trade.getOpenTime().format(TIME_FORMAT);
            String yesClose = trade.isYesClosed() ?
                String.format("YES: $%s @ %s",
                    trade.getYesClosePrice().setScale(4, RoundingMode.HALF_UP),
                    trade.getYesCloseTime().format(TIME_FORMAT)) : "YES: HELD";
            String noClose = trade.isNoClosed() ?
                String.format("NO: $%s @ %s",
                    trade.getNoClosePrice().setScale(4, RoundingMode.HALF_UP),
                    trade.getNoCloseTime().format(TIME_FORMAT)) : "NO: HELD";
            String pnl = trade.getProfitLoss() != null ?
                trade.getProfitLoss().setScale(4, RoundingMode.HALF_UP).toString() : "OPEN";

            writer.printf("%s | YES=$%s | NO=$%s | %s | %s | $%s | %s%n",
                openTime,
                trade.getOpenPriceYes().setScale(4, RoundingMode.HALF_UP),
                trade.getOpenPriceNo().setScale(4, RoundingMode.HALF_UP),
                yesClose, noClose, pnl, status);
        } catch (IOException e) {
            logger.error("Failed to write trade to log file", e);
        }
    }

    public void reset() {
        tradesOpened = 0;
        tradesClosedEarly = 0;
        tradesWon = 0;
        tradesLost = 0;
        cumulativeProfitLoss = BigDecimal.ZERO;
        openTrades.clear();
        shouldEnterInitialTrade = simulationEnabled;
        initializeLogFile();
        logger.info("Hold-to-Resolution simulation reset");
    }

    public void setSimulationEnabled(boolean enabled) {
        this.simulationEnabled = enabled;
        if (enabled) {
            this.shouldEnterInitialTrade = true;
            logger.info("Hold-to-Resolution simulation ENABLED - will enter initial trade on next check");
        } else {
            this.shouldEnterInitialTrade = false;
            logger.info("Hold-to-Resolution simulation DISABLED");
        }
    }

    public boolean isSimulationEnabled() {
        return simulationEnabled;
    }

    public int getTradesOpened() {
        return tradesOpened;
    }

    public int getTradesClosedEarly() {
        return tradesClosedEarly;
    }

    public int getTradesWon() {
        return tradesWon;
    }

    public int getTradesLost() {
        return tradesLost;
    }

    public BigDecimal getCumulativeProfitLoss() {
        return cumulativeProfitLoss;
    }

    public int getOpenTradesCount() {
        return openTrades.size();
    }

    public void resetStats() {
        reset();
    }

    public BigDecimal getTotalYesQuantity() {
        BigDecimal total = BigDecimal.ZERO;
        for (HoldToResolutionTrade trade : openTrades) {
            if (!trade.isYesClosed() && trade.getYesQuantity() != null) {
                total = total.add(trade.getYesQuantity());
            }
        }
        return total;
    }

    public BigDecimal getTotalNoQuantity() {
        BigDecimal total = BigDecimal.ZERO;
        for (HoldToResolutionTrade trade : openTrades) {
            if (!trade.isNoClosed() && trade.getNoQuantity() != null) {
                total = total.add(trade.getNoQuantity());
            }
        }
        return total;
    }

    private static class HoldToResolutionTrade {
        private String yesAssetId;
        private String noAssetId;
        private LocalDateTime openTime;
        private BigDecimal openPriceYes;
        private BigDecimal openPriceNo;
        private BigDecimal yesAmount;
        private BigDecimal noAmount;
        private BigDecimal yesQuantity;
        private BigDecimal noQuantity;
        private BigDecimal totalCost;

        private boolean yesClosed;
        private BigDecimal yesClosePrice;
        private LocalDateTime yesCloseTime;

        private boolean noClosed;
        private BigDecimal noClosePrice;
        private LocalDateTime noCloseTime;

        private BigDecimal profitLoss;

        public HoldToResolutionTrade() {
            this.openTime = LocalDateTime.now();
            this.yesClosed = false;
            this.noClosed = false;
        }

        public String getYesAssetId() { return yesAssetId; }
        public void setYesAssetId(String yesAssetId) { this.yesAssetId = yesAssetId; }

        public String getNoAssetId() { return noAssetId; }
        public void setNoAssetId(String noAssetId) { this.noAssetId = noAssetId; }

        public LocalDateTime getOpenTime() { return openTime; }

        public BigDecimal getOpenPriceYes() { return openPriceYes; }
        public void setOpenPriceYes(BigDecimal openPriceYes) { this.openPriceYes = openPriceYes; }

        public BigDecimal getOpenPriceNo() { return openPriceNo; }
        public void setOpenPriceNo(BigDecimal openPriceNo) { this.openPriceNo = openPriceNo; }

        public BigDecimal getYesAmount() { return yesAmount; }
        public void setYesAmount(BigDecimal yesAmount) { this.yesAmount = yesAmount; }

        public BigDecimal getNoAmount() { return noAmount; }
        public void setNoAmount(BigDecimal noAmount) { this.noAmount = noAmount; }

        public BigDecimal getYesQuantity() { return yesQuantity; }
        public void setYesQuantity(BigDecimal yesQuantity) { this.yesQuantity = yesQuantity; }

        public BigDecimal getNoQuantity() { return noQuantity; }
        public void setNoQuantity(BigDecimal noQuantity) { this.noQuantity = noQuantity; }

        public BigDecimal getTotalCost() { return totalCost; }
        public void setTotalCost(BigDecimal totalCost) { this.totalCost = totalCost; }

        public boolean isYesClosed() { return yesClosed; }
        public void setYesClosed(boolean yesClosed) { this.yesClosed = yesClosed; }

        public BigDecimal getYesClosePrice() { return yesClosePrice; }
        public void setYesClosePrice(BigDecimal yesClosePrice) { this.yesClosePrice = yesClosePrice; }

        public LocalDateTime getYesCloseTime() { return yesCloseTime; }
        public void setYesCloseTime(LocalDateTime yesCloseTime) { this.yesCloseTime = yesCloseTime; }

        public boolean isNoClosed() { return noClosed; }
        public void setNoClosed(boolean noClosed) { this.noClosed = noClosed; }

        public BigDecimal getNoClosePrice() { return noClosePrice; }
        public void setNoClosePrice(BigDecimal noClosePrice) { this.noClosePrice = noClosePrice; }

        public LocalDateTime getNoCloseTime() { return noCloseTime; }
        public void setNoCloseTime(LocalDateTime noCloseTime) { this.noCloseTime = noCloseTime; }

        public BigDecimal getProfitLoss() { return profitLoss; }
        public void setProfitLoss(BigDecimal profitLoss) { this.profitLoss = profitLoss; }
    }
}
