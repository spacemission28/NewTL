package com.polymarket.orderbook.service;

import com.polymarket.orderbook.model.ArbitrageOpportunity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class LocalArbitrageStorage {

    private static final Logger logger = LoggerFactory.getLogger(LocalArbitrageStorage.class);
    private static final String DATA_DIR = "arbitrage_data";
    private static final DateTimeFormatter FILE_DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter TIMESTAMP_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final Path dataDirectory;
    private int totalOpportunitiesDetected;
    private BigDecimal sumOfEdges;
    private BigDecimal maxEdgeSeen;
    private BigDecimal minEdgeSeen;

    public LocalArbitrageStorage() {
        this.dataDirectory = Paths.get(DATA_DIR);
        this.totalOpportunitiesDetected = 0;
        this.sumOfEdges = BigDecimal.ZERO;
        this.maxEdgeSeen = BigDecimal.ZERO;
        this.minEdgeSeen = new BigDecimal("999999");
        ensureDirectoryExists();
    }

    private void ensureDirectoryExists() {
        try {
            if (!Files.exists(dataDirectory)) {
                Files.createDirectories(dataDirectory);
                logger.info("Created arbitrage data directory: {}", dataDirectory.toAbsolutePath());
            }
        } catch (IOException e) {
            logger.error("Failed to create arbitrage data directory", e);
        }
    }

    public void saveOpportunity(ArbitrageOpportunity opportunity) {
        try {
            totalOpportunitiesDetected++;
            BigDecimal edge = opportunity.getArbitrageEdge();
            if (edge != null) {
                sumOfEdges = sumOfEdges.add(edge);
                if (edge.compareTo(maxEdgeSeen) > 0) {
                    maxEdgeSeen = edge;
                }
                if (edge.compareTo(minEdgeSeen) < 0) {
                    minEdgeSeen = edge;
                }
            }

            String today = FILE_DATE_FORMAT.format(Instant.now().atZone(ZoneId.systemDefault()));
            Path csvFile = dataDirectory.resolve("arbitrage_" + today + ".csv");

            boolean isNewFile = !Files.exists(csvFile);

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(csvFile.toFile(), true))) {
                if (isNewFile) {
                    writeHeader(writer);
                }
                writeOpportunity(writer, opportunity);
            }

            if (totalOpportunitiesDetected % 100 == 0) {
                logger.info("Arbitrage tracking stats - Total: {}, Avg Edge: ${}, Max: ${}, Min: ${}",
                    totalOpportunitiesDetected,
                    getAverageEdge().setScale(2, java.math.RoundingMode.HALF_UP),
                    maxEdgeSeen.setScale(2, java.math.RoundingMode.HALF_UP),
                    minEdgeSeen.setScale(2, java.math.RoundingMode.HALF_UP));
            }

            logger.debug("Saved arbitrage opportunity to: {} (Total: {})", csvFile.getFileName(), totalOpportunitiesDetected);

        } catch (IOException e) {
            logger.error("Failed to save arbitrage opportunity to file", e);
        }
    }

    private void writeHeader(BufferedWriter writer) throws IOException {
        writer.write("timestamp,market_slug,market_question,");
        writer.write("coinbase_price,market_start_price,actual_change_pct,");
        writer.write("poly_up_prob,poly_down_prob,arbitrage_edge_pct,");
        writer.write("direction,has_opportunity");
        writer.newLine();
    }

    private void writeOpportunity(BufferedWriter writer, ArbitrageOpportunity opportunity) throws IOException {
        String timestamp = TIMESTAMP_FORMAT.format(
                Instant.ofEpochMilli(opportunity.getTimestamp()).atZone(ZoneId.systemDefault())
        );

        writer.write(quote(timestamp));
        writer.write(",");
        writer.write(quote(opportunity.getMarketSlug()));
        writer.write(",");
        writer.write(quote(opportunity.getMarketQuestion()));
        writer.write(",");
        writer.write(formatBigDecimal(opportunity.getCoinbasePrice()));
        writer.write(",");
        writer.write(formatBigDecimal(opportunity.getCoinbasePriceAtMarketStart()));
        writer.write(",");
        writer.write(formatBigDecimal(opportunity.getActualPriceChange()));
        writer.write(",");
        writer.write(formatBigDecimal(opportunity.getPolymarketUpProbability()));
        writer.write(",");
        writer.write(formatBigDecimal(opportunity.getPolymarketDownProbability()));
        writer.write(",");
        writer.write(formatBigDecimal(opportunity.getArbitrageEdge()));
        writer.write(",");
        writer.write(opportunity.getDirection() != null ? opportunity.getDirection().name() : "NONE");
        writer.write(",");
        writer.write(String.valueOf(opportunity.hasOpportunity()));
        writer.newLine();
    }

    private String quote(String value) {
        if (value == null) {
            return "\"\"";
        }
        return "\"" + value.replace("\"", "\"\"") + "\"";
    }

    private String formatBigDecimal(BigDecimal value) {
        return value != null ? value.toString() : "0";
    }

    public File getDataDirectory() {
        return dataDirectory.toFile();
    }

    public Path getTodaysCsvFile() {
        String today = FILE_DATE_FORMAT.format(Instant.now().atZone(ZoneId.systemDefault()));
        return dataDirectory.resolve("arbitrage_" + today + ".csv");
    }

    public int getTotalOpportunitiesDetected() {
        return totalOpportunitiesDetected;
    }

    public BigDecimal getAverageEdge() {
        if (totalOpportunitiesDetected == 0) {
            return BigDecimal.ZERO;
        }
        return sumOfEdges.divide(new BigDecimal(totalOpportunitiesDetected), 6, java.math.RoundingMode.HALF_UP);
    }

    public BigDecimal getMaxEdgeSeen() {
        return maxEdgeSeen;
    }

    public BigDecimal getMinEdgeSeen() {
        return minEdgeSeen.compareTo(new BigDecimal("999999")) == 0 ? BigDecimal.ZERO : minEdgeSeen;
    }

    public void resetStats() {
        totalOpportunitiesDetected = 0;
        sumOfEdges = BigDecimal.ZERO;
        maxEdgeSeen = BigDecimal.ZERO;
        minEdgeSeen = new BigDecimal("999999");
        logger.info("Arbitrage storage stats reset");
    }
}
