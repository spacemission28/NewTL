package com.polymarket.orderbook.service;

import com.polymarket.orderbook.model.ArbitrageOpportunity;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public class ArbitragePersistenceService {

    private static final Logger logger = LoggerFactory.getLogger(ArbitragePersistenceService.class);

    private final String supabaseUrl;
    private final String supabaseKey;
    private final CloseableHttpClient httpClient;

    public ArbitragePersistenceService(String supabaseUrl, String supabaseKey) {
        this.supabaseUrl = supabaseUrl;
        this.supabaseKey = supabaseKey;
        this.httpClient = HttpClients.createDefault();
    }

    public void saveOpportunity(ArbitrageOpportunity opportunity) {
        try {
            String endpoint = supabaseUrl + "/rest/v1/arbitrage_opportunities";

            String jsonBody = buildJsonPayload(opportunity);

            HttpPost request = new HttpPost(endpoint);
            request.setHeader("apikey", supabaseKey);
            request.setHeader("Authorization", "Bearer " + supabaseKey);
            request.setHeader("Content-Type", "application/json");
            request.setHeader("Prefer", "return=minimal");

            request.setEntity(new StringEntity(jsonBody, ContentType.APPLICATION_JSON));

            try (CloseableHttpResponse response = httpClient.execute(request)) {
                int statusCode = response.getCode();

                if (statusCode >= 200 && statusCode < 300) {
                    logger.debug("Saved arbitrage opportunity to Supabase: {}", opportunity.getMarketSlug());
                } else {
                    logger.warn("Failed to save arbitrage opportunity. Status: {}", statusCode);
                }
            }

        } catch (IOException e) {
            logger.error("Error saving arbitrage opportunity to Supabase", e);
        }
    }

    private String buildJsonPayload(ArbitrageOpportunity opportunity) {
        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"market_slug\":").append(quote(opportunity.getMarketSlug())).append(",");
        json.append("\"market_question\":").append(quote(opportunity.getMarketQuestion())).append(",");
        json.append("\"polymarket_up_probability\":").append(opportunity.getPolymarketUpProbability()).append(",");
        json.append("\"polymarket_down_probability\":").append(opportunity.getPolymarketDownProbability()).append(",");
        json.append("\"coinbase_price\":").append(opportunity.getCoinbasePrice()).append(",");
        json.append("\"market_start_price\":").append(opportunity.getCoinbasePriceAtMarketStart()).append(",");
        json.append("\"actual_price_change_pct\":").append(opportunity.getActualPriceChange()).append(",");
        json.append("\"arbitrage_edge_pct\":").append(opportunity.getArbitrageEdge()).append(",");
        json.append("\"direction\":").append(quote(opportunity.getDirection().name())).append(",");
        json.append("\"has_opportunity\":").append(opportunity.hasOpportunity());
        json.append("}");
        return json.toString();
    }

    private String quote(String value) {
        if (value == null) {
            return "null";
        }
        return "\"" + value.replace("\"", "\\\"") + "\"";
    }

    public void close() {
        try {
            if (httpClient != null) {
                httpClient.close();
            }
        } catch (IOException e) {
            logger.error("Failed to close HTTP client", e);
        }
    }
}
