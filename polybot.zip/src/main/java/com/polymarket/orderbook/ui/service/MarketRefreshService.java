package com.polymarket.orderbook.ui.service;

import com.polymarket.orderbook.model.Market;
import com.polymarket.orderbook.service.MarketService;
import javafx.concurrent.ScheduledService;
import javafx.concurrent.Task;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MarketRefreshService extends ScheduledService<Market> {

    private static final Logger logger = LoggerFactory.getLogger(MarketRefreshService.class);

    private final String marketSlug;
    private final MarketService marketService;

    public MarketRefreshService(String marketSlug, MarketService marketService) {
        this.marketSlug = marketSlug;
        this.marketService = marketService;
    }

    @Override
    protected Task<Market> createTask() {
        return new Task<Market>() {
            @Override
            protected Market call() throws Exception {
                logger.debug("Checking for market updates for slug: {}", marketSlug);
                Market market = marketService.fetchMarket(marketSlug);

                if (market == null) {
                    logger.warn("Failed to fetch market for slug: {}", marketSlug);
                    return null;
                }

                logger.debug("Fetched market - active: {}, question: {}",
                            market.getActive(), market.getQuestion());

                return market;
            }
        };
    }
}
