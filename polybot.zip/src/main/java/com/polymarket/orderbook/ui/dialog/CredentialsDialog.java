package com.polymarket.orderbook.ui.dialog;

import com.polymarket.orderbook.config.PolymarketCredentials;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CredentialsDialog extends Dialog<PolymarketCredentials> {

    private static final Logger logger = LoggerFactory.getLogger(CredentialsDialog.class);

    private final TextField apiKeyField;
    private final PasswordField apiSecretField;
    private final PasswordField apiPassphraseField;
    private final PasswordField privateKeyField;
    private final PolymarketCredentials credentials;

    public CredentialsDialog(PolymarketCredentials credentials) {
        this.credentials = credentials;

        setTitle("Polymarket API Credentials");
        setHeaderText("Enter your Polymarket credentials\n(From Polymarket dashboard + MetaMask wallet)");

        apiKeyField = new TextField();
        apiKeyField.setPromptText("Your API Key");
        apiKeyField.setPrefWidth(400);
        apiKeyField.setFont(Font.font("Roboto", 14));

        apiSecretField = new PasswordField();
        apiSecretField.setPromptText("Your API Secret");
        apiSecretField.setPrefWidth(400);
        apiSecretField.setFont(Font.font("Roboto", 14));

        apiPassphraseField = new PasswordField();
        apiPassphraseField.setPromptText("Your API Passphrase");
        apiPassphraseField.setPrefWidth(400);
        apiPassphraseField.setFont(Font.font("Roboto", 14));

        privateKeyField = new PasswordField();
        privateKeyField.setPromptText("Your MetaMask Private Key (64 hex characters)");
        privateKeyField.setPrefWidth(400);
        privateKeyField.setFont(Font.font("Roboto", 14));

        if (credentials.isAuthenticated()) {
            apiKeyField.setText(credentials.getApiKey());
            apiSecretField.setText(credentials.getApiSecret());
            apiPassphraseField.setText(credentials.getApiPassphrase());
        }

        if (credentials.hasPrivateKey()) {
            privateKeyField.setText(credentials.getPrivateKey());
        }

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 20, 10, 20));

        grid.add(new Label("API Key:"), 0, 0);
        grid.add(apiKeyField, 1, 0);
        grid.add(new Label("API Secret:"), 0, 1);
        grid.add(apiSecretField, 1, 1);
        grid.add(new Label("API Passphrase:"), 0, 2);
        grid.add(apiPassphraseField, 1, 2);
        grid.add(new Label("Private Key:"), 0, 3);
        grid.add(privateKeyField, 1, 3);

        Label infoLabel = new Label(
            "API credentials from Polymarket dashboard (https://polymarket.com/settings/api)\n" +
            "Private Key from MetaMask: Account Details → Export Private Key\n\n" +
            "All credentials are stored encrypted in: ~/.polymarket_credentials"
        );
        infoLabel.setWrapText(true);
        infoLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #666;");
        infoLabel.setPadding(new Insets(10, 0, 0, 0));

        VBox content = new VBox(10);
        content.getChildren().addAll(grid, infoLabel);

        getDialogPane().setContent(content);

        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelButtonType = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        getDialogPane().getButtonTypes().addAll(saveButtonType, cancelButtonType);

        Button saveButton = (Button) getDialogPane().lookupButton(saveButtonType);
        saveButton.setDisable(true);

        apiKeyField.textProperty().addListener((observable, oldValue, newValue) -> {
            saveButton.setDisable(!validateFields());
        });
        apiSecretField.textProperty().addListener((observable, oldValue, newValue) -> {
            saveButton.setDisable(!validateFields());
        });
        apiPassphraseField.textProperty().addListener((observable, oldValue, newValue) -> {
            saveButton.setDisable(!validateFields());
        });
        privateKeyField.textProperty().addListener((observable, oldValue, newValue) -> {
            saveButton.setDisable(!validateFields());
        });

        saveButton.setDisable(!validateFields());

        setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                String apiKey = apiKeyField.getText().trim();
                String secret = apiSecretField.getText().trim();
                String passphrase = apiPassphraseField.getText().trim();
                String privateKey = privateKeyField.getText().trim();

                String normalizedPrivateKey = privateKey.replaceAll("^0x", "");

                credentials.setCredentials(apiKey, secret, passphrase, normalizedPrivateKey);

                if (!normalizedPrivateKey.isEmpty()) {
                    try {
                        org.web3j.crypto.ECKeyPair keyPair = org.web3j.crypto.ECKeyPair.create(
                                new java.math.BigInteger(normalizedPrivateKey, 16)
                        );
                        org.web3j.crypto.Credentials web3Creds = org.web3j.crypto.Credentials.create(keyPair);
                        String walletAddress = web3Creds.getAddress();
                        credentials.setWalletAddress(walletAddress);
                        logger.info("Derived wallet address from private key: {}", walletAddress);
                    } catch (Exception e) {
                        logger.error("Failed to derive wallet address from private key", e);
                    }
                }

                credentials.saveToFile();

                logger.info("Credentials saved successfully");
                return credentials;
            }
            return null;
        });
    }

    private boolean validateFields() {
        String apiKey = apiKeyField.getText().trim();
        String secret = apiSecretField.getText().trim();
        String passphrase = apiPassphraseField.getText().trim();
        String privateKey = privateKeyField.getText().trim();

        boolean basicFieldsValid = !apiKey.isEmpty() && !secret.isEmpty() && !passphrase.isEmpty();

        if (!privateKey.isEmpty()) {
            String cleanKey = privateKey.replaceAll("^0x", "");
            boolean validLength = cleanKey.length() == 64;
            boolean validHex = cleanKey.matches("[0-9a-fA-F]+");
            return basicFieldsValid && validLength && validHex;
        }

        return basicFieldsValid;
    }
}
