package com.tradelogic.models;

public class TradeHistoryEntry {
    private long ticket;
    private long magic;
    private String symbol;
    private long timestamp;
    private String orderType;
    private String state;

    public TradeHistoryEntry() {}

    public TradeHistoryEntry(long ticket, long magic, String symbol, long timestamp) {
        this.ticket = ticket;
        this.magic = magic;
        this.symbol = symbol;
        this.timestamp = timestamp;
    }

    public TradeHistoryEntry(long ticket, long magic, String symbol, long timestamp, String orderType, String state) {
        this.ticket = ticket;
        this.magic = magic;
        this.symbol = symbol;
        this.timestamp = timestamp;
        this.orderType = orderType;
        this.state = state;
    }

    public long getTicket() {
        return ticket;
    }

    public void setTicket(long ticket) {
        this.ticket = ticket;
    }

    public long getMagic() {
        return magic;
    }

    public void setMagic(long magic) {
        this.magic = magic;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    @Override
    public String toString() {
        return String.format("TradeHistoryEntry{ticket=%d, magic=%d, symbol='%s', timestamp=%d, orderType='%s', state='%s'}",
            ticket, magic, symbol, timestamp, orderType, state);
    }
}
