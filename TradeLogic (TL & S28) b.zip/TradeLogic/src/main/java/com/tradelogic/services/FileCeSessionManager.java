package com.tradelogic.services;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.*;
import java.nio.file.*;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class FileCeSessionManager {

    public static class CeSession {
        public long id;
        public String robotId;
        public int currentSequence;
        public Long lastCandleTime;

        public CeSession(long id, String robotId, int currentSequence, Long lastCandleTime) {
            this.id = id;
            this.robotId = robotId;
            this.currentSequence = currentSequence;
            this.lastCandleTime = lastCandleTime;
        }
    }

    private final String dataFolder;
    private final String sessionFile;
    private final Map<String, CeSession> sessions = new ConcurrentHashMap<>();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private long nextId = 1;

    public FileCeSessionManager(String dataFolder) {
        this.dataFolder = dataFolder;
        this.sessionFile = dataFolder + "/ce_sessions.json";
        loadSessions();
    }

    private void loadSessions() {
        try {
            Path path = Paths.get(sessionFile);
            if (Files.exists(path)) {
                String json = new String(Files.readAllBytes(path));
                CeSession[] loadedSessions = gson.fromJson(json, CeSession[].class);
                if (loadedSessions != null) {
                    for (CeSession session : loadedSessions) {
                        sessions.put(session.robotId, session);
                        if (session.id >= nextId) {
                            nextId = session.id + 1;
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Failed to load C.E. sessions: " + e.getMessage());
        }
    }

    private void saveSessions() {
        try {
            Path folder = Paths.get(dataFolder);
            if (!Files.exists(folder)) {
                Files.createDirectories(folder);
            }

            String json = gson.toJson(sessions.values());
            Files.write(Paths.get(sessionFile), json.getBytes());
        } catch (Exception e) {
            System.err.println("Failed to save C.E. sessions: " + e.getMessage());
        }
    }

    public CeSession getOrCreateSession(String robotId, Long firstCandleTime) {
        return sessions.computeIfAbsent(robotId, id -> {
            CeSession session = new CeSession(nextId++, robotId, 0, firstCandleTime);
            saveSessions();
            return session;
        });
    }

    public boolean updateSession(long sessionId, int newSequence, long newCandleTime) {
        for (CeSession session : sessions.values()) {
            if (session.id == sessionId) {
                session.currentSequence = newSequence;
                session.lastCandleTime = newCandleTime;
                saveSessions();
                return true;
            }
        }
        return false;
    }
}
