#!/usr/bin/env python3
"""
Polymarket BTC Monitor - Live prices with integrated Coinbase feed
Monitors Polymarket 15-min BTC markets and Coinbase BTC prices
No need for separate coinbase_btc_feed.py
"""

import os
import asyncio
import json
import subprocess
import re
import time
import platform
from datetime import datetime, timezone, timedelta
from dotenv import load_dotenv
import websockets
from py_clob_client.client import ClobClient
from py_clob_client.clob_types import MarketOrderArgs, OrderArgs, OrderType
from py_clob_client.order_builder.constants import BUY, SELL

load_dotenv()

PK = os.getenv("PK")
if not PK:
    print("❌ ERROR: PK not found in .env file")
    print("Make sure you're running this from the folder containing .env")
    exit(1)

# Initialize CLOB client to get API key
client = ClobClient("https://clob.polymarket.com", key=PK, chain_id=137, signature_type=0)
creds = client.create_or_derive_api_creds()
client.set_api_creds(creds)
API_KEY = creds.api_key

print(f"✅ API Key loaded: {API_KEY[:20]}...")
print(f"✅ Using signature_type=0 (EOA/Standard wallet)")
print(f"\n⚠️  IMPORTANT: If orders fail, you may need to set token allowances!")
print(f"   See: https://gist.github.com/poly-rodr/44313920481de58d5a3f6d1f8226bd5e")
print(f"   This is a one-time setup for MetaMask/hardware wallets\n")


def run_command(cmd):
    """Run a shell command and return output"""
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return result.stdout


def find_current_btc_market():
    """Load current 15-min BTC market from ~/Desktop/current_market.json"""
    market_file = os.path.join(os.path.expanduser("~"), "Desktop", "current_market.json")

    try:
        with open(market_file, 'r') as f:
            data = json.load(f)

        current = data.get('current')
        if not current:
            print(f"❌ No current market in {market_file}")
            return None

        # Convert timestamps to datetime objects
        period_start = datetime.fromtimestamp(current['period_start'], tz=timezone.utc)
        period_end = datetime.fromtimestamp(current['period_end'], tz=timezone.utc)

        print(f"✅ Loaded market from file: {current['slug']}")

        return {
            'question': current['question'],
            'up_token': current['up_token'],
            'down_token': current['down_token'],
            'slug': current['slug'],
            'period_start': period_start,
            'period_end': period_end
        }

    except FileNotFoundError:
        print(f"❌ Market file not found: {market_file}")
        print("   Make sure check_polls.py is running!")
        return None
    except Exception as e:
        print(f"❌ Error reading market file: {e}")
        import traceback
        traceback.print_exc()
        return None


class CoinbaseFeed:
    """Integrated Coinbase BTC price feed"""
    def __init__(self):
        self.url = "wss://ws-feed.exchange.coinbase.com"
        self.ws = None
        self.current_price = None
        self.running = True

    async def connect_and_stream(self):
        """Connect to Coinbase and stream BTC prices"""
        while self.running:
            try:
                async with websockets.connect(
                    self.url,
                    ping_interval=20,
                    ping_timeout=10
                ) as ws:
                    self.ws = ws

                    # Subscribe to ticker channel
                    subscribe_msg = {
                        "type": "subscribe",
                        "product_ids": ["BTC-USD"],
                        "channels": ["ticker"]
                    }

                    await ws.send(json.dumps(subscribe_msg))

                    # Listen for messages
                    async for message in ws:
                        try:
                            data = json.loads(message)

                            # Only process ticker messages
                            if data.get("type") == "ticker":
                                self.current_price = float(data["price"])

                        except (json.JSONDecodeError, KeyError, ValueError):
                            continue
                        except Exception:
                            continue

            except websockets.exceptions.ConnectionClosed:
                if self.running:
                    await asyncio.sleep(2)
            except Exception:
                if self.running:
                    await asyncio.sleep(5)

    def stop(self):
        """Stop the Coinbase feed"""
        self.running = False


class PolyMonitor:
    def __init__(self, api_key, coinbase_feed):
        self.api_key = api_key
        self.coinbase_feed = coinbase_feed
        self.ws_url = "wss://ws-subscriptions-clob.polymarket.com/ws/market"
        self.ws = None
        self.market = None
        self.prices = {
            'up_buy': None,
            'down_buy': None,
            'up_sell': None,
            'down_sell': None
        }
        self.strike_price = None
        self.last_check = None
        self.last_display_time = 0
        self.last_displayed_values = {}
        desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
        self.prices_file = os.path.join(desktop_path, "polymarket_prices.json")
        self.dashboard_file = os.path.join(desktop_path, "monitor_data.json")
        self.settings_file = os.path.join(desktop_path, "trading_settings.json")
        self.last_ping = None
        self.first_display = True
        self.ocr_price_file = os.path.join(desktop_path, "polymarket_ocr_price.txt")
        self.message_count_after_switch = 0
        self.open_positions = []
        self.liquidation_active = False
        self.max_concurrent_positions = 1
        self.is_windows = platform.system() == 'Windows'

    def get_trading_settings(self):
        """Read trading settings from file (set by HTML dashboard)"""
        try:
            if os.path.exists(self.settings_file):
                with open(self.settings_file, 'r') as f:
                    settings = json.load(f)
                    return {
                        'risk_amount': settings.get('risk_amount', 100),
                        'profit_threshold': settings.get('profit_threshold', 5),
                        'min_arb_gap': settings.get('min_arb_gap', 0),
                        'trading_active': settings.get('trading_active', False),
                        'trading_paused': settings.get('trading_paused', False)
                    }
        except:
            pass

        return {
            'risk_amount': 100,
            'profit_threshold': 5,
            'min_arb_gap': 0,
            'trading_active': False,
            'trading_paused': False
        }

    def should_trade_based_on_arb_gap(self):
        settings = self.get_trading_settings()
        if not settings['trading_active'] or settings['trading_paused']:
            return None, None
        if len(self.open_positions) >= self.max_concurrent_positions:
            return None, None
        # CRITICAL: Filter out illiquid markets
        up_buy = self.prices.get('up_buy')
        down_buy = self.prices.get('down_buy')
        if up_buy and down_buy:
            total = up_buy + down_buy
            if total >= 1.03:
                return None, None
        if self.market:
            now = datetime.now(timezone.utc)
            time_until_end = (self.market['period_end'] - now).total_seconds()
            if time_until_end <= 120:
                return None, None
        poly_btc_price = self.get_ocr_price()
        if not self.coinbase_feed.current_price or not poly_btc_price:
            return None, None
        arb_gap = self.coinbase_feed.current_price - poly_btc_price
        min_arb_gap = settings['min_arb_gap']
        if arb_gap >= min_arb_gap and min_arb_gap > 0:
            up_buy_price = self.prices.get('up_buy')
            if up_buy_price:
                return 'UP', up_buy_price
        elif arb_gap <= -min_arb_gap and min_arb_gap > 0:
            down_buy_price = self.prices.get('down_buy')
            if down_buy_price:
                return 'DOWN', down_buy_price
        return None, None

    def execute_trade(self, token_side, price, risk_amount, order_type='market'):
        try:
            token_id = self.market['up_token'] if token_side == 'UP' else self.market['down_token']
            shares_to_buy = risk_amount / price
            width = 80 if self.is_windows else 160
            print(f"\n{'='*width}")
            print(f"TRADE SIGNAL DETECTED")
            print(f"{'='*width}")
            print(f"Token Side:  {token_side}")
            print(f"Price:       ${price:.4f}")
            print(f"Risk Amount: ${risk_amount}")
            print(f"Shares:      {shares_to_buy:.2f}")
            print(f"Order Type:  {order_type.upper()}")
            print(f"{'='*width}\n")
            order_response = None
            if order_type == 'market':
                print(f"📤 Placing market BUY order on Polymarket...")
                print(f"   Token ID: {token_id}")
                print(f"   Amount: ${shares_to_buy:.2f}")
                print(f"   Side: BUY")
                market_order = MarketOrderArgs(token_id=token_id, amount=shares_to_buy, side=BUY)
                time.sleep(0.5)
                signed_order = client.create_market_order(market_order)
                time.sleep(0.5)
                max_retries = 3
                retry_delay = 2
                order_response = None
                for attempt in range(max_retries):
                    try:
                        order_response = client.post_order(signed_order, OrderType.FOK)
                        print(f"\n📋 Full API Response:")
                        print(f"{json.dumps(order_response, indent=2)}")
                        break
                    except Exception as e:
                        if '403' in str(e) or 'Cloudflare' in str(e):
                            if attempt < max_retries - 1:
                                print(f"⚠️  Cloudflare block detected (attempt {attempt + 1}/{max_retries})")
                                print(f"   Waiting {retry_delay}s before retry...")
                                time.sleep(retry_delay)
                                retry_delay *= 2
                            else:
                                print(f"❌ Cloudflare blocked after {max_retries} attempts")
                                raise
                        else:
                            raise
                if not order_response or 'error' in str(order_response).lower():
                    print(f"\n❌ ORDER FAILED!")
                    print(f"Response: {order_response}")
                    return False, None
                print(f"\n✅ Order successfully placed on Polymarket!")
            elif order_type == 'limit':
                print(f"📤 Placing limit BUY order on Polymarket...")
                print(f"   Token ID: {token_id}")
                print(f"   Price: ${price:.4f}")
                print(f"   Size: {shares_to_buy:.2f} shares")
                print(f"   Side: BUY")
                limit_order = OrderArgs(token_id=token_id, price=price, size=shares_to_buy, side=BUY)
                signed_order = client.create_order(limit_order)
                order_response = client.post_order(signed_order, OrderType.GTC)
                print(f"\n📋 Full API Response:")
                print(f"{json.dumps(order_response, indent=2)}")
                if not order_response or 'error' in str(order_response).lower():
                    print(f"\n❌ ORDER FAILED!")
                    print(f"Response: {order_response}")
                    return False, None
                print(f"\n✅ Order successfully placed on Polymarket!")
            position = {
                'token_side': token_side,
                'token_id': token_id,
                'price': price,
                'shares': shares_to_buy,
                'order_type': order_type,
                'order_response': order_response,
                'timestamp': datetime.now(timezone.utc).timestamp()
            }
            self.open_positions.append(position)
            return True, {
                'token_side': token_side,
                'price': price,
                'shares': shares_to_buy,
                'order_type': order_type,
                'order_response': order_response
            }
        except Exception as e:
            print(f"❌ Trade execution error: {e}")
            return False, None

    def liquidate_position(self, position):
        try:
            token_side = position['token_side']
            token_id = position['token_id']
            shares = position['shares']
            sell_price = self.prices.get(f'{token_side.lower()}_sell')
            width = 80 if self.is_windows else 160
            print(f"\n{'='*width}")
            print(f"LIQUIDATION ATTEMPT")
            print(f"{'='*width}")
            print(f"Token Side:  {token_side}")
            print(f"Shares:      {shares:.2f}")
            print(f"Sell Price:  ${sell_price:.4f}" if sell_price else "Price N/A")
            print(f"{'='*width}\n")
            print(f"📤 Placing market SELL order on Polymarket...")
            market_order = MarketOrderArgs(token_id=token_id, amount=shares, side=SELL)
            signed_order = client.create_market_order(market_order)
            order_response = client.post_order(signed_order, OrderType.FOK)
            print(f"✅ Position liquidated! Response: {order_response}")
            return True
        except Exception as e:
            print(f"❌ Liquidation error: {e}")
            return False

    async def liquidation_loop(self):
        if not self.market:
            return
        while True:
            try:
                now = datetime.now(timezone.utc)
                time_until_end = (self.market['period_end'] - now).total_seconds()
                if time_until_end <= 10 and time_until_end > 0:
                    if not self.liquidation_active:
                        self.liquidation_active = True
                        print(f"\n{'🚨'*40}")
                        print(f"LIQUIDATION WINDOW ACTIVATED - {int(time_until_end)}s until poll end")
                        print(f"Attempting to liquidate {len(self.open_positions)} open positions")
                        print(f"{'🚨'*40}\n")
                    if self.open_positions:
                        positions_to_remove = []
                        for i, position in enumerate(self.open_positions):
                            success = self.liquidate_position(position)
                            if success:
                                positions_to_remove.append(i)
                        for i in sorted(positions_to_remove, reverse=True):
                            self.open_positions.pop(i)
                        if not self.open_positions:
                            print(f"\n✅ All positions liquidated successfully\n")
                    await asyncio.sleep(0.1)
                elif time_until_end <= 0:
                    if self.liquidation_active:
                        self.liquidation_active = False
                        if self.open_positions:
                            print(f"\n⚠️ Poll ended with {len(self.open_positions)} positions still open\n")
                        self.open_positions = []
                    await asyncio.sleep(1)
                else:
                    self.liquidation_active = False
                    await asyncio.sleep(1)
            except Exception as e:
                print(f"❌ Liquidation loop error: {e}")
                await asyncio.sleep(1)

    def get_ocr_price(self):
        try:
            if os.path.exists(self.ocr_price_file):
                with open(self.ocr_price_file, 'r') as f:
                    price_str = f.read().strip()
                    if price_str:
                        price_str = price_str.replace('$', '').replace(',', '')
                        return float(price_str)
        except:
            pass
        return None

    def write_prices_to_file(self):
        try:
            up_buy = self.prices['up_buy']
            down_buy = self.prices['down_buy']
            buy_total = None
            has_arbitrage = False
            arbitrage_profit = 0.0
            if up_buy is not None and down_buy is not None:
                buy_total = up_buy + down_buy
                if buy_total < 1.0:
                    has_arbitrage = True
                    arbitrage_profit = 1.0 - buy_total
            arb_gap = None
            poly_btc_price = self.get_ocr_price()
            if self.coinbase_feed.current_price and poly_btc_price:
                arb_gap = self.coinbase_feed.current_price - poly_btc_price
            next_switch = None
            if self.market:
                now = datetime.now(timezone.utc)
                switch_time = self.market['period_end'] - timedelta(seconds=5)
                time_left = (switch_time - now).total_seconds()
                if time_left > 0:
                    mins, secs = divmod(int(time_left), 60)
                    next_switch = f"{mins}m {secs}s"
            dashboard_data = {
                'up_buy': up_buy,
                'down_buy': down_buy,
                'up_sell': self.prices['up_sell'],
                'down_sell': self.prices['down_sell'],
                'coinbase_price': self.coinbase_feed.current_price,
                'polymarket_btc_price': poly_btc_price,
                'buy_total': buy_total,
                'has_arbitrage': has_arbitrage,
                'arbitrage_profit': arbitrage_profit,
                'arb_gap': arb_gap,
                'next_switch': next_switch,
                'positions_count': len(self.open_positions),
                'liquidation_active': self.liquidation_active
            }
            temp_file = self.dashboard_file + ".tmp"
            with open(temp_file, 'w') as f:
                json.dump(dashboard_data, f, indent=2)
                f.flush()
                os.fsync(f.fileno())
            if os.path.exists(self.dashboard_file):
                try:
                    os.remove(self.dashboard_file)
                except:
                    pass
            os.rename(temp_file, self.dashboard_file)
            legacy_data = {
                'up_buy': up_buy,
                'down_buy': down_buy,
                'up_sell': self.prices['up_sell'],
                'down_sell': self.prices['down_sell'],
                'coinbase_price': self.coinbase_feed.current_price,
                'strike_price': self.strike_price,
                'market_slug': self.market['slug'] if self.market else None,
                'period_end': self.market['period_end'].timestamp() if self.market else None,
                'timestamp': datetime.now(timezone.utc).timestamp()
            }
            temp_file = self.prices_file + ".tmp"
            with open(temp_file, 'w') as f:
                json.dump(legacy_data, f, indent=2)
                f.flush()
                os.fsync(f.fileno())
            if os.path.exists(self.prices_file):
                try:
                    os.remove(self.prices_file)
                except:
                    pass
            os.rename(temp_file, self.prices_file)
        except Exception as e:
            pass

    def display_prices(self):
        up_buy = self.prices['up_buy']
        down_buy = self.prices['down_buy']
        up_sell = self.prices['up_sell']
        down_sell = self.prices['down_sell']
        coinbase_price = self.coinbase_feed.current_price
        has_arbitrage = False
        market_illiquid = False
        if up_buy is not None and down_buy is not None:
            total_buy = up_buy + down_buy
            # Filter out illiquid markets - when total >= 1.03, market has no real orders yet
            if total_buy >= 1.03:
                market_illiquid = True
                # Print warning once every 10 seconds
                if not hasattr(self, 'last_illiquid_warning') or (time.time() - self.last_illiquid_warning) > 10:
                    self.last_illiquid_warning = time.time()
                    print(f"\n⚠️  Market illiquid (total={total_buy:.4f}) - waiting for competitive orders...")
                return
            has_arbitrage = total_buy < 1.0
        current_time = time.time()
        current_values = {
            'up_buy': up_buy,
            'down_buy': down_buy,
            'up_sell': up_sell,
            'down_sell': down_sell,
            'coinbase': coinbase_price,
            'has_arb': has_arbitrage
        }
        time_elapsed = current_time - self.last_display_time
        values_changed = current_values != self.last_displayed_values
        min_interval = 3.0 if self.is_windows else 0.5
        if time_elapsed < min_interval and not values_changed and not has_arbitrage:
            return
        self.last_display_time = current_time
        self.last_displayed_values = current_values.copy()
        self.write_prices_to_file()
        width = 80 if self.is_windows else 160
        if self.is_windows:
            print("\n" + "=" * width + "\n")
        else:
            print("\033[2J\033[H", end="")
        print("=" * width)
        print("POLYMARKET BTC 15-MIN MONITOR - LIVE PRICES")
        print("=" * width)
        if self.market:
            print(f"\n{self.market['question']}")
            now = datetime.now(timezone.utc)
            switch_time = self.market['period_end'] - timedelta(seconds=5)
            time_left = (switch_time - now).total_seconds()
            mins, secs = divmod(int(time_left), 60)
            print(f"Next switch in: {mins}m {secs}s (5s before period end)")
        now_str = datetime.now().strftime("%H:%M:%S")
        print(f"\nTime: {now_str}")
        print("\n" + "=" * width)
        print(f"{'TOKEN':<15} {'BUY PRICE':<15} {'SELL PRICE':<15} {'COINBASE BTC':<20}")
        print("=" * width)
        up_buy_str = f"${up_buy:.4f}" if up_buy else "Waiting..."
        down_buy_str = f"${down_buy:.4f}" if down_buy else "Waiting..."
        up_sell_str = f"${up_sell:.4f}" if up_sell else "Waiting..."
        down_sell_str = f"${down_sell:.4f}" if down_sell else "Waiting..."
        coinbase_str = f"${coinbase_price:,.2f}" if coinbase_price else "Connecting..."
        print(f"{'UP Token':<15} {up_buy_str:<15} {up_sell_str:<15} {coinbase_str:<20}")
        print(f"{'DOWN Token':<15} {down_buy_str:<15} {down_sell_str:<15}")
        print("\n" + "=" * width)
        if up_buy and down_buy:
            total_buy = up_buy + down_buy
            print(f"BUY TOTAL: ${total_buy:.4f}")
            print()
            if total_buy < 1.0:
                profit = 1.0 - total_buy
                print(f"🟢 Arbitrage Opportunity: ${profit:.4f} profit (BUY BOTH)")
            else:
                print(f"🟠 NO Arbitrage Opportunity")
        else:
            print(f"BUY TOTAL: Waiting...")
            print()
            print(f"🟠 NO Arbitrage Opportunity")
        print("\n" + "-" * width)
        poly_btc_price = self.get_ocr_price()
        if coinbase_price and poly_btc_price:
            arb_gap = coinbase_price - poly_btc_price
            print(f"Polymarket BTC (OCR): ${poly_btc_price:,.2f}")
            print(f"Arb Gap: ${arb_gap:,.2f} (Coinbase - Polymarket)")
        elif poly_btc_price:
            print(f"Polymarket BTC (OCR): ${poly_btc_price:,.2f}")
            print(f"Arb Gap: [Waiting for Coinbase...]")
        elif coinbase_price:
            print(f"Arb Gap: [Waiting for OCR - run polymarket_ocr.py]")
        else:
            print(f"Arb Gap: [Waiting for feeds...]")
        print("\n" + "-" * width)
        if self.market:
            now = datetime.now(timezone.utc)
            time_until_end = (self.market['period_end'] - now).total_seconds()
            if time_until_end <= 10 and time_until_end > 0:
                print(f"🚨 LIQUIDATION WINDOW ACTIVE - {int(time_until_end)}s until poll end")
                print(f"🚨 Attempting to liquidate {len(self.open_positions)} open positions every 100ms")
            elif time_until_end <= 120 and time_until_end > 10:
                mins, secs = divmod(int(time_until_end), 60)
                print(f"⚠️  NO NEW TRADES - Final 2 minutes of poll ({mins}m {secs}s remaining)")
                print(f"📊 Open Positions: {len(self.open_positions)}")
            else:
                mins, secs = divmod(int(time_until_end), 60)
                print(f"✅ Trading Window Open ({mins}m {secs}s until restriction)")
                print(f"📊 Open Positions: {len(self.open_positions)}/{self.max_concurrent_positions}")
                if len(self.open_positions) >= self.max_concurrent_positions:
                    print(f"⚠️  Position limit reached - waiting for position to close before opening new trades")
        token_side, trade_price = self.should_trade_based_on_arb_gap()
        if token_side and trade_price:
            settings = self.get_trading_settings()
            success, order_details = self.execute_trade(token_side=token_side, price=trade_price, risk_amount=settings['risk_amount'], order_type='market')
            if success:
                print(f"✅ Trade signal logged for {token_side} token")
            else:
                print(f"❌ Trade execution failed")
        print("\n" + "=" * width)
        print("Press Ctrl+C to stop")

    async def check_and_switch_market(self):
        now = datetime.now(timezone.utc)
        switch_time = self.market['period_end'] - timedelta(seconds=5)
        if now > self.market['period_end']:
            data_file = os.path.join(os.path.expanduser("~"), "Desktop", "current_market.json")
            try:
                with open(data_file, 'r') as f:
                    data = json.load(f)
                current_market = data.get('current')
                if current_market and current_market['slug'] != self.market['slug']:
                    print(f"\n\n🔄 FORCE SWITCHING to current active market...\n")
                    print(f"   Old market: {self.market['slug']} (ended {int((now - self.market['period_end']).total_seconds())}s ago)\n")
                    print(f"   New market: {current_market['question']}\n")
                    next_market = {
                        'question': current_market['question'],
                        'up_token': current_market['up_token'],
                        'down_token': current_market['down_token'],
                        'slug': current_market['slug'],
                        'period_start': datetime.fromtimestamp(current_market['period_start'], tz=timezone.utc),
                        'period_end': datetime.fromtimestamp(current_market['period_end'], tz=timezone.utc)
                    }
                    self.market = next_market
                    self.prices = {'up_buy': None, 'down_buy': None, 'up_sell': None, 'down_sell': None}
                    await self.ws.close()
                    return True
            except Exception as e:
                print(f"❌ Error force-switching to current market: {e}\n")
        elif self.market and now >= switch_time:
            time_until_end = (self.market['period_end'] - now).total_seconds()
            data_file = os.path.join(os.path.expanduser("~"), "Desktop", "current_market.json")
            try:
                with open(data_file, 'r') as f:
                    data = json.load(f)
                upcoming = data.get('upcoming', [])
                next_market = None
                for market in upcoming:
                    market_start = datetime.fromtimestamp(market['period_start'], tz=timezone.utc)
                    if market_start >= self.market['period_end']:
                        next_market = {
                            'question': market['question'],
                            'up_token': market['up_token'],
                            'down_token': market['down_token'],
                            'slug': market['slug'],
                            'period_start': market_start,
                            'period_end': datetime.fromtimestamp(market['period_end'], tz=timezone.utc)
                        }
                        break
                if next_market and next_market['slug'] != self.market['slug']:
                    print(f"\n\n⏰ Switching to next market ({int(time_until_end)}s early)...\n")
                    print(f"✅ Found next market: {next_market['question']}")
                    print(f"   UP Token:   {next_market['up_token']}")
                    print(f"   DOWN Token: {next_market['down_token']}\n")
                    self.market = next_market
                    self.prices = {'up_buy': None, 'down_buy': None, 'up_sell': None, 'down_sell': None}
                    await self.ws.close()
                    return True
                else:
                    if time_until_end > 0:
                        print(f"⏳ {int(time_until_end)}s until switch. Waiting for next market to be available...\n")
                    else:
                        print(f"⚠️ Period ended! Waiting for next market in upcoming list...\n")
            except Exception as e:
                print(f"❌ Error reading upcoming markets: {e}\n")
        return False

    async def periodic_market_check(self):
        while True:
            try:
                await asyncio.sleep(3)
                await self.check_and_switch_market()
            except Exception as e:
                await asyncio.sleep(3)

    async def connect_and_monitor(self, market):
        self.market = market
        print(f"\n🔌 Connecting to {self.ws_url}...")
        async with websockets.connect(self.ws_url, ping_interval=20, ping_timeout=10, close_timeout=10) as ws:
            self.ws = ws
            print("✅ Connected to Polymarket!")
            print("\n🔍 Checking if market is current...")
            await asyncio.sleep(0.5)
            switched = await self.check_and_switch_market()
            print(f"\n📡 Subscribing to tokens...")
            up_token_id = self.market['up_token']
            down_token_id = self.market['down_token']

            print(f"   UP Token:   {up_token_id}")
            print(f"   DOWN Token: {down_token_id}")

            # DEBUG: Check if tokens are identical
            if up_token_id == down_token_id:
                print(f"\n   ❌ ERROR: UP and DOWN are THE SAME TOKEN!")
                print(f"   This will cause both to show identical prices!")
                print(f"   Check your current_market.json file!\n")
            else:
                print(f"   ✅ Tokens are different (correct)\n")

            subscribe_msg = {"assets_ids": [up_token_id, down_token_id], "type": "market"}
            await ws.send(json.dumps(subscribe_msg))
            print("✅ Subscribed! Listening for price updates...")
            print("⏳ Waiting for orderbook data from Polymarket...\n")
            self.message_count_after_switch = 0
            await asyncio.sleep(1)
            self.strike_price = self.coinbase_feed.current_price
            if self.strike_price:
                print(f"📍 Strike price set to: ${self.strike_price:,.2f}\n")
            check_task = asyncio.create_task(self.periodic_market_check())
            liquidation_task = asyncio.create_task(self.liquidation_loop())
            message_count = 0
            try:
                async for message in ws:
                    try:
                        data = json.loads(message)
                        message_count += 1
                        if hasattr(self, 'message_count_after_switch'):
                            self.message_count_after_switch += 1
                        if isinstance(data, list):
                            for book in data:
                                asset_id = book.get('asset_id')
                                asks = book.get('asks', [])
                                bids = book.get('bids', [])

                                if asks and len(asks) > 0:
                                    buy_price = float(asks[0].get('price', 0))
                                    if asset_id == self.market['up_token']:
                                        self.prices['up_buy'] = buy_price
                                    elif asset_id == self.market['down_token']:
                                        self.prices['down_buy'] = buy_price

                                if bids and len(bids) > 0:
                                    sell_price = float(bids[0].get('price', 0))
                                    if asset_id == self.market['up_token']:
                                        self.prices['up_sell'] = sell_price
                                    elif asset_id == self.market['down_token']:
                                        self.prices['down_sell'] = sell_price

                            if self.prices['up_buy'] or self.prices['down_buy']:
                                self.display_prices()
                        elif isinstance(data, dict):
                            if 'price_changes' in data:
                                for change in data.get('price_changes', []):
                                    asset_id = change.get('asset_id')
                                    best_ask = change.get('best_ask')
                                    best_bid = change.get('best_bid')
                                    if best_ask:
                                        buy_price = float(best_ask)
                                        if asset_id == self.market['up_token']:
                                            self.prices['up_buy'] = buy_price
                                        elif asset_id == self.market['down_token']:
                                            self.prices['down_buy'] = buy_price
                                    if best_bid:
                                        sell_price = float(best_bid)
                                        if asset_id == self.market['up_token']:
                                            self.prices['up_sell'] = sell_price
                                        elif asset_id == self.market['down_token']:
                                            self.prices['down_sell'] = sell_price

                                if self.prices['up_buy'] or self.prices['down_buy']:
                                    self.display_prices()
                            elif 'asks' in data or 'bids' in data:
                                asset_id = data.get('asset_id')
                                asks = data.get('asks', [])
                                bids = data.get('bids', [])
                                if asks and len(asks) > 0:
                                    buy_price = float(asks[0].get('price', 0))
                                    if asset_id == self.market['up_token']:
                                        self.prices['up_buy'] = buy_price
                                    elif asset_id == self.market['down_token']:
                                        self.prices['down_buy'] = buy_price
                                if bids and len(bids) > 0:
                                    sell_price = float(bids[0].get('price', 0))
                                    if asset_id == self.market['up_token']:
                                        self.prices['up_sell'] = sell_price
                                    elif asset_id == self.market['down_token']:
                                        self.prices['down_sell'] = sell_price
                                self.display_prices()
                    except json.JSONDecodeError:
                        continue
                    except Exception as e:
                        print(f"Error processing message: {e}")
                        continue
            except Exception as e:
                print(f"\n❌ Connection error: {e}")
            finally:
                check_task.cancel()
                liquidation_task.cancel()


async def main():
    print("POLYMARKET BTC MONITOR WITH INTEGRATED COINBASE FEED")
    print()
    print("🔍 Finding current market...")
    print()
    market = find_current_btc_market()
    if not market:
        print("❌ No active market found")
        print("Current 15-minute window may not have a market yet")
        return
    print(f"✅ Found: {market['question']}")
    print(f"   Slug: {market['slug']}")
    print(f"   UP Token:   {market['up_token']}")
    print(f"   DOWN Token: {market['down_token']}")
    print()
    coinbase_feed = CoinbaseFeed()
    monitor = PolyMonitor(API_KEY, coinbase_feed)
    monitor.market = market
    async def monitor_with_reconnect():
        while True:
            try:
                await monitor.connect_and_monitor(monitor.market)
                print(f"\n🔄 Reconnecting with new market: {monitor.market['slug']}\n")
                await asyncio.sleep(1)
            except KeyboardInterrupt:
                raise
            except Exception as e:
                print(f"\n❌ Connection error: {e}")
                print(f"🔄 Reconnecting in 3 seconds...\n")
                await asyncio.sleep(3)
    try:
        await asyncio.gather(coinbase_feed.connect_and_stream(), monitor_with_reconnect())
    except KeyboardInterrupt:
        print("\n\n👋 Stopped")
        coinbase_feed.stop()
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        coinbase_feed.stop()

if __name__ == "__main__":
    asyncio.run(main())
