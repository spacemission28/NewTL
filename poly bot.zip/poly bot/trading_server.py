#!/usr/bin/env python3
"""
Trading Dashboard Server
Serves the trading dashboard UI and provides API for settings
"""

import os
import json
from http.server import HTTPServer, SimpleHTTPRequestHandler
import urllib.parse

# Cross-platform Desktop path (works on Windows, macOS, Linux)
SETTINGS_FILE = os.path.join(os.path.expanduser("~"), "Desktop", "trading_settings.json")

class TradingHandler(SimpleHTTPRequestHandler):
    def log_error(self, format, *args):
        # Suppress connection error spam (common on Windows when browser refreshes)
        if 'ConnectionAbortedError' in str(args) or 'WinError 10053' in str(args):
            return
        super().log_error(format, *args)

    def do_GET(self):
        try:
            if self.path == '/api/settings':
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()

                # Load settings from file
                try:
                    with open(SETTINGS_FILE, 'r') as f:
                        settings = json.load(f)
                except (FileNotFoundError, json.JSONDecodeError):
                    settings = {
                        'risk_amount': 100,
                        'profit_threshold': 5,
                        'min_arb_gap': 0,
                        'trading_active': False,
                        'trading_paused': False
                    }

                self.wfile.write(json.dumps(settings).encode())
            else:
                # Serve static files
                super().do_GET()
        except (ConnectionAbortedError, BrokenPipeError, ConnectionResetError):
            # Browser closed connection early - normal on Windows, ignore
            pass

    def do_POST(self):
        try:
            if self.path == '/api/settings':
                content_length = int(self.headers['Content-Length'])
                post_data = self.rfile.read(content_length)
                settings = json.loads(post_data.decode())

                # Save settings to file
                temp_file = SETTINGS_FILE + ".tmp"
                with open(temp_file, 'w') as f:
                    json.dump(settings, f, indent=2)
                os.rename(temp_file, SETTINGS_FILE)

                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(json.dumps({'success': True}).encode())
            else:
                self.send_response(404)
                self.end_headers()
        except (ConnectionAbortedError, BrokenPipeError, ConnectionResetError):
            # Browser closed connection early - normal on Windows, ignore
            pass

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

def main():
    # Change to Desktop directory where monitor_data.json is written
    desktop_dir = os.path.join(os.path.expanduser("~"), "Desktop")
    project_dir = os.path.dirname(os.path.abspath(__file__))

    # Copy dashboard HTML to Desktop
    import shutil

    # Try a.html first (new version), fallback to trading_dashboard.html
    dashboard_files = ["a.html", "trading_dashboard.html"]
    copied = False

    for filename in dashboard_files:
        dashboard_file = os.path.join(project_dir, filename)
        if os.path.exists(dashboard_file):
            shutil.copy(dashboard_file, desktop_dir)
            print(f"✅ Copied {filename} to {desktop_dir}")
            copied = True
            break

    if not copied:
        print("⚠️  No dashboard HTML file found")

    os.chdir(desktop_dir)

    port = 8080
    # Bind to 0.0.0.0 to accept connections from any interface (including localhost)
    # This is needed for Windows and remote access
    server = HTTPServer(('0.0.0.0', port), TradingHandler)

    print("=" * 80)
    print("TRADING DASHBOARD SERVER")
    print("=" * 80)
    print(f"📡 Server running at: http://localhost:{port}")
    print(f"📊 Dashboard URLs:")
    print(f"   • http://localhost:{port}/a.html")
    print(f"   • http://localhost:{port}/trading_dashboard.html")
    print(f"📁 Serving from: {desktop_dir}")
    print(f"⚙️  Settings file: {SETTINGS_FILE}")
    print("=" * 80)
    print("\nPress Ctrl+C to stop")
    print()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n\n👋 Server stopped")

if __name__ == "__main__":
    main()
