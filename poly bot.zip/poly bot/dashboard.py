#!/usr/bin/env python3
"""
Simple web server for Polymarket BTC Monitor Dashboard
Serves the HTML dashboard on http://localhost:8080
"""

import http.server
import socketserver
import os
import sys
from pathlib import Path

PORT = 8080
DIRECTORY = os.path.expanduser("~/Desktop")

class CustomHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

    def end_headers(self):
        # Add CORS headers
        self.send_header('Access-Control-Allow-Origin', '*')
        # Disable caching for JSON files
        if self.path.endswith('.json'):
            self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate')
            self.send_header('Expires', '0')
        super().end_headers()

    def log_message(self, format, *args):
        # Suppress log messages for cleaner output
        pass


def main():
    # Copy dashboard.html to Desktop
    source_html = Path(__file__).parent / "dashboard.html"
    dest_html = Path(DIRECTORY) / "dashboard.html"

    if source_html.exists():
        import shutil
        shutil.copy(source_html, dest_html)
        print(f"✅ Dashboard copied to {dest_html}")
    else:
        print(f"⚠️  dashboard.html not found in {source_html.parent}")

    print()
    print("=" * 60)
    print("POLYMARKET BTC MONITOR DASHBOARD")
    print("=" * 60)
    print()
    print(f"🌐 Dashboard running at: http://localhost:{PORT}/dashboard.html")
    print()
    print("Press Ctrl+C to stop")
    print("=" * 60)
    print()

    try:
        with socketserver.TCPServer(("", PORT), CustomHTTPRequestHandler) as httpd:
            httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n\n👋 Shutting down...")
        sys.exit(0)
    except OSError as e:
        if "Address already in use" in str(e):
            print(f"\n❌ Port {PORT} is already in use!")
            print("Try:")
            print(f"  1. Stop other process using port {PORT}")
            print(f"  2. Or change PORT in start_dashboard.py")
            sys.exit(1)
        else:
            raise


if __name__ == "__main__":
    main()
