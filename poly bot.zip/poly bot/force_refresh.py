#!/usr/bin/env python3
"""
Force refresh the current market file to fix token assignments
"""
import os
import re
import json
import subprocess
import time
from datetime import datetime, timezone

def run_command(cmd):
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return result.stdout

market_file = os.path.join(os.path.expanduser("~"), "Desktop", "current_market.json")
desktop_dir = os.path.join(os.path.expanduser("~"), "Desktop")

print("="*80)
print("FORCE REFRESH MARKET DATA")
print("="*80)

# Ensure Desktop directory exists
if not os.path.exists(desktop_dir):
    os.makedirs(desktop_dir)
    print(f"\n✅ Created Desktop directory")

# Check if old file exists
if os.path.exists(market_file):
    print(f"\n⚠️  Found existing file. Checking token assignments...")
    with open(market_file, 'r') as f:
        old_data = json.load(f)
        old_current = old_data.get('current', {})
        print(f"\nOLD assignments:")
        print(f"  UP:   {old_current.get('up_token', 'N/A')[:20]}...")
        print(f"  DOWN: {old_current.get('down_token', 'N/A')[:20]}...")

    # Delete it
    os.remove(market_file)
    print(f"\n✅ Deleted old file")
else:
    print(f"\n✅ No existing file found")

# Get current period
now = datetime.now(timezone.utc)
current_timestamp = now.timestamp()
current_period = int(current_timestamp // 900) * 900

slug = f"btc-updown-15m-{current_period}"
url = f"https://polymarket.com/event/{slug}"

print(f"\nFetching fresh data for: {slug}")
html = run_command(f'curl -s "{url}"')

# Extract JSON
match = re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', html, re.DOTALL)
if not match:
    print("❌ Could not find market data in HTML")
    exit(1)

data = json.loads(match.group(1))

# Find market data
def find_tokens(obj, depth=0):
    if depth > 15:
        return None
    if isinstance(obj, dict):
        if 'clobTokenIds' in obj and 'question' in obj:
            return {
                'question': obj['question'],
                'token_ids': obj['clobTokenIds'],
                'outcomes': obj.get('outcomes', []),
                'slug': obj.get('slug')
            }
        for val in obj.values():
            result = find_tokens(val, depth+1)
            if result:
                return result
    elif isinstance(obj, list):
        for item in obj:
            result = find_tokens(item, depth+1)
            if result:
                return result
    return None

market = find_tokens(data)
if not market or len(market['token_ids']) < 2:
    print("❌ Could not parse market data")
    exit(1)

# Match tokens by outcome names
up_token = None
down_token = None

outcomes = market.get('outcomes', [])
token_ids = market['token_ids']

print(f"\nMatching logic:")
for i, outcome in enumerate(outcomes):
    if i < len(token_ids):
        print(f"  [{i}] '{outcome}' -> {token_ids[i][:20]}...")
        if 'UP' in str(outcome).upper() or 'HIGHER' in str(outcome).upper():
            up_token = token_ids[i]
            print(f"      ✅ Assigned to UP")
        elif 'DOWN' in str(outcome).upper() or 'LOWER' in str(outcome).upper():
            down_token = token_ids[i]
            print(f"      ✅ Assigned to DOWN")

# Fallback
if not up_token or not down_token:
    print(f"\n⚠️  Name matching failed, using index order")
    up_token = token_ids[0]
    down_token = token_ids[1]

# Create new market data
new_market = {
    'slug': slug,
    'period_start': current_period,
    'period_end': current_period + 900,
    'up_token': up_token,
    'down_token': down_token,
    'question': market['question'],
    'updated_at': int(time.time())
}

# Write file
output = {
    'current': new_market,
    'upcoming': []
}

with open(market_file, 'w') as f:
    json.dump(output, f, indent=2)

print(f"\n✅ Created new market file")
print(f"\nNEW assignments:")
print(f"  Question: {new_market['question']}")
print(f"  UP:   {up_token[:60]}")
print(f"  DOWN: {down_token[:60]}")

print("\n" + "="*80)
print("NEXT STEPS:")
print("="*80)
print("1. RESTART new_poly_monitor_btc.py")
print("2. Check browser - prices should now be correct")
print("3. UP buy + DOWN buy should ≈ $1.00")
print("="*80)
