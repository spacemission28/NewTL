package com.tradelogic.ui;

import com.tradelogic.Logger;
import com.tradelogic.models.SystemConfig;
import com.tradelogic.services.DrawdownMonitor;
import javafx.application.Platform;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Control panel for the right side of the Trade Logic interface (250px width).
 * Features:
 * - Large round master start/stop button (MUTED/ON)
 * - System-wide parameters display
 * - Daily drawdown monitoring
 * - Active robots count
 * - Real-time P&L display
 */
public class ControlPanelPane extends VBox {
    private final UUID userId;
    private final SystemConfig systemConfig;
    private final DrawdownMonitor drawdownMonitor;
    private final RobotMatrixTable matrixTable;

    // UI Components
    private Button masterButton;
    private Circle masterButtonCircle;
    private Label masterButtonLabel;
    private Label activeRobotsLabel;
    private Label currentDrawdownLabel;
    private TextField dailyLimitField;
    private Label totalRptLabel;
    private Button saveLayoutButton;
    private Button loadLayoutButton;
    private Button setDefaultsButton;

    private ScheduledExecutorService updateScheduler;
    private boolean isMasterEnabled = false;
    private BooleanProperty masterEnabledProperty = new SimpleBooleanProperty(false);
    private Runnable onSaveLayoutCallback;
    private Runnable onLoadLayoutCallback;
    private Runnable onSetDefaultsCallback;

    public ControlPanelPane(UUID userId, SystemConfig systemConfig, RobotMatrixTable matrixTable, Runnable onSaveLayoutCallback, Runnable onLoadLayoutCallback, Runnable onSetDefaultsCallback) {
        this.userId = userId;
        this.matrixTable = matrixTable;
        this.systemConfig = systemConfig;
        this.drawdownMonitor = DrawdownMonitor.getInstance();
        this.onSaveLayoutCallback = onSaveLayoutCallback;
        this.onLoadLayoutCallback = onLoadLayoutCallback;
        this.onSetDefaultsCallback = onSetDefaultsCallback;

        initialize();
        startRealtimeUpdates();
    }

    private void initialize() {
        setMinWidth(250);
        setMaxWidth(250);
        setPadding(new Insets(10, 10, 10, 10));
        setSpacing(10);
        setStyle("-fx-background-color: #2e2e2e; -fx-border-color: #444; -fx-border-width: 0 0 0 2;");

        // Master Button (Round, Large)
        createMasterButton();

        // Divider
        Separator separator1 = new Separator();
        separator1.setStyle("-fx-background-color: #444;");

        // System Parameters Section
        Label systemParamsTitle = createSectionTitle("System Parameters");

        HBox dailyLimitBox = createDailyLimitField();
        currentDrawdownLabel = createParameterLabel("Current P&L:", "0.0%");
        activeRobotsLabel = createParameterLabel("Active Robots:", "0/500");
        totalRptLabel = createParameterLabel("Total RPT:", "$0.00");

        // Divider
        Separator separator2 = new Separator();
        separator2.setStyle("-fx-background-color: #444;");

        // Set Defaults Button
        setDefaultsButton = new Button("Set Defaults");
        setDefaultsButton.setPrefWidth(200);
        setDefaultsButton.setPrefHeight(35);
        setDefaultsButton.setStyle(
            "-fx-background-color: #ff9800; " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 13px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 5;"
        );
        setDefaultsButton.setOnAction(e -> handleSetDefaults());
        VBox.setMargin(setDefaultsButton, new Insets(15, 25, 0, 25));

        // Save Layout Button
        saveLayoutButton = new Button("Save Layout");
        saveLayoutButton.setPrefWidth(200);
        saveLayoutButton.setPrefHeight(35);
        saveLayoutButton.setStyle(
            "-fx-background-color: #4a86e8; " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 13px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 5;"
        );
        saveLayoutButton.setOnAction(e -> handleSaveLayout());
        VBox.setMargin(saveLayoutButton, new Insets(15, 25, 0, 25));

        // Load Layout Button
        loadLayoutButton = new Button("Load Layout");
        loadLayoutButton.setPrefWidth(200);
        loadLayoutButton.setPrefHeight(35);
        loadLayoutButton.setStyle(
            "-fx-background-color: #66bb6a; " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 13px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 5;"
        );
        loadLayoutButton.setOnAction(e -> handleLoadLayout());
        VBox.setMargin(loadLayoutButton, new Insets(15, 25, 0, 25));

        // Add all components
        getChildren().addAll(
            masterButton,
            separator1,
            systemParamsTitle,
            dailyLimitBox,
            currentDrawdownLabel,
            activeRobotsLabel,
            totalRptLabel,
            separator2,
            setDefaultsButton,
            saveLayoutButton,
            loadLayoutButton
        );

        Logger.info("ControlPanelPane initialized (250px width) - System Parameters and control buttons");
    }

    /**
     * Creates the master button (60px diameter)
     */
    private void createMasterButton() {
        masterButton = new Button();
        masterButton.setPrefSize(100, 100);
        masterButton.setMaxSize(100, 100);
        masterButton.setMinSize(100, 100);

        // Create circular appearance
        masterButtonCircle = new Circle(50);
        masterButtonCircle.setFill(Color.GRAY);
        masterButtonCircle.setStroke(Color.web("#555"));
        masterButtonCircle.setStrokeWidth(2);

        masterButtonLabel = new Label("MUTED");
        masterButtonLabel.setFont(Font.font("System", FontWeight.BOLD, 14));
        masterButtonLabel.setTextFill(Color.WHITE);

        // Stack circle and label
        VBox buttonContent = new VBox(masterButtonCircle, masterButtonLabel);
        buttonContent.setAlignment(Pos.CENTER);
        buttonContent.setSpacing(-66); // Overlap to center text on circle

        masterButton.setGraphic(buttonContent);
        masterButton.setStyle("-fx-background-color: transparent; -fx-padding: 0;");

        // Center in pane with less margin at top
        VBox.setMargin(masterButton, new Insets(0, 0, 15, 0));
        setAlignment(Pos.TOP_CENTER);

        // Handle click
        masterButton.setOnAction(e -> toggleMasterTrading());
    }

    /**
     * Creates a section title label
     */
    private Label createSectionTitle(String text) {
        Label label = new Label(text);
        label.setFont(Font.font("System", FontWeight.BOLD, 14));
        label.setTextFill(Color.web("#cccccc"));
        label.setStyle("-fx-padding: 5 0 0 0;");
        return label;
    }

    /**
     * Creates a parameter display label
     */
    private Label createParameterLabel(String name, String initialValue) {
        Label label = new Label(name + " " + initialValue);
        label.setFont(Font.font("System", 12));
        label.setTextFill(Color.WHITE);
        label.setWrapText(true);
        return label;
    }

    /**
     * Creates the editable Daily DD Limit field
     */
    private HBox createDailyLimitField() {
        Label label = new Label("Daily DD Limit:");
        label.setFont(Font.font("System", 12));
        label.setTextFill(Color.web("#999999"));

        dailyLimitField = new TextField(String.format("%.1f", systemConfig.getDailyDrawdownHardStop()));
        dailyLimitField.setPrefWidth(60);
        dailyLimitField.setMaxWidth(60);
        dailyLimitField.setStyle(
            "-fx-background-color: #3e3e3e; " +
            "-fx-text-fill: #cccccc; " +
            "-fx-border-color: #555; " +
            "-fx-border-radius: 3; " +
            "-fx-background-radius: 3;"
        );

        Label percentLabel = new Label("%");
        percentLabel.setFont(Font.font("System", 12));
        percentLabel.setTextFill(Color.web("#999999"));

        dailyLimitField.focusedProperty().addListener((obs, wasFocused, isNowFocused) -> {
            if (!isNowFocused) {
                handleDailyLimitChange();
            }
        });

        dailyLimitField.setOnAction(e -> handleDailyLimitChange());

        HBox box = new HBox(4, label, dailyLimitField, percentLabel);
        box.setAlignment(Pos.CENTER_LEFT);
        return box;
    }

    /**
     * Handles Daily DD Limit field changes
     */
    private void handleDailyLimitChange() {
        if (isMasterEnabled) {
            Platform.runLater(() -> {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Cannot Change DD Limit");
                alert.setHeaderText(null);
                alert.setContentText("Daily DD Limit can only be changed when Master is MUTED.");
                alert.showAndWait();

                dailyLimitField.setText(String.format("%.1f", systemConfig.getDailyDrawdownHardStop()));
            });
            Logger.warning("Attempted to change DD Limit while Master is ON");
            return;
        }

        try {
            double newLimit = Double.parseDouble(dailyLimitField.getText().trim());

            if (newLimit <= 0 || newLimit > 100) {
                throw new IllegalArgumentException("DD Limit must be between 0.1 and 100.0");
            }

            systemConfig.setDailyDrawdownHardStop(newLimit);
            saveDailyLimitToDatabase(newLimit);

            dailyLimitField.setText(String.format("%.1f", newLimit));
            Logger.info("Daily DD Limit updated to " + newLimit + "%");

        } catch (NumberFormatException e) {
            Platform.runLater(() -> {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Invalid Input");
                alert.setHeaderText(null);
                alert.setContentText("Please enter a valid decimal number.");
                alert.showAndWait();

                dailyLimitField.setText(String.format("%.1f", systemConfig.getDailyDrawdownHardStop()));
            });
            Logger.error("Invalid DD Limit input: " + dailyLimitField.getText());
        } catch (IllegalArgumentException e) {
            Platform.runLater(() -> {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Invalid Range");
                alert.setHeaderText(null);
                alert.setContentText(e.getMessage());
                alert.showAndWait();

                dailyLimitField.setText(String.format("%.1f", systemConfig.getDailyDrawdownHardStop()));
            });
            Logger.error("DD Limit out of range: " + e.getMessage());
        }
    }

    /**
     * Saves Daily DD Limit to database
     */
    private void saveDailyLimitToDatabase(double newLimit) {
        try {
            systemConfig.setDailyDrawdownHardStop(newLimit);
            Logger.info("Daily DD Limit updated: " + newLimit);
        } catch (Exception e) {
            Logger.error("Failed to update Daily DD Limit: " + e.getMessage());
        }
    }

    /**
     * Toggles master trading ON/MUTED
     */
    private void toggleMasterTrading() {
        isMasterEnabled = !isMasterEnabled;
        masterEnabledProperty.set(isMasterEnabled);

        if (isMasterEnabled) {
            Map<String, Object> drawdownStats = drawdownMonitor.getDrawdownStats();
            double dailyDDPercent = (Double) drawdownStats.getOrDefault("daily_dd_percent", 0.0);
            double ddLimit = systemConfig.getDailyDrawdownHardStop();

            if (dailyDDPercent >= ddLimit) {
                Platform.runLater(() -> {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Cannot Start Trading");
                    alert.setHeaderText("Daily DD Limit Already Breached");
                    alert.setContentText(String.format(
                        "Current Daily DD: %.2f%%\nDD Limit: %.1f%%\n\nPlease wait until a new trading day.",
                        dailyDDPercent, ddLimit
                    ));
                    alert.showAndWait();
                });

                isMasterEnabled = false;
                Logger.error("Cannot enable Master - DD limit already breached: " + dailyDDPercent + "% >= " + ddLimit + "%");
                return;
            }

            masterButtonCircle.setFill(Color.web("#4cff4c"));
            masterButtonLabel.setText("ON");
            systemConfig.setMasterTradingEnabled(true);
            dailyLimitField.setDisable(true);
            matrixTable.snapshotActiveRows();
            Logger.info("Master trading ENABLED");

        } else {
            masterButtonCircle.setFill(Color.GRAY);
            masterButtonLabel.setText("MUTED");
            systemConfig.setMasterTradingEnabled(false);
            dailyLimitField.setDisable(false);
            matrixTable.clearLockedRows();
            Logger.info("Master trading MUTED");
        }
    }

    /**
     * Starts real-time updates (1 second interval)
     */
    private void startRealtimeUpdates() {
        updateScheduler = Executors.newScheduledThreadPool(1);
        updateScheduler.scheduleAtFixedRate(
            this::updateDisplay,
            0,
            1,
            TimeUnit.SECONDS
        );

        Logger.info("ControlPanel real-time updates started (1s interval)");
    }

    /**
     * Updates all display values from services
     */
    private void updateDisplay() {
        Platform.runLater(() -> {
            try {
                Map<String, Object> drawdownStats = drawdownMonitor.getDrawdownStats();

                double ddLimit = systemConfig.getDailyDrawdownHardStop();
                double dailyDDPercent = (Double) drawdownStats.getOrDefault("daily_dd_percent", 0.0);
                int activeRobots = systemConfig.getActiveRobotsCount();
                double totalRpt = systemConfig.getTotalRptAcrossRobots();

                if (!dailyLimitField.isFocused()) {
                    dailyLimitField.setText(String.format("%.1f", ddLimit));
                }

                String plColor = "#FFFFFF";
                if (dailyDDPercent > 0) {
                    plColor = "#4cff4c";
                } else if (dailyDDPercent < 0) {
                    double absLoss = Math.abs(dailyDDPercent);
                    if (absLoss >= ddLimit) {
                        plColor = "#ff0000";
                    } else if (absLoss >= (ddLimit - 2.0)) {
                        plColor = "#ffaa66";
                    } else {
                        plColor = "#ff6b6b";
                    }
                }
                currentDrawdownLabel.setText("Current P&L: " + String.format("%+.2f%%", dailyDDPercent));
                currentDrawdownLabel.setTextFill(Color.web(plColor));

                activeRobotsLabel.setText("Active Robots: " + activeRobots + "/500");
                totalRptLabel.setText("Total RPT: $" + String.format("%.2f", totalRpt));

                if (isMasterEnabled && Math.abs(dailyDDPercent) >= ddLimit) {
                    triggerEmergencyStop();
                    systemConfig.setMaxDailyDrawdownReached(true);
                    showEmergencyStopAlert(dailyDDPercent, ddLimit);
                }

            } catch (Exception e) {
                Logger.error("ERROR updating control panel: " + e.getMessage());
            }
        });
    }

    /**
     * Triggers emergency stop - liquidates all positions
     */
    private void triggerEmergencyStop() {
        isMasterEnabled = false;
        masterEnabledProperty.set(false);
        masterButtonCircle.setFill(Color.web("#ff6b6b"));
        masterButtonLabel.setText("STOPPED");
        systemConfig.setMasterTradingEnabled(false);
        dailyLimitField.setDisable(false);

        Logger.error("EMERGENCY STOP TRIGGERED - DD limit breached");

        // TODO: Liquidate all positions
        // TODO: Cancel all pending orders
    }

    /**
     * Shows critical alert when emergency stop is triggered
     */
    private void showEmergencyStopAlert(double currentDD, double ddLimit) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("EMERGENCY STOP");
        alert.setHeaderText("Daily Drawdown Limit Breached!");
        alert.setContentText(String.format(
            "Current Daily DD: %.2f%%\nDD Limit: %.1f%%\n\nAll positions have been closed.\nTrading is stopped for the day.\nPlease review your strategies.",
            currentDD, ddLimit
        ));
        alert.showAndWait();

        Logger.error(String.format("CRITICAL: Emergency stop - DD %.2f%% >= Limit %.1f%%", currentDD, ddLimit));
    }

    /**
     * Stops real-time updates
     */
    public void stopRealtimeUpdates() {
        if (updateScheduler != null && !updateScheduler.isShutdown()) {
            updateScheduler.shutdown();
            try {
                if (!updateScheduler.awaitTermination(2, TimeUnit.SECONDS)) {
                    updateScheduler.shutdownNow();
                }
            } catch (InterruptedException e) {
                updateScheduler.shutdownNow();
                Thread.currentThread().interrupt();
            }
            Logger.info("ControlPanel real-time updates stopped");
        }
    }

    /**
     * Gets current master trading state
     */
    public boolean isMasterEnabled() {
        return isMasterEnabled;
    }

    /**
     * Programmatically sets master button state
     */
    public void setMasterEnabled(boolean enabled) {
        if (enabled != isMasterEnabled) {
            toggleMasterTrading();
        }
    }

    public void addMasterStateListener(javafx.beans.value.ChangeListener<? super Boolean> listener) {
        masterEnabledProperty.addListener(listener);
    }

    /**
     * Sets the callback for Save Layout button
     */
    public void setOnSaveLayoutCallback(Runnable callback) {
        this.onSaveLayoutCallback = callback;
    }

    /**
     * Handles Save Layout button click
     */
    private void handleSaveLayout() {
        Logger.info("Save Layout button clicked");
        System.out.println("[DEBUG] Save Layout button clicked");

        if (onSaveLayoutCallback != null) {
            System.out.println("[DEBUG] Executing Save Layout callback");
            try {
                onSaveLayoutCallback.run();
                System.out.println("[DEBUG] Save Layout callback completed");
            } catch (Exception e) {
                System.err.println("[ERROR] Save Layout callback failed: " + e.getMessage());
                e.printStackTrace();
                throw e;
            }
        } else {
            System.err.println("[ERROR] No Save Layout callback configured");
            Logger.warning("No Save Layout callback configured");
        }
    }

    /**
     * Handles Load Layout button click
     */
    private void handleLoadLayout() {
        Logger.info("Load Layout button clicked");
        System.out.println("[DEBUG] Load Layout button clicked");

        if (onLoadLayoutCallback != null) {
            System.out.println("[DEBUG] Executing Load Layout callback");
            try {
                onLoadLayoutCallback.run();
                System.out.println("[DEBUG] Load Layout callback completed");
            } catch (Exception e) {
                System.err.println("[ERROR] Load Layout callback failed: " + e.getMessage());
                e.printStackTrace();
                throw e;
            }
        } else {
            System.err.println("[ERROR] No Load Layout callback configured");
            Logger.warning("No Load Layout callback configured");
        }
    }

    /**
     * Sets the callback for Set Defaults button
     */
    public void setOnSetDefaultsCallback(Runnable callback) {
        this.onSetDefaultsCallback = callback;
    }

    /**
     * Handles Set Defaults button click
     */
    private void handleSetDefaults() {
        Logger.info("Set Defaults button clicked");
        System.out.println("[DEBUG] Set Defaults button clicked");

        if (onSetDefaultsCallback != null) {
            System.out.println("[DEBUG] Executing Set Defaults callback");
            try {
                onSetDefaultsCallback.run();
                System.out.println("[DEBUG] Set Defaults callback completed");
            } catch (Exception e) {
                System.err.println("[ERROR] Set Defaults callback failed: " + e.getMessage());
                e.printStackTrace();
                throw e;
            }
        } else {
            System.err.println("[ERROR] No Set Defaults callback configured");
            Logger.warning("No Set Defaults callback configured");
        }
    }
}
