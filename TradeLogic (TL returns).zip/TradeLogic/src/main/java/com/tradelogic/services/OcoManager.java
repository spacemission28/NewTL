package com.tradelogic.services;

import com.tradelogic.Logger;
import com.tradelogic.models.ExecutionFeedback;
import com.tradelogic.models.TradeCommand;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages OCO (One-Cancels-Other) logic for pending orders.
 *
 * When 14 orders are placed (7 BUY STOP + 7 SELL STOP) for a robot:
 * - All 14 orders share the same magic number
 * - When ANY order on one side fills, ALL orders on the opposite side must be deleted
 * - This prevents both sides from executing (which would be a hedge)
 *
 * This class tracks:
 * - Which magic numbers have pending order groups
 * - Which side filled first (BUY or SELL)
 * - Whether opposite side deletion has been triggered
 */
public class OcoManager {

    private static class OrderGroup {
        String magicNumber;
        UUID robotConfigId;
        boolean hasBuyOrders;
        boolean hasSellOrders;
        boolean buyFilled;
        boolean sellFilled;
        boolean oppositeDeleteSent;
        long placementTime;
        boolean endOfDayCleanupMarked;

        OrderGroup(String magicNumber, UUID robotConfigId) {
            this.magicNumber = magicNumber;
            this.robotConfigId = robotConfigId;
            this.hasBuyOrders = false;
            this.hasSellOrders = false;
            this.buyFilled = false;
            this.sellFilled = false;
            this.oppositeDeleteSent = false;
            this.placementTime = System.currentTimeMillis();
            this.endOfDayCleanupMarked = false;
        }
    }

    private final Map<String, OrderGroup> activeGroups = new ConcurrentHashMap<>();
    private TradeHistoryCache tradeHistoryCache;

    public OcoManager() {
        // Constructor explicitly added
    }

    /**
     * Registers a new OCO order group when 14 orders are placed
     */
    public void registerOrderGroup(String magicNumber, UUID robotConfigId, boolean hasBuy, boolean hasSell) {
        Logger.info("OCO DEBUG: ===== REGISTER ORDER GROUP CALLED =====");
        Logger.info("OCO DEBUG: Magic: " + magicNumber + ", RobotID: " + robotConfigId + ", HasBuy: " + hasBuy + ", HasSell: " + hasSell);

        OrderGroup group = new OrderGroup(magicNumber, robotConfigId);
        group.hasBuyOrders = hasBuy;
        group.hasSellOrders = hasSell;
        activeGroups.put(magicNumber, group);

        Logger.info("OCO DEBUG: Group added to activeGroups. Total groups now: " + activeGroups.size());
        Logger.info("OCO DEBUG: ActiveGroups keys: " + activeGroups.keySet());
        Logger.info("OCO Manager: Registered order group for magic " + magicNumber +
                   " (BUY: " + hasBuy + ", SELL: " + hasSell + ")");
    }

    /**
     * Processes execution feedback and determines if opposite side should be deleted
     *
     * @param feedback Execution feedback from MT5
     * @param command Original trade command
     * @return Optional delete command if opposite side needs deletion, empty otherwise
     */
    public Optional<TradeCommand> processFill(ExecutionFeedback feedback, TradeCommand command) {
        Logger.info("OCO DEBUG: processFill called - success=" + feedback.isSuccess() + ", magic=" + command.getMagicNumber());

        if (!feedback.isSuccess()) {
            Logger.info("OCO DEBUG: Feedback not successful, skipping");
            return Optional.empty();
        }

        String magicNumber = command.getMagicNumber();
        Logger.info("OCO DEBUG: Looking for group with magic: " + magicNumber);
        Logger.info("OCO DEBUG: Current activeGroups size: " + activeGroups.size());
        Logger.info("OCO DEBUG: Current activeGroups keys: " + activeGroups.keySet());

        OrderGroup group = activeGroups.get(magicNumber);

        if (group == null) {
            Logger.warning("OCO Manager: Received fill for unknown magic number " + magicNumber);
            Logger.warning("OCO DEBUG: activeGroups contains: " + activeGroups.keySet());
            Logger.warning("OCO DEBUG: Looking for: '" + magicNumber + "' (length=" + magicNumber.length() + ")");
            for (String key : activeGroups.keySet()) {
                Logger.warning("OCO DEBUG: Existing key: '" + key + "' (length=" + key.length() + ") equals=" + key.equals(magicNumber));
            }
            return Optional.empty();
        }

        Logger.info("OCO DEBUG: Found group - buyFilled=" + group.buyFilled + ", sellFilled=" + group.sellFilled + ", oppositeDeleteSent=" + group.oppositeDeleteSent);

        if (group.oppositeDeleteSent) {
            Logger.info("OCO Manager: Opposite delete already sent for magic " + magicNumber);
            return Optional.empty();
        }

        String action = command.getAction();
        if (!"PLACE_ORDER".equals(action)) {
            Logger.info("OCO DEBUG: Action not PLACE_ORDER, skipping (action=" + action + ")");
            return Optional.empty();
        }

        @SuppressWarnings("unchecked")
        Map<String, Object> params = command.getParameters();
        String orderType = (String) params.get("order_type");

        if (orderType == null) {
            Logger.info("OCO DEBUG: orderType is null, skipping (params=" + params + ")");
            return Optional.empty();
        }

        Logger.info("OCO DEBUG: orderType=" + orderType);

        boolean isBuy = orderType.startsWith("BUY");
        boolean isSell = orderType.startsWith("SELL");

        if (isBuy && !group.buyFilled) {
            group.buyFilled = true;
            Logger.info("OCO Manager: BUY order filled for magic " + magicNumber + " - FIRST BUY FILL");

            if (group.hasSellOrders) {
                group.oppositeDeleteSent = true;
                Logger.info("OCO Manager: Triggering delete of all SELL orders for magic " + magicNumber);
                return Optional.of(createDeleteCommand("BUY", magicNumber, group.robotConfigId));
            } else {
                Logger.info("OCO DEBUG: No SELL orders to delete");
            }
        } else if (isSell && !group.sellFilled) {
            group.sellFilled = true;
            Logger.info("OCO Manager: SELL order filled for magic " + magicNumber + " - FIRST SELL FILL");

            if (group.hasBuyOrders) {
                group.oppositeDeleteSent = true;
                Logger.info("OCO Manager: Triggering delete of all BUY orders for magic " + magicNumber);
                return Optional.of(createDeleteCommand("SELL", magicNumber, group.robotConfigId));
            } else {
                Logger.info("OCO DEBUG: No BUY orders to delete");
            }
        } else if (isBuy && group.buyFilled) {
            Logger.info("OCO Manager: Additional BUY fill detected for magic " + magicNumber + " (already processed, ignoring)");
        } else if (isSell && group.sellFilled) {
            Logger.info("OCO Manager: Additional SELL fill detected for magic " + magicNumber + " (already processed, ignoring)");
        } else {
            Logger.info("OCO DEBUG: Fill already processed (isBuy=" + isBuy + ", buyFilled=" + group.buyFilled + ", isSell=" + isSell + ", sellFilled=" + group.sellFilled + ")");
        }

        return Optional.empty();
    }

    /**
     * Creates a SINGLE delete command that tells MT5 to delete ALL opposite-side orders
     * with the specified magic number.
     */
    public TradeCommand createDeleteAllOppositeCommand(String filledSide, String magicNumber, UUID robotConfigId) {
        String oppositeType = filledSide.equals("BUY") ? "SELL" : "BUY";

        Map<String, Object> params = new HashMap<>();
        params.put("magic_number", magicNumber);
        params.put("order_type", oppositeType + "_STOP");
        params.put("delete_all", true);

        TradeCommand command = new TradeCommand(
            robotConfigId,
            magicNumber,
            "DELETE_ALL_OPPOSITE",
            params
        );

        Logger.info("OCO Manager: Created DELETE_ALL command for " + oppositeType + " orders (magic: " + magicNumber + ")");
        return command;
    }

    /**
     * Creates a delete command for opposite side orders
     */
    private TradeCommand createDeleteCommand(String filledSide, String magicNumber, UUID robotConfigId) {
        String oppositeType = filledSide.equals("BUY") ? "SELL" : "BUY";

        Map<String, Object> params = new HashMap<>();
        params.put("magic_number", magicNumber);
        params.put("order_type", oppositeType + "_STOP");

        TradeCommand command = new TradeCommand(
            robotConfigId,
            magicNumber,
            "DELETE_OPPOSITE_SIDE",
            params
        );

        Logger.info("OCO Manager: Created delete command for " + oppositeType + " orders (magic: " + magicNumber + ")");
        return command;
    }

    /**
     * Removes an order group from tracking (e.g., after all orders filled or deleted)
     */
    public void removeOrderGroup(String magicNumber) {
        OrderGroup removed = activeGroups.remove(magicNumber);
        if (removed != null) {
            Logger.info("OCO Manager: Removed order group for magic " + magicNumber);
        }
    }

    /**
     * Checks if a magic number has an active OCO group
     */
    public boolean hasActiveGroup(String magicNumber) {
        return activeGroups.containsKey(magicNumber);
    }

    /**
     * Gets all active magic numbers being tracked
     */
    public Set<String> getActiveMagicNumbers() {
        return new HashSet<>(activeGroups.keySet());
    }

    /**
     * Clears all tracked groups (useful for system reset)
     */
    public void clear() {
        int count = activeGroups.size();
        activeGroups.clear();
        Logger.info("OCO Manager: Cleared " + count + " order groups");
    }

    /**
     * Gets statistics about OCO management
     */
    public Map<String, Object> getStatistics() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("active_groups", activeGroups.size());

        int buyFilled = 0;
        int sellFilled = 0;
        int bothSides = 0;
        int deletesSent = 0;

        for (OrderGroup group : activeGroups.values()) {
            if (group.buyFilled) buyFilled++;
            if (group.sellFilled) sellFilled++;
            if (group.hasBuyOrders && group.hasSellOrders) bothSides++;
            if (group.oppositeDeleteSent) deletesSent++;
        }

        stats.put("buy_filled", buyFilled);
        stats.put("sell_filled", sellFilled);
        stats.put("both_sides_pending", bothSides);
        stats.put("deletes_sent", deletesSent);

        return stats;
    }

    /**
     * Marks that a delete command was sent for end-of-day cleanup
     */
    public void markEndOfDayCleanup(String magicNumber) {
        OrderGroup group = activeGroups.get(magicNumber);
        if (group != null) {
            group.oppositeDeleteSent = true;
            Logger.info("OCO Manager: Marked EOD cleanup for magic " + magicNumber);
        }
    }
}
