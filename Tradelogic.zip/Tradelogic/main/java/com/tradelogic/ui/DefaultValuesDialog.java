package com.tradelogic.ui;

import com.tradelogic.ui.NumberConverters.IntegerNumberConverter;
import com.tradelogic.ui.NumberConverters.DoubleNumberConverter;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.util.StringConverter;

import java.util.HashMap;
import java.util.Map;

public class DefaultValuesDialog extends Dialog<Map<String, Object>> {

    private final ComboBox<String> symbolCombo;
    private final ComboBox<String> timeframeCombo;
    private final ComboBox<Integer> closeHourCombo;
    private final ComboBox<Integer> closeMinuteCombo;
    private final TextField minX1HeightField;
    private final ComboBox<String> x1TypeCombo;
    private final TextField trigPercentField;
    private final TextField stopLossPercentField;
    private final TextField rptPercentField;
    private final TextField rptFixedAmountField;
    private final TextField tp1PercentField;
    private final Spinner<Integer> tp1VolumeSpinner;
    private final TextField tp2PercentField;
    private final Spinner<Integer> tp2VolumeSpinner;
    private final TextField tp3PercentField;
    private final Spinner<Integer> tp3VolumeSpinner;
    private final TextField tp4PercentField;
    private final Spinner<Integer> tp4VolumeSpinner;
    private final TextField tp5PercentField;
    private final Spinner<Integer> tp5VolumeSpinner;
    private final TextField tp6PercentField;
    private final Spinner<Integer> tp6VolumeSpinner;
    private final TextField tp7PercentField;
    private final Spinner<Integer> tp7VolumeSpinner;
    private final CheckBox commissionsEnabledCheckBox;
    private final ComboBox<String> commissionTypeCombo;
    private final TextField commissionValueField;
    private final CheckBox disableLeapfrogCheckBox;
    private final CheckBox smartTSCheckBox;
    private final ComboBox<Integer> endHourCombo;
    private final ComboBox<Integer> endMinuteCombo;
    private final CheckBox eodEnabledCheckBox;
    private final CheckBox strongThrustCheckBox;
    private final CheckBox orthodoxCCCheckBox;
    private final CheckBox allDayCheckBox;

    public DefaultValuesDialog(Map<String, Object> currentDefaults, ObservableList<String> availableSymbols) {
        setTitle("Set Default Values");
        setHeaderText("Configure default values for new robot rows");

        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        int row = 0;

        symbolCombo = new ComboBox<>(availableSymbols);
        symbolCombo.setEditable(false);
        String defaultSymbol = (String) currentDefaults.getOrDefault("symbol", "XAUUSD");
        if (availableSymbols.contains(defaultSymbol)) {
            symbolCombo.setValue(defaultSymbol);
        } else if (!availableSymbols.isEmpty()) {
            symbolCombo.setValue(availableSymbols.get(0));
        }
        grid.add(new Label("Symbol:"), 0, row);
        grid.add(symbolCombo, 1, row++);

        timeframeCombo = new ComboBox<>(FXCollections.observableArrayList(
            "M1", "M2", "M3", "M5", "M10", "M15", "M30", "H1", "H3", "H4", "D1"
        ));
        timeframeCombo.setValue((String) currentDefaults.getOrDefault("timeframe", "H1"));
        grid.add(new Label("Timeframe:"), 0, row);
        grid.add(timeframeCombo, 1, row++);

        // Create Close Hour ComboBox with values 0-23
        ObservableList<Integer> hours = FXCollections.observableArrayList();
        for (int i = 0; i <= 23; i++) {
            hours.add(i);
        }
        closeHourCombo = new ComboBox<>(hours);
        closeHourCombo.setValue(((Number) currentDefaults.getOrDefault("close_hour", 15)).intValue());
        grid.add(new Label("Close Hour:"), 0, row);
        grid.add(closeHourCombo, 1, row++);

        // Create Close Minute ComboBox with values 0-59
        ObservableList<Integer> minutes = FXCollections.observableArrayList();
        for (int i = 0; i <= 59; i++) {
            minutes.add(i);
        }
        closeMinuteCombo = new ComboBox<>(minutes);
        closeMinuteCombo.setValue(((Number) currentDefaults.getOrDefault("close_minute", 30)).intValue());
        grid.add(new Label("Close Minute:"), 0, row);
        grid.add(closeMinuteCombo, 1, row++);

        minX1HeightField = new TextField(String.valueOf(((Number) currentDefaults.getOrDefault("min_x1_height", 7.0)).doubleValue()));
        grid.add(new Label("Min X1 Height:"), 0, row);
        grid.add(minX1HeightField, 1, row++);

        x1TypeCombo = new ComboBox<>(FXCollections.observableArrayList(
            "Yen Pips", "Non-Yen Pips", "Cents", "Points"
        ));
        x1TypeCombo.setValue((String) currentDefaults.getOrDefault("x1_type", "Cents"));
        grid.add(new Label("X1 Type:"), 0, row);
        grid.add(x1TypeCombo, 1, row++);

        trigPercentField = new TextField(String.valueOf(((Number) currentDefaults.getOrDefault("trig_percent", 13.0)).doubleValue()));
        grid.add(new Label("Trig %:"), 0, row);
        grid.add(trigPercentField, 1, row++);

        stopLossPercentField = new TextField(String.valueOf(((Number) currentDefaults.getOrDefault("stop_loss_percent", 13.0)).doubleValue()));
        grid.add(new Label("Stop Loss %:"), 0, row);
        grid.add(stopLossPercentField, 1, row++);

        rptPercentField = new TextField(String.valueOf(((Number) currentDefaults.getOrDefault("rpt_percent", 0.3)).doubleValue()));
        grid.add(new Label("RPT %:"), 0, row);
        grid.add(rptPercentField, 1, row++);

        rptFixedAmountField = new TextField(String.valueOf(((Number) currentDefaults.getOrDefault("rpt_fixed_amount", 0.0)).doubleValue()));
        grid.add(new Label("RPT Fixed $:"), 0, row);
        grid.add(rptFixedAmountField, 1, row++);

        tp1PercentField = new TextField(String.valueOf(((Number) currentDefaults.getOrDefault("tp1_percent", 100.0)).doubleValue()));
        tp1VolumeSpinner = new Spinner<>(0, 100, ((Number) currentDefaults.getOrDefault("tp1_volume", 14)).intValue());
        grid.add(new Label("TP1 %:"), 0, row);
        grid.add(tp1PercentField, 1, row);
        grid.add(new Label("Vol:"), 2, row);
        grid.add(tp1VolumeSpinner, 3, row++);

        tp2PercentField = new TextField(String.valueOf(((Number) currentDefaults.getOrDefault("tp2_percent", 110.0)).doubleValue()));
        tp2VolumeSpinner = new Spinner<>(0, 100, ((Number) currentDefaults.getOrDefault("tp2_volume", 14)).intValue());
        grid.add(new Label("TP2 %:"), 0, row);
        grid.add(tp2PercentField, 1, row);
        grid.add(new Label("Vol:"), 2, row);
        grid.add(tp2VolumeSpinner, 3, row++);

        tp3PercentField = new TextField(String.valueOf(((Number) currentDefaults.getOrDefault("tp3_percent", 125.0)).doubleValue()));
        tp3VolumeSpinner = new Spinner<>(0, 100, ((Number) currentDefaults.getOrDefault("tp3_volume", 14)).intValue());
        grid.add(new Label("TP3 %:"), 0, row);
        grid.add(tp3PercentField, 1, row);
        grid.add(new Label("Vol:"), 2, row);
        grid.add(tp3VolumeSpinner, 3, row++);

        tp4PercentField = new TextField(String.valueOf(((Number) currentDefaults.getOrDefault("tp4_percent", 150.0)).doubleValue()));
        tp4VolumeSpinner = new Spinner<>(0, 100, ((Number) currentDefaults.getOrDefault("tp4_volume", 14)).intValue());
        grid.add(new Label("TP4 %:"), 0, row);
        grid.add(tp4PercentField, 1, row);
        grid.add(new Label("Vol:"), 2, row);
        grid.add(tp4VolumeSpinner, 3, row++);

        tp5PercentField = new TextField(String.valueOf(((Number) currentDefaults.getOrDefault("tp5_percent", 200.0)).doubleValue()));
        tp5VolumeSpinner = new Spinner<>(0, 100, ((Number) currentDefaults.getOrDefault("tp5_volume", 14)).intValue());
        grid.add(new Label("TP5 %:"), 0, row);
        grid.add(tp5PercentField, 1, row);
        grid.add(new Label("Vol:"), 2, row);
        grid.add(tp5VolumeSpinner, 3, row++);

        tp6PercentField = new TextField(String.valueOf(((Number) currentDefaults.getOrDefault("tp6_percent", 250.0)).doubleValue()));
        tp6VolumeSpinner = new Spinner<>(0, 100, ((Number) currentDefaults.getOrDefault("tp6_volume", 14)).intValue());
        grid.add(new Label("TP6 %:"), 0, row);
        grid.add(tp6PercentField, 1, row);
        grid.add(new Label("Vol:"), 2, row);
        grid.add(tp6VolumeSpinner, 3, row++);

        tp7PercentField = new TextField(String.valueOf(((Number) currentDefaults.getOrDefault("tp7_percent", 300.0)).doubleValue()));
        tp7VolumeSpinner = new Spinner<>(0, 100, ((Number) currentDefaults.getOrDefault("tp7_volume", 16)).intValue());
        grid.add(new Label("TP7 %:"), 0, row);
        grid.add(tp7PercentField, 1, row);
        grid.add(new Label("Vol:"), 2, row);
        grid.add(tp7VolumeSpinner, 3, row++);

        // Commission fields
        commissionsEnabledCheckBox = new CheckBox();
        commissionsEnabledCheckBox.setSelected((Boolean) currentDefaults.getOrDefault("commissions_enabled", false));
        grid.add(new Label("Commissions Enabled:"), 0, row);
        grid.add(commissionsEnabledCheckBox, 1, row++);

        commissionTypeCombo = new ComboBox<>(FXCollections.observableArrayList(
            "No_Commissions", "FX_per_Lot", "ETF_Stock"
        ));
        commissionTypeCombo.setValue((String) currentDefaults.getOrDefault("commission_type", "No_Commissions"));
        grid.add(new Label("Commission Type:"), 0, row);
        grid.add(commissionTypeCombo, 1, row++);

        commissionValueField = new TextField(String.valueOf(((Number) currentDefaults.getOrDefault("commission_value", 0.0)).doubleValue()));
        grid.add(new Label("Commission Value:"), 0, row);
        grid.add(commissionValueField, 1, row++);

        disableLeapfrogCheckBox = new CheckBox();
        disableLeapfrogCheckBox.setSelected((Boolean) currentDefaults.getOrDefault("disable_leapfrog", false));
        grid.add(new Label("Disable Leapfrog:"), 0, row);
        grid.add(disableLeapfrogCheckBox, 1, row++);

        smartTSCheckBox = new CheckBox();
        smartTSCheckBox.setSelected((Boolean) currentDefaults.getOrDefault("smart_ts", false));
        grid.add(new Label("Smart TS:"), 0, row);
        grid.add(smartTSCheckBox, 1, row++);

        // EOD fields
        ObservableList<Integer> endHours = FXCollections.observableArrayList();
        for (int i = 0; i <= 23; i++) {
            endHours.add(i);
        }
        endHourCombo = new ComboBox<>(endHours);
        endHourCombo.setValue(((Number) currentDefaults.getOrDefault("end_hour", 23)).intValue());
        grid.add(new Label("End Hour:"), 0, row);
        grid.add(endHourCombo, 1, row++);

        ObservableList<Integer> endMinutes = FXCollections.observableArrayList();
        for (int i = 0; i <= 59; i++) {
            endMinutes.add(i);
        }
        endMinuteCombo = new ComboBox<>(endMinutes);
        endMinuteCombo.setValue(((Number) currentDefaults.getOrDefault("end_minute", 50)).intValue());
        grid.add(new Label("End Minute:"), 0, row);
        grid.add(endMinuteCombo, 1, row++);

        eodEnabledCheckBox = new CheckBox();
        eodEnabledCheckBox.setSelected((Boolean) currentDefaults.getOrDefault("eod_enabled", false));
        grid.add(new Label("EOD Enabled:"), 0, row);
        grid.add(eodEnabledCheckBox, 1, row++);

        strongThrustCheckBox = new CheckBox();
        strongThrustCheckBox.setSelected((Boolean) currentDefaults.getOrDefault("strong_thrust", false));
        grid.add(new Label("Strong Thrust:"), 0, row);
        grid.add(strongThrustCheckBox, 1, row++);

        orthodoxCCCheckBox = new CheckBox();
        orthodoxCCCheckBox.setSelected((Boolean) currentDefaults.getOrDefault("orthodox_cc", false));
        grid.add(new Label("Orthodox CC:"), 0, row);
        grid.add(orthodoxCCCheckBox, 1, row++);

        allDayCheckBox = new CheckBox();
        allDayCheckBox.setSelected((Boolean) currentDefaults.getOrDefault("all_day", false));
        grid.add(new Label("All Day:"), 0, row);
        grid.add(allDayCheckBox, 1, row++);

        ScrollPane scrollPane = new ScrollPane(grid);
        scrollPane.setFitToWidth(true);
        scrollPane.setPrefViewportHeight(600);
        scrollPane.setStyle("-fx-background-color: transparent;");
        getDialogPane().setContent(scrollPane);

        setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                Map<String, Object> defaults = new HashMap<>();
                defaults.put("symbol", symbolCombo.getValue() != null ? symbolCombo.getValue() : "");
                defaults.put("timeframe", timeframeCombo.getValue() != null ? timeframeCombo.getValue() : "");
                defaults.put("close_hour", closeHourCombo.getValue() != null ? closeHourCombo.getValue() : 0);
                defaults.put("close_minute", closeMinuteCombo.getValue() != null ? closeMinuteCombo.getValue() : 0);
                defaults.put("min_x1_height", minX1HeightField.getText() != null && !minX1HeightField.getText().isEmpty() ? Double.parseDouble(minX1HeightField.getText()) : 0.0);
                defaults.put("x1_type", x1TypeCombo.getValue() != null ? x1TypeCombo.getValue() : "");
                defaults.put("trig_percent", trigPercentField.getText() != null && !trigPercentField.getText().isEmpty() ? Double.parseDouble(trigPercentField.getText()) : 0.0);
                defaults.put("stop_loss_percent", stopLossPercentField.getText() != null && !stopLossPercentField.getText().isEmpty() ? Double.parseDouble(stopLossPercentField.getText()) : 0.0);
                defaults.put("rpt_percent", rptPercentField.getText() != null && !rptPercentField.getText().isEmpty() ? Double.parseDouble(rptPercentField.getText()) : 0.0);
                defaults.put("rpt_fixed_amount", rptFixedAmountField.getText() != null && !rptFixedAmountField.getText().isEmpty() ? Double.parseDouble(rptFixedAmountField.getText()) : 0.0);
                defaults.put("tp1_percent", tp1PercentField.getText() != null && !tp1PercentField.getText().isEmpty() ? Double.parseDouble(tp1PercentField.getText()) : 0.0);
                defaults.put("tp1_volume", tp1VolumeSpinner.getValue() != null ? tp1VolumeSpinner.getValue() : 0);
                defaults.put("tp2_percent", tp2PercentField.getText() != null && !tp2PercentField.getText().isEmpty() ? Double.parseDouble(tp2PercentField.getText()) : 0.0);
                defaults.put("tp2_volume", tp2VolumeSpinner.getValue() != null ? tp2VolumeSpinner.getValue() : 0);
                defaults.put("tp3_percent", tp3PercentField.getText() != null && !tp3PercentField.getText().isEmpty() ? Double.parseDouble(tp3PercentField.getText()) : 0.0);
                defaults.put("tp3_volume", tp3VolumeSpinner.getValue() != null ? tp3VolumeSpinner.getValue() : 0);
                defaults.put("tp4_percent", tp4PercentField.getText() != null && !tp4PercentField.getText().isEmpty() ? Double.parseDouble(tp4PercentField.getText()) : 0.0);
                defaults.put("tp4_volume", tp4VolumeSpinner.getValue() != null ? tp4VolumeSpinner.getValue() : 0);
                defaults.put("tp5_percent", tp5PercentField.getText() != null && !tp5PercentField.getText().isEmpty() ? Double.parseDouble(tp5PercentField.getText()) : 0.0);
                defaults.put("tp5_volume", tp5VolumeSpinner.getValue() != null ? tp5VolumeSpinner.getValue() : 0);
                defaults.put("tp6_percent", tp6PercentField.getText() != null && !tp6PercentField.getText().isEmpty() ? Double.parseDouble(tp6PercentField.getText()) : 0.0);
                defaults.put("tp6_volume", tp6VolumeSpinner.getValue() != null ? tp6VolumeSpinner.getValue() : 0);
                defaults.put("tp7_percent", tp7PercentField.getText() != null && !tp7PercentField.getText().isEmpty() ? Double.parseDouble(tp7PercentField.getText()) : 0.0);
                defaults.put("tp7_volume", tp7VolumeSpinner.getValue() != null ? tp7VolumeSpinner.getValue() : 0);
                defaults.put("commissions_enabled", commissionsEnabledCheckBox.isSelected());
                defaults.put("commission_type", commissionTypeCombo.getValue() != null ? commissionTypeCombo.getValue() : "No_Commissions");
                defaults.put("commission_value", commissionValueField.getText() != null && !commissionValueField.getText().isEmpty() ? Double.parseDouble(commissionValueField.getText()) : 0.0);
                defaults.put("disable_leapfrog", disableLeapfrogCheckBox.isSelected());
                defaults.put("smart_ts", smartTSCheckBox.isSelected());
                defaults.put("end_hour", endHourCombo.getValue() != null ? endHourCombo.getValue() : 23);
                defaults.put("end_minute", endMinuteCombo.getValue() != null ? endMinuteCombo.getValue() : 50);
                defaults.put("eod_enabled", eodEnabledCheckBox.isSelected());
                defaults.put("strong_thrust", strongThrustCheckBox.isSelected());
                defaults.put("orthodox_cc", orthodoxCCCheckBox.isSelected());
                defaults.put("all_day", allDayCheckBox.isSelected());
                return defaults;
            }
            return null;
        });
    }
}
