package com.tradelogic.ui;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Window;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Optional;

public class DateRangeDialog extends Dialog<DateRangeDialog.DateRange> {

    private DatePicker fromDatePicker;
    private DatePicker toDatePicker;

    public static class DateRange {
        public final long fromTimestamp;
        public final long toTimestamp;

        public DateRange(long fromTimestamp, long toTimestamp) {
            this.fromTimestamp = fromTimestamp;
            this.toTimestamp = toTimestamp;
        }
    }

    public DateRangeDialog(Window owner) {
        setTitle("Select Report Date Range");
        setHeaderText("Choose the date range for the trade history report");

        DialogPane dialogPane = getDialogPane();
        dialogPane.getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        fromDatePicker = new DatePicker();
        fromDatePicker.setValue(LocalDate.now().minusDays(30));
        fromDatePicker.setShowWeekNumbers(false);

        toDatePicker = new DatePicker();
        toDatePicker.setValue(LocalDate.now());
        toDatePicker.setShowWeekNumbers(false);

        grid.add(new Label("From Date:"), 0, 0);
        grid.add(fromDatePicker, 1, 0);
        grid.add(new Label("To Date:"), 0, 1);
        grid.add(toDatePicker, 1, 1);

        Button last7DaysButton = new Button("Last 7 Days");
        last7DaysButton.setOnAction(e -> {
            fromDatePicker.setValue(LocalDate.now().minusDays(7));
            toDatePicker.setValue(LocalDate.now());
        });

        Button last30DaysButton = new Button("Last 30 Days");
        last30DaysButton.setOnAction(e -> {
            fromDatePicker.setValue(LocalDate.now().minusDays(30));
            toDatePicker.setValue(LocalDate.now());
        });

        Button last90DaysButton = new Button("Last 90 Days");
        last90DaysButton.setOnAction(e -> {
            fromDatePicker.setValue(LocalDate.now().minusDays(90));
            toDatePicker.setValue(LocalDate.now());
        });

        Button allTimeButton = new Button("All Time");
        allTimeButton.setOnAction(e -> {
            fromDatePicker.setValue(LocalDate.of(2020, 1, 1));
            toDatePicker.setValue(LocalDate.now());
        });

        GridPane buttonGrid = new GridPane();
        buttonGrid.setHgap(5);
        buttonGrid.add(last7DaysButton, 0, 0);
        buttonGrid.add(last30DaysButton, 1, 0);
        buttonGrid.add(last90DaysButton, 2, 0);
        buttonGrid.add(allTimeButton, 3, 0);

        grid.add(new Label("Quick Select:"), 0, 2);
        grid.add(buttonGrid, 1, 2);

        dialogPane.setContent(grid);

        setResultConverter(dialogButton -> {
            if (dialogButton == ButtonType.OK) {
                LocalDate fromDate = fromDatePicker.getValue();
                LocalDate toDate = toDatePicker.getValue();

                if (fromDate != null && toDate != null) {
                    if (fromDate.isAfter(toDate)) {
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Invalid Date Range");
                        alert.setHeaderText("Start date cannot be after end date");
                        alert.showAndWait();
                        return null;
                    }

                    long fromTimestamp = fromDate.atStartOfDay(ZoneId.of("Europe/Athens")).toEpochSecond();
                    long toTimestamp = toDate.plusDays(1).atStartOfDay(ZoneId.of("Europe/Athens")).toEpochSecond() - 1;

                    return new DateRange(fromTimestamp, toTimestamp);
                }
            }
            return null;
        });

        if (owner != null) {
            initOwner(owner);
        }
    }
}
