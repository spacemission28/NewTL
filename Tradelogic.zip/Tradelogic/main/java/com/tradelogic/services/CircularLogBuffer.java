package com.tradelogic.services;

import javafx.application.Platform;
import javafx.scene.control.TextArea;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * High-performance circular buffer for console logging.
 * Maintains only the last N lines in UI while writing all logs to disk.
 * Solves the StringUTF16.putCharSB performance bottleneck.
 */
public class CircularLogBuffer {

    private static final int MAX_CONSOLE_LINES = 100;
    private static final int FLUSH_INTERVAL_MS = 1000;
    private static final DateTimeFormatter FILE_DATE_FORMAT = DateTimeFormatter.ofPattern("yyyyMMdd");
    private static final DateTimeFormatter LOG_TIMESTAMP_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    private final ConcurrentLinkedQueue<String> consoleBuffer = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<String> diskBuffer = new ConcurrentLinkedQueue<>();
    private final TextArea logArea;
    private final ScheduledExecutorService flushExecutor;
    private final AtomicBoolean isRunning = new AtomicBoolean(true);
    private final String logDirectory;

    private PrintWriter currentLogWriter;
    private String currentLogFile;

    /**
     * Constructor with custom market data path.
     */
    public CircularLogBuffer(TextArea logArea, String marketDataPath) {
        this.logArea = logArea;
        this.logDirectory = (marketDataPath != null && !marketDataPath.trim().isEmpty())
            ? marketDataPath
            : "market_data";
        this.flushExecutor = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "LogFlushThread");
            t.setDaemon(true);
            return t;
        });

        ensureLogDirectory();
        openLogFile();
        startFlushTask();
    }

    /**
     * Constructor with default market data path.
     */
    public CircularLogBuffer(TextArea logArea) {
        this(logArea, "market_data");
    }

    /**
     * Add a log message. This is thread-safe and non-blocking.
     */
    public void log(String message) {
        if (!isRunning.get()) return;

        String timestampedMessage = String.format("[%s] %s",
            LocalDateTime.now().format(LOG_TIMESTAMP_FORMAT),
            message);

        consoleBuffer.offer(timestampedMessage);
        diskBuffer.offer(timestampedMessage);

        while (consoleBuffer.size() > MAX_CONSOLE_LINES) {
            consoleBuffer.poll();
        }
    }

    /**
     * Starts the background flush task that updates UI and writes to disk.
     */
    private void startFlushTask() {
        flushExecutor.scheduleAtFixedRate(() -> {
            try {
                flushToDisk();
                updateUI();
            } catch (Throwable t) {
                // CRITICAL: Catch Throwable to prevent scheduler death
                System.err.println("CRITICAL ERROR in CircularLogBuffer: " + t.getClass().getName() + " - " + t.getMessage());
                t.printStackTrace(System.err);
            }
        }, FLUSH_INTERVAL_MS, FLUSH_INTERVAL_MS, TimeUnit.MILLISECONDS);
    }

    /**
     * Writes queued log messages to disk file.
     */
    private void flushToDisk() {
        if (diskBuffer.isEmpty()) return;

        checkLogFileRotation();

        if (currentLogWriter != null) {
            while (!diskBuffer.isEmpty()) {
                String message = diskBuffer.poll();
                if (message != null) {
                    currentLogWriter.println(message);
                }
            }
            currentLogWriter.flush();
        }
    }

    /**
     * Updates the UI with current console buffer contents.
     * This replaces all text at once instead of appending, which is much faster.
     */
    private void updateUI() {
        if (logArea == null) return;

        Platform.runLater(() -> {
            StringBuilder sb = new StringBuilder(consoleBuffer.size() * 100);
            for (String line : consoleBuffer) {
                sb.append(line).append('\n');
            }

            String currentText = logArea.getText();
            String newText = sb.toString();

            if (!currentText.equals(newText)) {
                logArea.setText(newText);
                logArea.setScrollTop(Double.MAX_VALUE);
            }
        });
    }

    /**
     * Ensures the log directory exists.
     */
    private void ensureLogDirectory() {
        File logDir = new File(logDirectory);
        if (!logDir.exists()) {
            logDir.mkdirs();
        }
    }

    /**
     * Opens a new log file for the current day.
     */
    private void openLogFile() {
        try {
            if (currentLogWriter != null) {
                currentLogWriter.close();
            }

            String dateStr = LocalDateTime.now().format(FILE_DATE_FORMAT);
            currentLogFile = String.format("%s/tradelogic_%s.log", logDirectory, dateStr);

            currentLogWriter = new PrintWriter(
                new BufferedWriter(new FileWriter(currentLogFile, true)),
                false
            );

            File logFile = new File(currentLogFile);
            System.out.println("Opened log file: " + logFile.getAbsolutePath());

        } catch (IOException e) {
            System.err.println("Failed to open log file: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Checks if we need to rotate to a new log file (daily rotation).
     */
    private void checkLogFileRotation() {
        String dateStr = LocalDateTime.now().format(FILE_DATE_FORMAT);
        String expectedFile = String.format("%s/tradelogic_%s.log", logDirectory, dateStr);

        if (!expectedFile.equals(currentLogFile)) {
            openLogFile();
        }
    }

    /**
     * Shuts down the logging system gracefully.
     */
    public void shutdown() {
        isRunning.set(false);

        flushExecutor.shutdown();
        try {
            if (!flushExecutor.awaitTermination(5, TimeUnit.SECONDS)) {
                flushExecutor.shutdownNow();
            }
        } catch (InterruptedException e) {
            flushExecutor.shutdownNow();
            Thread.currentThread().interrupt();
        }

        flushToDisk();

        if (currentLogWriter != null) {
            currentLogWriter.close();
            currentLogWriter = null;
        }
    }

    /**
     * Clears the console buffer (disk logs are preserved).
     */
    public void clearConsole() {
        consoleBuffer.clear();
        Platform.runLater(() -> {
            if (logArea != null) {
                logArea.clear();
            }
        });
    }

    /**
     * Returns the current log file path.
     */
    public String getCurrentLogFile() {
        return currentLogFile;
    }
}
