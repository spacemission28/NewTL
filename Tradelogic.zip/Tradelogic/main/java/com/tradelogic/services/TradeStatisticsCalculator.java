package com.tradelogic.services;

import com.tradelogic.models.TradeHistoryEntry;
import com.tradelogic.models.TradeStatistics;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class TradeStatisticsCalculator {

    public static TradeStatistics calculate(List<TradeHistoryEntry> trades, String accountName,
                                           String accountNumber, String company, double currentBalance) {
        TradeStatistics stats = new TradeStatistics();

        stats.setAccountName(accountName);
        stats.setAccountNumber(accountNumber);
        stats.setCompany(company);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm")
            .withZone(ZoneId.of("Europe/Athens"));
        stats.setReportDate(formatter.format(Instant.now()));

        if (trades == null || trades.isEmpty()) {
            stats.setBalance(currentBalance);
            stats.setEquity(currentBalance);
            return stats;
        }

        List<TradeHistoryEntry> profitTrades = new ArrayList<>();
        List<TradeHistoryEntry> lossTrades = new ArrayList<>();
        List<TradeHistoryEntry> shortTrades = new ArrayList<>();
        List<TradeHistoryEntry> longTrades = new ArrayList<>();

        double grossProfit = 0.0;
        double grossLoss = 0.0;
        double totalNetProfit = 0.0;

        for (TradeHistoryEntry trade : trades) {
            double netProfit = trade.getProfit() + trade.getSwap() + trade.getCommission();
            totalNetProfit += netProfit;

            if (netProfit > 0) {
                profitTrades.add(trade);
                grossProfit += netProfit;
            } else if (netProfit < 0) {
                lossTrades.add(trade);
                grossLoss += Math.abs(netProfit);
            }

            String orderType = trade.getOrderType();
            if ("BUY".equalsIgnoreCase(orderType)) {
                longTrades.add(trade);
            } else if ("SELL".equalsIgnoreCase(orderType)) {
                shortTrades.add(trade);
            }
        }

        stats.setTotalTrades(trades.size());
        stats.setTotalNetProfit(totalNetProfit);
        stats.setGrossProfit(grossProfit);
        stats.setGrossLoss(grossLoss);

        if (grossLoss > 0) {
            stats.setProfitFactor(grossProfit / grossLoss);
        } else {
            stats.setProfitFactor(grossProfit > 0 ? Double.POSITIVE_INFINITY : 0.0);
        }

        stats.setExpectedPayoff(trades.size() > 0 ? totalNetProfit / trades.size() : 0.0);

        stats.setProfitTrades(profitTrades.size());
        stats.setProfitTradesPercent(trades.size() > 0 ? (profitTrades.size() * 100.0 / trades.size()) : 0.0);

        stats.setLossTrades(lossTrades.size());
        stats.setLossTradesPercent(trades.size() > 0 ? (lossTrades.size() * 100.0 / trades.size()) : 0.0);

        stats.setShortTrades(shortTrades.size());
        int shortTradesWon = 0;
        for (TradeHistoryEntry trade : shortTrades) {
            double netProfit = trade.getProfit() + trade.getSwap() + trade.getCommission();
            if (netProfit > 0) shortTradesWon++;
        }
        stats.setShortTradesWon(shortTradesWon);
        stats.setShortTradesWonPercent(shortTrades.size() > 0 ? (shortTradesWon * 100.0 / shortTrades.size()) : 0.0);

        stats.setLongTrades(longTrades.size());
        int longTradesWon = 0;
        for (TradeHistoryEntry trade : longTrades) {
            double netProfit = trade.getProfit() + trade.getSwap() + trade.getCommission();
            if (netProfit > 0) longTradesWon++;
        }
        stats.setLongTradesWon(longTradesWon);
        stats.setLongTradesWonPercent(longTrades.size() > 0 ? (longTradesWon * 100.0 / longTrades.size()) : 0.0);

        if (!profitTrades.isEmpty()) {
            double maxProfit = Double.NEGATIVE_INFINITY;
            double sumProfit = 0.0;
            for (TradeHistoryEntry trade : profitTrades) {
                double netProfit = trade.getProfit() + trade.getSwap() + trade.getCommission();
                if (netProfit > maxProfit) maxProfit = netProfit;
                sumProfit += netProfit;
            }
            stats.setLargestProfitTrade(maxProfit);
            stats.setAverageProfitTrade(sumProfit / profitTrades.size());
        }

        if (!lossTrades.isEmpty()) {
            double maxLoss = Double.POSITIVE_INFINITY;
            double sumLoss = 0.0;
            for (TradeHistoryEntry trade : lossTrades) {
                double netProfit = trade.getProfit() + trade.getSwap() + trade.getCommission();
                if (netProfit < maxLoss) maxLoss = netProfit;
                sumLoss += netProfit;
            }
            stats.setLargestLossTrade(maxLoss);
            stats.setAverageLossTrade(sumLoss / lossTrades.size());
        }

        calculateConsecutiveStats(trades, stats);

        calculateDrawdown(trades, currentBalance, stats);

        stats.setBalance(currentBalance);
        stats.setEquity(currentBalance);

        if (stats.getBalanceDrawdownAbsolute() > 0) {
            stats.setRecoveryFactor(totalNetProfit / stats.getBalanceDrawdownAbsolute());
        } else {
            stats.setRecoveryFactor(totalNetProfit > 0 ? Double.POSITIVE_INFINITY : 0.0);
        }

        stats.setSharpeRatio(calculateSharpeRatio(trades));

        return stats;
    }

    private static void calculateConsecutiveStats(List<TradeHistoryEntry> trades, TradeStatistics stats) {
        if (trades.isEmpty()) return;

        int currentWinStreak = 0;
        int currentLossStreak = 0;
        double currentWinProfit = 0.0;
        double currentLossAmount = 0.0;

        int maxWinStreak = 0;
        int maxLossStreak = 0;
        double maxWinProfit = 0.0;
        double maxLossAmount = 0.0;

        int maxProfitCount = 0;
        double maxProfit = 0.0;
        int maxLossCount = 0;
        double maxLoss = 0.0;

        double currentMaxProfit = 0.0;
        int currentMaxProfitCount = 0;
        double currentMaxLoss = 0.0;
        int currentMaxLossCount = 0;

        int totalWinStreaks = 0;
        int winStreakCount = 0;
        int totalLossStreaks = 0;
        int lossStreakCount = 0;

        for (TradeHistoryEntry trade : trades) {
            double netProfit = trade.getProfit() + trade.getSwap() + trade.getCommission();

            if (netProfit > 0) {
                currentWinStreak++;
                currentWinProfit += netProfit;
                currentMaxProfitCount++;
                currentMaxProfit += netProfit;

                if (currentLossStreak > 0) {
                    if (currentLossStreak > maxLossStreak) {
                        maxLossStreak = currentLossStreak;
                        maxLossAmount = currentLossAmount;
                    }
                    totalLossStreaks += currentLossStreak;
                    lossStreakCount++;
                    currentLossStreak = 0;
                    currentLossAmount = 0.0;
                }

                if (currentMaxLoss < 0) {
                    if (currentMaxLoss < maxLoss) {
                        maxLoss = currentMaxLoss;
                        maxLossCount = currentMaxLossCount;
                    }
                    currentMaxLoss = 0.0;
                    currentMaxLossCount = 0;
                }
            } else if (netProfit < 0) {
                currentLossStreak++;
                currentLossAmount += netProfit;
                currentMaxLossCount++;
                currentMaxLoss += netProfit;

                if (currentWinStreak > 0) {
                    if (currentWinStreak > maxWinStreak) {
                        maxWinStreak = currentWinStreak;
                        maxWinProfit = currentWinProfit;
                    }
                    totalWinStreaks += currentWinStreak;
                    winStreakCount++;
                    currentWinStreak = 0;
                    currentWinProfit = 0.0;
                }

                if (currentMaxProfit > 0) {
                    if (currentMaxProfit > maxProfit) {
                        maxProfit = currentMaxProfit;
                        maxProfitCount = currentMaxProfitCount;
                    }
                    currentMaxProfit = 0.0;
                    currentMaxProfitCount = 0;
                }
            }
        }

        if (currentWinStreak > maxWinStreak) {
            maxWinStreak = currentWinStreak;
            maxWinProfit = currentWinProfit;
        }
        if (currentWinStreak > 0) {
            totalWinStreaks += currentWinStreak;
            winStreakCount++;
        }

        if (currentLossStreak > maxLossStreak) {
            maxLossStreak = currentLossStreak;
            maxLossAmount = currentLossAmount;
        }
        if (currentLossStreak > 0) {
            totalLossStreaks += currentLossStreak;
            lossStreakCount++;
        }

        if (currentMaxProfit > maxProfit) {
            maxProfit = currentMaxProfit;
            maxProfitCount = currentMaxProfitCount;
        }

        if (currentMaxLoss < maxLoss) {
            maxLoss = currentMaxLoss;
            maxLossCount = currentMaxLossCount;
        }

        stats.setMaxConsecutiveWins(maxWinStreak);
        stats.setMaxConsecutiveWinsProfit(maxWinProfit);
        stats.setMaxConsecutiveLosses(maxLossStreak);
        stats.setMaxConsecutiveLossesLoss(maxLossAmount);

        stats.setMaxConsecutiveProfitCount(maxProfitCount);
        stats.setMaxConsecutiveProfit(maxProfit);
        stats.setMaxConsecutiveLossCount(maxLossCount);
        stats.setMaxConsecutiveLoss(maxLoss);

        stats.setAverageConsecutiveWins(winStreakCount > 0 ? totalWinStreaks / winStreakCount : 0);
        stats.setAverageConsecutiveLosses(lossStreakCount > 0 ? totalLossStreaks / lossStreakCount : 0);
    }

    private static void calculateDrawdown(List<TradeHistoryEntry> trades, double currentBalance, TradeStatistics stats) {
        if (trades.isEmpty()) {
            stats.setBalanceDrawdownAbsolute(0.0);
            stats.setBalanceDrawdownMax(0.0);
            stats.setBalanceDrawdownMaxPercent(0.0);
            return;
        }

        double startingBalance = currentBalance;
        for (TradeHistoryEntry trade : trades) {
            double netProfit = trade.getProfit() + trade.getSwap() + trade.getCommission();
            startingBalance -= netProfit;
        }

        double peak = startingBalance;
        double maxDrawdown = 0.0;
        double maxDrawdownPercent = 0.0;
        double currentBalance2 = startingBalance;

        for (TradeHistoryEntry trade : trades) {
            double netProfit = trade.getProfit() + trade.getSwap() + trade.getCommission();
            currentBalance2 += netProfit;

            if (currentBalance2 > peak) {
                peak = currentBalance2;
            }

            double drawdown = peak - currentBalance2;
            if (drawdown > maxDrawdown) {
                maxDrawdown = drawdown;
                maxDrawdownPercent = peak > 0 ? (drawdown / peak) * 100.0 : 0.0;
            }
        }

        stats.setBalanceDrawdownAbsolute(maxDrawdown);
        stats.setBalanceDrawdownMax(maxDrawdown);
        stats.setBalanceDrawdownMaxPercent(maxDrawdownPercent);
        stats.setBalanceDrawdownRelative(maxDrawdown);
        stats.setBalanceDrawdownRelativePercent(maxDrawdownPercent);
        stats.setBalanceDrawdown(maxDrawdown);
    }

    private static double calculateSharpeRatio(List<TradeHistoryEntry> trades) {
        if (trades.isEmpty()) return 0.0;

        double mean = 0.0;
        for (TradeHistoryEntry trade : trades) {
            double netProfit = trade.getProfit() + trade.getSwap() + trade.getCommission();
            mean += netProfit;
        }
        mean /= trades.size();

        double variance = 0.0;
        for (TradeHistoryEntry trade : trades) {
            double netProfit = trade.getProfit() + trade.getSwap() + trade.getCommission();
            double diff = netProfit - mean;
            variance += diff * diff;
        }
        variance /= trades.size();

        double stdDev = Math.sqrt(variance);

        if (stdDev == 0) return 0.0;

        return mean / stdDev;
    }
}
