package com.tradelogic.services;

import com.tradelogic.Logger;
import com.tradelogic.models.MarketBarData;
import com.tradelogic.models.TickData;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Manages automatic purging of old market data to prevent memory growth.
 *
 * Retention Policy:
 * - Tick data: Last 1000 ticks per symbol (~5 minutes at 1 tick/300ms)
 * - Candles ≤H1: 24 hours
 * - Candles >H1: 7 days
 */
public class DataPurgeManager {
    private static final long PURGE_INTERVAL_MINUTES = 15;

    private static final int MAX_TICKS_PER_SYMBOL = 1000;
    private static final long MAX_CANDLE_AGE_MINUTES_SHORT = 24 * 60;
    private static final long MAX_CANDLE_AGE_MINUTES_LONG = 7 * 24 * 60;

    private static final String[] SHORT_TIMEFRAMES = {"M1", "M5", "M15", "M30", "H1"};

    private final ConcurrentHashMap<String, TickData> tickData;
    private final ConcurrentHashMap<String, MarketBarData> ohlcData;
    private final ScheduledExecutorService scheduler;

    public DataPurgeManager(
        ConcurrentHashMap<String, TickData> tickData,
        ConcurrentHashMap<String, MarketBarData> ohlcData
    ) {
        this.tickData = tickData;
        this.ohlcData = ohlcData;
        this.scheduler = Executors.newScheduledThreadPool(1, r -> {
            Thread t = new Thread(r, "data-purge-manager");
            t.setDaemon(true);
            return t;
        });
    }

    /**
     * Start automatic data purging
     */
    public void start() {
        scheduler.scheduleAtFixedRate(
            this::purgeOldData,
            PURGE_INTERVAL_MINUTES,
            PURGE_INTERVAL_MINUTES,
            TimeUnit.MINUTES
        );
        Logger.info("DataPurgeManager started (purge every " + PURGE_INTERVAL_MINUTES + " minutes)");
    }

    /**
     * Stop automatic data purging
     */
    public void stop() {
        scheduler.shutdown();
        Logger.info("DataPurgeManager stopped");
    }

    /**
     * Perform purge operation with bulletproof exception handling
     */
    private void purgeOldData() {
        try {
            int purgedTicks = purgeTicks();
            int purgedCandles = purgeCandles();

            if (purgedTicks > 0 || purgedCandles > 0) {
                Logger.info(String.format(
                    "Data purge complete: %d ticks, %d candles removed (Mem: %dMB used / %dMB max)",
                    purgedTicks,
                    purgedCandles,
                    (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / (1024 * 1024),
                    Runtime.getRuntime().maxMemory() / (1024 * 1024)
                ));
            }
        } catch (Throwable t) {
            // CRITICAL: Catch Throwable (not just Exception) to prevent scheduler death
            String errorMsg = "CRITICAL ERROR in DataPurgeManager: " + t.getClass().getName() + " - " + t.getMessage();

            // Try to log normally
            try {
                Logger.error(errorMsg);
            } catch (Throwable logError) {
                // If Logger fails, write to System.err as last resort
                System.err.println(errorMsg);
                t.printStackTrace(System.err);
            }

            // Log full stack trace for debugging
            t.printStackTrace(System.err);
        }
    }

    /**
     * Purge old ticks based on count limit per symbol
     */
    private int purgeTicks() {
        Map<String, Integer> symbolCounts = new ConcurrentHashMap<>();

        for (String key : tickData.keySet()) {
            String symbol = extractSymbol(key);
            symbolCounts.merge(symbol, 1, Integer::sum);
        }

        int purged = 0;
        for (Map.Entry<String, Integer> entry : symbolCounts.entrySet()) {
            String symbol = entry.getKey();
            int count = entry.getValue();

            if (count > MAX_TICKS_PER_SYMBOL) {
                int toRemove = count - MAX_TICKS_PER_SYMBOL;
                purged += removeOldestTicks(symbol, toRemove);
            }
        }

        return purged;
    }

    /**
     * Purge old candles based on timeframe retention policy
     */
    private int purgeCandles() {
        long now = System.currentTimeMillis();
        int purged = 0;

        for (Map.Entry<String, MarketBarData> entry : ohlcData.entrySet()) {
            String key = entry.getKey();
            MarketBarData candle = entry.getValue();

            String timeframe = extractTimeframe(key);
            long maxAge = isShortTimeframe(timeframe) ?
                MAX_CANDLE_AGE_MINUTES_SHORT : MAX_CANDLE_AGE_MINUTES_LONG;

            long ageMinutes = (now - candle.getCloseTime()) / (60 * 1000);

            if (ageMinutes > maxAge) {
                ohlcData.remove(key);
                purged++;
            }
        }

        return purged;
    }

    /**
     * Remove oldest ticks for a symbol
     */
    private int removeOldestTicks(String symbol, int count) {
        return tickData.entrySet().stream()
            .filter(entry -> extractSymbol(entry.getKey()).equals(symbol))
            .sorted((e1, e2) -> Long.compare(e1.getValue().getTimestampSeconds(), e2.getValue().getTimestampSeconds()))
            .limit(count)
            .mapToInt(entry -> {
                tickData.remove(entry.getKey());
                return 1;
            })
            .sum();
    }

    /**
     * Extract symbol from key (format: "EURUSD_timestamp" or "EURUSD_M5_timestamp")
     */
    private String extractSymbol(String key) {
        int firstUnderscore = key.indexOf('_');
        return firstUnderscore > 0 ? key.substring(0, firstUnderscore) : key;
    }

    /**
     * Extract timeframe from key (format: "EURUSD_M5_timestamp")
     */
    private String extractTimeframe(String key) {
        String[] parts = key.split("_");
        return parts.length >= 2 ? parts[1] : "";
    }

    /**
     * Check if timeframe is short-term (≤H1)
     */
    private boolean isShortTimeframe(String timeframe) {
        for (String shortTf : SHORT_TIMEFRAMES) {
            if (shortTf.equals(timeframe)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Get current data statistics
     */
    public String getStats() {
        return String.format(
            "Ticks: %d | Candles: %d | Memory: %dMB / %dMB",
            tickData.size(),
            ohlcData.size(),
            (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / (1024 * 1024),
            Runtime.getRuntime().maxMemory() / (1024 * 1024)
        );
    }
}
