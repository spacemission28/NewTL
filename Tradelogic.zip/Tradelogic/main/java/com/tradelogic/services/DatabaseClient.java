package com.tradelogic.services;

import com.tradelogic.models.RobotConfig;
import com.tradelogic.models.TradeCommand;
import java.util.List;
import java.util.Map;

public interface DatabaseClient {
    void upsertRobotConfig(String userId, RobotConfig config) throws Exception;
    List<RobotConfig> loadRobotConfigs(String userId) throws Exception;
    void saveDefaultValues(String userId, Map<String, Object> defaults) throws Exception;
    Map<String, Object> loadDefaultValues(String userId) throws Exception;
    void deleteRobotConfigs(String userId, List<Integer> robotNumbers) throws Exception;

    List<com.tradelogic.models.MarketBarData> getRecentCompletedBars(String symbol, String timeframe, int count) throws Exception;
    double getLatestBid(String symbol) throws Exception;
    double getLatestAsk(String symbol) throws Exception;
    long getLatestTickTimestamp() throws Exception;
    void insertTradeCommand(TradeCommand command) throws Exception;
    void close();
}
